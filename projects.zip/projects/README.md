# 网址导航系统

基于 Spring Boot 3 + Vue 3 的一站式网址导航系统，提供简洁高效的网址管理和访问体验。

## 项目结构

```
projects/
├── service-qm/          # 后端服务 (Spring Boot 3)
│   ├── sql/            # 数据库初始化脚本
│   ├── src/main/java/  # Java 源代码
│   └── pom.xml         # Maven 配置
│
└── web-qm/             # 前端项目 (Vue 3)
    ├── src/            # 源代码
    └── package.json    # npm 配置
```

## 技术栈

### 后端
- Spring Boot 3.2
- MyBatis Plus
- MySQL 8.0
- JDK 21
- Knife4j (API 文档)

### 前端
- Vue 3
- Vite
- Element Plus
- Tailwind CSS
- GSAP (动画)
- Axios

## 快速开始

### 1. 数据库配置

1. 创建 MySQL 数据库并执行初始化脚本：

```bash
mysql -u root -p < service-qm/sql/init.sql
```

2. 修改数据库连接配置 `service-qm/src/main/resources/application.yml`：

```yaml
spring:
  datasource:
    url: jdbc:mysql://localhost:3306/nav_system
    username: root
    password: your_password
```

### 2. 启动后端服务

```bash
cd service-qm
mvn spring-boot:run
```

后端服务将在 http://localhost:8080 启动

API 文档地址：http://localhost:8080/doc.html

### 3. 启动前端项目

```bash
cd web-qm
npm install
npm run dev
```

前端服务将在 http://localhost:3000 启动

## 功能特性

- ✅ 网址分类管理 - 多级分类展示网址
- ✅ 自定义工作台 - 个性化收藏常用网址
- ✅ 智能搜索 - 支持网址搜索和多搜索引擎
- ✅ 热门推荐 - 基于点击量的热门网址
- ✅ 深色模式 - 护眼的深色主题
- ✅ 响应式设计 - 适配各种屏幕尺寸
- ✅ 流畅动画 - GSAP 驱动的动画效果

## API 接口

| 接口 | 方法 | 说明 |
|------|------|------|
| `/api/categories` | GET | 获取分类列表 |
| `/api/categories/{id}` | GET | 获取分类详情 |
| `/api/categories/all` | GET | 获取所有分类及内容 |
| `/api/websites/hot` | GET | 获取热门网站 |
| `/api/search` | GET | 搜索网站 |
| `/api/workspace/{userId}` | GET | 获取用户工作台 |
| `/api/workspace` | POST | 添加到工作台 |
| `/api/config` | GET | 获取系统配置 |

## 页面路由

| 路径 | 页面 |
|------|------|
| `/` | 首页 |
| `/category/:id` | 分类详情页 |
| `/customize` | 自定义工作台 |
| `/hot` | 热门网址 |
| `/search` | 搜索结果 |
| `/about` | 关于页面 |

## 生产构建

### 后端

```bash
cd service-qm
mvn clean package -DskipTests
java -jar target/service-qm-1.0-SNAPSHOT.jar
```

### 前端

```bash
cd web-qm
npm run build
```

构建产物在 `dist/` 目录

## License

MIT

