# 网址导航系统

基于 Spring Boot 3 + Spring Cloud Gateway + Vue 3 的一站式网址导航系统，采用微服务架构。

## 项目结构

```
projects/
├── service-qm/              # 后端服务 (Spring Boot 3 多模块)
│   ├── pom.xml             # 父模块 POM
│   ├── common/             # 公共模块
│   │   └── src/main/java/com/yinwang/common/
│   │       ├── result/     # 统一响应结果
│   │       ├── exception/  # 全局异常处理
│   │       ├── constant/   # 常量定义
│   │       ├── entity/     # 基础实体
│   │       └── util/       # 工具类
│   ├── nav-service/        # 核心业务服务 (端口: 8081)
│   │   └── src/main/java/com/yinwang/nav/
│   │       ├── entity/     # 实体类
│   │       ├── mapper/     # MyBatis Mapper
│   │       ├── service/    # 服务层
│   │       ├── controller/ # 控制器
│   │       └── config/     # 配置类
│   ├── gateway/            # API网关 (端口: 8080)
│   │   └── src/main/java/com/yinwang/gateway/
│   │       ├── config/     # 网关配置
│   │       ├── filter/     # 全局过滤器
│   │       └── handler/    # 异常/降级处理
│   └── sql/                # 数据库脚本
│
└── web-qm/                 # 前端项目 (Vue 3)
    └── src/
        ├── api/            # API接口
        ├── components/     # 组件
        ├── views/          # 页面
        ├── stores/         # 状态管理
        └── router/         # 路由
```

## 技术栈

### 后端
| 模块 | 技术 | 说明 |
|------|------|------|
| 父模块 | Maven | 依赖版本管理 |
| common | - | 公共工具、异常处理、响应封装 |
| nav-service | Spring Boot 3.2 | 核心业务API |
| nav-service | MyBatis Plus | ORM框架 |
| nav-service | MySQL 8.0 | 关系型数据库 |
| nav-service | Knife4j | API文档 |
| gateway | Spring Cloud Gateway | API网关 |
| gateway | Resilience4j | 熔断降级 |

### 前端
- Vue 3 + Vue Router + Pinia
- Element Plus
- Tailwind CSS
- GSAP (动画)
- Axios

## 系统架构

```
                    ┌─────────────────┐
                    │   Vue 3 前端    │
                    │   (Port: 3000)  │
                    └────────┬────────┘
                             │
                             ▼
                    ┌─────────────────┐
                    │ Spring Cloud    │
                    │    Gateway      │
                    │  (Port: 8080)   │
                    └────────┬────────┘
                             │
        ┌────────────────────┼────────────────────┐
        │                    │                    │
        ▼                    ▼                    ▼
┌───────────────┐   ┌───────────────┐   ┌───────────────┐
│  nav-service  │   │   (预留)      │   │   (预留)      │
│ (Port: 8081)  │   │ user-service  │   │ other-service │
└───────┬───────┘   └───────────────┘   └───────────────┘
        │
        ▼
┌───────────────┐
│    MySQL      │
│  nav_system   │
└───────────────┘
```

## 网关功能

- **路由转发**: 将 `/api/**` 请求转发到 nav-service
- **跨域处理**: 统一处理CORS
- **请求日志**: 记录请求日志和响应时间
- **熔断降级**: 服务不可用时返回友好提示
- **限流**: 支持基于Redis的请求限流（可选）
- **认证预留**: 预留身份认证过滤器

## 快速开始

### 1. 初始化数据库

```bash
mysql -u root -p < service-qm/sql/init.sql
```

### 2. 修改数据库配置

编辑 `service-qm/nav-service/src/main/resources/application.yml`

```yaml
spring:
  datasource:
    url: jdbc:mysql://localhost:3306/nav_system
    username: root
    password: your_password
```

### 3. 编译项目

```bash
cd service-qm
mvn clean install -DskipTests
```

### 4. 启动服务

**方式一：分别启动**

```bash
# 1. 启动核心业务服务 (8081)
cd nav-service
mvn spring-boot:run

# 2. 启动网关服务 (8080)
cd ../gateway
mvn spring-boot:run
```

**方式二：使用JAR包**

```bash
# 1. 启动核心业务服务
java -jar nav-service/target/nav-service-1.0-SNAPSHOT.jar

# 2. 启动网关服务
java -jar gateway/target/gateway-1.0-SNAPSHOT.jar
```

### 5. 启动前端

```bash
cd web-qm
npm install
npm run dev
```

## 访问地址

| 服务 | 地址 | 说明 |
|------|------|------|
| 前端 | http://localhost:3000 | Vue应用 |
| 网关 | http://localhost:8080 | API入口 |
| 业务服务 | http://localhost:8081 | 直接访问 |
| API文档 | http://localhost:8081/doc.html | Knife4j文档 |

## API接口

所有API通过网关访问 (http://localhost:8080)

| 接口 | 方法 | 说明 |
|------|------|------|
| `/api/categories` | GET | 获取分类列表 |
| `/api/categories/{id}` | GET | 获取分类详情 |
| `/api/categories/all` | GET | 获取所有分类及内容 |
| `/api/websites/hot` | GET | 获取热门网站 |
| `/api/search` | GET | 搜索网站 |
| `/api/workspace/{userId}` | GET | 获取用户工作台 |
| `/api/config` | GET | 获取系统配置 |

## 扩展说明

### 添加新服务

1. 在 `service-qm` 下创建新模块
2. 在父 `pom.xml` 中添加模块
3. 在 `gateway/src/main/resources/application.yml` 中添加路由规则

### 启用Redis限流

1. 安装并启动Redis
2. 在 `gateway/pom.xml` 中取消 `spring-boot-starter-data-redis-reactive` 的 optional
3. 在 `application.yml` 中添加Redis配置

```yaml
spring:
  redis:
    host: localhost
    port: 6379
```

## License

MIT
