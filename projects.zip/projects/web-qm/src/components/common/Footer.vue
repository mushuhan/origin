<template>
  <footer class="footer">
    <div class="footer-content">
      <div class="footer-main">
        <div class="footer-brand">
          <div class="brand-logo">
            <el-icon :size="24"><Compass /></el-icon>
          </div>
          <div class="brand-info">
            <div class="brand-name">{{ appStore.siteConfig.site_name || '网址导航' }}</div>
            <div class="brand-desc">{{ appStore.siteConfig.site_description || '一站式网址导航系统' }}</div>
          </div>
        </div>
        
        <div class="footer-links">
          <router-link 
            v-for="link in footerLinks" 
            :key="link.name"
            :to="link.url"
            class="footer-link"
          >
            {{ link.name }}
          </router-link>
        </div>
        
        <div class="footer-social">
          <a 
            v-for="social in socialLinks" 
            :key="social.name"
            :href="social.url"
            target="_blank"
            rel="noopener noreferrer"
            class="social-link"
          >
            <el-icon :size="18">
              <component :is="getSocialIcon(social.icon)" />
            </el-icon>
          </a>
        </div>
      </div>
      
      <div class="footer-bottom">
        <div class="copyright">{{ appStore.siteConfig.copyright || '© 2024 网址导航 All Rights Reserved' }}</div>
      </div>
    </div>
  </footer>
</template>

<script setup>
import { computed } from 'vue'
import { useAppStore } from '@/stores/app'
import { Compass, Link as LinkIcon } from '@element-plus/icons-vue'

const appStore = useAppStore()

const footerLinks = computed(() => {
  return appStore.siteConfig.footer_links || [
    { name: '关于我们', url: '/about' },
    { name: '联系我们', url: '/about' },
    { name: '使用条款', url: '/about' }
  ]
})

const socialLinks = computed(() => {
  return appStore.siteConfig.social_links || []
})

const getSocialIcon = (iconName) => {
  // 简化处理，统一使用链接图标
  return LinkIcon
}
</script>

<style lang="scss" scoped>
.footer {
  background: #f8f9fa;
  border-top: 1px solid #f0f0f0;
  margin-top: auto;
}

.dark .footer {
  background: #141414;
  border-top-color: #2a2a2a;
}

.footer-content {
  max-width: 1200px;
  margin: 0 auto;
  padding: 40px 32px 24px;
}

.footer-main {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  flex-wrap: wrap;
  gap: 32px;
  padding-bottom: 24px;
  border-bottom: 1px solid #f0f0f0;
}

.dark .footer-main {
  border-bottom-color: #2a2a2a;
}

.footer-brand {
  display: flex;
  align-items: center;
  gap: 12px;
}

.brand-logo {
  width: 44px;
  height: 44px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
}

.brand-name {
  font-size: 16px;
  font-weight: 600;
  color: #333;
}

.dark .brand-name {
  color: #e5e5e5;
}

.brand-desc {
  font-size: 12px;
  color: #999;
  margin-top: 2px;
}

.footer-links {
  display: flex;
  align-items: center;
  gap: 24px;
}

.footer-link {
  font-size: 14px;
  color: #666;
  text-decoration: none;
  transition: color 0.2s ease;
  
  &:hover {
    color: #667eea;
  }
}

.dark .footer-link {
  color: #a3a3a3;
  
  &:hover {
    color: #818cf8;
  }
}

.footer-social {
  display: flex;
  align-items: center;
  gap: 12px;
}

.social-link {
  width: 36px;
  height: 36px;
  border-radius: 8px;
  background: #e5e5e5;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #666;
  transition: all 0.2s ease;
  
  &:hover {
    background: #667eea;
    color: white;
  }
}

.dark .social-link {
  background: #2a2a2a;
  color: #a3a3a3;
  
  &:hover {
    background: #818cf8;
    color: white;
  }
}

.footer-bottom {
  padding-top: 24px;
  text-align: center;
}

.copyright {
  font-size: 13px;
  color: #999;
}

@media (max-width: 768px) {
  .footer-content {
    padding: 32px 16px 20px;
  }
  
  .footer-main {
    flex-direction: column;
    align-items: center;
    text-align: center;
  }
  
  .footer-brand {
    flex-direction: column;
  }
  
  .footer-links {
    flex-wrap: wrap;
    justify-content: center;
  }
}
</style>

