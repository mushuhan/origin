<template>
  <aside 
    :class="[
      'sidebar',
      { collapsed: collapsed }
    ]"
  >
    <!-- Logo区域 -->
    <div class="sidebar-logo">
      <div class="logo-icon">
        <el-icon :size="28"><Compass /></el-icon>
      </div>
      <transition name="fade">
        <span v-show="!collapsed" class="logo-text">网址导航</span>
      </transition>
    </div>
    
    <!-- 导航菜单 -->
    <nav class="sidebar-nav">
      <div class="nav-group">
        <div class="nav-group-title" v-show="!collapsed">快捷入口</div>
        
        <router-link 
          to="/customize" 
          :class="['nav-item', { active: $route.path === '/customize' }]"
          @click="handleNavClick"
        >
          <el-icon :size="20"><Briefcase /></el-icon>
          <span v-show="!collapsed">自定义工作台</span>
        </router-link>
        
        <router-link 
          to="/hot" 
          :class="['nav-item', { active: $route.path === '/hot' }]"
          @click="handleNavClick"
        >
          <el-icon :size="20"><TrendCharts /></el-icon>
          <span v-show="!collapsed">热门网址</span>
        </router-link>
      </div>
      
      <div class="nav-group">
        <div class="nav-group-title" v-show="!collapsed">网址分类</div>
        
        <router-link 
          v-for="(category, index) in displayCategories" 
          :key="category.id"
          :to="`/category/${category.id}`" 
          :class="['nav-item', { active: $route.path === `/category/${category.id}` }]"
          :style="{ animationDelay: `${index * 0.05}s` }"
          @click="handleNavClick"
        >
          <el-icon :size="20">
            <component :is="getCategoryIcon(category.icon)" />
          </el-icon>
          <span v-show="!collapsed">{{ category.name }}</span>
        </router-link>
      </div>
    </nav>
    
    <!-- 底部操作 -->
    <div class="sidebar-footer">
      <button class="collapse-btn" @click="$emit('toggle')">
        <el-icon :size="18">
          <component :is="collapsed ? 'Expand' : 'Fold'" />
        </el-icon>
      </button>
    </div>
  </aside>
</template>

<script setup>
import { computed, onMounted } from 'vue'
import { useNavStore } from '@/stores/nav'
import { 
  Compass, Briefcase, TrendCharts, Expand, Fold,
  Star, Document, Cpu, Brush, Lightning, 
  Reading, Headset, Tickets, Grid
} from '@element-plus/icons-vue'

const props = defineProps({
  collapsed: {
    type: Boolean,
    default: false
  }
})

const emit = defineEmits(['toggle'])

const navStore = useNavStore()

// 过滤掉第一个"自定义工作台"分类
const displayCategories = computed(() => {
  return navStore.categories.filter(c => c.id !== 1)
})

// 获取分类图标
const getCategoryIcon = (iconName) => {
  const iconMap = {
    'Star': Star,
    'Code': Cpu,
    'Palette': Brush,
    'Zap': Lightning,
    'GraduationCap': Reading,
    'Music': Headset,
    'Newspaper': Tickets,
    'Briefcase': Briefcase
  }
  return iconMap[iconName] || Grid
}

const handleNavClick = () => {
  // 移动端点击后关闭侧边栏
  if (window.innerWidth <= 768) {
    emit('toggle')
  }
}

onMounted(() => {
  navStore.fetchCategories()
})
</script>

<style lang="scss" scoped>
.sidebar {
  position: fixed;
  left: 0;
  top: 0;
  height: 100vh;
  width: var(--sidebar-width);
  background: white;
  border-right: 1px solid #f0f0f0;
  display: flex;
  flex-direction: column;
  transition: width var(--transition-duration);
  z-index: 50;
  overflow: hidden;
  
  &.collapsed {
    width: var(--sidebar-collapsed-width);
    
    .nav-item {
      justify-content: center;
      padding: 12px;
    }
  }
}

.dark .sidebar {
  background: #1a1a1a;
  border-right-color: #2a2a2a;
}

.sidebar-logo {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 20px;
  border-bottom: 1px solid #f0f0f0;
  
  .logo-icon {
    width: 40px;
    height: 40px;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    flex-shrink: 0;
  }
  
  .logo-text {
    font-size: 18px;
    font-weight: 600;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    white-space: nowrap;
  }
}

.dark .sidebar-logo {
  border-bottom-color: #2a2a2a;
}

.sidebar-nav {
  flex: 1;
  overflow-y: auto;
  padding: 16px 12px;
}

.nav-group {
  margin-bottom: 24px;
  
  &:last-child {
    margin-bottom: 0;
  }
}

.nav-group-title {
  font-size: 12px;
  color: #999;
  padding: 0 12px;
  margin-bottom: 8px;
  text-transform: uppercase;
  letter-spacing: 0.5px;
}

.dark .nav-group-title {
  color: #666;
}

.nav-item {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 12px 16px;
  border-radius: 12px;
  color: #666;
  text-decoration: none;
  transition: all 0.2s ease;
  margin-bottom: 4px;
  animation: slideInLeft 0.3s ease-out both;
  
  span {
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  
  &:hover {
    background: #f5f5f5;
    color: #333;
  }
  
  &.active {
    background: linear-gradient(135deg, rgba(102, 126, 234, 0.1) 0%, rgba(118, 75, 162, 0.1) 100%);
    color: #667eea;
    
    .el-icon {
      color: #667eea;
    }
  }
}

.dark .nav-item {
  color: #a3a3a3;
  
  &:hover {
    background: #2a2a2a;
    color: #e5e5e5;
  }
  
  &.active {
    background: rgba(102, 126, 234, 0.15);
    color: #818cf8;
    
    .el-icon {
      color: #818cf8;
    }
  }
}

.sidebar-footer {
  padding: 16px;
  border-top: 1px solid #f0f0f0;
  
  .collapse-btn {
    width: 100%;
    height: 40px;
    border: none;
    background: #f5f5f5;
    border-radius: 10px;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #666;
    transition: all 0.2s ease;
    
    &:hover {
      background: #eee;
      color: #333;
    }
  }
}

.dark .sidebar-footer {
  border-top-color: #2a2a2a;
  
  .collapse-btn {
    background: #2a2a2a;
    color: #a3a3a3;
    
    &:hover {
      background: #3a3a3a;
      color: #e5e5e5;
    }
  }
}

@keyframes slideInLeft {
  from {
    opacity: 0;
    transform: translateX(-10px);
  }
  to {
    opacity: 1;
    transform: translateX(0);
  }
}

@media (max-width: 768px) {
  .sidebar {
    transform: translateX(-100%);
    
    &:not(.collapsed) {
      transform: translateX(0);
      width: 280px;
    }
  }
}
</style>

