<template>
  <header :class="['header', { collapsed: collapsed }]">
    <div class="header-left">
      <!-- 移动端菜单按钮 -->
      <button class="menu-btn md-hidden" @click="$emit('toggle-sidebar')">
        <el-icon :size="22"><Menu /></el-icon>
      </button>
      
      <!-- 搜索框 -->
      <div class="search-box">
        <el-popover
          :visible="showSearchPopover"
          placement="bottom-start"
          :width="400"
          trigger="manual"
          :show-arrow="false"
          popper-class="search-popover"
        >
          <template #reference>
            <div class="search-input-wrapper">
              <el-icon class="search-icon"><Search /></el-icon>
              <input
                v-model="searchKeyword"
                type="text"
                placeholder="搜索网址或输入URL直接访问..."
                class="search-input"
                @focus="handleSearchFocus"
                @blur="handleSearchBlur"
                @keydown.enter="handleSearch"
                @input="handleSearchInput"
              />
              <el-dropdown v-if="navStore.searchEngines.length" trigger="click" @command="handleEngineChange">
                <span class="engine-selector">
                  {{ currentEngine?.name || '百度' }}
                  <el-icon><ArrowDown /></el-icon>
                </span>
                <template #dropdown>
                  <el-dropdown-menu>
                    <el-dropdown-item 
                      v-for="engine in navStore.searchEngines" 
                      :key="engine.id"
                      :command="engine"
                    >
                      {{ engine.name }}
                    </el-dropdown-item>
                  </el-dropdown-menu>
                </template>
              </el-dropdown>
            </div>
          </template>
          
          <!-- 搜索建议 -->
          <div class="search-suggestions">
            <div v-if="searchResults.length" class="suggestion-section">
              <div class="suggestion-title">搜索结果</div>
              <div 
                v-for="website in searchResults" 
                :key="website.id"
                class="suggestion-item"
                @mousedown.prevent="goToWebsite(website)"
              >
                <img 
                  v-if="website.icon" 
                  :src="website.icon" 
                  class="suggestion-icon"
                  @error="handleIconError"
                />
                <div v-else class="suggestion-icon placeholder">
                  {{ website.name.charAt(0) }}
                </div>
                <div class="suggestion-info">
                  <div class="suggestion-name">{{ website.name }}</div>
                  <div class="suggestion-url">{{ website.url }}</div>
                </div>
              </div>
            </div>
            
            <div v-else-if="hotSearches.length && !searchKeyword" class="suggestion-section">
              <div class="suggestion-title">热门搜索</div>
              <div class="hot-tags">
                <span 
                  v-for="(hot, index) in hotSearches" 
                  :key="hot.id"
                  class="hot-tag"
                  @mousedown.prevent="searchKeyword = hot.keyword; handleSearch()"
                >
                  <span class="hot-index" :class="{ top: index < 3 }">{{ index + 1 }}</span>
                  {{ hot.keyword }}
                </span>
              </div>
            </div>
            
            <div v-else-if="searchKeyword && !searchResults.length" class="no-result">
              <el-icon :size="32"><SearchOff /></el-icon>
              <p>未找到相关网址，按回车使用搜索引擎搜索</p>
            </div>
          </div>
        </el-popover>
      </div>
    </div>
    
    <div class="header-right">
      <!-- 当前时间 -->
      <div class="time-display">
        <div class="time">{{ currentTime }}</div>
        <div class="date">{{ currentDate }}</div>
      </div>
      
      <!-- 操作按钮 -->
      <div class="header-actions">
        <el-tooltip content="首页" placement="bottom">
          <button class="action-btn" @click="$router.push('/')">
            <el-icon :size="20"><HomeFilled /></el-icon>
          </button>
        </el-tooltip>
        
        <el-tooltip :content="isDark ? '浅色模式' : '深色模式'" placement="bottom">
          <button class="action-btn" @click="$emit('toggle-dark')">
            <el-icon :size="20">
              <component :is="isDark ? 'Sunny' : 'Moon'" />
            </el-icon>
          </button>
        </el-tooltip>
        
        <el-tooltip content="设置" placement="bottom">
          <button class="action-btn">
            <el-icon :size="20"><Setting /></el-icon>
          </button>
        </el-tooltip>
      </div>
    </div>
  </header>
</template>

<script setup>
import { ref, computed, onMounted, onUnmounted } from 'vue'
import { useRouter } from 'vue-router'
import { useAppStore } from '@/stores/app'
import { useNavStore } from '@/stores/nav'
import { searchWebsites, getHotSearches } from '@/api/search'
import { clickWebsite } from '@/api/website'
import { 
  Menu, Search, ArrowDown, HomeFilled, 
  Sunny, Moon, Setting 
} from '@element-plus/icons-vue'

const props = defineProps({
  collapsed: Boolean
})

const emit = defineEmits(['toggle-sidebar', 'toggle-dark'])

const router = useRouter()
const appStore = useAppStore()
const navStore = useNavStore()

const searchKeyword = ref('')
const showSearchPopover = ref(false)
const searchResults = ref([])
const hotSearches = ref([])
const currentEngine = ref(null)
const currentTime = ref('')
const currentDate = ref('')
let timeInterval = null
let searchTimeout = null

const isDark = computed(() => appStore.isDark)

// 更新时间
const updateTime = () => {
  const now = new Date()
  currentTime.value = now.toLocaleTimeString('zh-CN', { 
    hour: '2-digit', 
    minute: '2-digit'
  })
  currentDate.value = now.toLocaleDateString('zh-CN', {
    month: 'long',
    day: 'numeric',
    weekday: 'long'
  })
}

// 搜索输入处理
const handleSearchInput = () => {
  if (searchTimeout) {
    clearTimeout(searchTimeout)
  }
  
  if (searchKeyword.value.trim()) {
    searchTimeout = setTimeout(async () => {
      try {
        const res = await searchWebsites(searchKeyword.value, 8)
        if (res.code === 200) {
          searchResults.value = res.data.websites || []
        }
      } catch (error) {
        console.error('搜索失败:', error)
      }
    }, 300)
  } else {
    searchResults.value = []
  }
}

// 搜索框获取焦点
const handleSearchFocus = async () => {
  showSearchPopover.value = true
  
  if (!hotSearches.value.length) {
    try {
      const res = await getHotSearches(10)
      if (res.code === 200) {
        hotSearches.value = res.data || []
      }
    } catch (error) {
      console.error('获取热门搜索失败:', error)
    }
  }
}

// 搜索框失去焦点
const handleSearchBlur = () => {
  setTimeout(() => {
    showSearchPopover.value = false
  }, 200)
}

// 执行搜索
const handleSearch = () => {
  const keyword = searchKeyword.value.trim()
  if (!keyword) return
  
  // 检查是否是URL
  if (isValidUrl(keyword)) {
    let url = keyword
    if (!url.startsWith('http://') && !url.startsWith('https://')) {
      url = 'https://' + url
    }
    window.open(url, '_blank')
    return
  }
  
  // 使用搜索引擎搜索
  if (currentEngine.value) {
    const searchUrl = currentEngine.value.urlTemplate.replace('{keyword}', encodeURIComponent(keyword))
    window.open(searchUrl, '_blank')
  } else {
    // 默认使用百度
    window.open(`https://www.baidu.com/s?wd=${encodeURIComponent(keyword)}`, '_blank')
  }
}

// 检查是否是有效URL
const isValidUrl = (string) => {
  const urlPattern = /^(https?:\/\/)?([\da-z.-]+)\.([a-z.]{2,6})([\/\w .-]*)*\/?$/i
  return urlPattern.test(string)
}

// 跳转到网站
const goToWebsite = (website) => {
  clickWebsite(website.id)
  window.open(website.url, '_blank')
  showSearchPopover.value = false
  searchKeyword.value = ''
  searchResults.value = []
}

// 切换搜索引擎
const handleEngineChange = (engine) => {
  currentEngine.value = engine
}

// 图标加载失败处理
const handleIconError = (e) => {
  e.target.style.display = 'none'
}

onMounted(() => {
  updateTime()
  timeInterval = setInterval(updateTime, 1000)
  
  // 获取搜索引擎
  navStore.fetchSearchEngines().then(() => {
    if (navStore.searchEngines.length) {
      currentEngine.value = navStore.searchEngines.find(e => e.isDefault) || navStore.searchEngines[0]
    }
  })
})

onUnmounted(() => {
  if (timeInterval) {
    clearInterval(timeInterval)
  }
})
</script>

<style lang="scss" scoped>
.header {
  position: fixed;
  top: 0;
  right: 0;
  left: var(--sidebar-width);
  height: var(--header-height);
  background: rgba(255, 255, 255, 0.8);
  backdrop-filter: blur(20px);
  border-bottom: 1px solid #f0f0f0;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 24px;
  z-index: 40;
  transition: left var(--transition-duration);
  
  &.collapsed {
    left: var(--sidebar-collapsed-width);
  }
}

.dark .header {
  background: rgba(26, 26, 26, 0.8);
  border-bottom-color: #2a2a2a;
}

.header-left {
  display: flex;
  align-items: center;
  gap: 16px;
  flex: 1;
}

.menu-btn {
  display: none;
  width: 40px;
  height: 40px;
  border: none;
  background: transparent;
  border-radius: 10px;
  cursor: pointer;
  color: #666;
  
  &:hover {
    background: #f5f5f5;
  }
}

.dark .menu-btn {
  color: #a3a3a3;
  
  &:hover {
    background: #2a2a2a;
  }
}

.search-box {
  flex: 1;
  max-width: 560px;
}

.search-input-wrapper {
  display: flex;
  align-items: center;
  background: #f5f5f5;
  border-radius: 12px;
  padding: 0 16px;
  height: 44px;
  transition: all 0.2s ease;
  border: 2px solid transparent;
  
  &:focus-within {
    background: white;
    border-color: #667eea;
    box-shadow: 0 0 0 4px rgba(102, 126, 234, 0.1);
  }
}

.dark .search-input-wrapper {
  background: #2a2a2a;
  
  &:focus-within {
    background: #1a1a1a;
    border-color: #818cf8;
    box-shadow: 0 0 0 4px rgba(129, 140, 248, 0.1);
  }
}

.search-icon {
  color: #999;
  margin-right: 12px;
}

.search-input {
  flex: 1;
  border: none;
  background: transparent;
  font-size: 14px;
  color: #333;
  outline: none;
  
  &::placeholder {
    color: #999;
  }
}

.dark .search-input {
  color: #e5e5e5;
  
  &::placeholder {
    color: #666;
  }
}

.engine-selector {
  display: flex;
  align-items: center;
  gap: 4px;
  padding: 4px 8px;
  background: #e5e5e5;
  border-radius: 6px;
  font-size: 12px;
  color: #666;
  cursor: pointer;
  transition: all 0.2s ease;
  
  &:hover {
    background: #d5d5d5;
  }
}

.dark .engine-selector {
  background: #3a3a3a;
  color: #a3a3a3;
  
  &:hover {
    background: #4a4a4a;
  }
}

.header-right {
  display: flex;
  align-items: center;
  gap: 24px;
}

.time-display {
  text-align: right;
  
  .time {
    font-size: 20px;
    font-weight: 600;
    color: #333;
    line-height: 1.2;
  }
  
  .date {
    font-size: 12px;
    color: #999;
  }
}

.dark .time-display {
  .time {
    color: #e5e5e5;
  }
  
  .date {
    color: #666;
  }
}

.header-actions {
  display: flex;
  align-items: center;
  gap: 8px;
}

.action-btn {
  width: 40px;
  height: 40px;
  border: none;
  background: transparent;
  border-radius: 10px;
  cursor: pointer;
  color: #666;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.2s ease;
  
  &:hover {
    background: #f5f5f5;
    color: #333;
  }
}

.dark .action-btn {
  color: #a3a3a3;
  
  &:hover {
    background: #2a2a2a;
    color: #e5e5e5;
  }
}

// 搜索建议弹窗样式
.search-suggestions {
  .suggestion-section {
    padding: 8px 0;
  }
  
  .suggestion-title {
    font-size: 12px;
    color: #999;
    padding: 8px 12px;
  }
  
  .suggestion-item {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 10px 12px;
    border-radius: 8px;
    cursor: pointer;
    transition: background 0.2s ease;
    
    &:hover {
      background: #f5f5f5;
    }
  }
  
  .suggestion-icon {
    width: 32px;
    height: 32px;
    border-radius: 8px;
    object-fit: cover;
    
    &.placeholder {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 14px;
      font-weight: 600;
    }
  }
  
  .suggestion-info {
    flex: 1;
    min-width: 0;
  }
  
  .suggestion-name {
    font-size: 14px;
    color: #333;
    font-weight: 500;
  }
  
  .suggestion-url {
    font-size: 12px;
    color: #999;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  
  .hot-tags {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
    padding: 0 12px;
  }
  
  .hot-tag {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 6px 12px;
    background: #f5f5f5;
    border-radius: 20px;
    font-size: 13px;
    color: #666;
    cursor: pointer;
    transition: all 0.2s ease;
    
    &:hover {
      background: #e5e5e5;
      color: #333;
    }
    
    .hot-index {
      width: 18px;
      height: 18px;
      border-radius: 4px;
      background: #ddd;
      color: #666;
      font-size: 12px;
      display: flex;
      align-items: center;
      justify-content: center;
      
      &.top {
        background: linear-gradient(135deg, #ff6b6b 0%, #ffa502 100%);
        color: white;
      }
    }
  }
  
  .no-result {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    padding: 32px;
    color: #999;
    
    p {
      margin-top: 12px;
      font-size: 13px;
    }
  }
}

@media (max-width: 768px) {
  .header {
    left: 0 !important;
    padding: 0 16px;
  }
  
  .menu-btn {
    display: flex;
    align-items: center;
    justify-content: center;
  }
  
  .time-display {
    display: none;
  }
  
  .search-box {
    max-width: none;
  }
}

.md-hidden {
  @media (min-width: 769px) {
    display: none !important;
  }
}
</style>

<style>
.search-popover {
  padding: 0 !important;
  border-radius: 16px !important;
  box-shadow: 0 10px 40px rgba(0, 0, 0, 0.1) !important;
}

.dark .search-popover {
  background: #242424 !important;
  border-color: #3a3a3a !important;
}
</style>

