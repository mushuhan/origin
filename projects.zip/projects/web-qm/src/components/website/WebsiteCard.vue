<template>
  <div 
    class="website-card"
    @click="handleClick"
    @contextmenu.prevent="showContextMenu"
  >
    <div class="card-icon">
      <img 
        v-if="website.icon" 
        :src="website.icon" 
        :alt="website.name"
        @error="handleIconError"
      />
      <span v-else class="icon-placeholder">
        {{ website.name.charAt(0).toUpperCase() }}
      </span>
      <div v-if="website.isHot" class="hot-badge">
        <el-icon :size="10"><Star /></el-icon>
      </div>
    </div>
    
    <div class="card-info">
      <div class="card-name">{{ website.name }}</div>
      <div class="card-desc" v-if="showDesc">{{ website.description || website.url }}</div>
    </div>
    
    <!-- 悬浮提示 -->
    <transition name="tooltip">
      <div v-if="showTooltip" class="card-tooltip">
        <div class="tooltip-title">{{ website.name }}</div>
        <div class="tooltip-desc">{{ website.description }}</div>
        <div class="tooltip-url">{{ website.url }}</div>
      </div>
    </transition>
  </div>
  
  <!-- 右键菜单 -->
  <el-dropdown
    ref="contextMenuRef"
    trigger="contextmenu"
    :teleported="true"
    @command="handleCommand"
  >
    <span></span>
    <template #dropdown>
      <el-dropdown-menu>
        <el-dropdown-item command="open">
          <el-icon><Link /></el-icon>
          在新标签页打开
        </el-dropdown-item>
        <el-dropdown-item command="copy">
          <el-icon><CopyDocument /></el-icon>
          复制链接
        </el-dropdown-item>
        <el-dropdown-item command="workspace" v-if="!isWorkspace">
          <el-icon><Plus /></el-icon>
          添加到工作台
        </el-dropdown-item>
        <el-dropdown-item command="delete" v-if="isWorkspace" divided>
          <el-icon><Delete /></el-icon>
          从工作台移除
        </el-dropdown-item>
      </el-dropdown-menu>
    </template>
  </el-dropdown>
</template>

<script setup>
import { ref } from 'vue'
import { ElMessage } from 'element-plus'
import { useWorkspaceStore } from '@/stores/workspace'
import { clickWebsite } from '@/api/website'
import { Star, Link, CopyDocument, Plus, Delete } from '@element-plus/icons-vue'

const props = defineProps({
  website: {
    type: Object,
    required: true
  },
  showDesc: {
    type: Boolean,
    default: false
  },
  isWorkspace: {
    type: Boolean,
    default: false
  }
})

const emit = defineEmits(['delete'])

const workspaceStore = useWorkspaceStore()
const contextMenuRef = ref(null)
const showTooltip = ref(false)
let tooltipTimer = null

// 点击卡片
const handleClick = () => {
  if (!props.isWorkspace) {
    clickWebsite(props.website.id)
  }
  window.open(props.website.url, '_blank')
}

// 显示右键菜单
const showContextMenu = (e) => {
  // 触发下拉菜单
}

// 处理右键菜单命令
const handleCommand = async (command) => {
  switch (command) {
    case 'open':
      handleClick()
      break
    case 'copy':
      await navigator.clipboard.writeText(props.website.url)
      ElMessage.success('链接已复制')
      break
    case 'workspace':
      const success = await workspaceStore.addFromSystem(props.website.id)
      if (success) {
        ElMessage.success('已添加到工作台')
      } else {
        ElMessage.warning('添加失败或已存在')
      }
      break
    case 'delete':
      emit('delete', props.website)
      break
  }
}

// 图标加载失败
const handleIconError = (e) => {
  e.target.style.display = 'none'
  e.target.nextElementSibling?.classList.remove('hidden')
}

// 鼠标悬浮显示提示
const handleMouseEnter = () => {
  tooltipTimer = setTimeout(() => {
    showTooltip.value = true
  }, 500)
}

const handleMouseLeave = () => {
  if (tooltipTimer) {
    clearTimeout(tooltipTimer)
  }
  showTooltip.value = false
}
</script>

<style lang="scss" scoped>
.website-card {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 12px;
  border-radius: 12px;
  cursor: pointer;
  transition: all 0.2s ease;
  position: relative;
  
  &:hover {
    background: #f5f5f5;
    
    .card-icon img,
    .card-icon .icon-placeholder {
      transform: scale(1.05);
    }
  }
  
  &:active {
    transform: scale(0.98);
  }
}

.dark .website-card {
  &:hover {
    background: #2a2a2a;
  }
}

.card-icon {
  position: relative;
  width: 48px;
  height: 48px;
  border-radius: 12px;
  overflow: hidden;
  flex-shrink: 0;
  
  img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform 0.2s ease;
  }
  
  .icon-placeholder {
    width: 100%;
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    font-size: 20px;
    font-weight: 600;
    transition: transform 0.2s ease;
  }
  
  .hot-badge {
    position: absolute;
    top: -4px;
    right: -4px;
    width: 18px;
    height: 18px;
    background: linear-gradient(135deg, #ff6b6b 0%, #ffa502 100%);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    box-shadow: 0 2px 6px rgba(255, 107, 107, 0.4);
  }
}

.card-info {
  flex: 1;
  min-width: 0;
}

.card-name {
  font-size: 14px;
  font-weight: 500;
  color: #333;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.dark .card-name {
  color: #e5e5e5;
}

.card-desc {
  font-size: 12px;
  color: #999;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  margin-top: 4px;
}

.dark .card-desc {
  color: #666;
}

.card-tooltip {
  position: absolute;
  bottom: calc(100% + 8px);
  left: 50%;
  transform: translateX(-50%);
  background: white;
  border-radius: 12px;
  padding: 12px;
  box-shadow: 0 10px 40px rgba(0, 0, 0, 0.15);
  z-index: 100;
  min-width: 200px;
  max-width: 300px;
  
  .tooltip-title {
    font-size: 14px;
    font-weight: 600;
    color: #333;
    margin-bottom: 4px;
  }
  
  .tooltip-desc {
    font-size: 12px;
    color: #666;
    margin-bottom: 8px;
    line-height: 1.5;
  }
  
  .tooltip-url {
    font-size: 11px;
    color: #999;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  
  &::after {
    content: '';
    position: absolute;
    bottom: -6px;
    left: 50%;
    transform: translateX(-50%);
    border-left: 6px solid transparent;
    border-right: 6px solid transparent;
    border-top: 6px solid white;
  }
}

.dark .card-tooltip {
  background: #2a2a2a;
  
  .tooltip-title {
    color: #e5e5e5;
  }
  
  .tooltip-desc {
    color: #a3a3a3;
  }
  
  &::after {
    border-top-color: #2a2a2a;
  }
}

.tooltip-enter-active,
.tooltip-leave-active {
  transition: all 0.2s ease;
}

.tooltip-enter-from,
.tooltip-leave-to {
  opacity: 0;
  transform: translateX(-50%) translateY(4px);
}
</style>

