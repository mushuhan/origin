<template>
  <div class="website-section" ref="sectionRef">
    <div class="section-header">
      <h3 class="section-title">{{ section.name }}</h3>
      <span class="section-count">{{ section.websites?.length || 0 }}个网站</span>
    </div>
    
    <div class="section-grid">
      <WebsiteCard
        v-for="(website, index) in section.websites"
        :key="website.id"
        :website="website"
        :style="{ animationDelay: `${index * 0.05}s` }"
        class="animate-item"
      />
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { gsap } from 'gsap'
import WebsiteCard from './WebsiteCard.vue'

const props = defineProps({
  section: {
    type: Object,
    required: true
  }
})

const sectionRef = ref(null)

onMounted(() => {
  // GSAP 入场动画
  if (sectionRef.value) {
    const items = sectionRef.value.querySelectorAll('.animate-item')
    gsap.from(items, {
      opacity: 0,
      y: 20,
      duration: 0.4,
      stagger: 0.05,
      ease: 'power2.out'
    })
  }
})
</script>

<style lang="scss" scoped>
.website-section {
  margin-bottom: 32px;
}

.section-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 16px;
}

.section-title {
  font-size: 16px;
  font-weight: 600;
  color: #333;
  display: flex;
  align-items: center;
  gap: 8px;
  
  &::before {
    content: '';
    width: 4px;
    height: 16px;
    background: linear-gradient(180deg, #667eea 0%, #764ba2 100%);
    border-radius: 2px;
  }
}

.dark .section-title {
  color: #e5e5e5;
}

.section-count {
  font-size: 12px;
  color: #999;
}

.section-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
  gap: 8px;
}

@media (max-width: 768px) {
  .section-grid {
    grid-template-columns: repeat(2, 1fr);
  }
}

@media (max-width: 480px) {
  .section-grid {
    grid-template-columns: 1fr;
  }
}
</style>

