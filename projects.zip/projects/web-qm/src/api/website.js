import request from './request'

// 获取分区下的网站列表
export function getWebsitesBySection(sectionId) {
  return request.get(`/websites/section/${sectionId}`)
}

// 获取网站详情
export function getWebsiteDetail(id) {
  return request.get(`/websites/${id}`)
}

// 获取热门网站
export function getHotWebsites(limit = 20) {
  return request.get('/websites/hot', { params: { limit } })
}

// 增加点击次数
export function clickWebsite(id) {
  return request.post(`/websites/${id}/click`)
}

