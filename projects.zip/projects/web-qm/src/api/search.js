import request from './request'

// 搜索网站
export function searchWebsites(keyword, limit = 20) {
  return request.get('/search', { params: { keyword, limit } })
}

// 获取搜索引擎列表
export function getSearchEngines() {
  return request.get('/search/engines')
}

// 获取默认搜索引擎
export function getDefaultSearchEngine() {
  return request.get('/search/engines/default')
}

// 获取热门搜索词
export function getHotSearches(limit = 10) {
  return request.get('/search/hot', { params: { limit } })
}

