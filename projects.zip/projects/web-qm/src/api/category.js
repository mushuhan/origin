import request from './request'

// 获取所有分类
export function getCategories() {
  return request.get('/categories')
}

// 获取分类详情（包含分区和网站）
export function getCategoryDetail(id) {
  return request.get(`/categories/${id}`)
}

// 获取所有分类及其内容
export function getAllCategoriesWithContent() {
  return request.get('/categories/all')
}

