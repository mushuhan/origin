import request from './request'

// 获取用户工作台
export function getUserWorkspace(userId) {
  return request.get(`/workspace/${userId}`)
}

// 添加网址到工作台
export function addToWorkspace(data) {
  return request.post('/workspace', data)
}

// 从系统网址添加到工作台
export function addFromWebsite(userId, websiteId) {
  return request.post('/workspace/from-website', null, {
    params: { userId, websiteId }
  })
}

// 更新工作台网址
export function updateWorkspace(id, data) {
  return request.put(`/workspace/${id}`, data)
}

// 更新工作台排序
export function updateWorkspaceSortOrder(userId, ids) {
  return request.put(`/workspace/${userId}/sort`, ids)
}

// 删除工作台网址
export function removeFromWorkspace(userId, id) {
  return request.delete(`/workspace/${userId}/${id}`)
}

