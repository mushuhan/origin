import request from './request'

// 获取所有系统配置
export function getConfig() {
  return request.get('/config')
}

// 获取指定配置
export function getConfigByKey(key) {
  return request.get(`/config/${key}`)
}

