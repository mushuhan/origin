<template>
  <div class="hot-page">
    <div class="page-container">
      <!-- 页面头部 -->
      <div class="page-header">
        <div class="header-info">
          <h1 class="page-title">
            <el-icon><TrendCharts /></el-icon>
            热门网址
          </h1>
          <p class="page-desc">发现最受欢迎的网站，探索更多精彩</p>
        </div>
      </div>
      
      <!-- 热门网址列表 -->
      <div class="hot-content">
        <div v-if="loading" class="loading-state">
          <el-skeleton :rows="8" animated />
        </div>
        
        <div v-else class="hot-grid">
          <div
            v-for="(website, index) in hotWebsites"
            :key="website.id"
            class="hot-item"
            :style="{ animationDelay: `${index * 0.05}s` }"
            @click="goToWebsite(website)"
          >
            <div class="hot-rank" :class="{ top: index < 3 }">
              {{ index + 1 }}
            </div>
            
            <div class="hot-icon">
              <img 
                v-if="website.icon" 
                :src="website.icon" 
                :alt="website.name"
                @error="handleIconError"
              />
              <span v-else class="icon-text">
                {{ website.name.charAt(0).toUpperCase() }}
              </span>
            </div>
            
            <div class="hot-info">
              <div class="hot-name">{{ website.name }}</div>
              <div class="hot-desc">{{ website.description || website.url }}</div>
            </div>
            
            <div class="hot-stats">
              <el-icon><View /></el-icon>
              {{ formatCount(website.clickCount) }}
            </div>
            
            <div class="hot-action">
              <el-button 
                type="primary" 
                size="small" 
                circle
                @click.stop="handleAddToWorkspace(website)"
              >
                <el-icon><Plus /></el-icon>
              </el-button>
            </div>
          </div>
        </div>
        
        <el-empty v-if="!loading && !hotWebsites.length" description="暂无热门网址" />
      </div>
      
      <!-- 底部 -->
      <Footer />
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import { gsap } from 'gsap'
import { getHotWebsites, clickWebsite } from '@/api/website'
import { useWorkspaceStore } from '@/stores/workspace'
import Footer from '@/components/common/Footer.vue'
import { TrendCharts, View, Plus } from '@element-plus/icons-vue'

const workspaceStore = useWorkspaceStore()

const hotWebsites = ref([])
const loading = ref(true)

// 格式化数字
const formatCount = (count) => {
  if (!count) return '0'
  if (count >= 10000) {
    return (count / 10000).toFixed(1) + 'w'
  }
  if (count >= 1000) {
    return (count / 1000).toFixed(1) + 'k'
  }
  return count.toString()
}

// 跳转网站
const goToWebsite = (website) => {
  clickWebsite(website.id)
  window.open(website.url, '_blank')
}

// 添加到工作台
const handleAddToWorkspace = async (website) => {
  const success = await workspaceStore.addFromSystem(website.id)
  if (success) {
    ElMessage.success('已添加到工作台')
  } else {
    ElMessage.warning('添加失败或已存在')
  }
}

// 图标错误处理
const handleIconError = (e) => {
  e.target.style.display = 'none'
}

// 获取热门网址
const fetchHotWebsites = async () => {
  loading.value = true
  try {
    const res = await getHotWebsites(50)
    if (res.code === 200) {
      hotWebsites.value = res.data || []
    }
  } catch (error) {
    console.error('获取热门网址失败:', error)
  } finally {
    loading.value = false
  }
}

onMounted(() => {
  fetchHotWebsites()
  
  // 入场动画
  gsap.from('.page-header', {
    opacity: 0,
    y: -20,
    duration: 0.4,
    ease: 'power2.out'
  })
})
</script>

<style lang="scss" scoped>
.hot-page {
  min-height: 100vh;
  display: flex;
  flex-direction: column;
}

.page-container {
  padding: calc(var(--header-height) + 24px) 32px 0;
  max-width: 1000px;
  margin: 0 auto;
  width: 100%;
}

.page-header {
  margin-bottom: 32px;
  padding: 32px;
  background: linear-gradient(135deg, #ff6b6b 0%, #ffa502 100%);
  border-radius: 20px;
  color: white;
}

.page-title {
  display: flex;
  align-items: center;
  gap: 10px;
  font-size: 26px;
  font-weight: 600;
  margin-bottom: 8px;
}

.page-desc {
  font-size: 14px;
  opacity: 0.9;
}

.hot-content {
  margin-bottom: 32px;
}

.hot-grid {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.hot-item {
  display: flex;
  align-items: center;
  gap: 16px;
  padding: 16px 20px;
  background: white;
  border-radius: 14px;
  cursor: pointer;
  transition: all 0.2s ease;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
  animation: fadeInUp 0.4s ease-out both;
  
  &:hover {
    transform: translateX(4px);
    box-shadow: 0 8px 30px rgba(0, 0, 0, 0.08);
    
    .hot-action {
      opacity: 1;
    }
  }
}

.dark .hot-item {
  background: #1a1a1a;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.2);
  
  &:hover {
    box-shadow: 0 8px 30px rgba(0, 0, 0, 0.3);
  }
}

.hot-rank {
  width: 32px;
  height: 32px;
  border-radius: 8px;
  background: #f0f0f0;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 14px;
  font-weight: 600;
  color: #666;
  flex-shrink: 0;
  
  &.top {
    background: linear-gradient(135deg, #ff6b6b 0%, #ffa502 100%);
    color: white;
  }
}

.dark .hot-rank {
  background: #2a2a2a;
  color: #a3a3a3;
  
  &.top {
    background: linear-gradient(135deg, #ff6b6b 0%, #ffa502 100%);
    color: white;
  }
}

.hot-icon {
  width: 48px;
  height: 48px;
  border-radius: 12px;
  overflow: hidden;
  flex-shrink: 0;
  
  img {
    width: 100%;
    height: 100%;
    object-fit: cover;
  }
  
  .icon-text {
    width: 100%;
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    font-size: 20px;
    font-weight: 600;
  }
}

.hot-info {
  flex: 1;
  min-width: 0;
}

.hot-name {
  font-size: 15px;
  font-weight: 500;
  color: #333;
  margin-bottom: 4px;
}

.dark .hot-name {
  color: #e5e5e5;
}

.hot-desc {
  font-size: 13px;
  color: #999;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.hot-stats {
  display: flex;
  align-items: center;
  gap: 4px;
  font-size: 13px;
  color: #999;
  flex-shrink: 0;
}

.hot-action {
  opacity: 0;
  transition: opacity 0.2s ease;
}

.loading-state {
  padding: 40px;
  background: white;
  border-radius: 16px;
}

.dark .loading-state {
  background: #1a1a1a;
}

@keyframes fadeInUp {
  from {
    opacity: 0;
    transform: translateY(15px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

@media (max-width: 768px) {
  .page-container {
    padding: calc(var(--header-height) + 16px) 16px 0;
  }
  
  .hot-item {
    padding: 14px 16px;
  }
  
  .hot-stats {
    display: none;
  }
  
  .hot-action {
    opacity: 1;
  }
}
</style>

