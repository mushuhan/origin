<template>
  <div class="home-page">
    <div class="page-container">
      <!-- 欢迎区域 -->
      <section class="welcome-section">
        <div class="welcome-content">
          <h1 class="welcome-title">
            <span class="greeting">{{ greeting }}，</span>
            <span class="highlight">欢迎使用网址导航</span>
          </h1>
          <p class="welcome-desc">快速访问您的常用网站，提升工作效率</p>
        </div>
        
        <div class="quick-stats">
          <div class="stat-item">
            <div class="stat-value">{{ totalWebsites }}</div>
            <div class="stat-label">收录网站</div>
          </div>
          <div class="stat-item">
            <div class="stat-value">{{ totalCategories }}</div>
            <div class="stat-label">网站分类</div>
          </div>
          <div class="stat-item">
            <div class="stat-value">{{ workspaceCount }}</div>
            <div class="stat-label">我的收藏</div>
          </div>
        </div>
      </section>
      
      <!-- 用户工作台快捷入口 -->
      <section v-if="workspaceStore.workspaces.length" class="workspace-preview">
        <div class="section-header">
          <h2 class="section-title">
            <el-icon><Briefcase /></el-icon>
            我的工作台
          </h2>
          <router-link to="/customize" class="view-more">
            查看全部 <el-icon><ArrowRight /></el-icon>
          </router-link>
        </div>
        
        <div class="workspace-grid">
          <WebsiteCard
            v-for="(item, index) in workspaceStore.workspaces.slice(0, 8)"
            :key="item.id"
            :website="item"
            :is-workspace="true"
            :style="{ animationDelay: `${index * 0.05}s` }"
            class="animate-item"
          />
        </div>
      </section>
      
      <!-- 热门推荐 -->
      <section v-if="navStore.hotWebsites.length" class="hot-section">
        <div class="section-header">
          <h2 class="section-title">
            <el-icon><TrendCharts /></el-icon>
            热门推荐
          </h2>
          <router-link to="/hot" class="view-more">
            查看更多 <el-icon><ArrowRight /></el-icon>
          </router-link>
        </div>
        
        <div class="hot-grid">
          <WebsiteCard
            v-for="(website, index) in navStore.hotWebsites.slice(0, 12)"
            :key="website.id"
            :website="website"
            :style="{ animationDelay: `${index * 0.05}s` }"
            class="animate-item"
          />
        </div>
      </section>
      
      <!-- 分类导航 -->
      <section class="categories-section">
        <div v-if="navStore.loading" class="loading-state">
          <el-skeleton :rows="8" animated />
        </div>
        
        <div v-else class="categories-content">
          <div 
            v-for="(category, catIndex) in displayCategories" 
            :key="category.id"
            class="category-block"
            :style="{ animationDelay: `${catIndex * 0.1}s` }"
          >
            <div class="category-header">
              <h2 class="category-title">
                <el-icon><component :is="getCategoryIcon(category.icon)" /></el-icon>
                {{ category.name }}
              </h2>
              <router-link :to="`/category/${category.id}`" class="view-more">
                查看全部 <el-icon><ArrowRight /></el-icon>
              </router-link>
            </div>
            
            <div class="category-content">
              <WebsiteSection
                v-for="section in category.sections"
                :key="section.id"
                :section="section"
              />
            </div>
          </div>
        </div>
      </section>
      
      <!-- 底部 -->
      <Footer />
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { gsap } from 'gsap'
import { useNavStore } from '@/stores/nav'
import { useWorkspaceStore } from '@/stores/workspace'
import WebsiteCard from '@/components/website/WebsiteCard.vue'
import WebsiteSection from '@/components/website/WebsiteSection.vue'
import Footer from '@/components/common/Footer.vue'
import { 
  Briefcase, TrendCharts, ArrowRight,
  Star, Document, Cpu, Brush, Lightning, 
  Reading, Headset, Tickets, Grid
} from '@element-plus/icons-vue'

const navStore = useNavStore()
const workspaceStore = useWorkspaceStore()

// 问候语
const greeting = computed(() => {
  const hour = new Date().getHours()
  if (hour < 6) return '夜深了'
  if (hour < 12) return '早上好'
  if (hour < 14) return '中午好'
  if (hour < 18) return '下午好'
  return '晚上好'
})

// 统计数据
const totalWebsites = computed(() => {
  let count = 0
  navStore.categoriesWithContent.forEach(cat => {
    cat.sections?.forEach(sec => {
      count += sec.websites?.length || 0
    })
  })
  return count
})

const totalCategories = computed(() => navStore.categories.length)
const workspaceCount = computed(() => workspaceStore.workspaces.length)

// 过滤分类（排除自定义工作台）
const displayCategories = computed(() => {
  return navStore.categoriesWithContent.filter(c => c.id !== 1)
})

// 获取分类图标
const getCategoryIcon = (iconName) => {
  const iconMap = {
    'Star': Star,
    'Code': Cpu,
    'Palette': Brush,
    'Zap': Lightning,
    'GraduationCap': Reading,
    'Music': Headset,
    'Newspaper': Tickets
  }
  return iconMap[iconName] || Grid
}

onMounted(() => {
  navStore.fetchAllCategoriesWithContent()
  navStore.fetchHotWebsites(12)
  workspaceStore.fetchWorkspaces()
  
  // 入场动画
  gsap.from('.welcome-section', {
    opacity: 0,
    y: 30,
    duration: 0.6,
    ease: 'power2.out'
  })
})
</script>

<style lang="scss" scoped>
.home-page {
  min-height: 100vh;
  display: flex;
  flex-direction: column;
}

.page-container {
  padding: calc(var(--header-height) + 24px) 32px 0;
  max-width: 1400px;
  margin: 0 auto;
  width: 100%;
}

// 欢迎区域
.welcome-section {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 32px 40px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  border-radius: 24px;
  margin-bottom: 32px;
  color: white;
}

.welcome-content {
  .welcome-title {
    font-size: 28px;
    font-weight: 700;
    margin-bottom: 8px;
    
    .greeting {
      opacity: 0.9;
    }
    
    .highlight {
      display: block;
    }
  }
  
  .welcome-desc {
    font-size: 14px;
    opacity: 0.8;
  }
}

.quick-stats {
  display: flex;
  gap: 40px;
  
  .stat-item {
    text-align: center;
  }
  
  .stat-value {
    font-size: 32px;
    font-weight: 700;
    line-height: 1.2;
  }
  
  .stat-label {
    font-size: 12px;
    opacity: 0.8;
    margin-top: 4px;
  }
}

// 通用 section 样式
.section-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 20px;
}

.section-title {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 18px;
  font-weight: 600;
  color: #333;
  
  .el-icon {
    color: #667eea;
  }
}

.dark .section-title {
  color: #e5e5e5;
  
  .el-icon {
    color: #818cf8;
  }
}

.view-more {
  display: flex;
  align-items: center;
  gap: 4px;
  font-size: 13px;
  color: #667eea;
  text-decoration: none;
  transition: all 0.2s ease;
  
  &:hover {
    color: #764ba2;
    gap: 8px;
  }
}

.dark .view-more {
  color: #818cf8;
  
  &:hover {
    color: #a78bfa;
  }
}

// 工作台预览
.workspace-preview,
.hot-section {
  margin-bottom: 40px;
}

.workspace-grid,
.hot-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
  gap: 8px;
  background: white;
  border-radius: 16px;
  padding: 16px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
}

.dark .workspace-grid,
.dark .hot-grid {
  background: #1a1a1a;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.2);
}

// 分类区域
.category-block {
  margin-bottom: 40px;
  animation: fadeInUp 0.5s ease-out both;
}

.category-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 20px;
  padding-bottom: 12px;
  border-bottom: 1px solid #f0f0f0;
}

.dark .category-header {
  border-bottom-color: #2a2a2a;
}

.category-title {
  display: flex;
  align-items: center;
  gap: 10px;
  font-size: 20px;
  font-weight: 600;
  color: #333;
  
  .el-icon {
    color: #667eea;
  }
}

.dark .category-title {
  color: #e5e5e5;
  
  .el-icon {
    color: #818cf8;
  }
}

.category-content {
  background: white;
  border-radius: 16px;
  padding: 24px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
}

.dark .category-content {
  background: #1a1a1a;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.2);
}

.loading-state {
  padding: 40px;
  background: white;
  border-radius: 16px;
}

.dark .loading-state {
  background: #1a1a1a;
}

@keyframes fadeInUp {
  from {
    opacity: 0;
    transform: translateY(20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

@media (max-width: 768px) {
  .page-container {
    padding: calc(var(--header-height) + 16px) 16px 0;
  }
  
  .welcome-section {
    flex-direction: column;
    text-align: center;
    padding: 24px;
    gap: 24px;
  }
  
  .welcome-content .welcome-title {
    font-size: 22px;
  }
  
  .quick-stats {
    gap: 24px;
    
    .stat-value {
      font-size: 24px;
    }
  }
  
  .workspace-grid,
  .hot-grid {
    grid-template-columns: repeat(2, 1fr);
  }
}
</style>

