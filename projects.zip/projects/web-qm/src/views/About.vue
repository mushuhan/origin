<template>
  <div class="about-page">
    <div class="page-container">
      <!-- 页面头部 -->
      <div class="page-header">
        <h1 class="page-title">关于网址导航</h1>
        <p class="page-desc">简洁、高效、个性化的一站式网址导航系统</p>
      </div>
      
      <!-- 功能特点 -->
      <section class="features-section">
        <h2 class="section-title">功能特点</h2>
        <div class="features-grid">
          <div class="feature-card" v-for="feature in features" :key="feature.title">
            <div class="feature-icon">
              <el-icon :size="28"><component :is="feature.icon" /></el-icon>
            </div>
            <h3 class="feature-title">{{ feature.title }}</h3>
            <p class="feature-desc">{{ feature.desc }}</p>
          </div>
        </div>
      </section>
      
      <!-- 使用说明 -->
      <section class="guide-section">
        <h2 class="section-title">使用说明</h2>
        <div class="guide-content">
          <div class="guide-item" v-for="(guide, index) in guides" :key="index">
            <div class="guide-number">{{ index + 1 }}</div>
            <div class="guide-info">
              <h4 class="guide-title">{{ guide.title }}</h4>
              <p class="guide-desc">{{ guide.desc }}</p>
            </div>
          </div>
        </div>
      </section>
      
      <!-- 技术栈 -->
      <section class="tech-section">
        <h2 class="section-title">技术栈</h2>
        <div class="tech-grid">
          <div class="tech-item" v-for="tech in techs" :key="tech.name">
            <div class="tech-name">{{ tech.name }}</div>
            <div class="tech-desc">{{ tech.desc }}</div>
          </div>
        </div>
      </section>
      
      <!-- 联系我们 -->
      <section class="contact-section">
        <h2 class="section-title">联系我们</h2>
        <div class="contact-content">
          <p>如果您有任何问题、建议或反馈，欢迎通过以下方式联系我们：</p>
          <div class="contact-info">
            <div class="contact-item">
              <el-icon><Message /></el-icon>
              <span>admin@example.com</span>
            </div>
            <div class="contact-item">
              <el-icon><Link /></el-icon>
              <span>github.com/example/nav-system</span>
            </div>
          </div>
        </div>
      </section>
      
      <!-- 底部 -->
      <Footer />
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { gsap } from 'gsap'
import Footer from '@/components/common/Footer.vue'
import { 
  Search, Collection, Setting, Moon, 
  Promotion, DataAnalysis, Message, Link
} from '@element-plus/icons-vue'

const features = ref([
  {
    icon: Search,
    title: '智能搜索',
    desc: '支持网址搜索、关键词补全、多搜索引擎切换，快速找到您需要的网站'
  },
  {
    icon: Collection,
    title: '个性化工作台',
    desc: '自定义添加常用网址，支持拖拽排序，打造专属于您的导航页面'
  },
  {
    icon: Setting,
    title: '高度可定制',
    desc: '支持深色模式、自定义分类、个性化布局，满足不同使用场景'
  },
  {
    icon: Moon,
    title: '深色模式',
    desc: '护眼深色主题，自动跟随系统设置，呵护您的双眼'
  },
  {
    icon: Promotion,
    title: '快捷访问',
    desc: '精心整理的网址分类，一键直达目标网站，提升工作效率'
  },
  {
    icon: DataAnalysis,
    title: '热门推荐',
    desc: '基于访问热度智能推荐，发现更多优质网站资源'
  }
])

const guides = ref([
  {
    title: '浏览网址分类',
    desc: '通过侧边栏选择不同分类，浏览该类别下的所有网站。点击网站卡片即可直接访问。'
  },
  {
    title: '使用搜索功能',
    desc: '在顶部搜索框输入网址名称或关键词，快速搜索相关网站。支持直接输入URL跳转。'
  },
  {
    title: '添加到工作台',
    desc: '右键点击任意网站卡片，选择"添加到工作台"，将常用网址收藏到个人工作台。'
  },
  {
    title: '管理个人工作台',
    desc: '在自定义工作台页面，您可以添加、编辑、删除和排序您的常用网址。'
  },
  {
    title: '切换显示模式',
    desc: '点击顶部的主题切换按钮，可在浅色和深色模式之间切换。'
  }
])

const techs = ref([
  { name: 'Vue 3', desc: '渐进式 JavaScript 框架' },
  { name: 'Vite', desc: '下一代前端构建工具' },
  { name: 'Element Plus', desc: 'Vue 3 组件库' },
  { name: 'Tailwind CSS', desc: '实用优先的 CSS 框架' },
  { name: 'GSAP', desc: '专业级动画库' },
  { name: 'Spring Boot 3', desc: 'Java 后端框架' },
  { name: 'MyBatis Plus', desc: 'MyBatis 增强工具' },
  { name: 'MySQL', desc: '关系型数据库' }
])

onMounted(() => {
  // 入场动画
  gsap.from('.page-header', {
    opacity: 0,
    y: -30,
    duration: 0.5,
    ease: 'power2.out'
  })
  
  gsap.from('.feature-card', {
    opacity: 0,
    y: 20,
    duration: 0.4,
    stagger: 0.1,
    ease: 'power2.out',
    delay: 0.2
  })
})
</script>

<style lang="scss" scoped>
.about-page {
  min-height: 100vh;
  display: flex;
  flex-direction: column;
}

.page-container {
  padding: calc(var(--header-height) + 24px) 32px 0;
  max-width: 1000px;
  margin: 0 auto;
  width: 100%;
}

.page-header {
  text-align: center;
  margin-bottom: 48px;
  padding: 48px 32px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  border-radius: 24px;
  color: white;
}

.page-title {
  font-size: 32px;
  font-weight: 700;
  margin-bottom: 12px;
}

.page-desc {
  font-size: 16px;
  opacity: 0.9;
}

.section-title {
  font-size: 22px;
  font-weight: 600;
  color: #333;
  margin-bottom: 24px;
  display: flex;
  align-items: center;
  gap: 10px;
  
  &::before {
    content: '';
    width: 4px;
    height: 22px;
    background: linear-gradient(180deg, #667eea 0%, #764ba2 100%);
    border-radius: 2px;
  }
}

.dark .section-title {
  color: #e5e5e5;
}

// 功能特点
.features-section {
  margin-bottom: 48px;
}

.features-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
  gap: 20px;
}

.feature-card {
  padding: 28px;
  background: white;
  border-radius: 16px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
  transition: all 0.3s ease;
  
  &:hover {
    transform: translateY(-4px);
    box-shadow: 0 12px 40px rgba(0, 0, 0, 0.1);
    
    .feature-icon {
      transform: scale(1.1);
    }
  }
}

.dark .feature-card {
  background: #1a1a1a;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.2);
  
  &:hover {
    box-shadow: 0 12px 40px rgba(0, 0, 0, 0.3);
  }
}

.feature-icon {
  width: 56px;
  height: 56px;
  background: linear-gradient(135deg, rgba(102, 126, 234, 0.1) 0%, rgba(118, 75, 162, 0.1) 100%);
  border-radius: 14px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #667eea;
  margin-bottom: 16px;
  transition: transform 0.3s ease;
}

.dark .feature-icon {
  color: #818cf8;
}

.feature-title {
  font-size: 17px;
  font-weight: 600;
  color: #333;
  margin-bottom: 8px;
}

.dark .feature-title {
  color: #e5e5e5;
}

.feature-desc {
  font-size: 14px;
  color: #666;
  line-height: 1.6;
}

.dark .feature-desc {
  color: #a3a3a3;
}

// 使用说明
.guide-section {
  margin-bottom: 48px;
}

.guide-content {
  background: white;
  border-radius: 16px;
  padding: 24px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
}

.dark .guide-content {
  background: #1a1a1a;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.2);
}

.guide-item {
  display: flex;
  gap: 16px;
  padding: 16px 0;
  border-bottom: 1px solid #f0f0f0;
  
  &:last-child {
    border-bottom: none;
  }
}

.dark .guide-item {
  border-bottom-color: #2a2a2a;
}

.guide-number {
  width: 32px;
  height: 32px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  font-size: 14px;
  font-weight: 600;
  flex-shrink: 0;
}

.guide-title {
  font-size: 15px;
  font-weight: 600;
  color: #333;
  margin-bottom: 4px;
}

.dark .guide-title {
  color: #e5e5e5;
}

.guide-desc {
  font-size: 14px;
  color: #666;
  line-height: 1.5;
}

.dark .guide-desc {
  color: #a3a3a3;
}

// 技术栈
.tech-section {
  margin-bottom: 48px;
}

.tech-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
  gap: 12px;
}

.tech-item {
  padding: 16px 20px;
  background: white;
  border-radius: 12px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
}

.dark .tech-item {
  background: #1a1a1a;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.2);
}

.tech-name {
  font-size: 15px;
  font-weight: 600;
  color: #667eea;
  margin-bottom: 4px;
}

.dark .tech-name {
  color: #818cf8;
}

.tech-desc {
  font-size: 13px;
  color: #999;
}

// 联系我们
.contact-section {
  margin-bottom: 48px;
}

.contact-content {
  background: white;
  border-radius: 16px;
  padding: 24px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
  
  p {
    font-size: 14px;
    color: #666;
    margin-bottom: 16px;
  }
}

.dark .contact-content {
  background: #1a1a1a;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.2);
  
  p {
    color: #a3a3a3;
  }
}

.contact-info {
  display: flex;
  flex-wrap: wrap;
  gap: 24px;
}

.contact-item {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 14px;
  color: #333;
  
  .el-icon {
    color: #667eea;
  }
}

.dark .contact-item {
  color: #e5e5e5;
  
  .el-icon {
    color: #818cf8;
  }
}

@media (max-width: 768px) {
  .page-container {
    padding: calc(var(--header-height) + 16px) 16px 0;
  }
  
  .page-header {
    padding: 32px 20px;
  }
  
  .page-title {
    font-size: 24px;
  }
  
  .features-grid {
    grid-template-columns: 1fr;
  }
  
  .tech-grid {
    grid-template-columns: repeat(2, 1fr);
  }
}
</style>

