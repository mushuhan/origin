<template>
  <div class="customize-page">
    <div class="page-container">
      <!-- 页面头部 -->
      <div class="page-header">
        <div class="header-info">
          <h1 class="page-title">
            <el-icon><Briefcase /></el-icon>
            我的工作台
          </h1>
          <p class="page-desc">添加和管理您的常用网址，支持拖拽排序</p>
        </div>
        
        <div class="header-actions">
          <el-button type="primary" @click="showAddDialog = true">
            <el-icon><Plus /></el-icon>
            添加网址
          </el-button>
        </div>
      </div>
      
      <!-- 工作台内容 -->
      <div class="workspace-content">
        <div v-if="workspaceStore.loading" class="loading-state">
          <el-skeleton :rows="6" animated />
        </div>
        
        <div v-else-if="workspaceStore.workspaces.length" class="workspace-grid" ref="gridRef">
          <div
            v-for="(item, index) in workspaceStore.workspaces"
            :key="item.id"
            class="workspace-item"
            :data-id="item.id"
            :style="{ animationDelay: `${index * 0.05}s` }"
          >
            <div class="item-drag-handle">
              <el-icon><Rank /></el-icon>
            </div>
            
            <div class="item-icon" @click="goToWebsite(item)">
              <img 
                v-if="item.icon" 
                :src="item.icon" 
                :alt="item.name"
                @error="handleIconError"
              />
              <span v-else class="icon-text">
                {{ item.name.charAt(0).toUpperCase() }}
              </span>
            </div>
            
            <div class="item-info" @click="goToWebsite(item)">
              <div class="item-name">{{ item.name }}</div>
              <div class="item-url">{{ item.url }}</div>
            </div>
            
            <div class="item-actions">
              <el-tooltip content="编辑" placement="top">
                <button class="action-btn" @click="handleEdit(item)">
                  <el-icon><Edit /></el-icon>
                </button>
              </el-tooltip>
              <el-tooltip content="删除" placement="top">
                <button class="action-btn delete" @click="handleDelete(item)">
                  <el-icon><Delete /></el-icon>
                </button>
              </el-tooltip>
            </div>
          </div>
        </div>
        
        <el-empty v-else description="暂无收藏的网址">
          <el-button type="primary" @click="showAddDialog = true">添加第一个网址</el-button>
        </el-empty>
      </div>
      
      <!-- 从系统添加 -->
      <div class="system-websites">
        <div class="section-header">
          <h2 class="section-title">
            <el-icon><Grid /></el-icon>
            从推荐网址添加
          </h2>
        </div>
        
        <div class="recommend-grid">
          <div
            v-for="website in recommendWebsites"
            :key="website.id"
            class="recommend-item"
            @click="handleAddFromSystem(website)"
          >
            <div class="recommend-icon">
              <img 
                v-if="website.icon" 
                :src="website.icon" 
                @error="handleIconError"
              />
              <span v-else>{{ website.name.charAt(0) }}</span>
            </div>
            <span class="recommend-name">{{ website.name }}</span>
            <el-icon class="add-icon"><Plus /></el-icon>
          </div>
        </div>
      </div>
      
      <!-- 底部 -->
      <Footer />
    </div>
    
    <!-- 添加/编辑对话框 -->
    <el-dialog
      v-model="showAddDialog"
      :title="editingItem ? '编辑网址' : '添加网址'"
      width="480px"
      :close-on-click-modal="false"
    >
      <el-form :model="formData" :rules="formRules" ref="formRef" label-width="80px">
        <el-form-item label="网站名称" prop="name">
          <el-input v-model="formData.name" placeholder="请输入网站名称" />
        </el-form-item>
        <el-form-item label="网站URL" prop="url">
          <el-input v-model="formData.url" placeholder="请输入网站URL" />
        </el-form-item>
        <el-form-item label="图标URL" prop="icon">
          <el-input v-model="formData.icon" placeholder="请输入图标URL（可选）" />
        </el-form-item>
        <el-form-item label="描述" prop="description">
          <el-input 
            v-model="formData.description" 
            type="textarea" 
            :rows="2"
            placeholder="请输入网站描述（可选）" 
          />
        </el-form-item>
      </el-form>
      
      <template #footer>
        <el-button @click="showAddDialog = false">取消</el-button>
        <el-button type="primary" @click="handleSubmit">确定</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, nextTick } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { gsap } from 'gsap'
import { useWorkspaceStore } from '@/stores/workspace'
import { useNavStore } from '@/stores/nav'
import Footer from '@/components/common/Footer.vue'
import { 
  Briefcase, Plus, Rank, Edit, Delete, Grid
} from '@element-plus/icons-vue'

const workspaceStore = useWorkspaceStore()
const navStore = useNavStore()

const gridRef = ref(null)
const formRef = ref(null)
const showAddDialog = ref(false)
const editingItem = ref(null)

const formData = ref({
  name: '',
  url: '',
  icon: '',
  description: ''
})

const formRules = {
  name: [
    { required: true, message: '请输入网站名称', trigger: 'blur' }
  ],
  url: [
    { required: true, message: '请输入网站URL', trigger: 'blur' },
    { type: 'url', message: '请输入有效的URL', trigger: 'blur' }
  ]
}

// 推荐网站
const recommendWebsites = computed(() => {
  return navStore.hotWebsites.slice(0, 12)
})

// 跳转网站
const goToWebsite = (item) => {
  window.open(item.url, '_blank')
}

// 编辑
const handleEdit = (item) => {
  editingItem.value = item
  formData.value = {
    name: item.name,
    url: item.url,
    icon: item.icon || '',
    description: item.description || ''
  }
  showAddDialog.value = true
}

// 删除
const handleDelete = async (item) => {
  try {
    await ElMessageBox.confirm(
      `确定要删除"${item.name}"吗？`,
      '删除确认',
      {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }
    )
    
    const success = await workspaceStore.removeWebsite(item.id)
    if (success) {
      ElMessage.success('删除成功')
    }
  } catch (e) {
    // 取消删除
  }
}

// 从系统添加
const handleAddFromSystem = async (website) => {
  const success = await workspaceStore.addFromSystem(website.id)
  if (success) {
    ElMessage.success('添加成功')
  } else {
    ElMessage.warning('添加失败或已存在')
  }
}

// 提交表单
const handleSubmit = async () => {
  if (!formRef.value) return
  
  try {
    await formRef.value.validate()
    
    let success
    if (editingItem.value) {
      success = await workspaceStore.updateWebsite(editingItem.value.id, formData.value)
    } else {
      success = await workspaceStore.addWebsite(formData.value)
    }
    
    if (success) {
      ElMessage.success(editingItem.value ? '更新成功' : '添加成功')
      showAddDialog.value = false
      resetForm()
    }
  } catch (e) {
    // 验证失败
  }
}

// 重置表单
const resetForm = () => {
  editingItem.value = null
  formData.value = {
    name: '',
    url: '',
    icon: '',
    description: ''
  }
}

// 图标错误处理
const handleIconError = (e) => {
  e.target.style.display = 'none'
}

// 初始化拖拽排序
const initSortable = async () => {
  await nextTick()
  
  if (!gridRef.value) return
  
  // 简单的拖拽实现（实际项目中建议使用 Sortable.js 或 vuedraggable）
  const items = gridRef.value.querySelectorAll('.workspace-item')
  items.forEach(item => {
    const handle = item.querySelector('.item-drag-handle')
    
    handle.addEventListener('mousedown', (e) => {
      item.classList.add('dragging')
      
      const onMouseMove = (moveEvent) => {
        // 简化的拖拽效果
      }
      
      const onMouseUp = async () => {
        item.classList.remove('dragging')
        document.removeEventListener('mousemove', onMouseMove)
        document.removeEventListener('mouseup', onMouseUp)
        
        // 获取新排序并更新
        const newOrder = Array.from(gridRef.value.querySelectorAll('.workspace-item'))
          .map(el => Number(el.dataset.id))
        
        await workspaceStore.updateSort(newOrder)
      }
      
      document.addEventListener('mousemove', onMouseMove)
      document.addEventListener('mouseup', onMouseUp)
    })
  })
}

onMounted(() => {
  workspaceStore.fetchWorkspaces()
  navStore.fetchHotWebsites(12)
  
  // 入场动画
  gsap.from('.page-header', {
    opacity: 0,
    y: -20,
    duration: 0.4,
    ease: 'power2.out'
  })
})
</script>

<style lang="scss" scoped>
.customize-page {
  min-height: 100vh;
  display: flex;
  flex-direction: column;
}

.page-container {
  padding: calc(var(--header-height) + 24px) 32px 0;
  max-width: 1200px;
  margin: 0 auto;
  width: 100%;
}

.page-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 32px;
  padding: 24px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  border-radius: 20px;
  color: white;
}

.page-title {
  display: flex;
  align-items: center;
  gap: 10px;
  font-size: 24px;
  font-weight: 600;
  margin-bottom: 6px;
}

.page-desc {
  font-size: 14px;
  opacity: 0.85;
}

.workspace-content {
  background: white;
  border-radius: 16px;
  padding: 24px;
  margin-bottom: 32px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
}

.dark .workspace-content {
  background: #1a1a1a;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.2);
}

.workspace-grid {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.workspace-item {
  display: flex;
  align-items: center;
  gap: 16px;
  padding: 16px;
  background: #f8f9fa;
  border-radius: 14px;
  transition: all 0.2s ease;
  animation: fadeInUp 0.4s ease-out both;
  
  &:hover {
    background: #f0f0f0;
    
    .item-actions {
      opacity: 1;
    }
  }
  
  &.dragging {
    opacity: 0.8;
    box-shadow: 0 8px 30px rgba(0, 0, 0, 0.15);
  }
}

.dark .workspace-item {
  background: #242424;
  
  &:hover {
    background: #2a2a2a;
  }
}

.item-drag-handle {
  cursor: grab;
  padding: 8px;
  color: #999;
  
  &:active {
    cursor: grabbing;
  }
}

.item-icon {
  width: 48px;
  height: 48px;
  border-radius: 12px;
  overflow: hidden;
  cursor: pointer;
  flex-shrink: 0;
  
  img {
    width: 100%;
    height: 100%;
    object-fit: cover;
  }
  
  .icon-text {
    width: 100%;
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    font-size: 20px;
    font-weight: 600;
  }
}

.item-info {
  flex: 1;
  min-width: 0;
  cursor: pointer;
}

.item-name {
  font-size: 15px;
  font-weight: 500;
  color: #333;
  margin-bottom: 4px;
}

.dark .item-name {
  color: #e5e5e5;
}

.item-url {
  font-size: 13px;
  color: #999;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.item-actions {
  display: flex;
  gap: 8px;
  opacity: 0;
  transition: opacity 0.2s ease;
}

.action-btn {
  width: 32px;
  height: 32px;
  border: none;
  background: #e5e5e5;
  border-radius: 8px;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #666;
  transition: all 0.2s ease;
  
  &:hover {
    background: #d5d5d5;
    color: #333;
  }
  
  &.delete:hover {
    background: #fee2e2;
    color: #ef4444;
  }
}

.dark .action-btn {
  background: #3a3a3a;
  color: #a3a3a3;
  
  &:hover {
    background: #4a4a4a;
    color: #e5e5e5;
  }
  
  &.delete:hover {
    background: rgba(239, 68, 68, 0.2);
    color: #f87171;
  }
}

// 系统网站推荐
.system-websites {
  margin-bottom: 32px;
}

.section-header {
  margin-bottom: 16px;
}

.section-title {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 18px;
  font-weight: 600;
  color: #333;
  
  .el-icon {
    color: #667eea;
  }
}

.dark .section-title {
  color: #e5e5e5;
  
  .el-icon {
    color: #818cf8;
  }
}

.recommend-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(140px, 1fr));
  gap: 12px;
}

.recommend-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
  padding: 16px;
  background: white;
  border-radius: 12px;
  cursor: pointer;
  transition: all 0.2s ease;
  position: relative;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
  
  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 30px rgba(0, 0, 0, 0.1);
    
    .add-icon {
      opacity: 1;
      transform: scale(1);
    }
  }
}

.dark .recommend-item {
  background: #1a1a1a;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.2);
  
  &:hover {
    box-shadow: 0 8px 30px rgba(0, 0, 0, 0.3);
  }
}

.recommend-icon {
  width: 44px;
  height: 44px;
  border-radius: 12px;
  overflow: hidden;
  
  img {
    width: 100%;
    height: 100%;
    object-fit: cover;
  }
  
  span {
    width: 100%;
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    font-size: 18px;
    font-weight: 600;
  }
}

.recommend-name {
  font-size: 13px;
  color: #333;
  text-align: center;
}

.dark .recommend-name {
  color: #e5e5e5;
}

.add-icon {
  position: absolute;
  top: 8px;
  right: 8px;
  width: 20px;
  height: 20px;
  background: #667eea;
  border-radius: 50%;
  color: white;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 12px;
  opacity: 0;
  transform: scale(0.8);
  transition: all 0.2s ease;
}

.loading-state {
  padding: 20px;
}

@keyframes fadeInUp {
  from {
    opacity: 0;
    transform: translateY(15px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

@media (max-width: 768px) {
  .page-container {
    padding: calc(var(--header-height) + 16px) 16px 0;
  }
  
  .page-header {
    flex-direction: column;
    text-align: center;
    gap: 16px;
  }
  
  .item-actions {
    opacity: 1;
  }
  
  .recommend-grid {
    grid-template-columns: repeat(3, 1fr);
  }
}
</style>

