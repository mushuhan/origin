<template>
  <div class="search-page">
    <div class="page-container">
      <!-- 搜索头部 -->
      <div class="search-header">
        <div class="search-box">
          <el-input
            v-model="keyword"
            size="large"
            placeholder="搜索网址..."
            clearable
            @keydown.enter="handleSearch"
          >
            <template #prefix>
              <el-icon><Search /></el-icon>
            </template>
            <template #append>
              <el-button type="primary" @click="handleSearch">搜索</el-button>
            </template>
          </el-input>
        </div>
        
        <div class="search-info" v-if="searchResult">
          找到 <span class="highlight">{{ searchResult.total }}</span> 个与 
          "<span class="highlight">{{ searchResult.keyword }}</span>" 相关的网址
        </div>
      </div>
      
      <!-- 搜索结果 -->
      <div class="search-content">
        <div v-if="loading" class="loading-state">
          <el-skeleton :rows="6" animated />
        </div>
        
        <div v-else-if="searchResult?.websites?.length" class="result-grid">
          <div
            v-for="(website, index) in searchResult.websites"
            :key="website.id"
            class="result-item"
            :style="{ animationDelay: `${index * 0.05}s` }"
            @click="goToWebsite(website)"
          >
            <div class="result-icon">
              <img 
                v-if="website.icon" 
                :src="website.icon" 
                :alt="website.name"
                @error="handleIconError"
              />
              <span v-else class="icon-text">
                {{ website.name.charAt(0).toUpperCase() }}
              </span>
            </div>
            
            <div class="result-info">
              <div class="result-name" v-html="highlightKeyword(website.name)"></div>
              <div class="result-desc" v-html="highlightKeyword(website.description || '')"></div>
              <div class="result-url">{{ website.url }}</div>
            </div>
            
            <div class="result-action">
              <el-button 
                type="primary" 
                size="small"
                plain
                @click.stop="handleAddToWorkspace(website)"
              >
                <el-icon><Plus /></el-icon>
                收藏
              </el-button>
            </div>
          </div>
        </div>
        
        <el-empty 
          v-else-if="searchResult && !searchResult.websites?.length" 
          description="未找到相关网址"
        >
          <el-button type="primary" @click="searchWithEngine">
            使用搜索引擎搜索
          </el-button>
        </el-empty>
        
        <!-- 无搜索时显示热门搜索 -->
        <div v-else class="hot-searches">
          <h3 class="hot-title">热门搜索</h3>
          <div class="hot-tags">
            <span 
              v-for="(hot, index) in hotSearches" 
              :key="hot.id"
              class="hot-tag"
              @click="keyword = hot.keyword; handleSearch()"
            >
              <span class="tag-index" :class="{ top: index < 3 }">{{ index + 1 }}</span>
              {{ hot.keyword }}
            </span>
          </div>
        </div>
      </div>
      
      <!-- 底部 -->
      <Footer />
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import { gsap } from 'gsap'
import { searchWebsites, getHotSearches } from '@/api/search'
import { clickWebsite } from '@/api/website'
import { useWorkspaceStore } from '@/stores/workspace'
import Footer from '@/components/common/Footer.vue'
import { Search, Plus } from '@element-plus/icons-vue'

const route = useRoute()
const router = useRouter()
const workspaceStore = useWorkspaceStore()

const keyword = ref('')
const searchResult = ref(null)
const hotSearches = ref([])
const loading = ref(false)

// 高亮关键词
const highlightKeyword = (text) => {
  if (!text || !keyword.value) return text
  const regex = new RegExp(`(${keyword.value})`, 'gi')
  return text.replace(regex, '<mark>$1</mark>')
}

// 搜索
const handleSearch = async () => {
  if (!keyword.value.trim()) {
    ElMessage.warning('请输入搜索关键词')
    return
  }
  
  // 更新URL
  router.push({ query: { q: keyword.value } })
  
  loading.value = true
  try {
    const res = await searchWebsites(keyword.value, 30)
    if (res.code === 200) {
      searchResult.value = res.data
    }
  } catch (error) {
    console.error('搜索失败:', error)
    ElMessage.error('搜索失败')
  } finally {
    loading.value = false
  }
}

// 使用搜索引擎搜索
const searchWithEngine = () => {
  window.open(`https://www.baidu.com/s?wd=${encodeURIComponent(keyword.value)}`, '_blank')
}

// 跳转网站
const goToWebsite = (website) => {
  clickWebsite(website.id)
  window.open(website.url, '_blank')
}

// 添加到工作台
const handleAddToWorkspace = async (website) => {
  const success = await workspaceStore.addFromSystem(website.id)
  if (success) {
    ElMessage.success('已添加到工作台')
  } else {
    ElMessage.warning('添加失败或已存在')
  }
}

// 图标错误处理
const handleIconError = (e) => {
  e.target.style.display = 'none'
}

// 获取热门搜索
const fetchHotSearches = async () => {
  try {
    const res = await getHotSearches(10)
    if (res.code === 200) {
      hotSearches.value = res.data || []
    }
  } catch (error) {
    console.error('获取热门搜索失败:', error)
  }
}

// 监听URL参数
watch(() => route.query.q, (q) => {
  if (q) {
    keyword.value = q
    handleSearch()
  }
}, { immediate: true })

onMounted(() => {
  fetchHotSearches()
  
  // 入场动画
  gsap.from('.search-header', {
    opacity: 0,
    y: -20,
    duration: 0.4,
    ease: 'power2.out'
  })
})
</script>

<style lang="scss" scoped>
.search-page {
  min-height: 100vh;
  display: flex;
  flex-direction: column;
}

.page-container {
  padding: calc(var(--header-height) + 24px) 32px 0;
  max-width: 900px;
  margin: 0 auto;
  width: 100%;
}

.search-header {
  margin-bottom: 32px;
}

.search-box {
  margin-bottom: 16px;
  
  :deep(.el-input-group__append) {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    border: none;
    
    .el-button {
      background: transparent;
      border: none;
      color: white;
    }
  }
  
  :deep(.el-input__wrapper) {
    border-radius: 12px 0 0 12px;
  }
}

.search-info {
  font-size: 14px;
  color: #666;
  
  .highlight {
    color: #667eea;
    font-weight: 500;
  }
}

.dark .search-info {
  color: #a3a3a3;
  
  .highlight {
    color: #818cf8;
  }
}

.search-content {
  margin-bottom: 32px;
}

.result-grid {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.result-item {
  display: flex;
  align-items: center;
  gap: 16px;
  padding: 20px;
  background: white;
  border-radius: 14px;
  cursor: pointer;
  transition: all 0.2s ease;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
  animation: fadeInUp 0.4s ease-out both;
  
  &:hover {
    box-shadow: 0 8px 30px rgba(0, 0, 0, 0.08);
    transform: translateY(-2px);
    
    .result-action {
      opacity: 1;
    }
  }
}

.dark .result-item {
  background: #1a1a1a;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.2);
  
  &:hover {
    box-shadow: 0 8px 30px rgba(0, 0, 0, 0.3);
  }
}

.result-icon {
  width: 52px;
  height: 52px;
  border-radius: 14px;
  overflow: hidden;
  flex-shrink: 0;
  
  img {
    width: 100%;
    height: 100%;
    object-fit: cover;
  }
  
  .icon-text {
    width: 100%;
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    font-size: 22px;
    font-weight: 600;
  }
}

.result-info {
  flex: 1;
  min-width: 0;
}

.result-name {
  font-size: 16px;
  font-weight: 500;
  color: #333;
  margin-bottom: 4px;
  
  :deep(mark) {
    background: rgba(102, 126, 234, 0.2);
    color: #667eea;
    padding: 0 2px;
    border-radius: 2px;
  }
}

.dark .result-name {
  color: #e5e5e5;
  
  :deep(mark) {
    background: rgba(129, 140, 248, 0.2);
    color: #818cf8;
  }
}

.result-desc {
  font-size: 13px;
  color: #666;
  margin-bottom: 4px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  
  :deep(mark) {
    background: rgba(102, 126, 234, 0.2);
    color: #667eea;
    padding: 0 2px;
    border-radius: 2px;
  }
}

.dark .result-desc {
  color: #a3a3a3;
}

.result-url {
  font-size: 12px;
  color: #999;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.result-action {
  opacity: 0;
  transition: opacity 0.2s ease;
}

// 热门搜索
.hot-searches {
  background: white;
  border-radius: 16px;
  padding: 24px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
}

.dark .hot-searches {
  background: #1a1a1a;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.2);
}

.hot-title {
  font-size: 16px;
  font-weight: 600;
  color: #333;
  margin-bottom: 16px;
}

.dark .hot-title {
  color: #e5e5e5;
}

.hot-tags {
  display: flex;
  flex-wrap: wrap;
  gap: 12px;
}

.hot-tag {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  padding: 8px 16px;
  background: #f5f5f5;
  border-radius: 20px;
  font-size: 14px;
  color: #666;
  cursor: pointer;
  transition: all 0.2s ease;
  
  &:hover {
    background: #e5e5e5;
    color: #333;
  }
  
  .tag-index {
    width: 20px;
    height: 20px;
    border-radius: 4px;
    background: #ddd;
    color: #666;
    font-size: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    
    &.top {
      background: linear-gradient(135deg, #ff6b6b 0%, #ffa502 100%);
      color: white;
    }
  }
}

.dark .hot-tag {
  background: #2a2a2a;
  color: #a3a3a3;
  
  &:hover {
    background: #3a3a3a;
    color: #e5e5e5;
  }
  
  .tag-index {
    background: #3a3a3a;
    color: #a3a3a3;
  }
}

.loading-state {
  padding: 40px;
  background: white;
  border-radius: 16px;
}

.dark .loading-state {
  background: #1a1a1a;
}

@keyframes fadeInUp {
  from {
    opacity: 0;
    transform: translateY(15px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

@media (max-width: 768px) {
  .page-container {
    padding: calc(var(--header-height) + 16px) 16px 0;
  }
  
  .result-action {
    opacity: 1;
  }
}
</style>

