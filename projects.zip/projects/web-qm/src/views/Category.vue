<template>
  <div class="category-page">
    <div class="page-container">
      <!-- 顶部导航 -->
      <div class="page-header">
        <div class="header-left">
          <button class="back-btn" @click="$router.push('/')">
            <el-icon><ArrowLeft /></el-icon>
            返回首页
          </button>
        </div>
        
        <div class="header-center" v-if="category">
          <el-icon class="category-icon">
            <component :is="getCategoryIcon(category.icon)" />
          </el-icon>
          <h1 class="page-title">{{ category.name }}</h1>
        </div>
        
        <div class="header-right">
          <el-input
            v-model="searchKeyword"
            placeholder="在此分类中搜索..."
            prefix-icon="Search"
            clearable
            class="category-search"
          />
        </div>
      </div>
      
      <!-- 加载状态 -->
      <div v-if="navStore.loading" class="loading-state">
        <el-skeleton :rows="10" animated />
      </div>
      
      <!-- 分类内容 -->
      <div v-else-if="category" class="category-content">
        <div class="category-desc" v-if="category.description">
          {{ category.description }}
        </div>
        
        <!-- 分区列表 -->
        <div 
          v-for="(section, index) in filteredSections" 
          :key="section.id"
          class="section-block"
          :style="{ animationDelay: `${index * 0.1}s` }"
        >
          <div class="section-header">
            <h2 class="section-title">{{ section.name }}</h2>
            <span class="section-count">{{ section.websites?.length || 0 }}个网站</span>
          </div>
          
          <div class="website-grid">
            <div
              v-for="(website, wIndex) in section.websites"
              :key="website.id"
              class="website-item"
              :style="{ animationDelay: `${wIndex * 0.03}s` }"
              @click="goToWebsite(website)"
              @contextmenu.prevent="handleContextMenu(website, $event)"
            >
              <div class="website-icon">
                <img 
                  v-if="website.icon" 
                  :src="website.icon" 
                  :alt="website.name"
                  @error="handleIconError"
                />
                <span v-else class="icon-text">
                  {{ website.name.charAt(0).toUpperCase() }}
                </span>
                <span v-if="website.isHot" class="hot-badge">
                  <el-icon :size="8"><Star /></el-icon>
                </span>
              </div>
              <div class="website-info">
                <div class="website-name">{{ website.name }}</div>
                <div class="website-desc">{{ website.description || website.url }}</div>
              </div>
            </div>
          </div>
        </div>
        
        <el-empty v-if="!filteredSections.length" description="该分类下暂无网站" />
      </div>
      
      <el-empty v-else description="分类不存在" />
      
      <!-- 底部 -->
      <Footer />
    </div>
    
    <!-- 右键菜单 -->
    <el-dropdown
      ref="contextMenuRef"
      trigger="contextmenu"
      :teleported="true"
      @command="handleCommand"
    >
      <span style="position: fixed; visibility: hidden;"></span>
      <template #dropdown>
        <el-dropdown-menu>
          <el-dropdown-item command="open">
            <el-icon><Link /></el-icon>
            在新标签页打开
          </el-dropdown-item>
          <el-dropdown-item command="copy">
            <el-icon><CopyDocument /></el-icon>
            复制链接
          </el-dropdown-item>
          <el-dropdown-item command="workspace">
            <el-icon><Plus /></el-icon>
            添加到工作台
          </el-dropdown-item>
        </el-dropdown-menu>
      </template>
    </el-dropdown>
  </div>
</template>

<script setup>
import { ref, computed, watch, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import { gsap } from 'gsap'
import { useNavStore } from '@/stores/nav'
import { useWorkspaceStore } from '@/stores/workspace'
import { clickWebsite } from '@/api/website'
import Footer from '@/components/common/Footer.vue'
import { 
  ArrowLeft, Star, Link, CopyDocument, Plus,
  StarFilled, Document, Cpu, Brush, Lightning, 
  Reading, Headset, Tickets, Grid
} from '@element-plus/icons-vue'

const route = useRoute()
const router = useRouter()
const navStore = useNavStore()
const workspaceStore = useWorkspaceStore()

const searchKeyword = ref('')
const contextMenuRef = ref(null)
const selectedWebsite = ref(null)

const category = computed(() => navStore.currentCategory)

// 过滤分区
const filteredSections = computed(() => {
  if (!category.value?.sections) return []
  
  if (!searchKeyword.value.trim()) {
    return category.value.sections
  }
  
  const keyword = searchKeyword.value.toLowerCase()
  return category.value.sections
    .map(section => ({
      ...section,
      websites: section.websites?.filter(w => 
        w.name.toLowerCase().includes(keyword) ||
        w.description?.toLowerCase().includes(keyword) ||
        w.url.toLowerCase().includes(keyword)
      )
    }))
    .filter(section => section.websites?.length > 0)
})

// 获取分类图标
const getCategoryIcon = (iconName) => {
  const iconMap = {
    'Star': StarFilled,
    'Code': Cpu,
    'Palette': Brush,
    'Zap': Lightning,
    'GraduationCap': Reading,
    'Music': Headset,
    'Newspaper': Tickets
  }
  return iconMap[iconName] || Grid
}

// 跳转网站
const goToWebsite = (website) => {
  clickWebsite(website.id)
  window.open(website.url, '_blank')
}

// 右键菜单
const handleContextMenu = (website, event) => {
  selectedWebsite.value = website
}

// 处理命令
const handleCommand = async (command) => {
  if (!selectedWebsite.value) return
  
  switch (command) {
    case 'open':
      goToWebsite(selectedWebsite.value)
      break
    case 'copy':
      await navigator.clipboard.writeText(selectedWebsite.value.url)
      ElMessage.success('链接已复制')
      break
    case 'workspace':
      const success = await workspaceStore.addFromSystem(selectedWebsite.value.id)
      if (success) {
        ElMessage.success('已添加到工作台')
      } else {
        ElMessage.warning('添加失败或已存在')
      }
      break
  }
}

// 图标错误处理
const handleIconError = (e) => {
  e.target.style.display = 'none'
}

// 监听路由变化
watch(() => route.params.id, (id) => {
  if (id) {
    navStore.fetchCategoryDetail(id)
  }
}, { immediate: true })

onMounted(() => {
  // 入场动画
  gsap.from('.page-header', {
    opacity: 0,
    y: -20,
    duration: 0.4,
    ease: 'power2.out'
  })
})
</script>

<style lang="scss" scoped>
.category-page {
  min-height: 100vh;
  display: flex;
  flex-direction: column;
}

.page-container {
  padding: calc(var(--header-height) + 24px) 32px 0;
  max-width: 1400px;
  margin: 0 auto;
  width: 100%;
}

.page-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 32px;
  padding: 20px 24px;
  background: white;
  border-radius: 16px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
}

.dark .page-header {
  background: #1a1a1a;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.2);
}

.back-btn {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 8px 16px;
  border: none;
  background: #f5f5f5;
  border-radius: 8px;
  font-size: 14px;
  color: #666;
  cursor: pointer;
  transition: all 0.2s ease;
  
  &:hover {
    background: #e5e5e5;
    color: #333;
  }
}

.dark .back-btn {
  background: #2a2a2a;
  color: #a3a3a3;
  
  &:hover {
    background: #3a3a3a;
    color: #e5e5e5;
  }
}

.header-center {
  display: flex;
  align-items: center;
  gap: 12px;
  
  .category-icon {
    font-size: 24px;
    color: #667eea;
  }
  
  .page-title {
    font-size: 22px;
    font-weight: 600;
    color: #333;
  }
}

.dark .header-center {
  .category-icon {
    color: #818cf8;
  }
  
  .page-title {
    color: #e5e5e5;
  }
}

.category-search {
  width: 240px;
  
  :deep(.el-input__wrapper) {
    border-radius: 10px;
  }
}

.category-desc {
  padding: 16px 20px;
  background: linear-gradient(135deg, rgba(102, 126, 234, 0.1) 0%, rgba(118, 75, 162, 0.1) 100%);
  border-radius: 12px;
  margin-bottom: 24px;
  color: #666;
  font-size: 14px;
}

.dark .category-desc {
  color: #a3a3a3;
}

.section-block {
  margin-bottom: 32px;
  animation: fadeInUp 0.5s ease-out both;
}

.section-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 16px;
}

.section-title {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 18px;
  font-weight: 600;
  color: #333;
  
  &::before {
    content: '';
    width: 4px;
    height: 18px;
    background: linear-gradient(180deg, #667eea 0%, #764ba2 100%);
    border-radius: 2px;
  }
}

.dark .section-title {
  color: #e5e5e5;
}

.section-count {
  font-size: 12px;
  color: #999;
}

.website-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
  gap: 12px;
}

.website-item {
  display: flex;
  align-items: center;
  gap: 14px;
  padding: 16px;
  background: white;
  border-radius: 14px;
  cursor: pointer;
  transition: all 0.2s ease;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
  animation: fadeInUp 0.4s ease-out both;
  
  &:hover {
    box-shadow: 0 8px 30px rgba(0, 0, 0, 0.08);
    transform: translateY(-2px);
    
    .website-icon img,
    .website-icon .icon-text {
      transform: scale(1.08);
    }
  }
}

.dark .website-item {
  background: #1a1a1a;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.2);
  
  &:hover {
    box-shadow: 0 8px 30px rgba(0, 0, 0, 0.3);
  }
}

.website-icon {
  position: relative;
  width: 52px;
  height: 52px;
  border-radius: 14px;
  overflow: hidden;
  flex-shrink: 0;
  
  img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform 0.2s ease;
  }
  
  .icon-text {
    width: 100%;
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    font-size: 22px;
    font-weight: 600;
    transition: transform 0.2s ease;
  }
  
  .hot-badge {
    position: absolute;
    top: -2px;
    right: -2px;
    width: 16px;
    height: 16px;
    background: linear-gradient(135deg, #ff6b6b 0%, #ffa502 100%);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
  }
}

.website-info {
  flex: 1;
  min-width: 0;
}

.website-name {
  font-size: 15px;
  font-weight: 500;
  color: #333;
  margin-bottom: 4px;
}

.dark .website-name {
  color: #e5e5e5;
}

.website-desc {
  font-size: 13px;
  color: #999;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.loading-state {
  padding: 40px;
  background: white;
  border-radius: 16px;
}

.dark .loading-state {
  background: #1a1a1a;
}

@keyframes fadeInUp {
  from {
    opacity: 0;
    transform: translateY(15px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

@media (max-width: 768px) {
  .page-container {
    padding: calc(var(--header-height) + 16px) 16px 0;
  }
  
  .page-header {
    flex-direction: column;
    gap: 16px;
    text-align: center;
  }
  
  .category-search {
    width: 100%;
  }
  
  .website-grid {
    grid-template-columns: 1fr;
  }
}
</style>

