<template>
  <div :class="['main-layout', { dark: isDark }]">
    <!-- 侧边栏 -->
    <Sidebar 
      :collapsed="sidebarCollapsed" 
      @toggle="toggleSidebar"
    />
    
    <!-- 主内容区 -->
    <div :class="['main-content', { collapsed: sidebarCollapsed }]">
      <!-- 顶部栏 -->
      <Header 
        :collapsed="sidebarCollapsed"
        @toggle-sidebar="toggleSidebar"
        @toggle-dark="toggleDark"
      />
      
      <!-- 路由视图 -->
      <router-view v-slot="{ Component }">
        <transition name="fade" mode="out-in">
          <component :is="Component" />
        </transition>
      </router-view>
    </div>
    
    <!-- 移动端遮罩 -->
    <div 
      v-if="showMobileOverlay" 
      class="mobile-overlay"
      @click="closeMobileSidebar"
    ></div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, watch } from 'vue'
import { useAppStore } from '@/stores/app'
import Sidebar from '@/components/layout/Sidebar.vue'
import Header from '@/components/layout/Header.vue'

const appStore = useAppStore()
const sidebarCollapsed = ref(false)

const isDark = computed(() => appStore.isDark)
const showMobileOverlay = computed(() => {
  return window.innerWidth <= 768 && !sidebarCollapsed.value
})

const toggleSidebar = () => {
  sidebarCollapsed.value = !sidebarCollapsed.value
}

const toggleDark = () => {
  appStore.toggleDark()
}

const closeMobileSidebar = () => {
  if (window.innerWidth <= 768) {
    sidebarCollapsed.value = true
  }
}

// 监听暗色模式变化
watch(isDark, (val) => {
  if (val) {
    document.documentElement.classList.add('dark')
    document.body.classList.add('dark')
  } else {
    document.documentElement.classList.remove('dark')
    document.body.classList.remove('dark')
  }
}, { immediate: true })

onMounted(() => {
  // 初始化系统配置
  appStore.fetchConfig()
  
  // 响应式处理
  const handleResize = () => {
    if (window.innerWidth <= 768) {
      sidebarCollapsed.value = true
    }
  }
  
  handleResize()
  window.addEventListener('resize', handleResize)
})
</script>

<style scoped>
.mobile-overlay {
  position: fixed;
  inset: 0;
  background: rgba(0, 0, 0, 0.5);
  z-index: 40;
  display: none;
}

@media (max-width: 768px) {
  .mobile-overlay {
    display: block;
  }
}
</style>
