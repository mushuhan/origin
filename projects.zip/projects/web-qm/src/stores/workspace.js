import { defineStore } from 'pinia'
import { ref } from 'vue'
import { useAppStore } from './app'
import { 
  getUserWorkspace, 
  addToWorkspace, 
  addFromWebsite,
  updateWorkspace,
  updateWorkspaceSortOrder,
  removeFromWorkspace 
} from '@/api/workspace'

export const useWorkspaceStore = defineStore('workspace', () => {
  // 状态
  const workspaces = ref([])
  const loading = ref(false)
  
  // 获取用户工作台
  async function fetchWorkspaces() {
    const appStore = useAppStore()
    loading.value = true
    try {
      const res = await getUserWorkspace(appStore.userId)
      if (res.code === 200) {
        workspaces.value = res.data
      }
    } catch (error) {
      console.error('获取工作台失败:', error)
    } finally {
      loading.value = false
    }
  }
  
  // 添加网址到工作台
  async function addWebsite(data) {
    const appStore = useAppStore()
    try {
      const res = await addToWorkspace({
        userId: appStore.userId,
        ...data
      })
      if (res.code === 200) {
        await fetchWorkspaces()
        return true
      }
      return false
    } catch (error) {
      console.error('添加网址失败:', error)
      return false
    }
  }
  
  // 从系统网站添加到工作台
  async function addFromSystem(websiteId) {
    const appStore = useAppStore()
    try {
      const res = await addFromWebsite(appStore.userId, websiteId)
      if (res.code === 200) {
        await fetchWorkspaces()
        return true
      }
      return false
    } catch (error) {
      console.error('添加网址失败:', error)
      return false
    }
  }
  
  // 更新工作台网址
  async function updateWebsite(id, data) {
    try {
      const res = await updateWorkspace(id, data)
      if (res.code === 200) {
        await fetchWorkspaces()
        return true
      }
      return false
    } catch (error) {
      console.error('更新网址失败:', error)
      return false
    }
  }
  
  // 更新排序
  async function updateSort(ids) {
    const appStore = useAppStore()
    try {
      const res = await updateWorkspaceSortOrder(appStore.userId, ids)
      if (res.code === 200) {
        return true
      }
      return false
    } catch (error) {
      console.error('更新排序失败:', error)
      return false
    }
  }
  
  // 删除网址
  async function removeWebsite(id) {
    const appStore = useAppStore()
    try {
      const res = await removeFromWorkspace(appStore.userId, id)
      if (res.code === 200) {
        workspaces.value = workspaces.value.filter(w => w.id !== id)
        return true
      }
      return false
    } catch (error) {
      console.error('删除网址失败:', error)
      return false
    }
  }
  
  return {
    workspaces,
    loading,
    fetchWorkspaces,
    addWebsite,
    addFromSystem,
    updateWebsite,
    updateSort,
    removeWebsite
  }
})

