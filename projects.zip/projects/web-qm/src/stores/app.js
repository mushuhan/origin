import { defineStore } from 'pinia'
import { ref, watch } from 'vue'
import { getConfig } from '@/api/config'

export const useAppStore = defineStore('app', () => {
  // 状态
  const isDark = ref(false)
  const siteConfig = ref({
    site_name: '网址导航',
    site_logo: '/logo.svg',
    site_description: '一站式网址导航系统',
    copyright: '© 2024 网址导航 All Rights Reserved',
    footer_links: [],
    social_links: []
  })
  
  // 用户ID（基于浏览器存储）
  const userId = ref(localStorage.getItem('nav_user_id') || generateUserId())
  
  // 生成用户ID
  function generateUserId() {
    const id = 'user_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9)
    localStorage.setItem('nav_user_id', id)
    return id
  }
  
  // 切换暗色模式
  function toggleDark() {
    isDark.value = !isDark.value
    localStorage.setItem('nav_dark_mode', isDark.value ? '1' : '0')
  }
  
  // 获取系统配置
  async function fetchConfig() {
    try {
      const res = await getConfig()
      if (res.code === 200 && res.data) {
        Object.assign(siteConfig.value, res.data)
        // 解析JSON字符串
        if (typeof siteConfig.value.footer_links === 'string') {
          try {
            siteConfig.value.footer_links = JSON.parse(siteConfig.value.footer_links)
          } catch (e) {
            siteConfig.value.footer_links = []
          }
        }
        if (typeof siteConfig.value.social_links === 'string') {
          try {
            siteConfig.value.social_links = JSON.parse(siteConfig.value.social_links)
          } catch (e) {
            siteConfig.value.social_links = []
          }
        }
      }
    } catch (error) {
      console.error('获取配置失败:', error)
    }
  }
  
  // 初始化暗色模式
  const savedDark = localStorage.getItem('nav_dark_mode')
  if (savedDark !== null) {
    isDark.value = savedDark === '1'
  } else {
    // 跟随系统
    isDark.value = window.matchMedia('(prefers-color-scheme: dark)').matches
  }
  
  return {
    isDark,
    siteConfig,
    userId,
    toggleDark,
    fetchConfig
  }
})

