import { defineStore } from 'pinia'
import { ref } from 'vue'
import { getCategories, getAllCategoriesWithContent, getCategoryDetail } from '@/api/category'
import { getHotWebsites } from '@/api/website'
import { getSearchEngines } from '@/api/search'

export const useNavStore = defineStore('nav', () => {
  // 状态
  const categories = ref([])
  const categoriesWithContent = ref([])
  const currentCategory = ref(null)
  const hotWebsites = ref([])
  const searchEngines = ref([])
  const loading = ref(false)
  
  // 获取分类列表
  async function fetchCategories() {
    try {
      const res = await getCategories()
      if (res.code === 200) {
        categories.value = res.data
      }
    } catch (error) {
      console.error('获取分类失败:', error)
    }
  }
  
  // 获取所有分类及内容
  async function fetchAllCategoriesWithContent() {
    loading.value = true
    try {
      const res = await getAllCategoriesWithContent()
      if (res.code === 200) {
        categoriesWithContent.value = res.data
      }
    } catch (error) {
      console.error('获取分类内容失败:', error)
    } finally {
      loading.value = false
    }
  }
  
  // 获取分类详情
  async function fetchCategoryDetail(id) {
    loading.value = true
    try {
      const res = await getCategoryDetail(id)
      if (res.code === 200) {
        currentCategory.value = res.data
      }
    } catch (error) {
      console.error('获取分类详情失败:', error)
    } finally {
      loading.value = false
    }
  }
  
  // 获取热门网站
  async function fetchHotWebsites(limit = 20) {
    try {
      const res = await getHotWebsites(limit)
      if (res.code === 200) {
        hotWebsites.value = res.data
      }
    } catch (error) {
      console.error('获取热门网站失败:', error)
    }
  }
  
  // 获取搜索引擎列表
  async function fetchSearchEngines() {
    try {
      const res = await getSearchEngines()
      if (res.code === 200) {
        searchEngines.value = res.data
      }
    } catch (error) {
      console.error('获取搜索引擎失败:', error)
    }
  }
  
  return {
    categories,
    categoriesWithContent,
    currentCategory,
    hotWebsites,
    searchEngines,
    loading,
    fetchCategories,
    fetchAllCategoriesWithContent,
    fetchCategoryDetail,
    fetchHotWebsites,
    fetchSearchEngines
  }
})

