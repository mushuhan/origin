import { fileURLToPath, URL } from 'node:url'
import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'

export default defineConfig({
  plugins: [vue()],
  resolve: {
    alias: {
      '@': fileURLToPath(new URL('./src', import.meta.url))
    }
  },
  server: {
    port: 3000,
    proxy: {
      // 所有API请求代理到网关
      '/api': {
        target: 'http://localhost:8080',
        changeOrigin: true
      },
      // API文档代理
      '/doc.html': {
        target: 'http://localhost:8081',
        changeOrigin: true
      },
      '/v3/api-docs': {
        target: 'http://localhost:8081',
        changeOrigin: true
      },
      '/webjars': {
        target: 'http://localhost:8081',
        changeOrigin: true
      }
    }
  }
})
