package com.yinwang.gateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * 网关服务启动类
 */
@SpringBootApplication
public class GatewayApplication {
    public static void main(String[] args) {
        SpringApplication.run(GatewayApplication.class, args);
        System.out.println("=================================");
        System.out.println("  Gateway 网关服务启动成功!");
        System.out.println("  端口: 8080");
        System.out.println("  路由: /api/** -> nav-service:8081");
        System.out.println("=================================");
    }
}

