package com.yinwang.gateway.filter;

import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.core.Ordered;
import org.springframework.http.HttpHeaders;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

import java.util.List;

/**
 * 全局认证过滤器（预留）
 * 当前系统不需要登录，此过滤器预留用于后续扩展
 */
@Slf4j
@Component
public class AuthGlobalFilter implements GlobalFilter, Ordered {
    
    // 白名单路径（不需要认证）
    private static final List<String> WHITE_LIST = List.of(
            "/api/categories",
            "/api/websites",
            "/api/search",
            "/api/config",
            "/api/workspace",
            "/doc.html",
            "/webjars",
            "/v3/api-docs",
            "/swagger-resources"
    );
    
    @Override
    public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {
        ServerHttpRequest request = exchange.getRequest();
        String path = request.getURI().getPath();
        
        // 检查是否在白名单中
        boolean isWhiteListed = WHITE_LIST.stream().anyMatch(path::startsWith);
        
        if (isWhiteListed) {
            return chain.filter(exchange);
        }
        
        // 获取请求头中的认证信息（预留）
        HttpHeaders headers = request.getHeaders();
        String authorization = headers.getFirst("Authorization");
        
        // 当前不做认证，直接放行
        // 后续可在此添加JWT验证等逻辑
        
        return chain.filter(exchange);
    }
    
    @Override
    public int getOrder() {
        return -50;
    }
}

