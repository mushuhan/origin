package com.yinwang.gateway.filter;

import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.core.Ordered;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

/**
 * 全局日志过滤器
 */
@Slf4j
@Component
public class LoggingGlobalFilter implements GlobalFilter, Ordered {
    
    @Override
    public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {
        ServerHttpRequest request = exchange.getRequest();
        
        long startTime = System.currentTimeMillis();
        String requestId = java.util.UUID.randomUUID().toString().substring(0, 8);
        
        log.info("[{}] 请求开始: {} {}", 
                requestId, 
                request.getMethod(), 
                request.getURI().getPath());
        
        return chain.filter(exchange).then(Mono.fromRunnable(() -> {
            long endTime = System.currentTimeMillis();
            log.info("[{}] 请求完成: {} {} - {}ms - 状态: {}", 
                    requestId,
                    request.getMethod(), 
                    request.getURI().getPath(),
                    (endTime - startTime),
                    exchange.getResponse().getStatusCode());
        }));
    }
    
    @Override
    public int getOrder() {
        return -100;
    }
}

