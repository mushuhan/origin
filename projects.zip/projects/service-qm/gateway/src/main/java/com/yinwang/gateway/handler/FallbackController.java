package com.yinwang.gateway.handler;

import com.yinwang.common.result.Result;
import com.yinwang.common.result.ResultCode;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

/**
 * 熔断降级处理器
 */
@Slf4j
@RestController
@RequestMapping("/fallback")
public class FallbackController {
    
    @GetMapping("/nav")
    public Mono<Result<Void>> navFallback() {
        log.warn("导航服务熔断降级");
        return Mono.just(Result.error(ResultCode.SERVICE_UNAVAILABLE.getCode(), 
                "导航服务暂时不可用，请稍后重试"));
    }
}

