-- =====================================================
-- 网址导航系统数据库初始化脚本
-- Database: MySQL 8.0+
-- =====================================================

-- 创建数据库
CREATE DATABASE IF NOT EXISTS `nav_system` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE `nav_system`;

-- =====================================================
-- 1. 分类表 (categories)
-- =====================================================
DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
    `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '分类ID',
    `name` VARCHAR(100) NOT NULL COMMENT '分类名称',
    `icon` VARCHAR(255) DEFAULT NULL COMMENT '分类图标',
    `description` VARCHAR(500) DEFAULT NULL COMMENT '分类描述',
    `sort_order` INT DEFAULT 0 COMMENT '排序顺序',
    `is_visible` TINYINT(1) DEFAULT 1 COMMENT '是否可见 0-隐藏 1-显示',
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (`id`),
    INDEX `idx_sort_order` (`sort_order`),
    INDEX `idx_is_visible` (`is_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='网址分类表';

-- =====================================================
-- 2. 分区表 (sections)
-- =====================================================
DROP TABLE IF EXISTS `sections`;
CREATE TABLE `sections` (
    `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '分区ID',
    `category_id` BIGINT NOT NULL COMMENT '所属分类ID',
    `name` VARCHAR(100) NOT NULL COMMENT '分区名称',
    `description` VARCHAR(500) DEFAULT NULL COMMENT '分区描述',
    `sort_order` INT DEFAULT 0 COMMENT '排序顺序',
    `is_visible` TINYINT(1) DEFAULT 1 COMMENT '是否可见 0-隐藏 1-显示',
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (`id`),
    INDEX `idx_category_id` (`category_id`),
    INDEX `idx_sort_order` (`sort_order`),
    CONSTRAINT `fk_sections_category` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='网址分区表';

-- =====================================================
-- 3. 网址表 (websites)
-- =====================================================
DROP TABLE IF EXISTS `websites`;
CREATE TABLE `websites` (
    `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '网址ID',
    `section_id` BIGINT NOT NULL COMMENT '所属分区ID',
    `name` VARCHAR(100) NOT NULL COMMENT '网站名称',
    `url` VARCHAR(500) NOT NULL COMMENT '网站URL',
    `icon` VARCHAR(500) DEFAULT NULL COMMENT '网站图标URL',
    `description` VARCHAR(500) DEFAULT NULL COMMENT '网站描述',
    `sort_order` INT DEFAULT 0 COMMENT '排序顺序',
    `click_count` BIGINT DEFAULT 0 COMMENT '点击次数',
    `is_hot` TINYINT(1) DEFAULT 0 COMMENT '是否热门 0-否 1-是',
    `is_visible` TINYINT(1) DEFAULT 1 COMMENT '是否可见 0-隐藏 1-显示',
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (`id`),
    INDEX `idx_section_id` (`section_id`),
    INDEX `idx_sort_order` (`sort_order`),
    INDEX `idx_click_count` (`click_count`),
    INDEX `idx_is_hot` (`is_hot`),
    INDEX `idx_name` (`name`),
    FULLTEXT INDEX `ft_search` (`name`, `description`),
    CONSTRAINT `fk_websites_section` FOREIGN KEY (`section_id`) REFERENCES `sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='网站信息表';

-- =====================================================
-- 4. 用户自定义工作台表 (user_workspaces)
-- =====================================================
DROP TABLE IF EXISTS `user_workspaces`;
CREATE TABLE `user_workspaces` (
    `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '工作台ID',
    `user_id` VARCHAR(100) NOT NULL COMMENT '用户标识(使用浏览器指纹或UUID)',
    `name` VARCHAR(100) NOT NULL COMMENT '自定义名称',
    `url` VARCHAR(500) NOT NULL COMMENT '网站URL',
    `icon` VARCHAR(500) DEFAULT NULL COMMENT '网站图标URL',
    `description` VARCHAR(500) DEFAULT NULL COMMENT '网站描述',
    `sort_order` INT DEFAULT 0 COMMENT '排序顺序',
    `website_id` BIGINT DEFAULT NULL COMMENT '关联的系统网址ID(如果是从库中添加的)',
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (`id`),
    INDEX `idx_user_id` (`user_id`),
    INDEX `idx_sort_order` (`sort_order`),
    INDEX `idx_website_id` (`website_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户自定义工作台表';

-- =====================================================
-- 5. 搜索引擎表 (search_engines)
-- =====================================================
DROP TABLE IF EXISTS `search_engines`;
CREATE TABLE `search_engines` (
    `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '搜索引擎ID',
    `name` VARCHAR(100) NOT NULL COMMENT '搜索引擎名称',
    `url_template` VARCHAR(500) NOT NULL COMMENT 'URL模板(使用{keyword}占位符)',
    `icon` VARCHAR(500) DEFAULT NULL COMMENT '搜索引擎图标',
    `sort_order` INT DEFAULT 0 COMMENT '排序顺序',
    `is_default` TINYINT(1) DEFAULT 0 COMMENT '是否默认 0-否 1-是',
    `is_visible` TINYINT(1) DEFAULT 1 COMMENT '是否可见 0-隐藏 1-显示',
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (`id`),
    INDEX `idx_sort_order` (`sort_order`),
    INDEX `idx_is_default` (`is_default`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='搜索引擎表';

-- =====================================================
-- 6. 系统配置表 (system_configs)
-- =====================================================
DROP TABLE IF EXISTS `system_configs`;
CREATE TABLE `system_configs` (
    `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '配置ID',
    `config_key` VARCHAR(100) NOT NULL COMMENT '配置键',
    `config_value` TEXT COMMENT '配置值',
    `description` VARCHAR(500) DEFAULT NULL COMMENT '配置描述',
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (`id`),
    UNIQUE INDEX `uk_config_key` (`config_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='系统配置表';

-- =====================================================
-- 7. 热门搜索词表 (hot_searches)
-- =====================================================
DROP TABLE IF EXISTS `hot_searches`;
CREATE TABLE `hot_searches` (
    `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT 'ID',
    `keyword` VARCHAR(100) NOT NULL COMMENT '搜索关键词',
    `search_count` BIGINT DEFAULT 1 COMMENT '搜索次数',
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (`id`),
    UNIQUE INDEX `uk_keyword` (`keyword`),
    INDEX `idx_search_count` (`search_count`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='热门搜索词表';

-- =====================================================
-- 初始数据插入
-- =====================================================

-- 插入默认分类
INSERT INTO `categories` (`name`, `icon`, `description`, `sort_order`) VALUES
('自定义工作台', 'Briefcase', '您的个人工作台，可自由添加常用网址', 0),
('常用推荐', 'Star', '精选常用网站推荐', 1),
('技术开发', 'Code', '编程开发相关资源', 2),
('设计创意', 'Palette', '设计工具与灵感资源', 3),
('效率工具', 'Zap', '提升工作效率的工具', 4),
('学习教育', 'GraduationCap', '在线学习与教育资源', 5),
('娱乐休闲', 'Music', '影音娱乐与休闲网站', 6),
('新闻资讯', 'Newspaper', '新闻媒体与资讯平台', 7);

-- 插入分区数据
INSERT INTO `sections` (`category_id`, `name`, `description`, `sort_order`) VALUES
-- 常用推荐分区
(2, '搜索引擎', '主流搜索引擎', 1),
(2, '社交媒体', '社交网络平台', 2),
(2, '购物平台', '电商购物网站', 3),
-- 技术开发分区
(3, '代码托管', '代码托管平台', 1),
(3, '技术社区', '开发者社区', 2),
(3, '在线工具', '开发者在线工具', 3),
(3, '文档资源', '技术文档与教程', 4),
-- 设计创意分区
(4, '设计工具', '在线设计工具', 1),
(4, '素材资源', '设计素材网站', 2),
(4, '配色方案', '配色灵感网站', 3),
-- 效率工具分区
(5, '云存储', '云存储服务', 1),
(5, '在线文档', '在线协作文档', 2),
(5, 'AI工具', '人工智能工具', 3),
-- 学习教育分区
(6, '在线课程', '在线教育平台', 1),
(6, '编程学习', '编程学习资源', 2),
(6, '语言学习', '语言学习平台', 3),
-- 娱乐休闲分区
(7, '视频平台', '视频网站', 1),
(7, '音乐平台', '音乐网站', 2),
(7, '游戏娱乐', '游戏平台', 3),
-- 新闻资讯分区
(8, '综合新闻', '综合新闻门户', 1),
(8, '科技资讯', '科技新闻网站', 2),
(8, '财经资讯', '财经新闻网站', 3);

-- 插入网站数据
INSERT INTO `websites` (`section_id`, `name`, `url`, `icon`, `description`, `sort_order`, `is_hot`) VALUES
-- 搜索引擎
(1, 'Google', 'https://www.google.com', 'https://www.google.com/favicon.ico', '全球最大的搜索引擎', 1, 1),
(1, '百度', 'https://www.baidu.com', 'https://www.baidu.com/favicon.ico', '中国最大的搜索引擎', 2, 1),
(1, 'Bing', 'https://www.bing.com', 'https://www.bing.com/favicon.ico', '微软必应搜索引擎', 3, 0),
(1, 'DuckDuckGo', 'https://duckduckgo.com', 'https://duckduckgo.com/favicon.ico', '注重隐私的搜索引擎', 4, 0),
-- 社交媒体
(2, '微博', 'https://weibo.com', 'https://weibo.com/favicon.ico', '中国最大的社交媒体平台', 1, 1),
(2, '知乎', 'https://www.zhihu.com', 'https://www.zhihu.com/favicon.ico', '中文问答社区', 2, 1),
(2, 'Twitter/X', 'https://twitter.com', 'https://twitter.com/favicon.ico', '全球社交媒体平台', 3, 1),
(2, '豆瓣', 'https://www.douban.com', 'https://www.douban.com/favicon.ico', '书影音社区', 4, 0),
-- 购物平台
(3, '淘宝', 'https://www.taobao.com', 'https://www.taobao.com/favicon.ico', '中国最大的电商平台', 1, 1),
(3, '京东', 'https://www.jd.com', 'https://www.jd.com/favicon.ico', '综合电商平台', 2, 1),
(3, '拼多多', 'https://www.pinduoduo.com', 'https://www.pinduoduo.com/favicon.ico', '社交电商平台', 3, 1),
(3, '亚马逊', 'https://www.amazon.cn', 'https://www.amazon.cn/favicon.ico', '全球电商平台', 4, 0),
-- 代码托管
(4, 'GitHub', 'https://github.com', 'https://github.com/favicon.ico', '全球最大的代码托管平台', 1, 1),
(4, 'GitLab', 'https://gitlab.com', 'https://gitlab.com/favicon.ico', '代码托管与CI/CD平台', 2, 0),
(4, 'Gitee', 'https://gitee.com', 'https://gitee.com/favicon.ico', '国内代码托管平台', 3, 1),
(4, 'Bitbucket', 'https://bitbucket.org', 'https://bitbucket.org/favicon.ico', 'Atlassian代码托管', 4, 0),
-- 技术社区
(5, 'Stack Overflow', 'https://stackoverflow.com', 'https://stackoverflow.com/favicon.ico', '全球最大的程序员问答社区', 1, 1),
(5, '掘金', 'https://juejin.cn', 'https://juejin.cn/favicon.ico', '中文技术社区', 2, 1),
(5, 'CSDN', 'https://www.csdn.net', 'https://www.csdn.net/favicon.ico', '中国开发者社区', 3, 1),
(5, 'SegmentFault', 'https://segmentfault.com', 'https://segmentfault.com/favicon.ico', '技术问答社区', 4, 0),
-- 在线工具
(6, 'CodePen', 'https://codepen.io', 'https://codepen.io/favicon.ico', '前端代码演示平台', 1, 1),
(6, 'JSFiddle', 'https://jsfiddle.net', 'https://jsfiddle.net/favicon.ico', 'Web代码在线运行', 2, 0),
(6, 'Regex101', 'https://regex101.com', 'https://regex101.com/favicon.ico', '正则表达式测试工具', 3, 0),
(6, 'JSON Editor', 'https://jsoneditoronline.org', 'https://jsoneditoronline.org/favicon.ico', 'JSON在线编辑器', 4, 0),
-- 文档资源
(7, 'MDN Web Docs', 'https://developer.mozilla.org', 'https://developer.mozilla.org/favicon.ico', 'Web技术权威文档', 1, 1),
(7, 'Vue.js', 'https://vuejs.org', 'https://vuejs.org/favicon.ico', 'Vue.js官方文档', 2, 1),
(7, 'React', 'https://react.dev', 'https://react.dev/favicon.ico', 'React官方文档', 3, 1),
(7, 'TypeScript', 'https://www.typescriptlang.org', 'https://www.typescriptlang.org/favicon.ico', 'TypeScript官方文档', 4, 0),
-- 设计工具
(8, 'Figma', 'https://www.figma.com', 'https://www.figma.com/favicon.ico', '协作设计工具', 1, 1),
(8, 'Canva', 'https://www.canva.com', 'https://www.canva.com/favicon.ico', '在线设计平台', 2, 1),
(8, 'Adobe Creative Cloud', 'https://www.adobe.com/creativecloud.html', 'https://www.adobe.com/favicon.ico', 'Adobe创意套件', 3, 0),
(8, '即时设计', 'https://js.design', 'https://js.design/favicon.ico', '国产在线设计工具', 4, 0),
-- 素材资源
(9, 'Unsplash', 'https://unsplash.com', 'https://unsplash.com/favicon.ico', '免费高清图片', 1, 1),
(9, 'Pexels', 'https://www.pexels.com', 'https://www.pexels.com/favicon.ico', '免费图片视频素材', 2, 1),
(9, 'iconfont', 'https://www.iconfont.cn', 'https://www.iconfont.cn/favicon.ico', '阿里巴巴图标库', 3, 1),
(9, 'Font Awesome', 'https://fontawesome.com', 'https://fontawesome.com/favicon.ico', '图标字体库', 4, 0),
-- 配色方案
(10, 'Coolors', 'https://coolors.co', 'https://coolors.co/favicon.ico', '配色方案生成器', 1, 1),
(10, 'Color Hunt', 'https://colorhunt.co', 'https://colorhunt.co/favicon.ico', '配色灵感收集', 2, 0),
(10, 'Adobe Color', 'https://color.adobe.com', 'https://color.adobe.com/favicon.ico', 'Adobe配色工具', 3, 0),
-- 云存储
(11, '百度网盘', 'https://pan.baidu.com', 'https://pan.baidu.com/favicon.ico', '百度云存储', 1, 1),
(11, '阿里云盘', 'https://www.aliyundrive.com', 'https://www.aliyundrive.com/favicon.ico', '阿里云存储', 2, 1),
(11, 'Google Drive', 'https://drive.google.com', 'https://drive.google.com/favicon.ico', '谷歌云存储', 3, 0),
(11, 'OneDrive', 'https://onedrive.live.com', 'https://onedrive.live.com/favicon.ico', '微软云存储', 4, 0),
-- 在线文档
(12, '石墨文档', 'https://shimo.im', 'https://shimo.im/favicon.ico', '在线协作文档', 1, 1),
(12, '腾讯文档', 'https://docs.qq.com', 'https://docs.qq.com/favicon.ico', '腾讯在线文档', 2, 1),
(12, 'Notion', 'https://www.notion.so', 'https://www.notion.so/favicon.ico', '全能笔记工具', 3, 1),
(12, '飞书文档', 'https://www.feishu.cn', 'https://www.feishu.cn/favicon.ico', '字节跳动协作平台', 4, 0),
-- AI工具
(13, 'ChatGPT', 'https://chat.openai.com', 'https://chat.openai.com/favicon.ico', 'OpenAI对话AI', 1, 1),
(13, '文心一言', 'https://yiyan.baidu.com', 'https://yiyan.baidu.com/favicon.ico', '百度AI助手', 2, 1),
(13, 'Claude', 'https://claude.ai', 'https://claude.ai/favicon.ico', 'Anthropic AI助手', 3, 1),
(13, 'Midjourney', 'https://www.midjourney.com', 'https://www.midjourney.com/favicon.ico', 'AI绘画工具', 4, 1),
-- 在线课程
(14, '慕课网', 'https://www.imooc.com', 'https://www.imooc.com/favicon.ico', 'IT技能学习平台', 1, 1),
(14, '网易云课堂', 'https://study.163.com', 'https://study.163.com/favicon.ico', '综合学习平台', 2, 1),
(14, 'Coursera', 'https://www.coursera.org', 'https://www.coursera.org/favicon.ico', '全球在线教育平台', 3, 1),
(14, 'Udemy', 'https://www.udemy.com', 'https://www.udemy.com/favicon.ico', '在线课程平台', 4, 0),
-- 编程学习
(15, 'LeetCode', 'https://leetcode.cn', 'https://leetcode.cn/favicon.ico', '算法刷题平台', 1, 1),
(15, '力扣', 'https://leetcode.com', 'https://leetcode.com/favicon.ico', 'LeetCode国际版', 2, 0),
(15, 'freeCodeCamp', 'https://www.freecodecamp.org', 'https://www.freecodecamp.org/favicon.ico', '免费编程学习', 3, 1),
(15, 'Codecademy', 'https://www.codecademy.com', 'https://www.codecademy.com/favicon.ico', '交互式编程学习', 4, 0),
-- 语言学习
(16, '多邻国', 'https://www.duolingo.com', 'https://www.duolingo.com/favicon.ico', '语言学习应用', 1, 1),
(16, '扇贝', 'https://www.shanbay.com', 'https://www.shanbay.com/favicon.ico', '英语学习平台', 2, 0),
-- 视频平台
(17, 'Bilibili', 'https://www.bilibili.com', 'https://www.bilibili.com/favicon.ico', '中国最大的弹幕视频网站', 1, 1),
(17, 'YouTube', 'https://www.youtube.com', 'https://www.youtube.com/favicon.ico', '全球最大视频平台', 2, 1),
(17, '优酷', 'https://www.youku.com', 'https://www.youku.com/favicon.ico', '综合视频平台', 3, 0),
(17, '爱奇艺', 'https://www.iqiyi.com', 'https://www.iqiyi.com/favicon.ico', '综合视频平台', 4, 0),
-- 音乐平台
(18, '网易云音乐', 'https://music.163.com', 'https://music.163.com/favicon.ico', '网易音乐平台', 1, 1),
(18, 'QQ音乐', 'https://y.qq.com', 'https://y.qq.com/favicon.ico', '腾讯音乐平台', 2, 1),
(18, 'Spotify', 'https://www.spotify.com', 'https://www.spotify.com/favicon.ico', '全球流媒体平台', 3, 0),
-- 游戏娱乐
(19, 'Steam', 'https://store.steampowered.com', 'https://store.steampowered.com/favicon.ico', '游戏发行平台', 1, 1),
(19, 'Epic Games', 'https://www.epicgames.com', 'https://www.epicgames.com/favicon.ico', 'Epic游戏商城', 2, 0),
-- 综合新闻
(20, '今日头条', 'https://www.toutiao.com', 'https://www.toutiao.com/favicon.ico', '个性化新闻推荐', 1, 1),
(20, '新浪新闻', 'https://news.sina.com.cn', 'https://news.sina.com.cn/favicon.ico', '综合新闻门户', 2, 0),
(20, '腾讯新闻', 'https://news.qq.com', 'https://news.qq.com/favicon.ico', '腾讯新闻门户', 3, 0),
-- 科技资讯
(21, '36氪', 'https://36kr.com', 'https://36kr.com/favicon.ico', '科技创投资讯', 1, 1),
(21, '虎嗅', 'https://www.huxiu.com', 'https://www.huxiu.com/favicon.ico', '商业科技资讯', 2, 1),
(21, 'TechCrunch', 'https://techcrunch.com', 'https://techcrunch.com/favicon.ico', '科技新闻网站', 3, 0),
-- 财经资讯
(22, '东方财富', 'https://www.eastmoney.com', 'https://www.eastmoney.com/favicon.ico', '财经资讯平台', 1, 1),
(22, '雪球', 'https://xueqiu.com', 'https://xueqiu.com/favicon.ico', '投资者社区', 2, 1);

-- 插入搜索引擎数据
INSERT INTO `search_engines` (`name`, `url_template`, `icon`, `sort_order`, `is_default`) VALUES
('Google', 'https://www.google.com/search?q={keyword}', 'https://www.google.com/favicon.ico', 1, 0),
('百度', 'https://www.baidu.com/s?wd={keyword}', 'https://www.baidu.com/favicon.ico', 2, 1),
('Bing', 'https://www.bing.com/search?q={keyword}', 'https://www.bing.com/favicon.ico', 3, 0),
('DuckDuckGo', 'https://duckduckgo.com/?q={keyword}', 'https://duckduckgo.com/favicon.ico', 4, 0),
('GitHub', 'https://github.com/search?q={keyword}', 'https://github.com/favicon.ico', 5, 0),
('Stack Overflow', 'https://stackoverflow.com/search?q={keyword}', 'https://stackoverflow.com/favicon.ico', 6, 0),
('知乎', 'https://www.zhihu.com/search?q={keyword}', 'https://www.zhihu.com/favicon.ico', 7, 0),
('Bilibili', 'https://search.bilibili.com/all?keyword={keyword}', 'https://www.bilibili.com/favicon.ico', 8, 0);

-- 插入系统配置数据
INSERT INTO `system_configs` (`config_key`, `config_value`, `description`) VALUES
('site_name', '网址导航', '网站名称'),
('site_logo', '/logo.svg', '网站Logo'),
('site_description', '一站式网址导航系统，助您快速访问常用网站', '网站描述'),
('copyright', '© 2024 网址导航 All Rights Reserved', '版权信息'),
('footer_links', '[{"name":"关于我们","url":"/about"},{"name":"联系我们","url":"/about"},{"name":"使用条款","url":"/about"}]', '底部链接'),
('social_links', '[{"name":"GitHub","url":"https://github.com","icon":"Github"},{"name":"微博","url":"https://weibo.com","icon":"Twitter"}]', '社交媒体链接');

-- 插入热门搜索词
INSERT INTO `hot_searches` (`keyword`, `search_count`) VALUES
('ChatGPT', 10000),
('GitHub', 8500),
('Vue', 7200),
('React', 6800),
('Python', 6500),
('前端开发', 5200),
('AI绘画', 4800),
('在线工具', 4200);

