package com.yinwang.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import java.time.LocalDateTime;

/**
 * 热门搜索词实体
 */
@Data
@TableName("hot_searches")
public class HotSearch {
    
    @TableId(type = IdType.AUTO)
    private Long id;
    
    private String keyword;
    
    private Long searchCount;
    
    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createdAt;
    
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updatedAt;
}

