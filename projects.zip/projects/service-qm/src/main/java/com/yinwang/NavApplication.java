package com.yinwang;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * 网址导航系统启动类
 */
@SpringBootApplication
@MapperScan("com.yinwang.mapper")
public class NavApplication {
    public static void main(String[] args) {
        SpringApplication.run(NavApplication.class, args);
    }
}

