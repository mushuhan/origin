package com.yinwang.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.yinwang.entity.UserWorkspace;
import org.apache.ibatis.annotations.Mapper;

/**
 * 用户工作台Mapper接口
 */
@Mapper
public interface UserWorkspaceMapper extends BaseMapper<UserWorkspace> {
}

