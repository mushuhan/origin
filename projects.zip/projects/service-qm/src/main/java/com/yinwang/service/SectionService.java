package com.yinwang.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.yinwang.entity.Section;

import java.util.List;

/**
 * 分区服务接口
 */
public interface SectionService extends IService<Section> {
    
    /**
     * 获取分类下的所有分区（包含网站）
     */
    List<Section> getSectionsByCategoryId(Long categoryId);
    
    /**
     * 获取分区详情（包含网站）
     */
    Section getSectionWithWebsites(Long sectionId);
}

