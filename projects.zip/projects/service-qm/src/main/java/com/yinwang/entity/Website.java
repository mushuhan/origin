package com.yinwang.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import java.time.LocalDateTime;

/**
 * 网站信息实体
 */
@Data
@TableName("websites")
public class Website {
    
    @TableId(type = IdType.AUTO)
    private Long id;
    
    private Long sectionId;
    
    private String name;
    
    private String url;
    
    private String icon;
    
    private String description;
    
    private Integer sortOrder;
    
    private Long clickCount;
    
    private Boolean isHot;
    
    private Boolean isVisible;
    
    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createdAt;
    
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updatedAt;
}

