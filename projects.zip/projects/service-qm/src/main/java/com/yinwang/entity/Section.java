package com.yinwang.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import java.time.LocalDateTime;
import java.util.List;

/**
 * 网址分区实体
 */
@Data
@TableName("sections")
public class Section {
    
    @TableId(type = IdType.AUTO)
    private Long id;
    
    private Long categoryId;
    
    private String name;
    
    private String description;
    
    private Integer sortOrder;
    
    private Boolean isVisible;
    
    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createdAt;
    
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updatedAt;
    
    /**
     * 分区下的网站列表（非数据库字段）
     */
    @TableField(exist = false)
    private List<Website> websites;
}

