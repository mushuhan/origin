package com.yinwang.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import java.time.LocalDateTime;

/**
 * 用户自定义工作台实体
 */
@Data
@TableName("user_workspaces")
public class UserWorkspace {
    
    @TableId(type = IdType.AUTO)
    private Long id;
    
    private String userId;
    
    private String name;
    
    private String url;
    
    private String icon;
    
    private String description;
    
    private Integer sortOrder;
    
    private Long websiteId;
    
    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createdAt;
    
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updatedAt;
}

