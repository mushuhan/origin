package com.yinwang.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.yinwang.entity.Section;
import org.apache.ibatis.annotations.Mapper;

/**
 * 分区Mapper接口
 */
@Mapper
public interface SectionMapper extends BaseMapper<Section> {
}

