package com.yinwang.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.yinwang.entity.Website;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * 网站Mapper接口
 */
@Mapper
public interface WebsiteMapper extends BaseMapper<Website> {
    
    /**
     * 全文搜索网站
     */
    @Select("SELECT * FROM websites WHERE MATCH(name, description) AGAINST(#{keyword} IN NATURAL LANGUAGE MODE) AND is_visible = 1 LIMIT #{limit}")
    List<Website> fullTextSearch(@Param("keyword") String keyword, @Param("limit") int limit);
    
    /**
     * 模糊搜索网站
     */
    @Select("SELECT * FROM websites WHERE (name LIKE CONCAT('%', #{keyword}, '%') OR description LIKE CONCAT('%', #{keyword}, '%')) AND is_visible = 1 ORDER BY click_count DESC LIMIT #{limit}")
    List<Website> fuzzySearch(@Param("keyword") String keyword, @Param("limit") int limit);
}

