package com.yinwang.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import java.time.LocalDateTime;

/**
 * 搜索引擎实体
 */
@Data
@TableName("search_engines")
public class SearchEngine {
    
    @TableId(type = IdType.AUTO)
    private Long id;
    
    private String name;
    
    private String urlTemplate;
    
    private String icon;
    
    private Integer sortOrder;
    
    private Boolean isDefault;
    
    private Boolean isVisible;
    
    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createdAt;
    
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updatedAt;
}

