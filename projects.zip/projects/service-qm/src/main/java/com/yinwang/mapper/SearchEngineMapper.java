package com.yinwang.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.yinwang.entity.SearchEngine;
import org.apache.ibatis.annotations.Mapper;

/**
 * 搜索引擎Mapper接口
 */
@Mapper
public interface SearchEngineMapper extends BaseMapper<SearchEngine> {
}

