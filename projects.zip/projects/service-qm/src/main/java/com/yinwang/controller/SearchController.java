package com.yinwang.controller;

import com.yinwang.common.Result;
import com.yinwang.entity.HotSearch;
import com.yinwang.entity.SearchEngine;
import com.yinwang.entity.Website;
import com.yinwang.service.HotSearchService;
import com.yinwang.service.SearchEngineService;
import com.yinwang.service.WebsiteService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 搜索控制器
 */
@Tag(name = "搜索功能", description = "搜索相关接口")
@RestController
@RequestMapping("/api/search")
@RequiredArgsConstructor
public class SearchController {
    
    private final WebsiteService websiteService;
    private final SearchEngineService searchEngineService;
    private final HotSearchService hotSearchService;
    
    @Operation(summary = "搜索网站")
    @GetMapping
    public Result<Map<String, Object>> search(
            @Parameter(description = "搜索关键词") @RequestParam String keyword,
            @Parameter(description = "返回数量") @RequestParam(defaultValue = "20") int limit) {
        
        // 记录搜索词
        hotSearchService.recordSearch(keyword);
        
        // 搜索网站
        List<Website> websites = websiteService.searchWebsites(keyword, limit);
        
        Map<String, Object> result = new HashMap<>();
        result.put("keyword", keyword);
        result.put("websites", websites);
        result.put("total", websites.size());
        
        return Result.success(result);
    }
    
    @Operation(summary = "获取搜索引擎列表")
    @GetMapping("/engines")
    public Result<List<SearchEngine>> getSearchEngines() {
        return Result.success(searchEngineService.getVisibleSearchEngines());
    }
    
    @Operation(summary = "获取默认搜索引擎")
    @GetMapping("/engines/default")
    public Result<SearchEngine> getDefaultSearchEngine() {
        SearchEngine engine = searchEngineService.getDefaultSearchEngine();
        if (engine == null) {
            return Result.error("未设置默认搜索引擎");
        }
        return Result.success(engine);
    }
    
    @Operation(summary = "获取热门搜索词")
    @GetMapping("/hot")
    public Result<List<HotSearch>> getHotSearches(
            @Parameter(description = "返回数量") @RequestParam(defaultValue = "10") int limit) {
        return Result.success(hotSearchService.getHotSearches(limit));
    }
}

