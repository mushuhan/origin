package com.yinwang.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.yinwang.entity.HotSearch;
import org.apache.ibatis.annotations.Mapper;

/**
 * 热门搜索Mapper接口
 */
@Mapper
public interface HotSearchMapper extends BaseMapper<HotSearch> {
}

