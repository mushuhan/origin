package com.yinwang.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.yinwang.entity.Category;
import com.yinwang.dto.CategoryWithSectionsDTO;

import java.util.List;

/**
 * 分类服务接口
 */
public interface CategoryService extends IService<Category> {
    
    /**
     * 获取所有可见分类（按排序）
     */
    List<Category> getVisibleCategories();
    
    /**
     * 获取分类及其下属分区和网站
     */
    CategoryWithSectionsDTO getCategoryWithSections(Long categoryId);
    
    /**
     * 获取所有分类及其下属分区和网站
     */
    List<CategoryWithSectionsDTO> getAllCategoriesWithSections();
}

