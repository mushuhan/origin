package com.yinwang.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.yinwang.entity.SystemConfig;

import java.util.Map;

/**
 * 系统配置服务接口
 */
public interface SystemConfigService extends IService<SystemConfig> {
    
    /**
     * 获取配置值
     */
    String getConfigValue(String key);
    
    /**
     * 获取所有配置
     */
    Map<String, String> getAllConfigs();
}

