package com.yinwang.dto;

import com.yinwang.entity.Category;
import com.yinwang.entity.Section;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

/**
 * 分类及其分区和网站的DTO
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class CategoryWithSectionsDTO extends Category {
    
    /**
     * 分区列表（包含网站）
     */
    private List<Section> sections;
}

