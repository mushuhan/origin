package com.yinwang.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.yinwang.entity.SearchEngine;

import java.util.List;

/**
 * 搜索引擎服务接口
 */
public interface SearchEngineService extends IService<SearchEngine> {
    
    /**
     * 获取所有可见搜索引擎
     */
    List<SearchEngine> getVisibleSearchEngines();
    
    /**
     * 获取默认搜索引擎
     */
    SearchEngine getDefaultSearchEngine();
}

