package com.yinwang.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.yinwang.entity.HotSearch;
import com.yinwang.mapper.HotSearchMapper;
import com.yinwang.service.HotSearchService;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * 热门搜索服务实现
 */
@Service
public class HotSearchServiceImpl extends ServiceImpl<HotSearchMapper, HotSearch> implements HotSearchService {
    
    @Override
    public List<HotSearch> getHotSearches(int limit) {
        return list(new LambdaQueryWrapper<HotSearch>()
                .orderByDesc(HotSearch::getSearchCount)
                .last("LIMIT " + limit));
    }
    
    @Override
    public void recordSearch(String keyword) {
        if (keyword == null || keyword.trim().isEmpty()) {
            return;
        }
        
        keyword = keyword.trim();
        
        HotSearch existing = getOne(new LambdaQueryWrapper<HotSearch>()
                .eq(HotSearch::getKeyword, keyword));
        
        if (existing != null) {
            existing.setSearchCount(existing.getSearchCount() + 1);
            updateById(existing);
        } else {
            HotSearch hotSearch = new HotSearch();
            hotSearch.setKeyword(keyword);
            hotSearch.setSearchCount(1L);
            save(hotSearch);
        }
    }
}

