package com.yinwang.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.yinwang.entity.HotSearch;

import java.util.List;

/**
 * 热门搜索服务接口
 */
public interface HotSearchService extends IService<HotSearch> {
    
    /**
     * 获取热门搜索词
     */
    List<HotSearch> getHotSearches(int limit);
    
    /**
     * 记录搜索词
     */
    void recordSearch(String keyword);
}

