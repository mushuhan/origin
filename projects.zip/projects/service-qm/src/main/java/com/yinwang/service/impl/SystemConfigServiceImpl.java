package com.yinwang.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.yinwang.entity.SystemConfig;
import com.yinwang.mapper.SystemConfigMapper;
import com.yinwang.service.SystemConfigService;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 系统配置服务实现
 */
@Service
public class SystemConfigServiceImpl extends ServiceImpl<SystemConfigMapper, SystemConfig> implements SystemConfigService {
    
    @Override
    public String getConfigValue(String key) {
        SystemConfig config = getOne(new LambdaQueryWrapper<SystemConfig>()
                .eq(SystemConfig::getConfigKey, key));
        return config != null ? config.getConfigValue() : null;
    }
    
    @Override
    public Map<String, String> getAllConfigs() {
        List<SystemConfig> configs = list();
        Map<String, String> result = new HashMap<>();
        configs.forEach(config -> result.put(config.getConfigKey(), config.getConfigValue()));
        return result;
    }
}

