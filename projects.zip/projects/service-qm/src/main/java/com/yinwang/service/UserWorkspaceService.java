package com.yinwang.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.yinwang.entity.UserWorkspace;

import java.util.List;

/**
 * 用户工作台服务接口
 */
public interface UserWorkspaceService extends IService<UserWorkspace> {
    
    /**
     * 获取用户的工作台网址列表
     */
    List<UserWorkspace> getUserWorkspaces(String userId);
    
    /**
     * 添加网址到工作台
     */
    UserWorkspace addToWorkspace(UserWorkspace workspace);
    
    /**
     * 从系统网址添加到工作台
     */
    UserWorkspace addFromWebsite(String userId, Long websiteId);
    
    /**
     * 更新工作台网址排序
     */
    void updateSortOrder(String userId, List<Long> ids);
    
    /**
     * 删除工作台网址
     */
    void removeFromWorkspace(String userId, Long id);
}

