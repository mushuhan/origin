package com.yinwang.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.yinwang.entity.Website;
import com.yinwang.mapper.WebsiteMapper;
import com.yinwang.service.WebsiteService;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * 网站服务实现
 */
@Service
public class WebsiteServiceImpl extends ServiceImpl<WebsiteMapper, Website> implements WebsiteService {
    
    @Override
    public List<Website> getWebsitesBySectionId(Long sectionId) {
        return list(new LambdaQueryWrapper<Website>()
                .eq(Website::getSectionId, sectionId)
                .eq(Website::getIsVisible, true)
                .orderByAsc(Website::getSortOrder));
    }
    
    @Override
    public List<Website> searchWebsites(String keyword, int limit) {
        // 先尝试模糊搜索
        return baseMapper.fuzzySearch(keyword, limit);
    }
    
    @Override
    public List<Website> getHotWebsites(int limit) {
        return list(new LambdaQueryWrapper<Website>()
                .eq(Website::getIsHot, true)
                .eq(Website::getIsVisible, true)
                .orderByDesc(Website::getClickCount)
                .last("LIMIT " + limit));
    }
    
    @Override
    public void incrementClickCount(Long websiteId) {
        Website website = getById(websiteId);
        if (website != null) {
            website.setClickCount(website.getClickCount() + 1);
            updateById(website);
        }
    }
}

