package com.yinwang.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

/**
 * 工作台网址请求DTO
 */
@Data
public class WorkspaceDTO {
    
    @NotBlank(message = "用户ID不能为空")
    private String userId;
    
    @NotBlank(message = "网站名称不能为空")
    private String name;
    
    @NotBlank(message = "网站URL不能为空")
    private String url;
    
    private String icon;
    
    private String description;
    
    private Integer sortOrder;
    
    private Long websiteId;
}

