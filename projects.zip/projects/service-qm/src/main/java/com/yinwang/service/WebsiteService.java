package com.yinwang.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.yinwang.entity.Website;

import java.util.List;

/**
 * 网站服务接口
 */
public interface WebsiteService extends IService<Website> {
    
    /**
     * 获取分区下的所有网站
     */
    List<Website> getWebsitesBySectionId(Long sectionId);
    
    /**
     * 搜索网站
     */
    List<Website> searchWebsites(String keyword, int limit);
    
    /**
     * 获取热门网站
     */
    List<Website> getHotWebsites(int limit);
    
    /**
     * 增加点击次数
     */
    void incrementClickCount(Long websiteId);
}

