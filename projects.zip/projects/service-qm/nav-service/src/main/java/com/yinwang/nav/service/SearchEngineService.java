package com.yinwang.nav.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.yinwang.nav.entity.SearchEngine;

import java.util.List;

public interface SearchEngineService extends IService<SearchEngine> {
    
    List<SearchEngine> getVisibleSearchEngines();
    
    SearchEngine getDefaultSearchEngine();
}

