package com.yinwang.nav.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.yinwang.common.exception.BusinessException;
import com.yinwang.nav.entity.UserWorkspace;
import com.yinwang.nav.entity.Website;
import com.yinwang.nav.mapper.UserWorkspaceMapper;
import com.yinwang.nav.service.UserWorkspaceService;
import com.yinwang.nav.service.WebsiteService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class UserWorkspaceServiceImpl extends ServiceImpl<UserWorkspaceMapper, UserWorkspace> implements UserWorkspaceService {
    
    private final WebsiteService websiteService;
    
    @Override
    public List<UserWorkspace> getUserWorkspaces(String userId) {
        return list(new LambdaQueryWrapper<UserWorkspace>()
                .eq(UserWorkspace::getUserId, userId)
                .orderByAsc(UserWorkspace::getSortOrder));
    }
    
    @Override
    public UserWorkspace addToWorkspace(UserWorkspace workspace) {
        Long count = count(new LambdaQueryWrapper<UserWorkspace>()
                .eq(UserWorkspace::getUserId, workspace.getUserId()));
        workspace.setSortOrder(count.intValue());
        save(workspace);
        return workspace;
    }
    
    @Override
    public UserWorkspace addFromWebsite(String userId, Long websiteId) {
        Website website = websiteService.getById(websiteId);
        if (website == null) {
            throw new BusinessException("网站不存在");
        }
        
        UserWorkspace existing = getOne(new LambdaQueryWrapper<UserWorkspace>()
                .eq(UserWorkspace::getUserId, userId)
                .eq(UserWorkspace::getWebsiteId, websiteId));
        if (existing != null) {
            return existing;
        }
        
        UserWorkspace workspace = new UserWorkspace();
        workspace.setUserId(userId);
        workspace.setWebsiteId(websiteId);
        workspace.setName(website.getName());
        workspace.setUrl(website.getUrl());
        workspace.setIcon(website.getIcon());
        workspace.setDescription(website.getDescription());
        
        return addToWorkspace(workspace);
    }
    
    @Override
    @Transactional
    public void updateSortOrder(String userId, List<Long> ids) {
        for (int i = 0; i < ids.size(); i++) {
            UserWorkspace workspace = getById(ids.get(i));
            if (workspace != null && workspace.getUserId().equals(userId)) {
                workspace.setSortOrder(i);
                updateById(workspace);
            }
        }
    }
    
    @Override
    public void removeFromWorkspace(String userId, Long id) {
        remove(new LambdaQueryWrapper<UserWorkspace>()
                .eq(UserWorkspace::getUserId, userId)
                .eq(UserWorkspace::getId, id));
    }
}

