package com.yinwang.nav.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.yinwang.nav.entity.SystemConfig;

import java.util.Map;

public interface SystemConfigService extends IService<SystemConfig> {
    
    String getConfigValue(String key);
    
    Map<String, String> getAllConfigs();
}

