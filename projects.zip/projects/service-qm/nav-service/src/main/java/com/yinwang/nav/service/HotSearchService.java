package com.yinwang.nav.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.yinwang.nav.entity.HotSearch;

import java.util.List;

public interface HotSearchService extends IService<HotSearch> {
    
    List<HotSearch> getHotSearches(int limit);
    
    void recordSearch(String keyword);
}

