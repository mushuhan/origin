package com.yinwang.nav.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.yinwang.nav.entity.SearchEngine;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface SearchEngineMapper extends BaseMapper<SearchEngine> {
}

