package com.yinwang.nav.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.yinwang.nav.entity.UserWorkspace;

import java.util.List;

public interface UserWorkspaceService extends IService<UserWorkspace> {
    
    List<UserWorkspace> getUserWorkspaces(String userId);
    
    UserWorkspace addToWorkspace(UserWorkspace workspace);
    
    UserWorkspace addFromWebsite(String userId, Long websiteId);
    
    void updateSortOrder(String userId, List<Long> ids);
    
    void removeFromWorkspace(String userId, Long id);
}

