package com.yinwang.nav.entity;

import com.baomidou.mybatisplus.annotation.*;
import com.yinwang.common.entity.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

/**
 * 网址分区实体
 */
@Data
@EqualsAndHashCode(callSuper = true)
@TableName("sections")
public class Section extends BaseEntity {
    
    @TableId(type = IdType.AUTO)
    private Long id;
    
    private Long categoryId;
    
    private String name;
    
    private String description;
    
    private Integer sortOrder;
    
    private Boolean isVisible;
    
    @TableField(exist = false)
    private List<Website> websites;
}

