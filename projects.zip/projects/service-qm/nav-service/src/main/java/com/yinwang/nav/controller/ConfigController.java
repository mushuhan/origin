package com.yinwang.nav.controller;

import com.yinwang.common.result.Result;
import com.yinwang.nav.service.SystemConfigService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@Tag(name = "系统配置", description = "系统配置相关接口")
@RestController
@RequestMapping("/api/config")
@RequiredArgsConstructor
public class ConfigController {
    
    private final SystemConfigService systemConfigService;
    
    @Operation(summary = "获取所有系统配置")
    @GetMapping
    public Result<Map<String, String>> getAllConfigs() {
        return Result.success(systemConfigService.getAllConfigs());
    }
    
    @Operation(summary = "获取指定配置")
    @GetMapping("/{key}")
    public Result<String> getConfig(@PathVariable String key) {
        String value = systemConfigService.getConfigValue(key);
        if (value == null) {
            return Result.error("配置项不存在");
        }
        return Result.success(value);
    }
}

