package com.yinwang.nav;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

/**
 * 导航服务启动类
 */
@SpringBootApplication
@MapperScan("com.yinwang.nav.mapper")
@ComponentScan(basePackages = {"com.yinwang.nav", "com.yinwang.common"})
public class NavServiceApplication {
    public static void main(String[] args) {
        SpringApplication.run(NavServiceApplication.class, args);
        System.out.println("=================================");
        System.out.println("  Nav Service 启动成功!");
        System.out.println("  端口: 8081");
        System.out.println("  API文档: http://localhost:8081/doc.html");
        System.out.println("=================================");
    }
}

