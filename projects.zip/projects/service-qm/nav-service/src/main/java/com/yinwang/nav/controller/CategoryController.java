package com.yinwang.nav.controller;

import com.yinwang.common.result.Result;
import com.yinwang.nav.dto.CategoryWithSectionsDTO;
import com.yinwang.nav.entity.Category;
import com.yinwang.nav.service.CategoryService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Tag(name = "分类管理", description = "网址分类相关接口")
@RestController
@RequestMapping("/api/categories")
@RequiredArgsConstructor
public class CategoryController {
    
    private final CategoryService categoryService;
    
    @Operation(summary = "获取所有分类列表")
    @GetMapping
    public Result<List<Category>> getCategories() {
        return Result.success(categoryService.getVisibleCategories());
    }
    
    @Operation(summary = "获取分类详情（包含分区和网站）")
    @GetMapping("/{id}")
    public Result<CategoryWithSectionsDTO> getCategoryDetail(@PathVariable Long id) {
        CategoryWithSectionsDTO dto = categoryService.getCategoryWithSections(id);
        if (dto == null) {
            return Result.error("分类不存在");
        }
        return Result.success(dto);
    }
    
    @Operation(summary = "获取所有分类及其内容")
    @GetMapping("/all")
    public Result<List<CategoryWithSectionsDTO>> getAllCategoriesWithContent() {
        return Result.success(categoryService.getAllCategoriesWithSections());
    }
}

