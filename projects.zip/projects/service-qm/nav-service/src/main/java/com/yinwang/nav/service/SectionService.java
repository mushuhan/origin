package com.yinwang.nav.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.yinwang.nav.entity.Section;

import java.util.List;

public interface SectionService extends IService<Section> {
    
    List<Section> getSectionsByCategoryId(Long categoryId);
    
    Section getSectionWithWebsites(Long sectionId);
}

