package com.yinwang.nav.dto;

import com.yinwang.nav.entity.Category;
import com.yinwang.nav.entity.Section;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

/**
 * 分类及其分区和网站的DTO
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class CategoryWithSectionsDTO extends Category {
    
    private List<Section> sections;
}

