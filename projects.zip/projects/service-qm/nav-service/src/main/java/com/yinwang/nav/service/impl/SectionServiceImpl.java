package com.yinwang.nav.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.yinwang.nav.entity.Section;
import com.yinwang.nav.entity.Website;
import com.yinwang.nav.mapper.SectionMapper;
import com.yinwang.nav.service.SectionService;
import com.yinwang.nav.service.WebsiteService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class SectionServiceImpl extends ServiceImpl<SectionMapper, Section> implements SectionService {
    
    private final WebsiteService websiteService;
    
    @Override
    public List<Section> getSectionsByCategoryId(Long categoryId) {
        List<Section> sections = list(new LambdaQueryWrapper<Section>()
                .eq(Section::getCategoryId, categoryId)
                .eq(Section::getIsVisible, true)
                .orderByAsc(Section::getSortOrder));
        
        sections.forEach(section -> {
            List<Website> websites = websiteService.getWebsitesBySectionId(section.getId());
            section.setWebsites(websites);
        });
        
        return sections;
    }
    
    @Override
    public Section getSectionWithWebsites(Long sectionId) {
        Section section = getById(sectionId);
        if (section != null) {
            List<Website> websites = websiteService.getWebsitesBySectionId(sectionId);
            section.setWebsites(websites);
        }
        return section;
    }
}

