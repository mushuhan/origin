package com.yinwang.nav.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.yinwang.nav.entity.HotSearch;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface HotSearchMapper extends BaseMapper<HotSearch> {
}

