package com.yinwang.nav.controller;

import com.yinwang.common.result.Result;
import com.yinwang.nav.entity.Website;
import com.yinwang.nav.service.WebsiteService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Tag(name = "网站管理", description = "网站相关接口")
@RestController
@RequestMapping("/api/websites")
@RequiredArgsConstructor
public class WebsiteController {
    
    private final WebsiteService websiteService;
    
    @Operation(summary = "获取分区下的网站列表")
    @GetMapping("/section/{sectionId}")
    public Result<List<Website>> getWebsitesBySection(@PathVariable Long sectionId) {
        return Result.success(websiteService.getWebsitesBySectionId(sectionId));
    }
    
    @Operation(summary = "获取网站详情")
    @GetMapping("/{id}")
    public Result<Website> getWebsite(@PathVariable Long id) {
        Website website = websiteService.getById(id);
        if (website == null) {
            return Result.error("网站不存在");
        }
        return Result.success(website);
    }
    
    @Operation(summary = "获取热门网站")
    @GetMapping("/hot")
    public Result<List<Website>> getHotWebsites(
            @Parameter(description = "返回数量") @RequestParam(defaultValue = "20") int limit) {
        return Result.success(websiteService.getHotWebsites(limit));
    }
    
    @Operation(summary = "增加网站点击次数")
    @PostMapping("/{id}/click")
    public Result<Void> clickWebsite(@PathVariable Long id) {
        websiteService.incrementClickCount(id);
        return Result.success();
    }
}

