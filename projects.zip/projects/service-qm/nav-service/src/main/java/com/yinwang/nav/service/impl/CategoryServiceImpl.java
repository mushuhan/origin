package com.yinwang.nav.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.yinwang.nav.dto.CategoryWithSectionsDTO;
import com.yinwang.nav.entity.Category;
import com.yinwang.nav.entity.Section;
import com.yinwang.nav.mapper.CategoryMapper;
import com.yinwang.nav.service.CategoryService;
import com.yinwang.nav.service.SectionService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class CategoryServiceImpl extends ServiceImpl<CategoryMapper, Category> implements CategoryService {
    
    private final SectionService sectionService;
    
    @Override
    public List<Category> getVisibleCategories() {
        return list(new LambdaQueryWrapper<Category>()
                .eq(Category::getIsVisible, true)
                .orderByAsc(Category::getSortOrder));
    }
    
    @Override
    public CategoryWithSectionsDTO getCategoryWithSections(Long categoryId) {
        Category category = getById(categoryId);
        if (category == null) {
            return null;
        }
        
        CategoryWithSectionsDTO dto = new CategoryWithSectionsDTO();
        BeanUtils.copyProperties(category, dto);
        
        List<Section> sections = sectionService.getSectionsByCategoryId(categoryId);
        dto.setSections(sections);
        
        return dto;
    }
    
    @Override
    public List<CategoryWithSectionsDTO> getAllCategoriesWithSections() {
        List<Category> categories = getVisibleCategories();
        
        return categories.stream().map(category -> {
            CategoryWithSectionsDTO dto = new CategoryWithSectionsDTO();
            BeanUtils.copyProperties(category, dto);
            List<Section> sections = sectionService.getSectionsByCategoryId(category.getId());
            dto.setSections(sections);
            return dto;
        }).collect(Collectors.toList());
    }
}

