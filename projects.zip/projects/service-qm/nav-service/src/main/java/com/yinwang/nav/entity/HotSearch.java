package com.yinwang.nav.entity;

import com.baomidou.mybatisplus.annotation.*;
import com.yinwang.common.entity.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 热门搜索词实体
 */
@Data
@EqualsAndHashCode(callSuper = true)
@TableName("hot_searches")
public class HotSearch extends BaseEntity {
    
    @TableId(type = IdType.AUTO)
    private Long id;
    
    private String keyword;
    
    private Long searchCount;
}

