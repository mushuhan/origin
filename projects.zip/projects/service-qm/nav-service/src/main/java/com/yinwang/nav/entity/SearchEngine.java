package com.yinwang.nav.entity;

import com.baomidou.mybatisplus.annotation.*;
import com.yinwang.common.entity.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 搜索引擎实体
 */
@Data
@EqualsAndHashCode(callSuper = true)
@TableName("search_engines")
public class SearchEngine extends BaseEntity {
    
    @TableId(type = IdType.AUTO)
    private Long id;
    
    private String name;
    
    private String urlTemplate;
    
    private String icon;
    
    private Integer sortOrder;
    
    private Boolean isDefault;
    
    private Boolean isVisible;
}

