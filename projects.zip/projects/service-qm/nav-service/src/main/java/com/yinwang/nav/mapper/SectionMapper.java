package com.yinwang.nav.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.yinwang.nav.entity.Section;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface SectionMapper extends BaseMapper<Section> {
}

