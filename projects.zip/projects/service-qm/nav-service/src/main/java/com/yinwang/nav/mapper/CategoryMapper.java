package com.yinwang.nav.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.yinwang.nav.entity.Category;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface CategoryMapper extends BaseMapper<Category> {
}

