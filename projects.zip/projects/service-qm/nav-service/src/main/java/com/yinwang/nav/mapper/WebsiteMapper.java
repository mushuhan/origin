package com.yinwang.nav.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.yinwang.nav.entity.Website;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface WebsiteMapper extends BaseMapper<Website> {
    
    @Select("SELECT * FROM websites WHERE (name LIKE CONCAT('%', #{keyword}, '%') OR description LIKE CONCAT('%', #{keyword}, '%')) AND is_visible = 1 ORDER BY click_count DESC LIMIT #{limit}")
    List<Website> fuzzySearch(@Param("keyword") String keyword, @Param("limit") int limit);
}

