package com.yinwang.nav.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.yinwang.nav.entity.SystemConfig;
import com.yinwang.nav.mapper.SystemConfigMapper;
import com.yinwang.nav.service.SystemConfigService;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class SystemConfigServiceImpl extends ServiceImpl<SystemConfigMapper, SystemConfig> implements SystemConfigService {
    
    @Override
    public String getConfigValue(String key) {
        SystemConfig config = getOne(new LambdaQueryWrapper<SystemConfig>()
                .eq(SystemConfig::getConfigKey, key));
        return config != null ? config.getConfigValue() : null;
    }
    
    @Override
    public Map<String, String> getAllConfigs() {
        List<SystemConfig> configs = list();
        Map<String, String> result = new HashMap<>();
        configs.forEach(config -> result.put(config.getConfigKey(), config.getConfigValue()));
        return result;
    }
}

