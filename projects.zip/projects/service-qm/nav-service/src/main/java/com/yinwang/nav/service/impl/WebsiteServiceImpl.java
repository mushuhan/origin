package com.yinwang.nav.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.yinwang.nav.entity.Website;
import com.yinwang.nav.mapper.WebsiteMapper;
import com.yinwang.nav.service.WebsiteService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class WebsiteServiceImpl extends ServiceImpl<WebsiteMapper, Website> implements WebsiteService {
    
    @Override
    public List<Website> getWebsitesBySectionId(Long sectionId) {
        return list(new LambdaQueryWrapper<Website>()
                .eq(Website::getSectionId, sectionId)
                .eq(Website::getIsVisible, true)
                .orderByAsc(Website::getSortOrder));
    }
    
    @Override
    public List<Website> searchWebsites(String keyword, int limit) {
        return baseMapper.fuzzySearch(keyword, limit);
    }
    
    @Override
    public List<Website> getHotWebsites(int limit) {
        return list(new LambdaQueryWrapper<Website>()
                .eq(Website::getIsHot, true)
                .eq(Website::getIsVisible, true)
                .orderByDesc(Website::getClickCount)
                .last("LIMIT " + limit));
    }
    
    @Override
    public void incrementClickCount(Long websiteId) {
        Website website = getById(websiteId);
        if (website != null) {
            website.setClickCount(website.getClickCount() + 1);
            updateById(website);
        }
    }
}

