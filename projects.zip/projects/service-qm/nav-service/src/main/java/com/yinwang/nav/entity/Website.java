package com.yinwang.nav.entity;

import com.baomidou.mybatisplus.annotation.*;
import com.yinwang.common.entity.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 网站信息实体
 */
@Data
@EqualsAndHashCode(callSuper = true)
@TableName("websites")
public class Website extends BaseEntity {
    
    @TableId(type = IdType.AUTO)
    private Long id;
    
    private Long sectionId;
    
    private String name;
    
    private String url;
    
    private String icon;
    
    private String description;
    
    private Integer sortOrder;
    
    private Long clickCount;
    
    private Boolean isHot;
    
    private Boolean isVisible;
}

