package com.yinwang.nav.entity;

import com.baomidou.mybatisplus.annotation.*;
import com.yinwang.common.entity.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 网址分类实体
 */
@Data
@EqualsAndHashCode(callSuper = true)
@TableName("categories")
public class Category extends BaseEntity {
    
    @TableId(type = IdType.AUTO)
    private Long id;
    
    private String name;
    
    private String icon;
    
    private String description;
    
    private Integer sortOrder;
    
    private Boolean isVisible;
}

