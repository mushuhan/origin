package com.yinwang.nav.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.yinwang.nav.entity.SearchEngine;
import com.yinwang.nav.mapper.SearchEngineMapper;
import com.yinwang.nav.service.SearchEngineService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SearchEngineServiceImpl extends ServiceImpl<SearchEngineMapper, SearchEngine> implements SearchEngineService {
    
    @Override
    public List<SearchEngine> getVisibleSearchEngines() {
        return list(new LambdaQueryWrapper<SearchEngine>()
                .eq(SearchEngine::getIsVisible, true)
                .orderByAsc(SearchEngine::getSortOrder));
    }
    
    @Override
    public SearchEngine getDefaultSearchEngine() {
        return getOne(new LambdaQueryWrapper<SearchEngine>()
                .eq(SearchEngine::getIsDefault, true)
                .eq(SearchEngine::getIsVisible, true));
    }
}

