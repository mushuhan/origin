package com.yinwang.nav.controller;

import com.yinwang.common.result.Result;
import com.yinwang.nav.dto.WorkspaceDTO;
import com.yinwang.nav.entity.UserWorkspace;
import com.yinwang.nav.service.UserWorkspaceService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.BeanUtils;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Tag(name = "工作台管理", description = "用户自定义工作台相关接口")
@RestController
@RequestMapping("/api/workspace")
@RequiredArgsConstructor
public class WorkspaceController {
    
    private final UserWorkspaceService userWorkspaceService;
    
    @Operation(summary = "获取用户工作台网址列表")
    @GetMapping("/{userId}")
    public Result<List<UserWorkspace>> getUserWorkspace(@PathVariable String userId) {
        return Result.success(userWorkspaceService.getUserWorkspaces(userId));
    }
    
    @Operation(summary = "添加网址到工作台")
    @PostMapping
    public Result<UserWorkspace> addToWorkspace(@Valid @RequestBody WorkspaceDTO dto) {
        UserWorkspace workspace = new UserWorkspace();
        BeanUtils.copyProperties(dto, workspace);
        return Result.success(userWorkspaceService.addToWorkspace(workspace));
    }
    
    @Operation(summary = "从系统网址添加到工作台")
    @PostMapping("/from-website")
    public Result<UserWorkspace> addFromWebsite(
            @Parameter(description = "用户ID") @RequestParam String userId,
            @Parameter(description = "网站ID") @RequestParam Long websiteId) {
        return Result.success(userWorkspaceService.addFromWebsite(userId, websiteId));
    }
    
    @Operation(summary = "更新工作台网址")
    @PutMapping("/{id}")
    public Result<UserWorkspace> updateWorkspace(
            @PathVariable Long id,
            @RequestBody WorkspaceDTO dto) {
        UserWorkspace workspace = userWorkspaceService.getById(id);
        if (workspace == null) {
            return Result.error("网址不存在");
        }
        
        if (dto.getName() != null) workspace.setName(dto.getName());
        if (dto.getUrl() != null) workspace.setUrl(dto.getUrl());
        if (dto.getIcon() != null) workspace.setIcon(dto.getIcon());
        if (dto.getDescription() != null) workspace.setDescription(dto.getDescription());
        
        userWorkspaceService.updateById(workspace);
        return Result.success(workspace);
    }
    
    @Operation(summary = "更新工作台排序")
    @PutMapping("/{userId}/sort")
    public Result<Void> updateSortOrder(
            @PathVariable String userId,
            @RequestBody List<Long> ids) {
        userWorkspaceService.updateSortOrder(userId, ids);
        return Result.success();
    }
    
    @Operation(summary = "从工作台删除网址")
    @DeleteMapping("/{userId}/{id}")
    public Result<Void> removeFromWorkspace(
            @PathVariable String userId,
            @PathVariable Long id) {
        userWorkspaceService.removeFromWorkspace(userId, id);
        return Result.success();
    }
}

