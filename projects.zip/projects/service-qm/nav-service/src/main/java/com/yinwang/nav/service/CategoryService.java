package com.yinwang.nav.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.yinwang.nav.dto.CategoryWithSectionsDTO;
import com.yinwang.nav.entity.Category;

import java.util.List;

public interface CategoryService extends IService<Category> {
    
    List<Category> getVisibleCategories();
    
    CategoryWithSectionsDTO getCategoryWithSections(Long categoryId);
    
    List<CategoryWithSectionsDTO> getAllCategoriesWithSections();
}

