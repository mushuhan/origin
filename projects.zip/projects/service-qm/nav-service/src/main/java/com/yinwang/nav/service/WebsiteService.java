package com.yinwang.nav.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.yinwang.nav.entity.Website;

import java.util.List;

public interface WebsiteService extends IService<Website> {
    
    List<Website> getWebsitesBySectionId(Long sectionId);
    
    List<Website> searchWebsites(String keyword, int limit);
    
    List<Website> getHotWebsites(int limit);
    
    void incrementClickCount(Long websiteId);
}

