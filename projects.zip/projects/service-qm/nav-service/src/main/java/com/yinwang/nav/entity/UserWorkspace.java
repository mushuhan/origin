package com.yinwang.nav.entity;

import com.baomidou.mybatisplus.annotation.*;
import com.yinwang.common.entity.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 用户自定义工作台实体
 */
@Data
@EqualsAndHashCode(callSuper = true)
@TableName("user_workspaces")
public class UserWorkspace extends BaseEntity {
    
    @TableId(type = IdType.AUTO)
    private Long id;
    
    private String userId;
    
    private String name;
    
    private String url;
    
    private String icon;
    
    private String description;
    
    private Integer sortOrder;
    
    private Long websiteId;
}

