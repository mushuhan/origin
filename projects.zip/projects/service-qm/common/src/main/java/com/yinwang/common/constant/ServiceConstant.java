package com.yinwang.common.constant;

/**
 * 服务常量
 */
public class ServiceConstant {
    
    /**
     * 服务名称
     */
    public static final String NAV_SERVICE = "nav-service";
    public static final String GATEWAY_SERVICE = "gateway";
    
    /**
     * API前缀
     */
    public static final String API_PREFIX = "/api";
    
    /**
     * 默认分页参数
     */
    public static final int DEFAULT_PAGE_NUM = 1;
    public static final int DEFAULT_PAGE_SIZE = 20;
    public static final int MAX_PAGE_SIZE = 100;
    
    private ServiceConstant() {
    }
}

