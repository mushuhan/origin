# 功能修改指南 v2

本文档详细说明了项目的功能修改和新增内容。

---

## 📋 修改概览

### 1. 轮播图优化
- ✅ 固定高度显示（280px），不随右侧排行榜高度变化
- ✅ 取消鼠标悬停时的模糊化效果
- ✅ 改为展示真实图片（从 assets 目录读取）

### 2. 布局调整
- ✅ 科室简介移至轮播图下方，同在排行榜左侧
- ✅ 排行榜固定定位（sticky）
- ✅ 整体采用黑白灰简约高级风

### 3. 科室简介优化
- ✅ 简洁化显示：横向滚动列表
- ✅ 默认仅显示部分描述，超出省略
- ✅ 点击弹窗显示详情
- ✅ 采用衬线体字体（与语录一致）
- ✅ 数据存储在数据库中

### 4. 看板生成器优化
- ✅ 入口简洁化（集成到快捷入口按钮组）
- ✅ 新建图表默认选择"不聚合"
- ✅ 新增统计卡片功能（字段计数/求和/平均等）
- ✅ 看板存储到数据库
- ✅ 可选择对全部人开放或仅自己可见
- ✅ 界面整体简洁化

---

## 📁 文件变更清单

### 前端 (web-net)

#### 新增文件
| 文件路径 | 说明 |
|---------|------|
| `src/components/common/ImageCarousel.vue` | 图片轮播组件 |

#### 修改文件
| 文件路径 | 修改内容 |
|---------|---------|
| `src/views/Home.vue` | 布局调整、科室简介简洁化、看板入口移至按钮组 |
| `src/views/Dashboard.vue` | 全面优化：不聚合、统计卡片、数据库存储、可见性 |
| `src/components/common/CoverflowCarousel.vue` | 取消模糊效果 |
| `src/router/index.js` | 添加看板路由 |
| `src/api/index.js` | 添加看板和科室API |
| `package.json` | 添加 xlsx、echarts 依赖 |

#### 删除文件
| 文件路径 | 原因 |
|---------|------|
| `src/components/common/DepartmentCarousel.vue` | 科室显示已整合到Home.vue |

### 后端 (server-net)

#### 新增文件
| 文件路径 | 说明 |
|---------|------|
| `app/controllers/dashboards.py` | 看板控制器 |
| `app/controllers/departments.py` | 科室控制器 |
| `app/models/dashboard.py` | 看板模型 |
| `app/models/department.py` | 科室模型 |

#### 修改文件
| 文件路径 | 修改内容 |
|---------|---------|
| `app/__init__.py` | 注册新蓝图 |
| `database.sql` | 添加dashboards和departments表 |

---

## 🚀 安装与运行

### 1. 安装新依赖

```bash
cd web-net
npm install
```

### 2. 更新数据库

在MySQL中执行新增的表结构：

```sql
-- 数据看板表
CREATE TABLE dashboards (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_uuid VARCHAR(36) NOT NULL,
    name VARCHAR(100) NOT NULL,
    config LONGTEXT DEFAULT NULL,
    visibility VARCHAR(20) DEFAULT 'private',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_uuid) REFERENCES users(uuid) ON DELETE CASCADE
);

-- 科室信息表
CREATE TABLE departments (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    description TEXT DEFAULT NULL,
    icon VARCHAR(50) DEFAULT 'OfficeBuilding',
    contact VARCHAR(100) DEFAULT NULL,
    sort_order INT DEFAULT 0,
    is_active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- 索引
CREATE INDEX idx_dashboards_user ON dashboards(user_uuid);
CREATE INDEX idx_dashboards_visibility ON dashboards(visibility);
CREATE INDEX idx_departments_active ON departments(is_active);
CREATE INDEX idx_departments_sort ON departments(sort_order);

-- 科室初始数据
INSERT INTO departments (name, description, icon, contact, sort_order) VALUES
('信息技术部', '负责公司信息系统建设与维护...', 'Monitor', '分机 8001', 1),
('人力资源部', '负责人才招聘、培训发展...', 'User', '分机 8002', 2),
('财务管理部', '负责财务规划、成本控制...', 'Wallet', '分机 8003', 3),
('市场营销部', '负责市场调研、品牌推广...', 'TrendCharts', '分机 8004', 4),
('行政综合部', '负责行政管理、后勤保障...', 'OfficeBuilding', '分机 8005', 5);
```

### 3. 启动项目

```bash
# 前端
cd web-net
npm run dev

# 后端
cd server-net
python run.py
```

---

## 📖 功能详解

### 首页布局

```
┌─────────────────────────────────────────────────┐
│                搜索框 + 语录轮播                 │
│         [工作台] [热门] [看板] ← 简洁入口         │
├────────────────────────────┬────────────────────┤
│                            │                    │
│        图片轮播 (280px)     │                    │
│                            │    热门排行榜       │
├────────────────────────────┤    (固定sticky)    │
│   科室简介 (横向滚动)        │                    │
│   [信息技术部][人力资源部]... │                    │
└────────────────────────────┴────────────────────┘
```

### 看板生成器功能

| 功能 | 说明 |
|------|------|
| **聚合方式** | 支持"不聚合"作为默认选项 |
| **统计卡片** | 对字段进行计数/求和/平均/最大/最小 |
| **可见性** | 私有（仅自己）或公开（所有人） |
| **数据库存储** | 看板自动保存到服务器 |

### API 接口

#### 看板 API
```
GET    /api/dashboards          # 获取看板列表
GET    /api/dashboards/:id      # 获取看板详情
POST   /api/dashboards          # 创建看板
PUT    /api/dashboards/:id      # 更新看板
DELETE /api/dashboards/:id      # 删除看板
```

#### 科室 API
```
GET    /api/departments         # 获取科室列表
GET    /api/departments/:id     # 获取科室详情
POST   /api/departments         # 创建科室
PUT    /api/departments/:id     # 更新科室
DELETE /api/departments/:id     # 删除科室
```

---

## 🎨 设计风格

- **色调**: 黑白灰简约高级风
- **字体**: 
  - 主体: 系统无衬线字体
  - 科室/语录: 衬线体 (Noto Serif SC)
- **圆角**: 10-16px
- **阴影**: 轻微阴影，保持简洁
- **交互**: 悬停显示操作按钮

---

## 📝 配置说明

### 修改科室数据

科室数据存储在数据库中，可通过后台API管理，或在 `Home.vue` 中修改默认数据：

```javascript
const departments = ref([
  { 
    id: 1, 
    name: '科室名称', 
    description: '科室描述...',
    icon: 'Monitor',  // Element Plus 图标
    contact: '联系方式'
  },
  // ...
])
```

### 修改轮播图片

在 `Home.vue` 中修改 `bannerImages` 数组，图片存放在 `src/assets/` 目录。

---

## 📌 版本信息

- 修改日期: 2024年
- 版本: v2.0
- 适用项目版本: web-net 1.0.0
