import { createStore } from 'vuex'
import * as api from '@/api'
import adminModule from './admin'

export default createStore({
  modules: {
    admin: adminModule
  },
  state: {
    // 主题
    isDark: localStorage.getItem('theme') === 'dark',
    
    // 侧边栏
    sidebarCollapsed: localStorage.getItem('sidebarCollapsed') === 'true',
    
    // 用户信息
    user: null,
    userToken: api.getUserToken(),
    
    // 分类数据
    categories: [],
    currentCategory: null,
    
    // 工作台数据
    workspace: [],
    folders: [],       // 网址文件夹 (sites)
    fileFolders: [],   // 数据文件文件夹 (files)
    
    // 热门网址
    hotWebsites: [],
    
    // 语录
    quotes: [],
    
    // 系统设置
    settings: {},
    
    // 搜索
    searchKeyword: '',
    searchResults: [],
    searchSuggestions: [],
    hotKeywords: [],
    
    // 加载状态
    loading: false,
    
    // 全局消息
    message: null
  },
  
  getters: {
    // 获取非系统分类
    regularCategories: state => state.categories.filter(c => !c.is_system),
    
    // 获取工作台分类
    workspaceCategory: state => state.categories.find(c => c.is_system),
    
    // 当前主题
    theme: state => state.isDark ? 'dark' : 'light',
    
    // 是否已登录（有用户Token）
    isLoggedIn: state => !!state.userToken,
    
    // 工作台网址数量
    workspaceCount: state => state.workspace.length,
    
    // 文件夹树（网址）
    folderTree: state => state.folders,
    
    // 文件夹树（数据文件）
    fileFolderTree: state => state.fileFolders
  },
  
  mutations: {
    // 设置主题
    SET_THEME(state, isDark) {
      state.isDark = isDark
      localStorage.setItem('theme', isDark ? 'dark' : 'light')
      
      if (isDark) {
        document.documentElement.classList.add('dark')
        document.body.classList.add('dark')
      } else {
        document.documentElement.classList.remove('dark')
        document.body.classList.remove('dark')
      }
    },
    
    // 切换侧边栏
    TOGGLE_SIDEBAR(state) {
      state.sidebarCollapsed = !state.sidebarCollapsed
      localStorage.setItem('sidebarCollapsed', state.sidebarCollapsed)
    },
    
    // 设置侧边栏状态
    SET_SIDEBAR_COLLAPSED(state, collapsed) {
      state.sidebarCollapsed = collapsed
      localStorage.setItem('sidebarCollapsed', collapsed)
    },
    
    // 设置用户
    SET_USER(state, user) {
      state.user = user
    },
    
    // 设置分类
    SET_CATEGORIES(state, categories) {
      state.categories = categories
    },
    
    // 设置当前分类
    SET_CURRENT_CATEGORY(state, category) {
      state.currentCategory = category
    },
    
    // 设置工作台
    SET_WORKSPACE(state, workspace) {
      state.workspace = workspace
    },
    
    // 设置网址文件夹
    SET_FOLDERS(state, folders) {
      state.folders = folders
    },
    
    // 设置数据文件文件夹
    SET_FILE_FOLDERS(state, folders) {
      state.fileFolders = folders
    },
    
    // 添加到工作台
    ADD_TO_WORKSPACE(state, item) {
      // 辅助函数：递归查找文件夹并添加网址
      const findFolderAndAddItem = (folders) => {
        for (const folder of folders) {
          // 找到目标文件夹
          if (folder.id === item.folder_id) {
            if (!folder.sites) folder.sites = []
            folder.sites.push(item)
            folder.sites_count = (folder.sites_count || 0) + 1
            return true
          }
          // 递归查找子文件夹
          if (folder.children && folder.children.length > 0) {
            if (findFolderAndAddItem(folder.children)) return true
          }
        }
        return false
      }

      // 如果属于某个文件夹，尝试添加到文件夹结构中
      if (item.folder_id) {
        const added = findFolderAndAddItem(state.folders)
        // 如果没找到文件夹（理论上不应发生），或者确实是未分组（逻辑上不应进这个if），则不处理或做备选处理
        if (!added) {
          // 可选：如果没找到文件夹，是否要放到未分组？通常不需要，可能是数据不一致
          console.warn('Added item to unknown folder:', item.folder_id)
        }
      } else {
        // 如果没有 folder_id，直接添加到根目录（未分组列表）
        state.workspace.push(item)
      }
    },

    INCREMENT_CLICK_COUNT(state, websiteId) {
      // 1. 更新热门网址列表
      const hotSite = state.hotWebsites.find(w => w.id === websiteId)
      if (hotSite) hotSite.click_count = (hotSite.click_count || 0) + 1

      // 2. 更新搜索结果列表
      const searchSite = state.searchResults.find(w => w.id === websiteId)
      if (searchSite) searchSite.click_count = (searchSite.click_count || 0) + 1

      // 3. 更新分类列表中的网址
      state.categories.forEach(cat => {
        if (cat.sections) {
          cat.sections.forEach(sec => {
            if (sec.websites) {
              const site = sec.websites.find(w => w.id === websiteId)
              if (site) site.click_count = (site.click_count || 0) + 1
            }
          })
        }
      })
    },
    
    // 从工作台移除
    REMOVE_FROM_WORKSPACE(state, id) {
      state.workspace = state.workspace.filter(item => item.id !== id)
    },
    
    // 更新工作台项目
    UPDATE_WORKSPACE_ITEM(state, updatedItem) {
      const index = state.workspace.findIndex(item => item.id === updatedItem.id)
      if (index !== -1) {
        state.workspace.splice(index, 1, updatedItem)
      }
    },
    
    // 设置热门网址
    SET_HOT_WEBSITES(state, websites) {
      state.hotWebsites = websites
    },
    
    // 设置语录
    SET_QUOTES(state, quotes) {
      state.quotes = quotes || []
    },

    // 设置单条语录（兼容随机获取）
    SET_QUOTE(state, quote) {
      if (Array.isArray(quote)) {
        state.quotes = quote
      } else if (quote) {
        state.quotes = [quote]
      }
    },
    
    // 设置系统设置
    SET_SETTINGS(state, settings) {
      state.settings = settings
    },
    
    // 设置搜索关键词
    SET_SEARCH_KEYWORD(state, keyword) {
      state.searchKeyword = keyword
    },
    
    // 设置搜索结果
    SET_SEARCH_RESULTS(state, results) {
      state.searchResults = results
    },
    
    // 设置搜索建议
    SET_SEARCH_SUGGESTIONS(state, { suggestions, hotKeywords }) {
      state.searchSuggestions = suggestions || []
      state.hotKeywords = hotKeywords || []
    },
    
    // 设置加载状态
    SET_LOADING(state, loading) {
      state.loading = loading
    },
    
    // 设置消息
    SET_MESSAGE(state, message) {
      state.message = message
    },
    
    // 添加文件夹（通用）
    ADD_FOLDER(state, folder) {
      const targetList = folder.category === 'files' ? state.fileFolders : state.folders
      
      // 情况1：如果是根目录文件夹（没有 parent_id），直接添加
      if (!folder.parent_id) {
        targetList.push(folder)
        return
      }

      // 情况2：如果是子文件夹，递归查找父节点
      const findParentAndAdd = (list) => {
        for (const item of list) {
          // 找到父文件夹
          if (item.id === folder.parent_id) {
            if (!item.children) item.children = []
            item.children.push(folder)
            return true
          }
          
          // 递归查找子级
          if (item.children && item.children.length > 0) {
            if (findParentAndAdd(item.children)) return true
          }
        }
        return false
      }

      // 执行查找
      const added = findParentAndAdd(targetList)
      
      // 容错：如果没找到父节点（极少情况），为了防止数据丢失，暂时放到根目录
      if (!added) {
        console.warn('Parent folder not found for:', folder)
        targetList.push(folder)
      }
    },
    
    // 更新文件夹（通用）
    UPDATE_FOLDER(state, updatedFolder) {
      const targetList = updatedFolder.category === 'files' ? state.fileFolders : state.folders
      
      const updateRecursive = (list) => {
        for (let i = 0; i < list.length; i++) {
          // 找到目标文件夹
          if (list[i].id === updatedFolder.id) {
            const oldFolder = list[i]
            
            // 使用新数据替换，但强制保留原有的子结构和统计数据
            list.splice(i, 1, {
              ...updatedFolder,                 // 新的名称、图标等
              children: oldFolder.children,     // 关键：保留子文件夹
              sites: oldFolder.sites,           // 关键：保留网址
              sites_count: oldFolder.sites_count // 关键：保留数量统计
            })
            return true
          }
          
          // 如果没找到，且当前文件夹有子级，则递归查找
          if (list[i].children && list[i].children.length > 0) {
            if (updateRecursive(list[i].children)) return true
          }
        }
        return false
      }
      
      // 开始递归查找（尝试两个列表）
      if (!updateRecursive(targetList)) {
        // 如果在目标列表没找到，尝试另一个列表（容错）
        const otherList = updatedFolder.category === 'files' ? state.folders : state.fileFolders
        updateRecursive(otherList)
      }
    },
    
    // 删除文件夹（通用）
    // 支持递归删除，会同时在两个列表中查找
    REMOVE_FOLDER(state, id) {
      // 辅助函数：递归查找并删除
      const removeRecursive = (list) => {
        for (let i = 0; i < list.length; i++) {
          // 找到要删除的文件夹
          if (list[i].id === id) {
            list.splice(i, 1) // 从数组中移除
            return true // 删除成功，停止查找
          }
          
          // 如果当前文件夹有子级，递归查找
          if (list[i].children && list[i].children.length > 0) {
            // 如果在子级中删除了，也返回 true
            if (removeRecursive(list[i].children)) return true
          }
        }
        return false
      }
      
      // 在两个列表中查找并删除
      if (!removeRecursive(state.folders)) {
        removeRecursive(state.fileFolders)
      }
    },
  },
  
  actions: {
    // 初始化主题
    initTheme({ commit, state }) {
      // 检查系统偏好
      if (localStorage.getItem('theme') === null) {
        const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches
        commit('SET_THEME', prefersDark)
      } else {
        commit('SET_THEME', state.isDark)
      }
    },
    
    // 切换主题
    toggleTheme({ commit, state }) {
      commit('SET_THEME', !state.isDark)
    },
    
    // 初始化用户
    async initUser({ commit, state }) {
      try {
        // 注册/获取用户
        const user = await api.registerUser(state.userToken)
        commit('SET_USER', user)
      } catch (error) {
        console.error('初始化用户失败:', error)
      }
    },
    
    // 获取首页数据
    async fetchHomeData({ commit }) {
      commit('SET_LOADING', true)
      try {
        const data = await api.getHomeData()
        commit('SET_CATEGORIES', data.categories || [])
        commit('SET_HOT_WEBSITES', data.hot_websites || [])
        commit('SET_SETTINGS', data.settings || {})
        commit('SET_QUOTES', data.quotes || [])
      } catch (error) {
        console.error('获取首页数据失败:', error)
        commit('SET_MESSAGE', { type: 'error', text: '获取数据失败' })
      } finally {
        commit('SET_LOADING', false)
      }
    },
    
    // 获取分类数据
    async fetchCategories({ commit }) {
      try {
        const categories = await api.getCategories(true)
        commit('SET_CATEGORIES', categories)
      } catch (error) {
        console.error('获取分类失败:', error)
      }
    },
    
    // 获取单个分类详情
    async fetchCategory({ commit }, id) {
      commit('SET_LOADING', true)
      try {
        const category = await api.getCategory(id)
        commit('SET_CURRENT_CATEGORY', category)
        return category
      } catch (error) {
        console.error('获取分类详情失败:', error)
        throw error
      } finally {
        commit('SET_LOADING', false)
      }
    },
    
    // 获取工作台数据（网址部分）
    async fetchWorkspace({ commit }) {
      try {
        const data = await api.getAllWorkspace()
        commit('SET_WORKSPACE', data.ungrouped || [])
        commit('SET_FOLDERS', data.folders || [])
      } catch (error) {
        console.error('获取工作台数据失败:', error)
      }
    },
    
    // 获取数据文件文件夹
    async fetchFileFolders({ commit }) {
      try {
        const folders = await api.getFolders(false, false, 'files')
        commit('SET_FILE_FOLDERS', folders || [])
      } catch (error) {
        console.error('获取文件夹失败:', error)
      }
    },
    
    // 添加到工作台
    async addToWorkspace({ commit }, data) {
      try {
        const item = await api.addToWorkspace(data)
        commit('ADD_TO_WORKSPACE', item)
        commit('SET_MESSAGE', { type: 'success', text: '添加成功' })
        return item
      } catch (error) {
        commit('SET_MESSAGE', { type: 'error', text: error.message || '添加失败' })
        throw error
      }
    },
    
    // 更新工作台项目
    async updateWorkspaceItem({ commit }, { id, data }) {
      try {
        const item = await api.updateWorkspaceItem(id, data)
        commit('UPDATE_WORKSPACE_ITEM', item)
        commit('SET_MESSAGE', { type: 'success', text: '更新成功' })
        return item
      } catch (error) {
        commit('SET_MESSAGE', { type: 'error', text: '更新失败' })
        throw error
      }
    },
    
    // 从工作台移除
    async removeFromWorkspace({ commit }, id) {
      try {
        await api.removeFromWorkspace(id)
        commit('REMOVE_FROM_WORKSPACE', id)
        commit('SET_MESSAGE', { type: 'success', text: '移除成功' })
      } catch (error) {
        commit('SET_MESSAGE', { type: 'error', text: '移除失败' })
        throw error
      }
    },
    
    // 重新排序工作台
    async reorderWorkspace({ commit }, items) {
      try {
        await api.reorderWorkspace(items)
      } catch (error) {
        console.error('排序失败:', error)
      }
    },
    
    // 创建文件夹（支持 category 参数）
    async createFolder({ commit }, data) {
      try {
        const folder = await api.createFolder(data)
        commit('ADD_FOLDER', folder)
        commit('SET_MESSAGE', { type: 'success', text: '文件夹创建成功' })
        return folder
      } catch (error) {
        commit('SET_MESSAGE', { type: 'error', text: '创建失败' })
        throw error
      }
    },
    
    // 更新文件夹
    async updateFolder({ commit }, { id, data }) {
      try {
        const folder = await api.updateFolder(id, data)
        commit('UPDATE_FOLDER', folder)
        return folder
      } catch (error) {
        commit('SET_MESSAGE', { type: 'error', text: '更新失败' })
        throw error
      }
    },
    
    // 删除文件夹
    async deleteFolder({ commit }, id) {
      try {
        await api.deleteFolder(id)
        commit('REMOVE_FOLDER', id)
        commit('SET_MESSAGE', { type: 'success', text: '文件夹已删除' })
      } catch (error) {
        commit('SET_MESSAGE', { type: 'error', text: '删除失败' })
        throw error
      }
    },
    
    // 搜索
    async search({ commit }, keyword) {
      if (!keyword.trim()) {
        commit('SET_SEARCH_RESULTS', [])
        return
      }
      
      commit('SET_LOADING', true)
      try {
        const results = await api.search(keyword)
        commit('SET_SEARCH_RESULTS', results)
        commit('SET_SEARCH_KEYWORD', keyword)
      } catch (error) {
        console.error('搜索失败:', error)
      } finally {
        commit('SET_LOADING', false)
      }
    },
    
    // 获取搜索建议
    async fetchSearchSuggestions({ commit }, keyword) {
      try {
        const data = await api.getSearchSuggestions(keyword)
        commit('SET_SEARCH_SUGGESTIONS', {
          suggestions: data.suggestions,
          hotKeywords: data.hot_keywords
        })
      } catch (error) {
        console.error('获取搜索建议失败:', error)
      }
    },
    
    // 网站点击
    async clickWebsite({ commit }, id) {
      try {
        await api.clickWebsite(id)
        // API 调用成功后，更新本地状态
        commit('INCREMENT_CLICK_COUNT', id)
      } catch (error) {
        console.error('记录点击失败:', error)
      }
    },
    
    // 获取随机语录
    async fetchRandomQuote({ commit }) {
      try {
        const quote = await api.getRandomQuote()
        commit('SET_QUOTE', quote)
      } catch (error) {
        console.error('获取语录失败:', error)
      }
    }
  }
})
