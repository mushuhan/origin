/**
 * 管理员状态管理模块
 * 
 * 处理管理员认证状态和后台数据
 */
import * as adminApi from '@/api/admin'

export default {
  namespaced: true,
  
  state: {
    // 认证状态
    isAuthenticated: false,
    authMode: 'dev', // 'dev' | 'prod'
    oauthUrl: null,
    
    // 当前管理员用户
    user: null,
    
    // Dashboard 统计数据
    stats: null,
    trends: null,
    
    // 用户列表
    users: [],
    usersPagination: {
      total: 0,
      page: 1,
      per_page: 20,
      pages: 0
    },
    
    // 加载状态
    loading: false,
    statsLoading: false,
    usersLoading: false,
    
    // 错误信息
    error: null
  },
  
  getters: {
    // 是否已登录
    isLoggedIn: state => state.isAuthenticated && !!state.user,
    
    // 是否是管理员
    isAdmin: state => state.user?.role === 'admin',
    
    // 是否是 dev 模式
    isDevMode: state => state.authMode === 'dev',
    
    // 当前用户信息
    currentUser: state => state.user,
    
    // 用户显示名称
    userName: state => state.user?.name || state.user?.email || '管理员'
  },
  
  mutations: {
    // 设置认证模式
    SET_AUTH_MODE(state, { mode, oauth_url }) {
      state.authMode = mode
      state.oauthUrl = oauth_url
    },
    
    // 设置认证状态
    SET_AUTHENTICATED(state, isAuthenticated) {
      state.isAuthenticated = isAuthenticated
    },
    
    // 设置用户信息
    SET_USER(state, user) {
      state.user = user
      state.isAuthenticated = !!user
    },
    
    // 设置统计数据
    SET_STATS(state, stats) {
      state.stats = stats
    },
    
    // 设置趋势数据
    SET_TRENDS(state, trends) {
      state.trends = trends
    },
    
    // 设置用户列表
    SET_USERS(state, { items, pagination }) {
      state.users = items
      state.usersPagination = pagination
    },
    
    // 更新单个用户
    UPDATE_USER(state, updatedUser) {
      const index = state.users.findIndex(u => u.uuid === updatedUser.uuid)
      if (index !== -1) {
        state.users.splice(index, 1, updatedUser)
      }
    },
    
    // 删除用户
    REMOVE_USER(state, uuid) {
      state.users = state.users.filter(u => u.uuid !== uuid)
      if (state.usersPagination.total > 0) {
        state.usersPagination.total--
      }
    },
    
    // 添加用户
    ADD_USER(state, user) {
      state.users.unshift(user)
      state.usersPagination.total++
    },
    
    // 设置加载状态
    SET_LOADING(state, loading) {
      state.loading = loading
    },
    
    SET_STATS_LOADING(state, loading) {
      state.statsLoading = loading
    },
    
    SET_USERS_LOADING(state, loading) {
      state.usersLoading = loading
    },
    
    // 设置错误
    SET_ERROR(state, error) {
      state.error = error
    },
    
    // 清除状态（登出时）
    CLEAR_STATE(state) {
      state.isAuthenticated = false
      state.user = null
      state.stats = null
      state.trends = null
      state.users = []
      state.usersPagination = {
        total: 0,
        page: 1,
        per_page: 20,
        pages: 0
      }
      state.error = null
    }
  },
  
  actions: {
    /**
     * 获取认证模式
     */
    async fetchAuthMode({ commit }) {
      try {
        const data = await adminApi.getAuthMode()
        commit('SET_AUTH_MODE', data)
        return data
      } catch (error) {
        console.error('获取认证模式失败:', error)
        throw error
      }
    },
    
    /**
     * 初始化认证状态
     * 检查本地 Token 并获取用户信息
     */
    async initAuth({ commit, dispatch }) {
      const token = adminApi.getAdminToken()
      if (!token) {
        commit('SET_AUTHENTICATED', false)
        return false
      }
      
      try {
        const user = await adminApi.getCurrentUser()
        commit('SET_USER', user)
        return true
      } catch (error) {
        // Token 无效，清除
        adminApi.clearAdminToken()
        commit('SET_AUTHENTICATED', false)
        return false
      }
    },
    
    /**
     * 账号密码登录（DEV 模式）
     */
    async login({ commit }, { email, password }) {
      commit('SET_LOADING', true)
      commit('SET_ERROR', null)
      
      try {
        const data = await adminApi.login(email, password)
        
        // 保存 Token
        adminApi.setAdminToken(data.token)
        
        // 验证是否是管理员
        if (data.user.role !== 'admin') {
          adminApi.clearAdminToken()
          throw new Error('您没有管理员权限')
        }
        
        commit('SET_USER', data.user)
        return data.user
      } catch (error) {
        commit('SET_ERROR', error.message)
        throw error
      } finally {
        commit('SET_LOADING', false)
      }
    },
    
    /**
     * 注册账号（DEV 模式）
     */
    async register({ commit }, { email, password, name }) {
      commit('SET_LOADING', true)
      commit('SET_ERROR', null)
      
      try {
        const data = await adminApi.register(email, password, name)
        
        // 保存 Token
        adminApi.setAdminToken(data.token)
        
        // 验证是否是管理员
        if (data.user.role !== 'admin') {
          adminApi.clearAdminToken()
          throw new Error('您没有管理员权限，请联系系统管理员')
        }
        
        commit('SET_USER', data.user)
        return data.user
      } catch (error) {
        commit('SET_ERROR', error.message)
        throw error
      } finally {
        commit('SET_LOADING', false)
      }
    },
    
    /**
     * OAuth 回调处理（PROD 模式）
     */
    async handleOAuthCallback({ commit }, { code, state }) {
      commit('SET_LOADING', true)
      commit('SET_ERROR', null)
      
      try {
        const data = await adminApi.oauthCallback(code, state)
        
        // 保存 Token
        adminApi.setAdminToken(data.token)
        
        // 验证是否是管理员
        if (data.user.role !== 'admin') {
          adminApi.clearAdminToken()
          throw new Error('您没有管理员权限')
        }
        
        commit('SET_USER', data.user)
        return data
      } catch (error) {
        commit('SET_ERROR', error.message)
        throw error
      } finally {
        commit('SET_LOADING', false)
      }
    },
    
    /**
     * 跳转到 OAuth 授权页面（PROD 模式）
     */
    redirectToOAuth({ state }) {
      if (state.oauthUrl) {
        window.location.href = state.oauthUrl
      }
    },
    
    /**
     * 登出
     */
    async logout({ commit }) {
      try {
        await adminApi.logout()
      } catch (error) {
        // 忽略登出 API 错误
      } finally {
        adminApi.clearAdminToken()
        commit('CLEAR_STATE')
      }
    },
    
    /**
     * 获取 Dashboard 统计数据
     */
    async fetchStats({ commit }) {
      commit('SET_STATS_LOADING', true)
      
      try {
        const stats = await adminApi.getDashboardStats()
        commit('SET_STATS', stats)
        return stats
      } catch (error) {
        console.error('获取统计数据失败:', error)
        throw error
      } finally {
        commit('SET_STATS_LOADING', false)
      }
    },
    
    /**
     * 获取用户增长趋势
     */
    async fetchTrends({ commit }, days = 30) {
      try {
        const trends = await adminApi.getUserTrends(days)
        commit('SET_TRENDS', trends)
        return trends
      } catch (error) {
        console.error('获取趋势数据失败:', error)
        throw error
      }
    },
    
    /**
     * 获取用户列表
     */
    async fetchUsers({ commit }, params = {}) {
      commit('SET_USERS_LOADING', true)
      
      try {
        const response = await adminApi.getUsers(params)
        commit('SET_USERS', {
          items: response.items,
          pagination: response.pagination
        })
        return response
      } catch (error) {
        console.error('获取用户列表失败:', error)
        throw error
      } finally {
        commit('SET_USERS_LOADING', false)
      }
    },
    
    /**
     * 创建用户
     */
    async createUser({ commit }, data) {
      try {
        const user = await adminApi.createUser(data)
        commit('ADD_USER', user)
        return user
      } catch (error) {
        console.error('创建用户失败:', error)
        throw error
      }
    },
    
    /**
     * 更新用户
     */
    async updateUser({ commit }, { uuid, data }) {
      try {
        const user = await adminApi.updateUser(uuid, data)
        commit('UPDATE_USER', user)
        return user
      } catch (error) {
        console.error('更新用户失败:', error)
        throw error
      }
    },
    
    /**
     * 删除用户
     */
    async deleteUser({ commit }, uuid) {
      try {
        await adminApi.deleteUser(uuid)
        commit('REMOVE_USER', uuid)
      } catch (error) {
        console.error('删除用户失败:', error)
        throw error
      }
    },
    
    /**
     * 设置用户角色
     */
    async setUserRole({ commit }, { uuid, role }) {
      try {
        const user = await adminApi.setUserRole(uuid, role)
        commit('UPDATE_USER', user)
        return user
      } catch (error) {
        console.error('设置角色失败:', error)
        throw error
      }
    },
    
    /**
     * 切换用户状态
     */
    async toggleUserStatus({ commit }, uuid) {
      try {
        const user = await adminApi.toggleUserStatus(uuid)
        commit('UPDATE_USER', user)
        return user
      } catch (error) {
        console.error('切换状态失败:', error)
        throw error
      }
    },
    
    /**
     * 重置用户密码
     */
    async resetUserPassword({ commit }, { uuid, newPassword }) {
      try {
        await adminApi.resetUserPassword(uuid, newPassword)
      } catch (error) {
        console.error('重置密码失败:', error)
        throw error
      }
    },
    
    /**
     * 批量删除用户
     */
    async batchDeleteUsers({ dispatch }, uuids) {
      try {
        await adminApi.batchDeleteUsers(uuids)
        // 重新获取列表
        await dispatch('fetchUsers')
      } catch (error) {
        console.error('批量删除失败:', error)
        throw error
      }
    },
    
    /**
     * 批量设置角色
     */
    async batchSetRole({ dispatch }, { uuids, role }) {
      try {
        await adminApi.batchSetRole(uuids, role)
        // 重新获取列表
        await dispatch('fetchUsers')
      } catch (error) {
        console.error('批量设置角色失败:', error)
        throw error
      }
    },
    
    /**
     * 从 Excel 导入用户
     */
    async importUsersFromExcel({ dispatch }, file) {
      try {
        const result = await adminApi.importUsersFromExcel(file)
        // 重新获取列表
        await dispatch('fetchUsers')
        return result
      } catch (error) {
        console.error('导入失败:', error)
        throw error
      }
    }
  }
}

