<script setup>
/**
 * 组织架构图组件 - 基于 AntV G6
 * 
 * Props:
 *   - data: 后端返回的组织树数据
 *   - direction: 布局方向 'TB' | 'LR' (默认 'LR')
 *   - layoutMode: 布局模式 'compact' | 'balanced' (默认 'balanced')
 *   - nodeClick: 节点点击回调
 * 
 * 功能:
 *   - 紧凑树布局 (CompactBox) / 平衡布局 (Mindmap)
 *   - 拖拽/缩放画布
 *   - 折叠/展开子节点
 *   - 自定义节点样式
 *   - 智能分布子节点，利用横向空间
 */
import { ref, onMounted, onUnmounted, watch, nextTick } from 'vue'
import G6 from '@antv/g6'

const props = defineProps({
  // 原始数据（后端返回格式）
  data: {
    type: Array,
    default: () => []
  },
  // 布局方向: 'TB' (上到下) | 'LR' (左到右)
  direction: {
    type: String,
    default: 'LR',
    validator: (val) => ['TB', 'LR', 'RL', 'BT'].includes(val)
  },
  // 布局模式: 'compact' (紧凑单侧) | 'balanced' (平衡两侧)
  layoutMode: {
    type: String,
    default: 'balanced',
    validator: (val) => ['compact', 'balanced'].includes(val)
  },
  // 每行最多显示的子节点数量（网格排列）
  colsPerRow: {
    type: Number,
    default: 4
  }
})

const emit = defineEmits(['node-click', 'node-dblclick'])

// 容器 ref
const containerRef = ref(null)

// G6 图实例
let graph = null

// 当前布局方向
let currentDirection = 'LR'

// 当前布局模式
let currentLayoutMode = 'balanced'

// 是否已注册自定义节点
let nodeRegistered = false

// ============ 布局配置 ============

// 节点尺寸常量
const NODE_WIDTH = 140
const NODE_HEIGHT = 56
const H_GAP = 24      // 水平间距
const V_GAP = 16      // 垂直间距
const LEVEL_GAP = 100 // 层级间距

/**
 * 获取布局配置
 * 使用 compactBox 基础布局，然后在 afterlayout 中调整为网格
 */
const getLayoutConfig = (direction, mode) => {
  const isVertical = direction === 'TB' || direction === 'BT'
  
  return {
    type: 'compactBox',
    direction: direction,
    getId: (d) => d.id,
    getWidth: () => NODE_WIDTH,
    getHeight: () => NODE_HEIGHT,
    getVGap: () => V_GAP,
    getHGap: () => isVertical ? H_GAP : LEVEL_GAP,
    radial: false
  }
}

/**
 * 将子节点调整为网格排列
 * 在布局完成后调用此函数
 * @param {Graph} graphInstance - G6 图实例
 * @param {string} direction - 布局方向
 * @param {number} colsPerRow - 每行最多节点数
 */
const adjustToGridLayout = (graphInstance, direction, colsPerRow = 4) => {
  if (!graphInstance) return
  
  const isLR = direction === 'LR' || direction === 'RL'
  const data = graphInstance.save()
  if (!data) return
  
  // 收集所有父子关系（只收集直接子节点，不递归处理子树）
  const parentChildMap = new Map()
  
  const collectDirectChildren = (node, parent = null) => {
    if (parent && !node.collapsed) {
      if (!parentChildMap.has(parent.id)) {
        parentChildMap.set(parent.id, [])
      }
      parentChildMap.get(parent.id).push(node)
    }
    // 只有当节点没有被折叠时才处理其子节点
    if (node.children && node.children.length > 0 && !node.collapsed) {
      node.children.forEach(child => collectDirectChildren(child, node))
    }
  }
  
  collectDirectChildren(data)
  
  // 按层级排序处理（从根节点开始，确保父节点先被处理）
  const sortedParents = Array.from(parentChildMap.keys())
  
  // 调整每组子节点的位置
  sortedParents.forEach(parentId => {
    const children = parentChildMap.get(parentId)
    if (!children || children.length <= 1) return // 单个子节点不需要调整
    
    const parentNode = graphInstance.findById(parentId)
    if (!parentNode) return
    
    const parentModel = parentNode.getModel()
    const parentX = parentModel.x
    const parentY = parentModel.y
    
    // 计算网格布局
    const cols = Math.min(children.length, colsPerRow)
    const rows = Math.ceil(children.length / cols)
    
    if (isLR) {
      // LR 方向：子节点在右侧，按网格排列（多列多行）
      const gridWidth = cols * (NODE_WIDTH + H_GAP) - H_GAP
      const gridHeight = rows * (NODE_HEIGHT + V_GAP) - V_GAP
      const startX = parentX + NODE_WIDTH / 2 + LEVEL_GAP
      const startY = parentY - gridHeight / 2 + NODE_HEIGHT / 2
      
      children.forEach((childData, idx) => {
        const row = Math.floor(idx / cols)
        const col = idx % cols
        const newX = startX + col * (NODE_WIDTH + H_GAP)
        const newY = startY + row * (NODE_HEIGHT + V_GAP)
        
        const childNode = graphInstance.findById(childData.id)
        if (childNode) {
          graphInstance.updateItem(childNode, { x: newX, y: newY }, false)
        }
      })
    } else {
      // TB 方向：子节点在下方，按网格排列（多行多列）
      const gridWidth = cols * (NODE_WIDTH + H_GAP) - H_GAP
      const startX = parentX - gridWidth / 2 + NODE_WIDTH / 2
      const startY = parentY + NODE_HEIGHT / 2 + LEVEL_GAP
      
      children.forEach((childData, idx) => {
        const row = Math.floor(idx / cols)
        const col = idx % cols
        const newX = startX + col * (NODE_WIDTH + H_GAP)
        const newY = startY + row * (NODE_HEIGHT + V_GAP)
        
        const childNode = graphInstance.findById(childData.id)
        if (childNode) {
          graphInstance.updateItem(childNode, { x: newX, y: newY }, false)
        }
      })
    }
  })
  
  // 刷新边的路径
  graphInstance.getEdges().forEach(edge => {
    graphInstance.refreshItem(edge)
  })
}

// ============ 数据转换 ============

/**
 * 将后端数据转换为 G6 TreeGraphData 格式
 * 后端格式: { id, name, position, avatar, children: [...] }
 * G6 格式: { id, label, children: [...], originalData: {}, _index }
 * 
 * 为每个节点添加 _index 用于智能分布子节点
 */
const transformData = (nodes) => {
  if (!nodes || nodes.length === 0) return null
  
  const transform = (node, index = 0) => {
    const hasChildren = node.children && node.children.length > 0
    
    return {
      id: String(node.id),
      label: node.name,
      _index: index,  // 在兄弟节点中的索引，用于平衡布局
      // 保存原始数据，用于点击事件
      originalData: {
        id: node.id,
        name: node.name,
        position: node.position || '',
        avatar: node.avatar || '',
        signature: node.signature || '',
        phone: node.phone || '',
        email: node.email || '',
        parent_id: node.parent_id,
        level: node.level
      },
      children: hasChildren 
        ? node.children.map((child, idx) => transform(child, idx)) 
        : []
    }
  }
  
  // 如果有多个根节点，创建虚拟根节点
  if (nodes.length === 1) {
    return transform(nodes[0], 0)
  } else {
    return {
      id: 'virtual-root',
      label: '组织架构',
      isVirtualRoot: true,
      _index: 0,
      children: nodes.map((node, idx) => transform(node, idx))
    }
  }
}

// ============ 自定义节点 ============

/**
 * 注册自定义节点 - 显示姓名和职位
 */
const registerCustomNode = () => {
  // 防止重复注册
  if (nodeRegistered) return
  nodeRegistered = true
  
  G6.registerNode('org-node', {
    draw(cfg, group) {
      const isRoot = cfg.level === 0 || cfg.isVirtualRoot
      const hasChildren = cfg.children && cfg.children.length > 0
      const collapsed = cfg.collapsed
      
      // 节点尺寸
      const width = 140
      const height = 56
      const radius = 10
      
      // 根据状态确定颜色
      let bgColor = '#ffffff'
      let borderColor = '#e5e7eb'
      let textColor = '#1f2937'
      let subTextColor = '#6b7280'
      
      if (isRoot) {
        bgColor = '#1f2937'
        borderColor = '#1f2937'
        textColor = '#ffffff'
        subTextColor = 'rgba(255,255,255,0.7)'
      } else if (hasChildren) {
        bgColor = '#3b82f6'
        borderColor = '#3b82f6'
        textColor = '#ffffff'
        subTextColor = 'rgba(255,255,255,0.7)'
        
        if (collapsed) {
          bgColor = '#1d4ed8'
          borderColor = '#1d4ed8'
        }
      }
      
      // 主容器
      const shape = group.addShape('rect', {
        attrs: {
          x: -width / 2,
          y: -height / 2,
          width,
          height,
          radius,
          fill: bgColor,
          stroke: borderColor,
          lineWidth: 1,
          shadowColor: 'rgba(0,0,0,0.08)',
          shadowBlur: 8,
          shadowOffsetY: 2,
          cursor: 'pointer'
        },
        name: 'node-bg'
      })
      
      // 头像背景
      const avatarSize = 32
      const avatarX = -width / 2 + 12
      const avatarY = -avatarSize / 2
      
      group.addShape('rect', {
        attrs: {
          x: avatarX,
          y: avatarY,
          width: avatarSize,
          height: avatarSize,
          radius: 8,
          fill: isRoot || hasChildren ? 'rgba(255,255,255,0.2)' : '#f3f4f6',
          cursor: 'pointer'
        },
        name: 'avatar-bg'
      })
      
      // 头像文字（首字母）
      const name = cfg.originalData?.name || cfg.label || ''
      group.addShape('text', {
        attrs: {
          x: avatarX + avatarSize / 2,
          y: 0,
          text: name.charAt(0),
          fontSize: 14,
          fontWeight: 600,
          fill: isRoot || hasChildren ? '#ffffff' : '#6b7280',
          textAlign: 'center',
          textBaseline: 'middle',
          cursor: 'pointer'
        },
        name: 'avatar-text'
      })
      
      // 姓名
      const textX = avatarX + avatarSize + 8
      group.addShape('text', {
        attrs: {
          x: textX,
          y: -8,
          text: name.length > 6 ? name.slice(0, 6) + '...' : name,
          fontSize: 12,
          fontWeight: 600,
          fill: textColor,
          textAlign: 'left',
          textBaseline: 'middle',
          cursor: 'pointer'
        },
        name: 'name-text'
      })
      
      // 职位
      const position = cfg.originalData?.position || ''
      group.addShape('text', {
        attrs: {
          x: textX,
          y: 10,
          text: position.length > 8 ? position.slice(0, 8) + '...' : position,
          fontSize: 10,
          fill: subTextColor,
          textAlign: 'left',
          textBaseline: 'middle',
          cursor: 'pointer'
        },
        name: 'position-text'
      })
      
      // 折叠/展开按钮
      if (hasChildren) {
        const btnX = width / 2 - 16
        const btnY = 0
        
        group.addShape('circle', {
          attrs: {
            x: btnX,
            y: btnY,
            r: 10,
            fill: 'rgba(255,255,255,0.3)',
            cursor: 'pointer'
          },
          name: 'collapse-btn-bg'
        })
        
        group.addShape('text', {
          attrs: {
            x: btnX,
            y: btnY,
            text: collapsed ? '+' : '−',
            fontSize: 14,
            fontWeight: 'bold',
            fill: '#ffffff',
            textAlign: 'center',
            textBaseline: 'middle',
            cursor: 'pointer'
          },
          name: 'collapse-btn-icon'
        })
      }
      
      return shape
    },
    
    // 更新节点状态
    update(cfg, node) {
      const group = node.getContainer()
      const hasChildren = cfg.children && cfg.children.length > 0
      const collapsed = cfg.collapsed
      
      // 更新折叠按钮图标
      const btnIcon = group.find(el => el.get('name') === 'collapse-btn-icon')
      if (btnIcon) {
        btnIcon.attr('text', collapsed ? '+' : '−')
      }
      
      // 更新背景色
      if (hasChildren && !cfg.isVirtualRoot && cfg.level !== 0) {
        const bg = group.find(el => el.get('name') === 'node-bg')
        if (bg) {
          bg.attr('fill', collapsed ? '#1d4ed8' : '#3b82f6')
          bg.attr('stroke', collapsed ? '#1d4ed8' : '#3b82f6')
        }
      }
    },
    
    // 获取锚点
    getAnchorPoints() {
      return [
        [0, 0.5],   // 左
        [1, 0.5],   // 右
        [0.5, 0],   // 上
        [0.5, 1]    // 下
      ]
    }
  }, 'single-node')
}

// ============ 初始化图表 ============

const initGraph = () => {
  if (!containerRef.value) return
  
  const container = containerRef.value
  const width = container.offsetWidth || 800
  const height = container.offsetHeight || 600
  
  // 注册自定义节点
  registerCustomNode()
  
  // 保存当前配置
  currentDirection = props.direction
  currentLayoutMode = props.layoutMode
  
  // 根据方向确定边类型
  const isVertical = props.direction === 'TB' || props.direction === 'BT'
  const edgeType = isVertical ? 'cubic-vertical' : 'cubic-horizontal'
  
  // 获取布局配置
  const layoutConfig = getLayoutConfig(props.direction, props.layoutMode)
  
  // 创建 TreeGraph 实例
  graph = new G6.TreeGraph({
    container: container,
    width,
    height,
    
    // 画布模式
    modes: {
      default: [
        'drag-canvas',      // 拖拽画布
        'zoom-canvas',      // 缩放画布
        {
          type: 'collapse-expand',  // 折叠展开
          trigger: 'click',
          onChange: (item, collapsed) => {
            const data = item.getModel()
            data.collapsed = collapsed
            return true
          }
        }
      ]
    },
    
    // 默认节点配置
    defaultNode: {
      type: 'org-node'
    },
    
    // 默认边配置 - 根据方向动态设置
    defaultEdge: {
      type: edgeType,
      style: {
        stroke: '#d1d5db',
        lineWidth: 2
      }
    },
    
    // 布局配置 - 根据模式动态选择
    layout: layoutConfig,
    
    // 适应画布
    fitView: true,
    fitViewPadding: [40, 40, 40, 40],
    
    // 动画配置
    animate: true,
    animateCfg: {
      duration: 300,
      easing: 'easeQuadOut'
    }
  })
  
  // 绑定事件
  bindEvents()
  
  // 渲染数据
  renderData()
}

// ============ 绑定事件 ============

const bindEvents = () => {
  if (!graph) return
  
  // 布局完成后调整为网格布局
  graph.on('afterlayout', () => {
    adjustToGridLayout(graph, currentDirection, props.colsPerRow)
  })
  
  // 折叠/展开后重新调整布局
  graph.on('aftercollapseexpand', () => {
    setTimeout(() => {
      adjustToGridLayout(graph, currentDirection, props.colsPerRow)
      graph.fitView()
    }, 100)
  })
  
  // 节点点击
  graph.on('node:click', (e) => {
    const nodeData = e.item.getModel()
    if (nodeData.originalData) {
      emit('node-click', nodeData.originalData)
    }
  })
  
  // 节点双击
  graph.on('node:dblclick', (e) => {
    const nodeData = e.item.getModel()
    if (nodeData.originalData) {
      emit('node-dblclick', nodeData.originalData)
    }
  })
  
  // 节点悬停效果
  graph.on('node:mouseenter', (e) => {
    const node = e.item
    graph.setItemState(node, 'hover', true)
    
    const bg = node.getContainer().find(el => el.get('name') === 'node-bg')
    if (bg) {
      bg.attr('shadowBlur', 16)
      bg.attr('shadowColor', 'rgba(0,0,0,0.15)')
    }
  })
  
  graph.on('node:mouseleave', (e) => {
    const node = e.item
    graph.setItemState(node, 'hover', false)
    
    const bg = node.getContainer().find(el => el.get('name') === 'node-bg')
    if (bg) {
      bg.attr('shadowBlur', 8)
      bg.attr('shadowColor', 'rgba(0,0,0,0.08)')
    }
  })
}

// ============ 渲染数据 ============

const renderData = () => {
  if (!graph || !props.data || props.data.length === 0) return
  
  const treeData = transformData(props.data)
  if (treeData) {
    graph.data(treeData)
    graph.render()
    graph.fitView()
  }
}

// ============ 暴露方法 ============

// 缩放
const zoomIn = () => {
  if (!graph) return
  const zoom = graph.getZoom()
  graph.zoomTo(Math.min(zoom * 1.2, 3))
}

const zoomOut = () => {
  if (!graph) return
  const zoom = graph.getZoom()
  graph.zoomTo(Math.max(zoom / 1.2, 0.3))
}

// 重置视图
const resetView = () => {
  if (!graph) return
  graph.fitView()
}

// 获取当前缩放比例
const getZoom = () => {
  return graph ? Math.round(graph.getZoom() * 100) : 100
}

// 全部展开
const expandAll = () => {
  if (!graph) return
  
  const expandNode = (node) => {
    const model = node.getModel()
    if (model.collapsed) {
      model.collapsed = false
      graph.updateItem(node, model)
    }
    const children = node.getOutEdges()
    children.forEach(edge => {
      const target = edge.getTarget()
      if (target) expandNode(target)
    })
  }
  
  graph.getNodes().forEach(node => {
    const model = node.getModel()
    if (model.collapsed) {
      graph.updateItem(node, { collapsed: false })
    }
  })
  
  graph.layout()
  graph.fitView()
}

// 全部折叠（只保留第一级）
const collapseAll = () => {
  if (!graph) return
  
  graph.getNodes().forEach(node => {
    const model = node.getModel()
    if (model.children && model.children.length > 0 && !model.isVirtualRoot) {
      graph.updateItem(node, { collapsed: true })
    }
  })
  
  graph.layout()
  graph.fitView()
}

/**
 * 重新创建图实例（方向或布局模式变化时调用）
 */
const recreateGraph = (direction, layoutMode) => {
  if (!graph || !containerRef.value) return
  
  // 保存当前数据
  const currentData = graph.save()
  
  // 销毁旧图
  graph.destroy()
  
  // 根据新方向确定边类型
  const isVertical = direction === 'TB' || direction === 'BT'
  const edgeType = isVertical ? 'cubic-vertical' : 'cubic-horizontal'
  
  // 获取布局配置
  const layoutConfig = getLayoutConfig(direction, layoutMode)
  
  const container = containerRef.value
  const width = container.offsetWidth || 800
  const height = container.offsetHeight || 600
  
  // 重新创建图实例
  graph = new G6.TreeGraph({
    container: container,
    width,
    height,
    modes: {
      default: [
        'drag-canvas',
        'zoom-canvas',
        {
          type: 'collapse-expand',
          trigger: 'click',
          onChange: (item, collapsed) => {
            const data = item.getModel()
            data.collapsed = collapsed
            return true
          }
        }
      ]
    },
    defaultNode: {
      type: 'org-node'
    },
    defaultEdge: {
      type: edgeType,
      style: {
        stroke: '#d1d5db',
        lineWidth: 2
      }
    },
    layout: layoutConfig,
    fitView: true,
    fitViewPadding: [40, 40, 40, 40],
    animate: true,
    animateCfg: {
      duration: 300,
      easing: 'easeQuadOut'
    }
  })
  
  // 重新绑定事件
  bindEvents()
  
  // 重新渲染数据
  if (currentData) {
    graph.data(currentData)
    graph.render()
    graph.fitView()
  }
}

// 切换布局方向
const changeDirection = (dir) => {
  if (!graph || !containerRef.value) return
  
  // 如果方向没变，不做操作
  if (dir === currentDirection) return
  
  currentDirection = dir
  recreateGraph(dir, currentLayoutMode)
}

// 切换布局模式
const changeLayoutMode = (mode) => {
  if (!graph || !containerRef.value) return
  
  // 如果模式没变，不做操作
  if (mode === currentLayoutMode) return
  
  currentLayoutMode = mode
  recreateGraph(currentDirection, mode)
}

// 获取当前布局模式
const getLayoutMode = () => currentLayoutMode

// 调整画布大小
const resize = () => {
  if (!graph || !containerRef.value) return
  
  const width = containerRef.value.offsetWidth
  const height = containerRef.value.offsetHeight
  
  graph.changeSize(width, height)
  graph.fitView()
}

// 暴露给父组件
defineExpose({
  zoomIn,
  zoomOut,
  resetView,
  getZoom,
  expandAll,
  collapseAll,
  changeDirection,
  changeLayoutMode,
  getLayoutMode,
  resize
})

// ============ 生命周期 ============

// 监听数据变化
watch(() => props.data, (newData) => {
  if (graph && newData && newData.length > 0) {
    renderData()
  }
}, { deep: true })

// 监听方向变化
watch(() => props.direction, (newDir) => {
  changeDirection(newDir)
})

// 监听布局模式变化
watch(() => props.layoutMode, (newMode) => {
  changeLayoutMode(newMode)
})

onMounted(() => {
  nextTick(() => {
    initGraph()
  })
  
  // 监听窗口大小变化
  window.addEventListener('resize', resize)
})

onUnmounted(() => {
  // 销毁图实例，防止内存泄漏
  if (graph) {
    graph.destroy()
    graph = null
  }
  
  window.removeEventListener('resize', resize)
})
</script>

<template>
  <div ref="containerRef" class="architecture-tree-container"></div>
</template>

<style lang="scss" scoped>
.architecture-tree-container {
  width: 100%;
  height: 100%;
  min-height: 400px;
  background: 
    radial-gradient(circle at 1px 1px, var(--border-secondary, #e5e7eb) 1px, transparent 1px);
  background-size: 24px 24px;
  border-radius: 12px;
  overflow: hidden;
}
</style>

