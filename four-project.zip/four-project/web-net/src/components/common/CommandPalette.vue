<script setup>
import { ref, computed, watch, onMounted, onUnmounted, nextTick } from 'vue'
import { useStore } from 'vuex'
import { useRouter } from 'vue-router'
import { search, getEmployees, clickWebsite } from '@/api'
import { debounce, trackWebsiteVisit } from '@/utils/helpers'

const props = defineProps({
  modelValue: {
    type: Boolean,
    default: false
  }
})

const emit = defineEmits(['update:modelValue'])

const store = useStore()
const router = useRouter()

// 状态
const inputRef = ref(null)
const keyword = ref('')
const isLoading = ref(false)
const selectedIndex = ref(0)
const activeTab = ref('all') // 'all' | 'websites' | 'employees'

// 搜索结果
const websites = ref([])
const employees = ref([])

// 显示状态
const isVisible = computed({
  get: () => props.modelValue,
  set: (val) => emit('update:modelValue', val)
})

// 组合结果
const allResults = computed(() => {
  const results = []
  
  if (activeTab.value === 'all' || activeTab.value === 'websites') {
    websites.value.forEach(site => {
      results.push({ type: 'website', data: site })
    })
  }
  
  if (activeTab.value === 'all' || activeTab.value === 'employees') {
    employees.value.forEach(emp => {
      results.push({ type: 'employee', data: emp })
    })
  }
  
  return results
})

// 统计
const counts = computed(() => ({
  all: websites.value.length + employees.value.length,
  websites: websites.value.length,
  employees: employees.value.length
}))

// 搜索函数
const doSearch = debounce(async (value) => {
  if (!value.trim()) {
    websites.value = []
    employees.value = []
    return
  }
  
  isLoading.value = true
  
  try {
    // 并行搜索
    const [websiteResults, employeeResults] = await Promise.allSettled([
      search(value, 20),
      getEmployees().then(list => 
        (list || []).filter(emp => 
          emp.name?.toLowerCase().includes(value.toLowerCase()) ||
          emp.position?.toLowerCase().includes(value.toLowerCase()) ||
          emp.phone?.includes(value)
        ).slice(0, 10)
      )
    ])
    
    websites.value = websiteResults.status === 'fulfilled' ? (websiteResults.value || []) : []
    employees.value = employeeResults.status === 'fulfilled' ? (employeeResults.value || []) : []
  } catch (e) {
    console.error('Search failed:', e)
  } finally {
    isLoading.value = false
  }
}, 250)

// 监听输入变化
watch(keyword, (value) => {
  selectedIndex.value = 0
  doSearch(value)
})

// 打开时聚焦
watch(isVisible, async (val) => {
  if (val) {
    await nextTick()
    inputRef.value?.focus()
    // 重置状态
    keyword.value = ''
    selectedIndex.value = 0
    activeTab.value = 'all'
    websites.value = []
    employees.value = []
  }
})

// 选择结果项
const selectResult = async (item) => {
  if (item.type === 'website') {
    // 记录本地访问（SmartQuickAccess）
    trackWebsiteVisit(item.data)
    
    // 调用服务端 API 增加点击数
    try {
      await clickWebsite(item.data.id)
    } catch (e) {
      // 忽略错误
    }
    
    // 打开链接
    window.open(item.data.url || item.data.custom_url, '_blank')
  } else if (item.type === 'employee') {
    // 跳转到人员详情或部门页
    if (item.data.department_id) {
      router.push(`/department/${item.data.department_id}`)
    }
  }
  
  closeModal()
}

// 键盘导航
const handleKeydown = (e) => {
  const total = allResults.value.length
  
  switch (e.key) {
    case 'ArrowDown':
      e.preventDefault()
      selectedIndex.value = (selectedIndex.value + 1) % Math.max(total, 1)
      scrollToSelected()
      break
    case 'ArrowUp':
      e.preventDefault()
      selectedIndex.value = selectedIndex.value <= 0 ? total - 1 : selectedIndex.value - 1
      scrollToSelected()
      break
    case 'Enter':
      e.preventDefault()
      if (allResults.value[selectedIndex.value]) {
        selectResult(allResults.value[selectedIndex.value])
      }
      break
    case 'Tab':
      e.preventDefault()
      // 切换标签
      const tabs = ['all', 'websites', 'employees']
      const currentIdx = tabs.indexOf(activeTab.value)
      activeTab.value = tabs[(currentIdx + 1) % tabs.length]
      selectedIndex.value = 0
      break
    case 'Escape':
      closeModal()
      break
  }
}

// 滚动到选中项
const scrollToSelected = () => {
  nextTick(() => {
    const selected = document.querySelector('.result-item.is-selected')
    selected?.scrollIntoView({ block: 'nearest', behavior: 'smooth' })
  })
}

// 关闭
const closeModal = () => {
  isVisible.value = false
}

// 全局快捷键
const handleGlobalKeydown = (e) => {
  // Cmd/Ctrl + K
  if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
    e.preventDefault()
    isVisible.value = !isVisible.value
  }
}

// 首字母
const getInitial = (name) => (name || '?').charAt(0).toUpperCase()

// 颜色
const getBgColor = (name) => {
  const colors = ['#3B82F6', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6', '#EC4899', '#06B6D4', '#84CC16']
  let hash = 0
  for (let i = 0; i < (name || '').length; i++) {
    hash = name.charCodeAt(i) + ((hash << 5) - hash)
  }
  return colors[Math.abs(hash) % colors.length]
}

// 高亮关键词
const highlightKeyword = (text, kw) => {
  if (!text || !kw) return text
  const regex = new RegExp(`(${kw.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi')
  return text.replace(regex, '<mark>$1</mark>')
}

onMounted(() => {
  window.addEventListener('keydown', handleGlobalKeydown)
})

onUnmounted(() => {
  window.removeEventListener('keydown', handleGlobalKeydown)
})
</script>

<template>
  <Teleport to="body">
    <transition name="modal">
      <div v-if="isVisible" class="command-palette-overlay" @click.self="closeModal">
        <div class="command-palette" @keydown="handleKeydown">
          <!-- 搜索头部 -->
          <div class="palette-header">
            <el-icon class="search-icon"><Search /></el-icon>
            <input
              ref="inputRef"
              v-model="keyword"
              type="text"
              class="search-input"
              placeholder="搜索应用、人员..."
              autocomplete="off"
              spellcheck="false"
            />
            <div class="header-actions">
              <kbd class="shortcut-key">ESC</kbd>
            </div>
          </div>
          
          <!-- 标签切换 -->
          <div class="palette-tabs" v-if="keyword">
            <button 
              class="tab-item" 
              :class="{ active: activeTab === 'all' }"
              @click="activeTab = 'all'; selectedIndex = 0"
            >
              全部
              <span class="tab-count">{{ counts.all }}</span>
            </button>
            <button 
              class="tab-item" 
              :class="{ active: activeTab === 'websites' }"
              @click="activeTab = 'websites'; selectedIndex = 0"
            >
              <el-icon><Link /></el-icon>
              应用
              <span class="tab-count">{{ counts.websites }}</span>
            </button>
            <button 
              class="tab-item" 
              :class="{ active: activeTab === 'employees' }"
              @click="activeTab = 'employees'; selectedIndex = 0"
            >
              <el-icon><User /></el-icon>
              人员
              <span class="tab-count">{{ counts.employees }}</span>
            </button>
          </div>
          
          <!-- 搜索结果 -->
          <div class="palette-body">
            <!-- 加载状态 -->
            <div v-if="isLoading" class="loading-state">
              <div class="loading-spinner"></div>
              <span>搜索中...</span>
            </div>
            
            <!-- 空状态 - 未输入 -->
            <div v-else-if="!keyword" class="empty-state">
              <div class="empty-icon">
                <el-icon><Search /></el-icon>
              </div>
              <p>输入关键词搜索应用或人员</p>
              <div class="shortcuts-hint">
                <span><kbd>↑</kbd><kbd>↓</kbd> 导航</span>
                <span><kbd>Tab</kbd> 切换分类</span>
                <span><kbd>Enter</kbd> 打开</span>
              </div>
            </div>
            
            <!-- 空状态 - 无结果 -->
            <div v-else-if="allResults.length === 0" class="empty-state">
              <div class="empty-icon">
                <el-icon><Search /></el-icon>
              </div>
              <p>未找到 "{{ keyword }}" 相关结果</p>
            </div>
            
            <!-- 结果列表 -->
            <div v-else class="results-list">
              <div
                v-for="(item, index) in allResults"
                :key="`${item.type}-${item.data.id}`"
                class="result-item"
                :class="{ 'is-selected': selectedIndex === index }"
                @click="selectResult(item)"
                @mouseenter="selectedIndex = index"
              >
                <!-- 网站类型 -->
                <template v-if="item.type === 'website'">
                  <div class="result-icon" :style="{ backgroundColor: getBgColor(item.data.name) }">
                    <img 
                      v-if="item.data.icon" 
                      :src="item.data.icon" 
                      :alt="item.data.name"
                      @error="$event.target.style.display = 'none'"
                    />
                    <span v-else>{{ getInitial(item.data.name) }}</span>
                  </div>
                  <div class="result-content">
                    <span class="result-title" v-html="highlightKeyword(item.data.name, keyword)"></span>
                    <span class="result-subtitle">{{ item.data.url }}</span>
                  </div>
                  <div class="result-type website">应用</div>
                </template>
                
                <!-- 人员类型 -->
                <template v-else-if="item.type === 'employee'">
                  <div class="result-icon employee" :style="{ backgroundColor: getBgColor(item.data.name) }">
                    <el-icon><User /></el-icon>
                  </div>
                  <div class="result-content">
                    <span class="result-title" v-html="highlightKeyword(item.data.name, keyword)"></span>
                    <span class="result-subtitle">
                      {{ item.data.position }}
                      <template v-if="item.data.phone"> · {{ item.data.phone }}</template>
                    </span>
                  </div>
                  <div class="result-type employee">人员</div>
                </template>
                
                <!-- 操作提示 -->
                <el-icon class="result-action"><ArrowRight /></el-icon>
              </div>
            </div>
          </div>
          
          <!-- 底部提示 -->
          <div class="palette-footer">
            <span class="hint"><kbd>⌘</kbd><kbd>K</kbd> 随时唤起</span>
          </div>
        </div>
      </div>
    </transition>
  </Teleport>
</template>

<style lang="scss" scoped>
// 遮罩层
.command-palette-overlay {
  position: fixed;
  inset: 0;
  z-index: 9999;
  display: flex;
  align-items: flex-start;
  justify-content: center;
  padding-top: 15vh;
  background: rgba(0, 0, 0, 0.5);
  backdrop-filter: blur(4px);
  -webkit-backdrop-filter: blur(4px);
}

// 主容器
.command-palette {
  width: 100%;
  max-width: 640px;
  max-height: 70vh;
  margin: 0 1rem;
  background: var(--card-bg);
  border: 1px solid var(--border-primary);
  border-radius: 16px;
  box-shadow: 
    0 25px 50px -12px rgba(0, 0, 0, 0.25),
    0 0 0 1px rgba(255, 255, 255, 0.05) inset;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

// 头部
.palette-header {
  display: flex;
  align-items: center;
  gap: 0.75rem;
  padding: 1rem 1.25rem;
  border-bottom: 1px solid var(--border-secondary);
}

.search-icon {
  color: var(--text-tertiary);
  font-size: 20px;
  flex-shrink: 0;
}

.search-input {
  flex: 1;
  font-size: 1.0625rem;
  font-weight: 500;
  color: var(--text-primary);
  background: transparent;
  
  &::placeholder {
    color: var(--text-tertiary);
    font-weight: 400;
  }
}

.header-actions {
  display: flex;
  align-items: center;
  gap: 0.5rem;
}

// 快捷键标签
kbd {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-width: 20px;
  height: 20px;
  padding: 0 5px;
  font-family: inherit;
  font-size: 0.6875rem;
  font-weight: 600;
  color: var(--text-tertiary);
  background: var(--bg-tertiary);
  border: 1px solid var(--border-primary);
  border-radius: 4px;
}

.shortcut-key {
  font-size: 0.625rem;
}

// 标签
.palette-tabs {
  display: flex;
  gap: 0.25rem;
  padding: 0.5rem 1rem;
  border-bottom: 1px solid var(--border-secondary);
  background: var(--bg-tertiary);
}

.tab-item {
  display: flex;
  align-items: center;
  gap: 0.375rem;
  padding: 0.375rem 0.75rem;
  font-size: 0.8125rem;
  font-weight: 500;
  color: var(--text-secondary);
  background: transparent;
  border-radius: 8px;
  transition: all 0.15s ease;
  
  &:hover {
    color: var(--text-primary);
    background: var(--bg-secondary);
  }
  
  &.active {
    color: var(--text-primary);
    background: var(--card-bg);
    box-shadow: var(--shadow-sm);
  }
  
  .el-icon {
    font-size: 14px;
  }
}

.tab-count {
  font-size: 0.6875rem;
  padding: 0 4px;
  color: var(--text-tertiary);
  background: var(--bg-tertiary);
  border-radius: 4px;
}

// 主体
.palette-body {
  flex: 1;
  overflow-y: auto;
  min-height: 200px;
  max-height: 400px;
}

// 加载状态
.loading-state {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.625rem;
  padding: 3rem;
  color: var(--text-tertiary);
  font-size: 0.875rem;
  
  .loading-spinner {
    width: 18px;
    height: 18px;
    border: 2px solid var(--border-primary);
    border-top-color: var(--text-primary);
    border-radius: 50%;
    animation: spin 0.7s linear infinite;
  }
}

@keyframes spin {
  to { transform: rotate(360deg); }
}

// 空状态
.empty-state {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 3rem 2rem;
  text-align: center;
  
  .empty-icon {
    width: 48px;
    height: 48px;
    border-radius: 12px;
    background: var(--bg-tertiary);
    display: flex;
    align-items: center;
    justify-content: center;
    margin-bottom: 1rem;
    
    .el-icon {
      font-size: 24px;
      color: var(--text-tertiary);
    }
  }
  
  p {
    font-size: 0.875rem;
    color: var(--text-secondary);
    margin-bottom: 1rem;
  }
}

.shortcuts-hint {
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  gap: 1rem;
  font-size: 0.75rem;
  color: var(--text-tertiary);
  
  span {
    display: flex;
    align-items: center;
    gap: 0.25rem;
  }
  
  kbd {
    min-width: 18px;
    height: 18px;
    font-size: 0.625rem;
  }
}

// 结果列表
.results-list {
  padding: 0.5rem;
}

.result-item {
  display: flex;
  align-items: center;
  gap: 0.875rem;
  padding: 0.75rem;
  border-radius: 10px;
  cursor: pointer;
  transition: all 0.15s ease;
  
  &:hover,
  &.is-selected {
    background: var(--bg-tertiary);
    
    .result-action {
      opacity: 1;
      transform: translateX(0);
    }
  }
  
  &.is-selected {
    background: var(--accent-light);
    
    .result-title {
      color: var(--accent);
    }
  }
}

.result-icon {
  width: 40px;
  height: 40px;
  border-radius: 10px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  overflow: hidden;
  color: white;
  font-weight: 700;
  font-size: 1rem;
  
  img {
    width: 100%;
    height: 100%;
    object-fit: cover;
  }
  
  &.employee {
    .el-icon {
      font-size: 18px;
    }
  }
}

.result-content {
  flex: 1;
  min-width: 0;
  display: flex;
  flex-direction: column;
  gap: 0.125rem;
}

.result-title {
  font-size: 0.9375rem;
  font-weight: 500;
  color: var(--text-primary);
  
  :deep(mark) {
    background: var(--accent-light);
    color: var(--accent);
    padding: 0 2px;
    border-radius: 2px;
  }
}

.result-subtitle {
  font-size: 0.75rem;
  color: var(--text-tertiary);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.result-type {
  font-size: 0.6875rem;
  font-weight: 500;
  padding: 0.25rem 0.5rem;
  border-radius: 6px;
  background: var(--bg-tertiary);
  color: var(--text-tertiary);
  
  &.website {
    background: rgba(59, 130, 246, 0.1);
    color: #3b82f6;
  }
  
  &.employee {
    background: rgba(16, 185, 129, 0.1);
    color: #10b981;
  }
}

.result-action {
  color: var(--text-tertiary);
  opacity: 0;
  transform: translateX(-4px);
  transition: all 0.15s ease;
}

// 底部
.palette-footer {
  padding: 0.625rem 1rem;
  border-top: 1px solid var(--border-secondary);
  background: var(--bg-tertiary);
  
  .hint {
    display: flex;
    align-items: center;
    gap: 0.375rem;
    font-size: 0.75rem;
    color: var(--text-tertiary);
    
    kbd {
      min-width: 16px;
      height: 16px;
      font-size: 0.625rem;
    }
  }
}

// 动画
.modal-enter-active,
.modal-leave-active {
  transition: all 0.2s ease;
  
  .command-palette {
    transition: all 0.2s cubic-bezier(0.16, 1, 0.3, 1);
  }
}

.modal-enter-from,
.modal-leave-to {
  opacity: 0;
  
  .command-palette {
    opacity: 0;
    transform: scale(0.95) translateY(-20px);
  }
}

// 响应式
@media (max-width: 640px) {
  .command-palette-overlay {
    padding-top: 5vh;
    align-items: flex-start;
  }
  
  .command-palette {
    max-height: 85vh;
    border-radius: 12px;
  }
  
  .palette-header {
    padding: 0.875rem 1rem;
  }
  
  .search-input {
    font-size: 1rem;
  }
  
  .palette-tabs {
    overflow-x: auto;
    -webkit-overflow-scrolling: touch;
    
    &::-webkit-scrollbar {
      display: none;
    }
  }
  
  .shortcuts-hint {
    display: none;
  }
}
</style>

