<script setup>
import { ref, computed, onMounted, onUnmounted, watch } from 'vue'
import { getFrequentlyVisited, getRecentlyVisited, trackWebsiteVisit, onQuickAccessUpdate } from '@/utils/helpers'
import { clickWebsite } from '@/api'

const props = defineProps({
  limit: {
    type: Number,
    default: 6
  },
  mode: {
    type: String,
    default: 'frequent', // 'frequent' | 'recent'
    validator: v => ['frequent', 'recent'].includes(v)
  }
})

const emit = defineEmits(['click'])

// 访问记录
const accessList = ref([])
const isLoaded = ref(false)

// 获取数据
const loadAccessData = () => {
  if (props.mode === 'frequent') {
    accessList.value = getFrequentlyVisited(props.limit)
  } else {
    accessList.value = getRecentlyVisited(props.limit)
  }
  isLoaded.value = true
}

// 是否显示组件（有数据时显示）
const shouldShow = computed(() => isLoaded.value && accessList.value.length > 0)

// 点击网站
const handleClick = async (item) => {
  // 记录本地点击（会自动触发刷新事件）
  trackWebsiteVisit(item.website)
  emit('click', item.website)
  
  // 调用服务端 API 增加点击数
  try {
    await clickWebsite(item.website.id)
  } catch (e) {
    // 忽略错误
  }
  
  // 打开链接
  if (item.website.url) {
    window.open(item.website.url, '_blank')
  }
}

// 首字母
const getInitial = (name) => {
  return (name || '?').charAt(0).toUpperCase()
}

// 随机颜色（基于名称）
const getBgColor = (name) => {
  const colors = [
    '#3B82F6', '#10B981', '#F59E0B', '#EF4444', 
    '#8B5CF6', '#EC4899', '#06B6D4', '#84CC16'
  ]
  let hash = 0
  for (let i = 0; i < (name || '').length; i++) {
    hash = name.charCodeAt(i) + ((hash << 5) - hash)
  }
  return colors[Math.abs(hash) % colors.length]
}

// 清理函数
let unsubscribe = null

// 初始化
onMounted(() => {
  loadAccessData()
  
  // 监听同一标签页内的更新事件
  unsubscribe = onQuickAccessUpdate(() => {
    loadAccessData()
  })
  
  // 监听 storage 变化（跨标签页同步）
  window.addEventListener('storage', (e) => {
    if (e.key === 'nav_quick_access_data') {
      loadAccessData()
    }
  })
})

// 清理
onUnmounted(() => {
  if (unsubscribe) {
    unsubscribe()
  }
})

// 监听模式变化
watch(() => props.mode, loadAccessData)

// 暴露刷新方法
defineExpose({ refresh: loadAccessData })
</script>

<template>
  <transition name="fade-slide">
    <div v-if="shouldShow" class="smart-quick-access">
      <div class="access-header">
        <span class="access-label">
          <el-icon><Clock /></el-icon>
          {{ mode === 'frequent' ? '常用' : '最近' }}
        </span>
      </div>
      
      <div class="access-list">
        <button
          v-for="(item, index) in accessList"
          :key="item.website.id"
          class="access-item"
          :style="{ animationDelay: `${index * 0.05}s` }"
          @click="handleClick(item)"
        >
          <!-- 图标 -->
          <div class="item-icon" :style="{ backgroundColor: getBgColor(item.website.name) }">
            <img 
              v-if="item.website.icon" 
              :src="item.website.icon" 
              :alt="item.website.name"
              @error="$event.target.style.display = 'none'"
            />
            <span v-else class="item-initial">{{ getInitial(item.website.name) }}</span>
          </div>
          
          <!-- 名称 -->
          <span class="item-name">{{ item.website.name }}</span>
          
          <!-- 访问次数徽章 -->
          <span v-if="mode === 'frequent' && item.clickCount > 1" class="item-badge">
            {{ item.clickCount > 99 ? '99+' : item.clickCount }}
          </span>
        </button>
      </div>
    </div>
  </transition>
</template>

<style lang="scss" scoped>
.smart-quick-access {
  width: 100%;
  max-width: 560px;
}

.access-header {
  margin-bottom: 0.625rem;
}

.access-label {
  display: inline-flex;
  align-items: center;
  gap: 0.375rem;
  font-size: 0.6875rem;
  font-weight: 600;
  color: var(--text-tertiary);
  text-transform: uppercase;
  letter-spacing: 0.5px;
  
  .el-icon {
    font-size: 0.75rem;
  }
}

.access-list {
  display: flex;
  flex-wrap: wrap;
  gap: 0.5rem;
  justify-content: center;
}

.access-item {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.5rem 0.875rem;
  background: var(--glass-bg);
  backdrop-filter: blur(12px);
  -webkit-backdrop-filter: blur(12px);
  border: 1px solid var(--glass-border);
  border-radius: 20px;
  cursor: pointer;
  transition: all 0.2s cubic-bezier(0.16, 1, 0.3, 1);
  animation: slideUp 0.4s ease forwards;
  opacity: 0;
  
  &:hover {
    background: var(--card-bg);
    border-color: var(--border-primary);
    transform: translateY(-2px);
    box-shadow: var(--shadow-md);
    
    .item-icon {
      transform: scale(1.1);
    }
  }
  
  &:active {
    transform: translateY(0) scale(0.98);
  }
}

.item-icon {
  width: 24px;
  height: 24px;
  border-radius: 6px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  overflow: hidden;
  transition: transform 0.2s ease;
  
  img {
    width: 100%;
    height: 100%;
    object-fit: cover;
  }
  
  .item-initial {
    font-size: 0.6875rem;
    font-weight: 700;
    color: white;
  }
}

.item-name {
  font-size: 0.8125rem;
  font-weight: 500;
  color: var(--text-primary);
  max-width: 100px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.item-badge {
  padding: 1px 5px;
  font-size: 0.625rem;
  font-weight: 600;
  color: var(--text-tertiary);
  background: var(--bg-tertiary);
  border-radius: 8px;
  min-width: 16px;
  text-align: center;
}

// 动画
@keyframes slideUp {
  from {
    opacity: 0;
    transform: translateY(8px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.fade-slide-enter-active,
.fade-slide-leave-active {
  transition: all 0.3s ease;
}

.fade-slide-enter-from,
.fade-slide-leave-to {
  opacity: 0;
  transform: translateY(-10px);
}

// 响应式
@media (max-width: 640px) {
  .access-list {
    gap: 0.375rem;
  }
  
  .access-item {
    padding: 0.4375rem 0.75rem;
  }
  
  .item-name {
    max-width: 70px;
    font-size: 0.75rem;
  }
  
  .item-icon {
    width: 20px;
    height: 20px;
  }
}
</style>

