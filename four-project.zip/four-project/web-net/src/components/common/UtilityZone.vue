<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import InvoiceCheck from './InvoiceCheck.vue'
import EmailGenerator from './EmailGenerator.vue'
import PdfConverter from './PdfConverter.vue'

const router = useRouter()

// 模态框状态
const showInvoiceCheck = ref(false)
const showEmailGenerator = ref(false)
const showPdfConverter = ref(false)

// 工具卡片数据（复刻科室卡片结构，无图标）
const tools = [
  {
    id: 'invoice',
    name: '发票校验小助手',
    description: '快速校验发票抬头和税号',
    action: () => { showInvoiceCheck.value = true }
  },
  {
    id: 'email',
    name: '精准邮件分发',
    description: '按条件筛选生成邮件列表',
    action: () => { showEmailGenerator.value = true }
  },
  {
    id: 'pdf',
    name: 'PDF格式转换',
    description: 'PDF转Excel/Word文档',
    action: () => { showPdfConverter.value = true }
  },
  {
    id: 'dashboard',
    name: '看板生成器',
    description: '可视化数据分析看板',
    action: () => { router.push('/dashboard') }
  }
]

// hover 状态
const activeIndex = ref(-1)
</script>

<template>
  <!-- 便捷工具区 - 严格复刻科室卡片样式 -->
  <div class="utility-box">
    <div class="utility-header">
      <span class="utility-label">便捷工具区</span>
    </div>
    <div class="utility-list">
      <button 
        v-for="(tool, idx) in tools" 
        :key="tool.id" 
        class="utility-item"
        :class="{ active: idx === activeIndex }"
        @mouseenter="activeIndex = idx"
        @mouseleave="activeIndex = -1"
        @click="tool.action"
      >
        <span class="utility-name">{{ tool.name }}</span>
        <span class="utility-desc">{{ tool.description }}</span>
        <el-icon class="utility-arrow"><ArrowRight /></el-icon>
      </button>
    </div>
  </div>

  <!-- 全局弹窗 - 使用 Teleport 挂载到 body -->
  <Teleport to="body">
    <!-- 发票校验弹窗 -->
    <el-dialog
      v-model="showInvoiceCheck"
      title="发票校验小助手"
      width="800px"
      :close-on-click-modal="false"
      destroy-on-close
      append-to-body
      class="utility-dialog"
    >
      <InvoiceCheck @close="showInvoiceCheck = false" />
    </el-dialog>

    <!-- 邮件生成器弹窗 -->
    <el-dialog
      v-model="showEmailGenerator"
      title="精准邮件分发生成器"
      width="1000px"
      :close-on-click-modal="false"
      destroy-on-close
      append-to-body
      class="utility-dialog email-dialog"
    >
      <EmailGenerator @close="showEmailGenerator = false" />
    </el-dialog>

    <!-- PDF转换弹窗 -->
    <el-dialog
      v-model="showPdfConverter"
      title="PDF格式转换"
      width="560px"
      :close-on-click-modal="false"
      destroy-on-close
      append-to-body
      class="utility-dialog"
    >
      <PdfConverter @close="showPdfConverter = false" />
    </el-dialog>
  </Teleport>
</template>

<style lang="scss" scoped>
// 严格复刻科室卡片样式
.utility-box {
  padding: 1rem 1.25rem;
  border-top: 1px solid var(--border-secondary);
}

.utility-header {
  margin-bottom: 0.75rem;
}

.utility-label {
  font-size: 0.6875rem;
  font-weight: 600;
  color: var(--text-tertiary);
  text-transform: uppercase;
  letter-spacing: 1px;
}

.utility-list {
  display: flex;
  gap: 0.5rem;
  overflow-x: auto;
  padding-bottom: 0.25rem;
  
  &::-webkit-scrollbar { display: none; }
}

.utility-item {
  flex-shrink: 0;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  padding: 0.75rem 1rem;
  background: var(--bg-tertiary);
  border: 1px solid transparent;
  border-radius: 10px;
  text-align: left;
  min-width: 160px;
  max-width: 200px;
  transition: all 0.15s ease;
  cursor: pointer;
  position: relative;
  
  &:hover, &.active {
    background: var(--bg-secondary);
    border-color: var(--border-primary);
    
    .utility-arrow {
      opacity: 1;
      transform: translateX(0);
    }
  }
}

.utility-arrow {
  position: absolute;
  top: 0.75rem;
  right: 0.75rem;
  font-size: 0.875rem;
  color: var(--text-tertiary);
  opacity: 0;
  transform: translateX(-4px);
  transition: all 0.15s ease;
}

.utility-name {
  font-family: 'Noto Serif SC', 'Source Han Serif SC', 'Songti SC', serif;
  font-size: 0.875rem;
  font-weight: 600;
  color: var(--text-primary);
  margin-bottom: 0.375rem;
}

.utility-desc {
  font-family: 'Noto Serif SC', 'Source Han Serif SC', 'Songti SC', serif;
  font-size: 0.75rem;
  color: var(--text-tertiary);
  line-height: 1.5;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}
</style>

<style lang="scss">
// 全局弹窗样式（非 scoped）
.utility-dialog {
  .el-dialog__header {
    padding: 1.25rem 1.5rem;
    border-bottom: 1px solid var(--border-secondary);
    margin: 0;
  }
  
  .el-dialog__body {
    padding: 0;
    max-height: 70vh;
    overflow-y: auto;
  }
  
  .el-dialog__title {
    font-weight: 600;
  }
}

.email-dialog {
  .el-dialog__body {
    max-height: 75vh;
  }
}
</style>
