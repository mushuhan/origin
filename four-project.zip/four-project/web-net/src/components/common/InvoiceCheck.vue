<script setup>
import { ref, computed, reactive } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { verifyInvoice, saveInvoiceHeader, getInvoiceHeaders } from '@/api'

const emit = defineEmits(['close'])

// 输入模式
const inputMode = ref('text') // 'text' | 'file'

// 手动输入
const manualInput = ref({
  title: '',
  tax_number: ''
})

// 文件上传
const fileList = ref([])
const uploading = ref(false)

// 校验结果
const verifyResults = ref([])
const verifying = ref(false)

// 已有抬头库（用于搜索建议）
const headerSuggestions = ref([])
const searchKeyword = ref('')

// 编辑状态管理 - 使用 Map 存储每个结果的编辑状态
// key: `${fileIdx}-${resultIdx}` 或 `manual-${idx}`
const editingItems = reactive(new Map())

// 获取编辑 key
const getEditKey = (fileIdx, resultIdx) => {
  if (fileIdx === null || fileIdx === undefined) {
    return `manual-${resultIdx}`
  }
  return `${fileIdx}-${resultIdx}`
}

// 开始编辑
const startEditing = (result, fileIdx = null, resultIdx = 0) => {
  const key = getEditKey(fileIdx, resultIdx)
  editingItems.set(key, {
    title: result.title || '',
    tax_number: result.tax_number || '',
    original: { ...result }
  })
}

// 取消编辑
const cancelEditing = (fileIdx = null, resultIdx = 0) => {
  const key = getEditKey(fileIdx, resultIdx)
  editingItems.delete(key)
}

// 确认编辑
const confirmEditing = (result, fileIdx = null, resultIdx = 0) => {
  const key = getEditKey(fileIdx, resultIdx)
  const editData = editingItems.get(key)
  
  if (!editData) return
  
  // 更新结果
  result.title = editData.title.trim()
  result.tax_number = editData.tax_number.trim().toUpperCase()
  result.edited = true  // 标记为已编辑
  
  // 清除编辑状态
  editingItems.delete(key)
  
  ElMessage.success('已更新，可点击"保存到库"按钮存储')
}

// 检查是否正在编辑
const isEditing = (fileIdx = null, resultIdx = 0) => {
  const key = getEditKey(fileIdx, resultIdx)
  return editingItems.has(key)
}

// 获取编辑数据
const getEditData = (fileIdx = null, resultIdx = 0) => {
  const key = getEditKey(fileIdx, resultIdx)
  return editingItems.get(key)
}

// 使用最匹配数据
const applyBestMatch = (result) => {
  if (!result.best_match) return
  
  result.title = result.best_match.title
  result.tax_number = result.best_match.tax_number
  result.status = 'pass'
  result.messages = ['已使用标准库数据']
  result.is_new = false
  result.edited = false
  result.best_match = null  // 清除匹配提示
  
  ElMessage.success('已应用标准库数据')
}

// 上传前检查
const beforeUpload = (file) => {
  const allowedTypes = ['application/pdf', 'image/jpeg', 'image/png', 'image/jpg', 'image/gif']
  const isAllowed = allowedTypes.includes(file.type) || 
                   file.name.toLowerCase().endsWith('.pdf') ||
                   file.name.toLowerCase().endsWith('.jpg') ||
                   file.name.toLowerCase().endsWith('.jpeg') ||
                   file.name.toLowerCase().endsWith('.png')
  
  if (!isAllowed) {
    ElMessage.error('仅支持 PDF、JPG、PNG 格式的文件')
    return false
  }
  
  const maxSize = 10 * 1024 * 1024 // 10MB
  if (file.size > maxSize) {
    ElMessage.error('文件大小不能超过 10MB')
    return false
  }
  
  return true
}

// 手动输入校验
const verifyManual = async () => {
  if (!manualInput.value.title && !manualInput.value.tax_number) {
    ElMessage.warning('请输入抬头或税号')
    return
  }
  
  verifying.value = true
  try {
    const results = await verifyInvoice({
      items: [{
        title: manualInput.value.title,
        tax_number: manualInput.value.tax_number
      }]
    })
    verifyResults.value = results
  } catch (e) {
    ElMessage.error(e.message || '校验失败')
  } finally {
    verifying.value = false
  }
}

// 文件上传校验
const verifyFiles = async () => {
  if (fileList.value.length === 0) {
    ElMessage.warning('请先上传文件')
    return
  }
  
  verifying.value = true
  
  try {
    const formData = new FormData()
    fileList.value.forEach(f => {
      formData.append('files', f.raw)
    })
    
    const results = await verifyInvoice(formData, true)
    verifyResults.value = results
  } catch (e) {
    ElMessage.error(e.message || '校验失败')
  } finally {
    verifying.value = false
  }
}

// 执行校验
const handleVerify = () => {
  if (inputMode.value === 'text') {
    verifyManual()
  } else {
    verifyFiles()
  }
}

// 保存新抬头
const handleSaveHeader = async (result) => {
  try {
    await ElMessageBox.confirm(
      `确定要将以下信息保存到发票抬头库吗？\n抬头：${result.title}\n税号：${result.tax_number}`,
      '保存发票信息',
      {
        confirmButtonText: '保存',
        cancelButtonText: '取消',
        type: 'info'
      }
    )
    
    await saveInvoiceHeader({
      title: result.title,
      tax_number: result.tax_number
    })
    
    ElMessage.success('保存成功')
    result.is_new = false
    result.edited = false  // 清除编辑标记，使按钮消失
    result.status = 'pass'
    result.messages = ['已保存到标准库']
  } catch (e) {
    if (e !== 'cancel') {
      ElMessage.error(e.message || '保存失败')
    }
  }
}

// 搜索抬头库
const searchHeaders = async (keyword) => {
  if (!keyword || keyword.length < 2) {
    headerSuggestions.value = []
    return
  }
  
  try {
    const headers = await getInvoiceHeaders(keyword)
    headerSuggestions.value = headers
  } catch (e) {
    console.error(e)
  }
}

// 选择建议
const selectSuggestion = (header) => {
  manualInput.value.title = header.title
  manualInput.value.tax_number = header.tax_number
  headerSuggestions.value = []
}

// 获取状态颜色
const getStatusType = (status) => {
  const map = {
    pass: 'success',
    fail: 'danger',
    warning: 'warning',
    unknown: 'info'
  }
  return map[status] || 'info'
}

// 获取状态文本
const getStatusText = (status) => {
  const map = {
    pass: '通过',
    fail: '不通过',
    warning: '待确认',
    unknown: '未知'
  }
  return map[status] || '未知'
}

// 清空
const handleClear = () => {
  manualInput.value = { title: '', tax_number: '' }
  fileList.value = []
  verifyResults.value = []
}

// 文件变化
const handleFileChange = (file, files) => {
  fileList.value = files
}

// 移除文件
const handleFileRemove = (file, files) => {
  fileList.value = files
}
</script>

<template>
  <div class="invoice-check">
    <!-- 输入模式切换 -->
    <div class="mode-switch">
      <el-radio-group v-model="inputMode" size="default">
        <el-radio-button value="text">
          <el-icon><EditPen /></el-icon>
          <span>手动输入</span>
        </el-radio-button>
        <el-radio-button value="file">
          <el-icon><Upload /></el-icon>
          <span>上传文件</span>
        </el-radio-button>
      </el-radio-group>
    </div>

    <!-- 手动输入模式 -->
    <div v-if="inputMode === 'text'" class="input-section">
      <el-form label-position="top" class="input-form">
        <el-form-item label="发票抬头">
          <el-input
            v-model="manualInput.title"
            placeholder="请输入公司名称"
            clearable
            @input="searchHeaders(manualInput.title)"
          >
            <template #prefix>
              <el-icon><OfficeBuilding /></el-icon>
            </template>
          </el-input>
          <!-- 搜索建议 -->
          <div v-if="headerSuggestions.length > 0" class="suggestions">
            <div
              v-for="s in headerSuggestions"
              :key="s.id"
              class="suggestion-item"
              @click="selectSuggestion(s)"
            >
              <span class="s-title">{{ s.title }}</span>
              <span class="s-tax">{{ s.tax_number }}</span>
            </div>
          </div>
        </el-form-item>
        <el-form-item label="纳税人识别号">
          <el-input
            v-model="manualInput.tax_number"
            placeholder="请输入15-20位税号"
            clearable
          >
            <template #prefix>
              <el-icon><Tickets /></el-icon>
            </template>
          </el-input>
        </el-form-item>
      </el-form>
    </div>

    <!-- 文件上传模式 -->
    <div v-else class="upload-section">
      <el-upload
        v-model:file-list="fileList"
        class="upload-area"
        drag
        multiple
        :auto-upload="false"
        :before-upload="beforeUpload"
        @change="handleFileChange"
        @remove="handleFileRemove"
        accept=".pdf,.jpg,.jpeg,.png"
      >
        <el-icon class="el-icon--upload"><UploadFilled /></el-icon>
        <div class="el-upload__text">
          拖拽文件到此处，或<em>点击上传</em>
        </div>
        <template #tip>
          <div class="el-upload__tip">
            支持 PDF、JPG、PNG 格式，单个文件不超过 10MB，支持批量上传
          </div>
        </template>
      </el-upload>
    </div>

    <!-- 操作按钮 -->
    <div class="actions">
      <el-button @click="handleClear">清空</el-button>
      <el-button
        type="primary"
        :loading="verifying"
        @click="handleVerify"
      >
        <el-icon><CircleCheck /></el-icon>
        <span>开始校验</span>
      </el-button>
    </div>

    <!-- 校验结果 -->
    <div v-if="verifyResults.length > 0" class="results-section">
      <div class="results-header">
        <span class="results-title">校验结果</span>
        <span class="results-count">共 {{ verifyResults.length }} 条</span>
      </div>
      
      <div class="results-list">
        <!-- 文件上传结果 -->
        <template v-if="inputMode === 'file'">
          <div
            v-for="(file, idx) in verifyResults"
            :key="idx"
            class="result-file"
          >
            <div class="file-header">
              <el-icon><Document /></el-icon>
              <span class="file-name">{{ file.filename }}</span>
            </div>
            
            <div v-if="file.results" class="file-results">
              <div
                v-for="(r, ridx) in file.results"
                :key="ridx"
                class="result-item"
              >
                <el-tag :type="getStatusType(r.status)" class="status-tag">
                  {{ getStatusText(r.status) }}
                  <span v-if="r.edited" class="edited-badge">已修改</span>
                </el-tag>
                
                <!-- 编辑模式 -->
                <div v-if="isEditing(idx, ridx)" class="result-content editing">
                  <div class="edit-row">
                    <span class="label">抬头：</span>
                    <el-input
                      v-model="getEditData(idx, ridx).title"
                      size="small"
                      placeholder="输入抬头名称"
                      clearable
                    />
                  </div>
                  <div class="edit-row">
                    <span class="label">税号：</span>
                    <el-input
                      v-model="getEditData(idx, ridx).tax_number"
                      size="small"
                      placeholder="输入18位税号"
                      clearable
                      maxlength="18"
                    />
                  </div>
                  <div class="edit-actions">
                    <el-button size="small" @click="cancelEditing(idx, ridx)">取消</el-button>
                    <el-button size="small" type="primary" @click="confirmEditing(r, idx, ridx)">确认</el-button>
                  </div>
                </div>
                
                <!-- 显示模式 -->
                <div v-else class="result-content">
                  <div v-if="r.title" class="result-row">
                    <span class="label">抬头：</span>
                    <span class="value">{{ r.title }}</span>
                  </div>
                  <div v-if="r.tax_number" class="result-row">
                    <span class="label">税号：</span>
                    <span class="value">{{ r.tax_number }}</span>
                  </div>
                  <div class="result-messages">
                    <span v-for="(msg, midx) in r.messages" :key="midx" class="msg">
                      {{ msg }}
                    </span>
                  </div>
                  <!-- 最匹配数据展示 -->
                  <div v-if="r.best_match" class="best-match">
                    <div class="match-header">
                      <el-icon><Connection /></el-icon>
                      <span>最匹配数据</span>
                      <el-tag size="small" type="info">{{ Math.round(r.best_match.similarity * 100) }}% 匹配</el-tag>
                    </div>
                    <div class="match-content">
                      <div class="match-row">
                        <span class="label">抬头：</span>
                        <span class="value">{{ r.best_match.title }}</span>
                      </div>
                      <div class="match-row">
                        <span class="label">税号：</span>
                        <span class="value">{{ r.best_match.tax_number }}</span>
                      </div>
                    </div>
                    <el-button
                      size="small"
                      text
                      type="primary"
                      @click="applyBestMatch(r)"
                    >
                      使用此数据
                    </el-button>
                  </div>
                </div>
                
                <!-- 操作按钮 -->
                <div class="result-actions">
                  <el-button
                    v-if="!isEditing(idx, ridx)"
                    size="small"
                    plain
                    @click="startEditing(r, idx, ridx)"
                  >
                    <el-icon><Edit /></el-icon>
                    修改
                  </el-button>
                  <el-button
                    v-if="!isEditing(idx, ridx) && (r.is_new || r.edited) && r.title && r.tax_number"
                    size="small"
                    type="primary"
                    plain
                    @click="handleSaveHeader(r)"
                  >
                    保存到库
                  </el-button>
                </div>
              </div>
            </div>
            
            <div v-else class="file-error">
              <el-tag type="danger">{{ file.messages?.[0] || '处理失败' }}</el-tag>
            </div>
          </div>
        </template>
        
        <!-- 手动输入结果 -->
        <template v-else>
          <div
            v-for="(r, idx) in verifyResults"
            :key="idx"
            class="result-item standalone"
          >
            <el-tag :type="getStatusType(r.status)" size="large" class="status-tag">
              {{ getStatusText(r.status) }}
              <span v-if="r.edited" class="edited-badge">已修改</span>
            </el-tag>
            
            <!-- 编辑模式 -->
            <div v-if="isEditing(null, idx)" class="result-content editing">
              <div class="edit-row">
                <span class="label">抬头：</span>
                <el-input
                  v-model="getEditData(null, idx).title"
                  size="default"
                  placeholder="输入抬头名称"
                  clearable
                />
              </div>
              <div class="edit-row">
                <span class="label">税号：</span>
                <el-input
                  v-model="getEditData(null, idx).tax_number"
                  size="default"
                  placeholder="输入18位税号"
                  clearable
                  maxlength="18"
                />
              </div>
              <div class="edit-actions">
                <el-button size="default" @click="cancelEditing(null, idx)">取消</el-button>
                <el-button size="default" type="primary" @click="confirmEditing(r, null, idx)">确认修改</el-button>
              </div>
            </div>
            
            <!-- 显示模式 -->
            <div v-else class="result-content">
              <div v-if="r.title" class="result-row">
                <span class="label">抬头：</span>
                <span class="value">{{ r.title }}</span>
              </div>
              <div v-if="r.tax_number" class="result-row">
                <span class="label">税号：</span>
                <span class="value">{{ r.tax_number }}</span>
              </div>
              <div class="result-messages">
                <span v-for="(msg, midx) in r.messages" :key="midx" class="msg">
                  {{ msg }}
                </span>
              </div>
              <div v-if="r.suggestions?.length" class="result-suggestions">
                <span class="suggestion-label">建议：</span>
                <span v-for="(s, sidx) in r.suggestions" :key="sidx">
                  税号应为 {{ s.tax_number }}
                </span>
              </div>
              <!-- 最匹配数据展示 -->
              <div v-if="r.best_match" class="best-match">
                <div class="match-header">
                  <el-icon><Connection /></el-icon>
                  <span>最匹配数据</span>
                  <el-tag size="small" type="info">{{ Math.round(r.best_match.similarity * 100) }}% 匹配</el-tag>
                </div>
                <div class="match-content">
                  <div class="match-row">
                    <span class="label">抬头：</span>
                    <span class="value">{{ r.best_match.title }}</span>
                  </div>
                  <div class="match-row">
                    <span class="label">税号：</span>
                    <span class="value">{{ r.best_match.tax_number }}</span>
                  </div>
                </div>
                <el-button
                  size="small"
                  text
                  type="primary"
                  @click="applyBestMatch(r)"
                >
                  使用此数据
                </el-button>
              </div>
            </div>
            
            <!-- 操作按钮 -->
            <div class="result-actions">
              <el-button
                v-if="!isEditing(null, idx)"
                size="default"
                plain
                @click="startEditing(r, null, idx)"
              >
                <el-icon><Edit /></el-icon>
                修改
              </el-button>
              <el-button
                v-if="!isEditing(null, idx) && (r.is_new || r.edited) && r.title && r.tax_number"
                size="default"
                type="primary"
                @click="handleSaveHeader(r)"
              >
                保存到抬头库
              </el-button>
            </div>
          </div>
        </template>
      </div>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.invoice-check {
  padding: 1.5rem;
}

.mode-switch {
  display: flex;
  justify-content: center;
  margin-bottom: 1.5rem;
  
  :deep(.el-radio-button__inner) {
    display: flex;
    align-items: center;
    gap: 0.375rem;
  }
}

.input-section {
  margin-bottom: 1.5rem;
}

.input-form {
  max-width: 500px;
  margin: 0 auto;
  
  :deep(.el-form-item__label) {
    font-weight: 500;
  }
}

.suggestions {
  position: absolute;
  top: 100%;
  left: 0;
  right: 0;
  background: var(--card-bg);
  border: 1px solid var(--border-primary);
  border-radius: 8px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
  z-index: 100;
  max-height: 200px;
  overflow-y: auto;
}

.suggestion-item {
  padding: 0.625rem 0.875rem;
  cursor: pointer;
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 1rem;
  
  &:hover {
    background: var(--bg-tertiary);
  }
  
  .s-title {
    font-size: 0.875rem;
    color: var(--text-primary);
  }
  
  .s-tax {
    font-size: 0.75rem;
    color: var(--text-tertiary);
    font-family: monospace;
  }
}

.upload-section {
  margin-bottom: 1.5rem;
  
  :deep(.upload-area) {
    width: 100%;
    
    .el-upload-dragger {
      width: 100%;
      padding: 2rem;
    }
  }
}

.actions {
  display: flex;
  justify-content: center;
  gap: 0.75rem;
  padding-bottom: 1.5rem;
  border-bottom: 1px solid var(--border-secondary);
}

.results-section {
  margin-top: 1.5rem;
}

.results-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1rem;
  
  .results-title {
    font-size: 1rem;
    font-weight: 600;
    color: var(--text-primary);
  }
  
  .results-count {
    font-size: 0.8125rem;
    color: var(--text-tertiary);
  }
}

.results-list {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

.result-file {
  background: var(--bg-tertiary);
  border-radius: 10px;
  padding: 1rem;
  
  .file-header {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    margin-bottom: 0.75rem;
    padding-bottom: 0.75rem;
    border-bottom: 1px solid var(--border-secondary);
    
    .file-name {
      font-weight: 500;
      color: var(--text-primary);
    }
  }
  
  .file-results {
    display: flex;
    flex-direction: column;
    gap: 0.75rem;
  }
  
  .file-error {
    padding: 0.5rem 0;
  }
}

.result-item {
  display: flex;
  align-items: flex-start;
  gap: 1rem;
  padding: 0.75rem;
  background: var(--card-bg);
  border-radius: 8px;
  flex-wrap: wrap;
  
  &.standalone {
    background: var(--bg-tertiary);
    padding: 1rem;
  }
  
  .status-tag {
    flex-shrink: 0;
    
    .edited-badge {
      margin-left: 0.25rem;
      font-size: 0.625rem;
      opacity: 0.8;
    }
  }
  
  .result-content {
    flex: 1;
    min-width: 0;
    
    &.editing {
      .edit-row {
        display: flex;
        align-items: center;
        gap: 0.5rem;
        margin-bottom: 0.5rem;
        
        .label {
          flex-shrink: 0;
          width: 3rem;
          color: var(--text-tertiary);
          font-size: 0.875rem;
        }
        
        .el-input {
          flex: 1;
        }
      }
      
      .edit-actions {
        display: flex;
        justify-content: flex-end;
        gap: 0.5rem;
        margin-top: 0.75rem;
        padding-top: 0.75rem;
        border-top: 1px dashed var(--border-secondary);
      }
    }
  }
  
  .result-row {
    margin-bottom: 0.25rem;
    font-size: 0.875rem;
    
    .label {
      color: var(--text-tertiary);
    }
    
    .value {
      color: var(--text-primary);
      font-weight: 500;
    }
  }
  
  .result-messages {
    margin-top: 0.5rem;
    
    .msg {
      display: block;
      font-size: 0.8125rem;
      color: var(--text-secondary);
      
      &::before {
        content: '• ';
        color: var(--text-tertiary);
      }
    }
  }
  
  .result-suggestions {
    margin-top: 0.5rem;
    font-size: 0.8125rem;
    color: var(--accent);
  }
  
  .best-match {
    margin-top: 0.75rem;
    padding: 0.625rem;
    background: rgba(var(--accent-rgb, 64, 158, 255), 0.08);
    border: 1px dashed rgba(var(--accent-rgb, 64, 158, 255), 0.3);
    border-radius: 6px;
    
    .match-header {
      display: flex;
      align-items: center;
      gap: 0.375rem;
      margin-bottom: 0.5rem;
      font-size: 0.75rem;
      color: var(--accent);
      font-weight: 500;
      
      .el-icon {
        font-size: 0.875rem;
      }
      
      .el-tag {
        margin-left: auto;
      }
    }
    
    .match-content {
      padding-left: 0.25rem;
      
      .match-row {
        font-size: 0.8125rem;
        margin-bottom: 0.125rem;
        
        .label {
          color: var(--text-tertiary);
        }
        
        .value {
          color: var(--text-primary);
          font-weight: 500;
        }
      }
    }
    
    .el-button {
      margin-top: 0.5rem;
      padding-left: 0;
    }
  }
  
  .result-actions {
    display: flex;
    flex-direction: column;
    gap: 0.375rem;
    flex-shrink: 0;
    
    .el-button {
      margin: 0;
    }
  }
}
</style>

