<script setup>
import { ref, computed, onMounted, onUnmounted, watch, nextTick } from 'vue'
import * as echarts from 'echarts'

const props = defineProps({
  // 卡片标题
  title: {
    type: String,
    default: '统计指标'
  },
  // 主要数值
  value: {
    type: [Number, String],
    default: 0
  },
  // 数值前缀
  prefix: {
    type: String,
    default: ''
  },
  // 数值后缀
  suffix: {
    type: String,
    default: ''
  },
  // 趋势百分比 (如 5.2 表示 +5.2%, -3.1 表示 -3.1%)
  trend: {
    type: Number,
    default: null
  },
  // 趋势标签 (如 "较昨日", "环比")
  trendLabel: {
    type: String,
    default: '较上期'
  },
  // Sparkline 数据 (最近 N 个数据点)
  sparklineData: {
    type: Array,
    default: () => []
  },
  // 主题色 (用于 sparkline 和强调色)
  color: {
    type: String,
    default: '#3b82f6'
  },
  // 图标 (可选，Element Plus 图标名)
  icon: {
    type: String,
    default: ''
  },
  // 是否加载中
  loading: {
    type: Boolean,
    default: false
  },
  // 卡片尺寸
  size: {
    type: String,
    default: 'default', // 'small' | 'default' | 'large'
    validator: (v) => ['small', 'default', 'large'].includes(v)
  }
})

const emit = defineEmits(['click'])

// Sparkline 容器引用
const sparklineRef = ref(null)
let chartInstance = null

// 格式化数值
const formattedValue = computed(() => {
  const val = props.value
  if (typeof val === 'number') {
    if (Math.abs(val) >= 1000000) {
      return (val / 1000000).toFixed(1) + 'M'
    } else if (Math.abs(val) >= 1000) {
      return (val / 1000).toFixed(1) + 'K'
    }
    return val.toLocaleString('zh-CN', { maximumFractionDigits: 2 })
  }
  return val
})

// 趋势方向
const trendDirection = computed(() => {
  if (props.trend === null || props.trend === undefined) return null
  return props.trend >= 0 ? 'up' : 'down'
})

// 趋势颜色
const trendColor = computed(() => {
  if (trendDirection.value === 'up') return '#10b981' // green
  if (trendDirection.value === 'down') return '#ef4444' // red
  return '#6b7280' // gray
})

// 格式化趋势值
const formattedTrend = computed(() => {
  if (props.trend === null || props.trend === undefined) return ''
  const sign = props.trend >= 0 ? '+' : ''
  return `${sign}${props.trend.toFixed(1)}%`
})

// 深色模式检测
const isDark = ref(document.documentElement.classList.contains('dark'))

// 渲染 Sparkline
const renderSparkline = () => {
  if (!sparklineRef.value || props.sparklineData.length < 2) return
  
  if (chartInstance) {
    chartInstance.dispose()
  }
  
  chartInstance = echarts.init(sparklineRef.value, null, {
    renderer: 'canvas'
  })
  
  const data = props.sparklineData
  const isPositiveTrend = data[data.length - 1] >= data[0]
  const lineColor = props.color || (isPositiveTrend ? '#10b981' : '#ef4444')
  
  const option = {
    animation: true,
    animationDuration: 800,
    grid: {
      top: 2,
      right: 2,
      bottom: 2,
      left: 2
    },
    xAxis: {
      type: 'category',
      show: false,
      data: data.map((_, i) => i)
    },
    yAxis: {
      type: 'value',
      show: false,
      min: (value) => value.min - (value.max - value.min) * 0.1,
      max: (value) => value.max + (value.max - value.min) * 0.1
    },
    series: [{
      type: 'line',
      data: data,
      smooth: true,
      symbol: 'none',
      lineStyle: {
        width: 2,
        color: lineColor
      },
      areaStyle: {
        color: {
          type: 'linear',
          x: 0,
          y: 0,
          x2: 0,
          y2: 1,
          colorStops: [
            { offset: 0, color: lineColor + '40' },
            { offset: 1, color: lineColor + '05' }
          ]
        }
      }
    }]
  }
  
  chartInstance.setOption(option)
}

// 监听数据变化
watch(() => props.sparklineData, () => {
  nextTick(() => renderSparkline())
}, { deep: true })

// 监听主题变化
const observer = new MutationObserver((mutations) => {
  mutations.forEach((mutation) => {
    if (mutation.attributeName === 'class') {
      isDark.value = document.documentElement.classList.contains('dark')
      nextTick(() => renderSparkline())
    }
  })
})

onMounted(() => {
  renderSparkline()
  observer.observe(document.documentElement, { attributes: true })
  
  // 监听窗口大小变化
  window.addEventListener('resize', handleResize)
})

onUnmounted(() => {
  observer.disconnect()
  window.removeEventListener('resize', handleResize)
  if (chartInstance) {
    chartInstance.dispose()
    chartInstance = null
  }
})

const handleResize = () => {
  chartInstance?.resize()
}

const handleClick = () => {
  emit('click')
}
</script>

<template>
  <div 
    class="stat-card" 
    :class="[`stat-card--${size}`, { 'stat-card--clickable': $attrs.onClick }]"
    @click="handleClick"
  >
    <!-- 加载状态 -->
    <div v-if="loading" class="stat-card__loading">
      <div class="stat-card__skeleton-title"></div>
      <div class="stat-card__skeleton-value"></div>
      <div class="stat-card__skeleton-sparkline"></div>
    </div>
    
    <template v-else>
      <!-- 头部：标题和图标 -->
      <div class="stat-card__header">
        <span class="stat-card__title">{{ title }}</span>
        <div v-if="icon" class="stat-card__icon" :style="{ backgroundColor: color + '15', color: color }">
          <el-icon><component :is="icon" /></el-icon>
        </div>
      </div>
      
      <!-- 主要数值 -->
      <div class="stat-card__value-row">
        <span class="stat-card__value">
          <span v-if="prefix" class="stat-card__prefix">{{ prefix }}</span>
          {{ formattedValue }}
          <span v-if="suffix" class="stat-card__suffix">{{ suffix }}</span>
        </span>
      </div>
      
      <!-- 趋势显示 -->
      <div v-if="trend !== null" class="stat-card__trend">
        <span 
          class="stat-card__trend-badge"
          :class="`stat-card__trend-badge--${trendDirection}`"
        >
          <svg v-if="trendDirection === 'up'" class="stat-card__trend-arrow" viewBox="0 0 20 20" fill="currentColor">
            <path fill-rule="evenodd" d="M5.293 9.707a1 1 0 010-1.414l4-4a1 1 0 011.414 0l4 4a1 1 0 01-1.414 1.414L11 7.414V15a1 1 0 11-2 0V7.414L6.707 9.707a1 1 0 01-1.414 0z" clip-rule="evenodd" />
          </svg>
          <svg v-else class="stat-card__trend-arrow" viewBox="0 0 20 20" fill="currentColor">
            <path fill-rule="evenodd" d="M14.707 10.293a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 111.414-1.414L9 12.586V5a1 1 0 012 0v7.586l2.293-2.293a1 1 0 011.414 0z" clip-rule="evenodd" />
          </svg>
          {{ formattedTrend }}
        </span>
        <span class="stat-card__trend-label">{{ trendLabel }}</span>
      </div>
      
      <!-- Sparkline 迷你图 -->
      <div 
        v-if="sparklineData && sparklineData.length >= 2" 
        ref="sparklineRef" 
        class="stat-card__sparkline"
      ></div>
    </template>
  </div>
</template>

<style lang="scss" scoped>
.stat-card {
  position: relative;
  background: var(--card-bg);
  border: 1px solid var(--border-secondary);
  border-radius: 12px;
  padding: 1.25rem;
  transition: all 0.2s ease;
  overflow: hidden;
  
  &:hover {
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
    border-color: var(--border-hover);
  }
  
  &--clickable {
    cursor: pointer;
    
    &:hover {
      transform: translateY(-2px);
    }
  }
  
  // 尺寸变体
  &--small {
    padding: 1rem;
    
    .stat-card__title { font-size: 0.6875rem; }
    .stat-card__value { font-size: 1.5rem; }
    .stat-card__sparkline { height: 32px; }
  }
  
  &--large {
    padding: 1.5rem;
    
    .stat-card__title { font-size: 0.8125rem; }
    .stat-card__value { font-size: 2.5rem; }
    .stat-card__sparkline { height: 56px; }
  }
  
  // 加载状态
  &__loading {
    display: flex;
    flex-direction: column;
    gap: 0.75rem;
  }
  
  &__skeleton-title {
    width: 60%;
    height: 12px;
    background: linear-gradient(90deg, var(--bg-tertiary) 25%, var(--bg-secondary) 50%, var(--bg-tertiary) 75%);
    background-size: 200% 100%;
    animation: shimmer 1.5s infinite;
    border-radius: 4px;
  }
  
  &__skeleton-value {
    width: 40%;
    height: 28px;
    background: linear-gradient(90deg, var(--bg-tertiary) 25%, var(--bg-secondary) 50%, var(--bg-tertiary) 75%);
    background-size: 200% 100%;
    animation: shimmer 1.5s infinite;
    border-radius: 6px;
  }
  
  &__skeleton-sparkline {
    width: 100%;
    height: 40px;
    background: linear-gradient(90deg, var(--bg-tertiary) 25%, var(--bg-secondary) 50%, var(--bg-tertiary) 75%);
    background-size: 200% 100%;
    animation: shimmer 1.5s infinite;
    border-radius: 6px;
    margin-top: auto;
  }
  
  @keyframes shimmer {
    0% { background-position: 200% 0; }
    100% { background-position: -200% 0; }
  }
  
  // 头部
  &__header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-bottom: 0.75rem;
  }
  
  &__title {
    font-size: 0.75rem;
    font-weight: 500;
    color: var(--text-tertiary);
    text-transform: uppercase;
    letter-spacing: 0.5px;
  }
  
  &__icon {
    width: 32px;
    height: 32px;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 16px;
  }
  
  // 数值行
  &__value-row {
    margin-bottom: 0.5rem;
  }
  
  &__value {
    font-size: 2rem;
    font-weight: 700;
    color: var(--text-primary);
    line-height: 1.2;
    font-variant-numeric: tabular-nums;
  }
  
  &__prefix,
  &__suffix {
    font-size: 0.875em;
    font-weight: 500;
    color: var(--text-secondary);
  }
  
  &__prefix {
    margin-right: 2px;
  }
  
  &__suffix {
    margin-left: 2px;
  }
  
  // 趋势
  &__trend {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    margin-bottom: 0.75rem;
  }
  
  &__trend-badge {
    display: inline-flex;
    align-items: center;
    gap: 2px;
    padding: 2px 8px;
    border-radius: 100px;
    font-size: 0.75rem;
    font-weight: 600;
    
    &--up {
      background: rgba(16, 185, 129, 0.1);
      color: #10b981;
    }
    
    &--down {
      background: rgba(239, 68, 68, 0.1);
      color: #ef4444;
    }
  }
  
  &__trend-arrow {
    width: 12px;
    height: 12px;
  }
  
  &__trend-label {
    font-size: 0.6875rem;
    color: var(--text-tertiary);
  }
  
  // Sparkline
  &__sparkline {
    height: 44px;
    margin-top: auto;
    margin-left: -0.5rem;
    margin-right: -0.5rem;
    margin-bottom: -0.25rem;
  }
}

// 深色模式微调
:root.dark .stat-card {
  &:hover {
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
  }
  
  &__trend-badge {
    &--up {
      background: rgba(16, 185, 129, 0.15);
    }
    
    &--down {
      background: rgba(239, 68, 68, 0.15);
    }
  }
}
</style>

