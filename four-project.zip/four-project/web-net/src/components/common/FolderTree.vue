<script setup>
import { ref, computed } from 'vue'

const props = defineProps({
  folders: {
    type: Array,
    default: () => []
  },
  selectedId: {
    type: [Number, String],
    default: null
  },
  expandedIds: {
    type: Array,
    default: () => []
  },
  editable: {
    type: Boolean,
    default: false
  },
  level: {
    type: Number,
    default: 0
  }
})

const emit = defineEmits([
  'select',
  'toggle',
  'create',
  'rename',
  'delete',
  'move'
])

const editingId = ref(null)
const editingName = ref('')
const newFolderParentId = ref(undefined)
const newFolderName = ref('')

// 检查是否展开
const isExpanded = (id) => props.expandedIds.includes(id)

// 切换展开状态
const toggleExpand = (folder) => {
  emit('toggle', folder.id)
}

// 选择文件夹
const selectFolder = (folder) => {
  emit('select', folder)
}

// 开始编辑
const startEdit = (folder) => {
  editingId.value = folder.id
  editingName.value = folder.name
}

// 保存编辑
const saveEdit = (folder) => {
  if (editingName.value.trim()) {
    emit('rename', folder.id, editingName.value.trim())
  }
  cancelEdit()
}

// 取消编辑
const cancelEdit = () => {
  editingId.value = null
  editingName.value = ''
}

// 删除文件夹
const deleteFolder = (folder) => {
  emit('delete', folder)
}

// 开始创建子文件夹
const startCreateFolder = (parentId = null) => {
  newFolderParentId.value = parentId
  newFolderName.value = ''
}

// 保存新文件夹
const saveNewFolder = () => {
  if (newFolderName.value.trim()) {
    emit('create', {
      name: newFolderName.value.trim(),
      parent_id: newFolderParentId.value
    })
  }
  cancelNewFolder()
}

// 取消创建
const cancelNewFolder = () => {
  newFolderParentId.value = undefined
  newFolderName.value = ''
}

// 获取文件夹图标
const getFolderIcon = (folder) => {
  if (folder.children && folder.children.length > 0) {
    return isExpanded(folder.id) ? 'FolderOpened' : 'Folder'
  }
  return 'Folder'
}
</script>

<template>
  <div class="folder-tree">
    <!-- 根目录新建按钮 -->
    <div v-if="editable && newFolderParentId === undefined && level === 0" class="new-folder-form">
      <button class="add-folder-btn" @click="startCreateFolder(null)">
        <el-icon><Plus /></el-icon>
        新建文件夹
      </button>
    </div>
    
    <!-- 新建文件夹输入框（根目录） -->
    <div v-if="newFolderParentId === null" class="new-folder-input">
      <input
        v-model="newFolderName"
        type="text"
        placeholder="文件夹名称"
        @keyup.enter="saveNewFolder"
        @keyup.esc="cancelNewFolder"
        autofocus
      />
      <button class="save-btn" @click="saveNewFolder">
        <el-icon><Check /></el-icon>
      </button>
      <button class="cancel-btn" @click="cancelNewFolder">
        <el-icon><Close /></el-icon>
      </button>
    </div>
    
    <!-- 文件夹列表 -->
    <div class="folder-list">
      <template v-for="folder in folders" :key="folder.id">
        <div
          class="folder-item"
          :class="{ 
            'is-selected': selectedId === folder.id,
            'is-expanded': isExpanded(folder.id)
          }"
        >
          <!-- 文件夹行 -->
          <div class="folder-row" @click="selectFolder(folder)">
            <!-- 展开/收起按钮 -->
            <button
              v-if="folder.children && folder.children.length > 0"
              class="expand-btn"
              @click.stop="toggleExpand(folder)"
            >
              <el-icon>
                <component :is="isExpanded(folder.id) ? 'ArrowDown' : 'ArrowRight'" />
              </el-icon>
            </button>
            <span v-else class="expand-placeholder"></span>
            
            <!-- 文件夹图标 -->
            <el-icon class="folder-icon" :style="{ color: folder.color }">
              <component :is="getFolderIcon(folder)" />
            </el-icon>
            
            <!-- 名称（编辑模式） -->
            <input
              v-if="editingId === folder.id"
              v-model="editingName"
              type="text"
              class="edit-input"
              @click.stop
              @keyup.enter="saveEdit(folder)"
              @keyup.esc="cancelEdit"
              @blur="saveEdit(folder)"
              autofocus
            />
            
            <!-- 名称（显示模式） -->
            <span v-else class="folder-name">{{ folder.name }}</span>
            
            <!-- 网址数量 -->
            <span v-if="folder.sites_count" class="sites-count">
              {{ folder.sites_count }}
            </span>
            
            <!-- 操作按钮 -->
            <div v-if="editable && editingId !== folder.id" class="folder-actions">
              <button class="action-btn" @click.stop="startEdit(folder)" title="重命名">
                <el-icon><Edit /></el-icon>
              </button>
              <button class="action-btn" @click.stop="startCreateFolder(folder.id)" title="添加子文件夹">
                <el-icon><Plus /></el-icon>
              </button>
              <button class="action-btn delete" @click.stop="deleteFolder(folder)" title="删除">
                <el-icon><Delete /></el-icon>
              </button>
            </div>
          </div>
          
          <!-- 新建子文件夹输入框 -->
          <div v-if="newFolderParentId === folder.id" class="new-folder-input child">
            <input
              v-model="newFolderName"
              type="text"
              placeholder="子文件夹名称"
              @keyup.enter="saveNewFolder"
              @keyup.esc="cancelNewFolder"
              autofocus
            />
            <button class="save-btn" @click="saveNewFolder">
              <el-icon><Check /></el-icon>
            </button>
            <button class="cancel-btn" @click="cancelNewFolder">
              <el-icon><Close /></el-icon>
            </button>
          </div>
          
          <!-- 子文件夹 -->
          <transition name="expand">
            <div v-if="isExpanded(folder.id) && folder.children && folder.children.length > 0" class="folder-children">
              <FolderTree
                :folders="folder.children"
                :selected-id="selectedId"
                :expanded-ids="expandedIds"
                :editable="editable"
                :level="level + 1"
                @select="emit('select', $event)"
                @toggle="emit('toggle', $event)"
                @create="emit('create', $event)"
                @rename="(id, name) => emit('rename', id, name)"  @delete="emit('delete', $event)"
              />
            </div>
          </transition>
        </div>
      </template>
    </div>
    
    <!-- 空状态 -->
    <div v-if="folders.length === 0" class="empty-state">
      <el-icon><FolderOpened /></el-icon>
      <p>暂无文件夹</p>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.folder-tree {
  width: 100%;
}

.add-folder-btn {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.5rem 0.75rem;
  font-size: 0.8125rem;
  color: var(--text-secondary);
  border-radius: 8px;
  transition: all 0.15s ease;
  margin-bottom: 0.5rem;
  
  &:hover {
    background: var(--bg-tertiary);
    color: var(--text-primary);
  }
}

.folder-list {
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.folder-item {
  border-radius: 8px;
  
  &.is-selected > .folder-row {
    background: var(--accent-light);
    
    .folder-name {
      color: var(--accent);
      font-weight: 500;
    }
  }
}

.folder-row {
  display: flex;
  align-items: center;
  gap: 0.375rem;
  padding: 0.5rem 0.5rem;
  border-radius: 8px;
  cursor: pointer;
  transition: background 0.15s ease;
  
  &:hover {
    background: var(--bg-tertiary);
    
    .folder-actions {
      opacity: 1;
    }
  }
}

.expand-btn {
  width: 20px;
  height: 20px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: var(--text-tertiary);
  border-radius: 4px;
  flex-shrink: 0;
  
  &:hover {
    background: var(--border-primary);
    color: var(--text-primary);
  }
  
  .el-icon {
    font-size: 12px;
  }
}

.expand-placeholder {
  width: 20px;
  flex-shrink: 0;
}

.folder-icon {
  font-size: 16px;
  flex-shrink: 0;
}

.folder-name {
  flex: 1;
  font-size: 0.8125rem;
  color: var(--text-primary);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.edit-input {
  flex: 1;
  padding: 0.25rem 0.5rem;
  font-size: 0.8125rem;
  background: var(--bg-secondary);
  border: 1px solid var(--border-primary);
  border-radius: 4px;
  color: var(--text-primary);
}

.sites-count {
  font-size: 0.75rem;
  color: var(--text-tertiary);
  padding: 2px 6px;
  background: var(--bg-tertiary);
  border-radius: 4px;
}

.folder-actions {
  display: flex;
  gap: 2px;
  opacity: 0;
  transition: opacity 0.15s ease;
}

.action-btn {
  width: 24px;
  height: 24px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: var(--text-tertiary);
  border-radius: 4px;
  
  &:hover {
    background: var(--border-primary);
    color: var(--text-primary);
  }
  
  &.delete:hover {
    background: rgba(239, 68, 68, 0.1);
    color: var(--error);
  }
  
  .el-icon {
    font-size: 14px;
  }
}

.folder-children {
  padding-left: 1.25rem;
}

.new-folder-input {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.5rem;
  
  &.child {
    padding-left: 2.5rem;
  }
  
  input {
    flex: 1;
    padding: 0.375rem 0.625rem;
    font-size: 0.8125rem;
    background: var(--bg-secondary);
    border: 1px solid var(--border-primary);
    border-radius: 6px;
    color: var(--text-primary);
    
    &:focus {
      border-color: var(--accent);
    }
  }
  
  .save-btn,
  .cancel-btn {
    width: 28px;
    height: 28px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 6px;
    
    .el-icon {
      font-size: 14px;
    }
  }
  
  .save-btn {
    background: var(--accent);
    color: white;
    
    &:hover {
      opacity: 0.9;
    }
  }
  
  .cancel-btn {
    background: var(--bg-tertiary);
    color: var(--text-secondary);
    
    &:hover {
      background: var(--border-primary);
    }
  }
}

.empty-state {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 2rem;
  color: var(--text-tertiary);
  
  .el-icon {
    font-size: 32px;
    margin-bottom: 0.5rem;
    opacity: 0.5;
  }
  
  p {
    font-size: 0.8125rem;
  }
}

// 展开动画
.expand-enter-active,
.expand-leave-active {
  transition: all 0.2s ease;
  overflow: hidden;
}

.expand-enter-from,
.expand-leave-to {
  opacity: 0;
  max-height: 0;
}

.expand-enter-to,
.expand-leave-from {
  max-height: 500px;
}
</style>

