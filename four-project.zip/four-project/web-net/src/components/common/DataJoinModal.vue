<script setup>
import { ref, reactive, computed, watch } from 'vue'
import { ElMessage, ElLoading } from 'element-plus'
import { previewJoin, executeJoin } from '@/api'

const props = defineProps({
  modelValue: {
    type: Boolean,
    default: false
  },
  // 可选的数据源列表 { name: string, data: { headers: [], rows: [] } }
  dataSources: {
    type: Array,
    default: () => []
  },
  // 已保存的看板 ID（用于从后端加载数据）
  dashboardId: {
    type: [Number, String],
    default: null
  }
})

const emit = defineEmits(['update:modelValue', 'confirm'])

// 对话框可见性
const visible = computed({
  get: () => props.modelValue,
  set: (val) => emit('update:modelValue', val)
})

// 步骤
const currentStep = ref(1)

// 表单数据
const joinConfig = reactive({
  source1: '',       // 表1名称
  source2: '',       // 表2名称
  joinKey1: '',      // 表1关联字段
  joinKey2: '',      // 表2关联字段
  joinType: 'inner', // inner / left / right / outer
  resultName: ''     // 虚拟数据集名称
})

// 预览数据
const previewData = ref({
  columns: [],
  rows: [],
  totalRows: 0
})
const previewLoading = ref(false)
const previewError = ref('')

// Join 类型选项
const joinTypes = [
  { value: 'inner', label: 'Inner Join', desc: '只保留两表都有的记录' },
  { value: 'left', label: 'Left Join', desc: '保留左表所有记录' },
  { value: 'right', label: 'Right Join', desc: '保留右表所有记录' },
  { value: 'outer', label: 'Full Outer Join', desc: '保留两表所有记录' }
]

// 数据源名称列表
const sourceNames = computed(() => {
  return props.dataSources.map(s => s.name)
})

// 表1的字段列表
const source1Fields = computed(() => {
  const source = props.dataSources.find(s => s.name === joinConfig.source1)
  return source?.data?.headers || []
})

// 表2的字段列表
const source2Fields = computed(() => {
  const source = props.dataSources.find(s => s.name === joinConfig.source2)
  return source?.data?.headers || []
})

// 重置表单
const resetForm = () => {
  currentStep.value = 1
  joinConfig.source1 = ''
  joinConfig.source2 = ''
  joinConfig.joinKey1 = ''
  joinConfig.joinKey2 = ''
  joinConfig.joinType = 'inner'
  joinConfig.resultName = ''
  previewData.value = { columns: [], rows: [], totalRows: 0 }
  previewError.value = ''
}

// 监听对话框关闭时重置
watch(visible, (val) => {
  if (!val) {
    resetForm()
  }
})

// 监听数据源变化时清空关联字段
watch(() => joinConfig.source1, () => {
  joinConfig.joinKey1 = ''
})

watch(() => joinConfig.source2, () => {
  joinConfig.joinKey2 = ''
})

// 步骤1：选择数据源
const canProceedStep1 = computed(() => {
  return joinConfig.source1 && joinConfig.source2 && joinConfig.source1 !== joinConfig.source2
})

// 步骤2：选择关联字段
const canProceedStep2 = computed(() => {
  return joinConfig.joinKey1 && joinConfig.joinKey2 && joinConfig.joinType
})

// 下一步
const nextStep = () => {
  if (currentStep.value === 1 && canProceedStep1.value) {
    currentStep.value = 2
  } else if (currentStep.value === 2 && canProceedStep2.value) {
    currentStep.value = 3
    doPreview()
  }
}

// 上一步
const prevStep = () => {
  if (currentStep.value > 1) {
    currentStep.value--
    previewError.value = ''
  }
}

// 执行预览
const doPreview = async () => {
  previewLoading.value = true
  previewError.value = ''
  
  try {
    const source1Data = props.dataSources.find(s => s.name === joinConfig.source1)?.data
    const source2Data = props.dataSources.find(s => s.name === joinConfig.source2)?.data
    
    if (!source1Data || !source2Data) {
      throw new Error('数据源不存在')
    }
    
    // 调用后端 API
    const result = await previewJoin({
      sheetData1: source1Data.rows,
      sheetData2: source2Data.rows,
      joinKey1: joinConfig.joinKey1,
      joinKey2: joinConfig.joinKey2,
      joinType: joinConfig.joinType,
      // 如果有看板ID，也传递用于后端优化
      dashboardId: props.dashboardId,
      sheetName1: joinConfig.source1,
      sheetName2: joinConfig.source2
    })
    
    previewData.value = {
      columns: result.columns || [],
      rows: result.rows || [],
      totalRows: result.totalRows || result.rows?.length || 0
    }
    
    // 自动生成结果名称
    if (!joinConfig.resultName) {
      joinConfig.resultName = `${joinConfig.source1}_${joinConfig.source2}_joined`
    }
  } catch (e) {
    console.error('Join 预览失败:', e)
    previewError.value = e.message || '合并预览失败，请检查关联字段类型是否匹配'
    previewData.value = { columns: [], rows: [], totalRows: 0 }
  } finally {
    previewLoading.value = false
  }
}

// 确认保存 - 执行完整的合并操作
const handleConfirm = async () => {
  if (!joinConfig.resultName.trim()) {
    ElMessage.warning('请输入虚拟数据集名称')
    return
  }
  
  if (previewData.value.columns.length === 0) {
    ElMessage.warning('请先预览合并结果')
    return
  }
  
  // 显示加载状态
  const loading = ElLoading.service({
    lock: true,
    text: '正在合并数据...',
    background: 'rgba(0, 0, 0, 0.7)'
  })
  
  try {
    const source1Data = props.dataSources.find(s => s.name === joinConfig.source1)?.data
    const source2Data = props.dataSources.find(s => s.name === joinConfig.source2)?.data
    
    if (!source1Data || !source2Data) {
      throw new Error('数据源不存在')
    }
    
    // 调用后端执行完整的 Join 操作
    const result = await executeJoin({
      sheetData1: source1Data.rows,
      sheetData2: source2Data.rows,
      joinKey1: joinConfig.joinKey1,
      joinKey2: joinConfig.joinKey2,
      joinType: joinConfig.joinType,
      resultName: joinConfig.resultName
    })
    
    // 构建虚拟数据集配置
    const virtualDataset = {
      name: joinConfig.resultName,
      type: 'join',
      config: {
        source1: joinConfig.source1,
        source2: joinConfig.source2,
        joinKey1: joinConfig.joinKey1,
        joinKey2: joinConfig.joinKey2,
        joinType: joinConfig.joinType
      },
      // 使用完整的合并数据
      data: {
        headers: result.headers || previewData.value.columns,
        rows: result.rows || []
      }
    }
    
    emit('confirm', virtualDataset)
    visible.value = false
    ElMessage.success(`虚拟数据集已创建，共 ${result.rows?.length || 0} 行数据`)
  } catch (e) {
    console.error('执行合并失败:', e)
    ElMessage.error(e.message || '合并失败，请重试')
  } finally {
    loading.close()
  }
}

// 获取 Join 类型描述
const getJoinTypeDesc = (type) => {
  return joinTypes.find(t => t.value === type)?.desc || ''
}
</script>

<template>
  <el-dialog 
    v-model="visible" 
    title="多表关联" 
    width="720px" 
    :close-on-click-modal="false"
    class="data-join-modal"
  >
    <!-- 步骤指示器 -->
    <div class="steps-indicator">
      <div class="step" :class="{ active: currentStep >= 1, completed: currentStep > 1 }">
        <span class="step-number">1</span>
        <span class="step-label">选择数据源</span>
      </div>
      <div class="step-line" :class="{ active: currentStep > 1 }"></div>
      <div class="step" :class="{ active: currentStep >= 2, completed: currentStep > 2 }">
        <span class="step-number">2</span>
        <span class="step-label">配置关联</span>
      </div>
      <div class="step-line" :class="{ active: currentStep > 2 }"></div>
      <div class="step" :class="{ active: currentStep >= 3 }">
        <span class="step-number">3</span>
        <span class="step-label">预览确认</span>
      </div>
    </div>
    
    <!-- 步骤1：选择数据源 -->
    <div v-show="currentStep === 1" class="step-content">
      <div class="join-visual">
        <div class="source-box">
          <div class="source-label">表 1（左表）</div>
          <el-select 
            v-model="joinConfig.source1" 
            placeholder="选择数据源"
            size="large"
            class="source-select"
          >
            <el-option 
              v-for="name in sourceNames" 
              :key="name" 
              :label="name" 
              :value="name"
              :disabled="name === joinConfig.source2"
            />
          </el-select>
          <div v-if="joinConfig.source1" class="source-info">
            {{ source1Fields.length }} 个字段
          </div>
        </div>
        
        <div class="join-icon">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M8 12h8M12 8l4 4-4 4"/>
          </svg>
        </div>
        
        <div class="source-box">
          <div class="source-label">表 2（右表）</div>
          <el-select 
            v-model="joinConfig.source2" 
            placeholder="选择数据源"
            size="large"
            class="source-select"
          >
            <el-option 
              v-for="name in sourceNames" 
              :key="name" 
              :label="name" 
              :value="name"
              :disabled="name === joinConfig.source1"
            />
          </el-select>
          <div v-if="joinConfig.source2" class="source-info">
            {{ source2Fields.length }} 个字段
          </div>
        </div>
      </div>
      
      <div v-if="sourceNames.length < 2" class="warning-tip">
        <el-icon><WarningFilled /></el-icon>
        <span>需要至少两个数据源才能进行关联操作</span>
      </div>
    </div>
    
    <!-- 步骤2：配置关联 -->
    <div v-show="currentStep === 2" class="step-content">
      <div class="join-config-visual">
        <!-- 左表字段 -->
        <div class="field-selector">
          <div class="field-selector-header">
            <span class="table-name">{{ joinConfig.source1 }}</span>
            <span class="field-label">关联字段</span>
          </div>
          <el-select 
            v-model="joinConfig.joinKey1" 
            placeholder="选择字段"
            size="default"
            filterable
          >
            <el-option 
              v-for="field in source1Fields" 
              :key="field" 
              :label="field" 
              :value="field"
            />
          </el-select>
        </div>
        
        <!-- Join 类型 -->
        <div class="join-type-selector">
          <div class="join-type-label">关联方式</div>
          <div class="join-type-options">
            <div 
              v-for="type in joinTypes"
              :key="type.value"
              class="join-type-option"
              :class="{ active: joinConfig.joinType === type.value }"
              @click="joinConfig.joinType = type.value"
            >
              <div class="join-type-visual" :class="type.value"></div>
              <span class="join-type-name">{{ type.label }}</span>
            </div>
          </div>
          <div class="join-type-desc">{{ getJoinTypeDesc(joinConfig.joinType) }}</div>
        </div>
        
        <!-- 右表字段 -->
        <div class="field-selector">
          <div class="field-selector-header">
            <span class="table-name">{{ joinConfig.source2 }}</span>
            <span class="field-label">关联字段</span>
          </div>
          <el-select 
            v-model="joinConfig.joinKey2" 
            placeholder="选择字段"
            size="default"
            filterable
          >
            <el-option 
              v-for="field in source2Fields" 
              :key="field" 
              :label="field" 
              :value="field"
            />
          </el-select>
        </div>
      </div>
    </div>
    
    <!-- 步骤3：预览确认 -->
    <div v-show="currentStep === 3" class="step-content">
      <div v-if="previewLoading" class="preview-loading">
        <el-icon class="loading-icon"><Loading /></el-icon>
        <span>正在合并数据...</span>
      </div>
      
      <div v-else-if="previewError" class="preview-error">
        <el-icon><CircleCloseFilled /></el-icon>
        <span>{{ previewError }}</span>
        <el-button size="small" @click="doPreview">重试</el-button>
      </div>
      
      <div v-else class="preview-result">
        <div class="preview-header">
          <div class="preview-stats">
            <span class="stat-item">
              <strong>{{ previewData.totalRows }}</strong> 行
            </span>
            <span class="stat-item">
              <strong>{{ previewData.columns.length }}</strong> 列
            </span>
          </div>
          <div class="result-name-input">
            <label>保存为</label>
            <el-input 
              v-model="joinConfig.resultName" 
              placeholder="虚拟数据集名称"
              size="small"
            />
          </div>
        </div>
        
        <div class="preview-table-wrapper">
          <el-table 
            :data="previewData.rows.slice(0, 10)" 
            stripe 
            border 
            size="small"
            max-height="280"
          >
            <el-table-column 
              v-for="col in previewData.columns" 
              :key="col" 
              :prop="col" 
              :label="col"
              min-width="100"
              show-overflow-tooltip
            />
          </el-table>
          <div v-if="previewData.totalRows > 10" class="preview-more">
            显示前 10 行，共 {{ previewData.totalRows }} 行
          </div>
        </div>
      </div>
    </div>
    
    <!-- 底部按钮 -->
    <template #footer>
      <div class="dialog-footer">
        <el-button @click="visible = false">取消</el-button>
        <el-button v-if="currentStep > 1" @click="prevStep">上一步</el-button>
        <el-button 
          v-if="currentStep < 3" 
          type="primary" 
          :disabled="currentStep === 1 ? !canProceedStep1 : !canProceedStep2"
          @click="nextStep"
        >
          下一步
        </el-button>
        <el-button 
          v-if="currentStep === 3" 
          type="primary" 
          :disabled="previewLoading || previewError || previewData.columns.length === 0"
          @click="handleConfirm"
        >
          确认创建
        </el-button>
      </div>
    </template>
  </el-dialog>
</template>

<style lang="scss" scoped>
.data-join-modal {
  :deep(.el-dialog__body) {
    padding-top: 0;
  }
  
  :deep(.el-dialog) {
    .el-dialog__header {
      background: var(--bg-tertiary);
    }
    
    .el-dialog__body {
      background: var(--card-bg);
    }
    
    .el-dialog__footer {
      background: var(--card-bg);
    }
  }
}

// 步骤指示器
.steps-indicator {
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 1.5rem 0;
  margin-bottom: 1rem;
}

.step {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 0.5rem;
  
  &.active .step-number {
    background: var(--el-color-primary);
    color: #fff;
    border-color: var(--el-color-primary);
  }
  
  &.completed .step-number {
    background: var(--el-color-success);
    border-color: var(--el-color-success);
    color: #fff;
  }
}

.step-number {
  width: 32px;
  height: 32px;
  border-radius: 50%;
  border: 2px solid var(--border-primary);
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: 600;
  font-size: 0.875rem;
  color: var(--text-tertiary);
  transition: all 0.2s ease;
}

.step-label {
  font-size: 0.75rem;
  color: var(--text-secondary);
}

.step-line {
  width: 60px;
  height: 2px;
  background: var(--border-primary);
  margin: 0 1rem;
  margin-bottom: 1.5rem;
  transition: background 0.2s ease;
  
  &.active {
    background: var(--el-color-primary);
  }
}

// 步骤内容
.step-content {
  min-height: 280px;
}

// 步骤1：数据源选择
.join-visual {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 2rem;
  padding: 2rem;
}

.source-box {
  flex: 1;
  max-width: 240px;
  text-align: center;
}

.source-label {
  font-size: 0.8125rem;
  font-weight: 500;
  color: var(--text-secondary);
  margin-bottom: 0.75rem;
}

.source-select {
  width: 100%;
}

.source-info {
  margin-top: 0.5rem;
  font-size: 0.75rem;
  color: var(--text-tertiary);
}

.join-icon {
  width: 48px;
  height: 48px;
  border-radius: 50%;
  background: var(--bg-tertiary);
  display: flex;
  align-items: center;
  justify-content: center;
  color: var(--text-secondary);
  
  svg {
    width: 24px;
    height: 24px;
  }
}

.warning-tip {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.5rem;
  padding: 1rem;
  background: rgba(245, 158, 11, 0.1);
  border-radius: 8px;
  color: #f59e0b;
  font-size: 0.875rem;
  margin-top: 1rem;
}

// 步骤2：配置关联
.join-config-visual {
  display: flex;
  align-items: flex-start;
  gap: 1.5rem;
  padding: 1rem;
}

.field-selector {
  flex: 1;
  
  .field-selector-header {
    margin-bottom: 0.75rem;
  }
  
  .table-name {
    display: block;
    font-size: 0.875rem;
    font-weight: 600;
    color: var(--text-primary);
    margin-bottom: 0.25rem;
  }
  
  .field-label {
    font-size: 0.75rem;
    color: var(--text-tertiary);
  }
  
  .el-select {
    width: 100%;
  }
}

.join-type-selector {
  flex: 0 0 200px;
  text-align: center;
}

.join-type-label {
  font-size: 0.75rem;
  color: var(--text-tertiary);
  margin-bottom: 0.75rem;
}

.join-type-options {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 0.5rem;
}

.join-type-option {
  padding: 0.75rem 0.5rem;
  border: 1px solid var(--border-secondary);
  border-radius: 8px;
  cursor: pointer;
  transition: all 0.15s ease;
  
  &:hover {
    border-color: var(--border-hover);
  }
  
  &.active {
    border-color: var(--el-color-primary);
    background: rgba(59, 130, 246, 0.05);
  }
}

.join-type-visual {
  width: 32px;
  height: 20px;
  margin: 0 auto 0.375rem;
  background: var(--bg-tertiary);
  border-radius: 4px;
  position: relative;
  
  &::before,
  &::after {
    content: '';
    position: absolute;
    width: 14px;
    height: 14px;
    border-radius: 50%;
    top: 3px;
  }
  
  &::before {
    left: 2px;
    background: rgba(59, 130, 246, 0.6);
  }
  
  &::after {
    right: 2px;
    background: rgba(16, 185, 129, 0.6);
  }
  
  &.inner::before,
  &.inner::after {
    opacity: 0.4;
  }
  
  &.left::after {
    opacity: 0.4;
  }
  
  &.right::before {
    opacity: 0.4;
  }
}

.join-type-name {
  font-size: 0.6875rem;
  color: var(--text-secondary);
}

.join-type-desc {
  margin-top: 0.75rem;
  font-size: 0.75rem;
  color: var(--text-tertiary);
}

// 步骤3：预览
.preview-loading {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 200px;
  gap: 1rem;
  color: var(--text-secondary);
  
  .loading-icon {
    font-size: 32px;
    animation: spin 1s linear infinite;
  }
}

@keyframes spin {
  from { transform: rotate(0deg); }
  to { transform: rotate(360deg); }
}

.preview-error {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 200px;
  gap: 0.75rem;
  color: #ef4444;
  
  .el-icon {
    font-size: 32px;
  }
}

.preview-result {
  .preview-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1rem;
  }
  
  .preview-stats {
    display: flex;
    gap: 1rem;
  }
  
  .stat-item {
    font-size: 0.8125rem;
    color: var(--text-secondary);
    
    strong {
      color: var(--text-primary);
      margin-right: 2px;
    }
  }
  
  .result-name-input {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    
    label {
      font-size: 0.75rem;
      color: var(--text-tertiary);
      white-space: nowrap;
    }
    
    .el-input {
      width: 200px;
    }
  }
}

.preview-table-wrapper {
  border: 1px solid var(--border-secondary);
  border-radius: 8px;
  overflow: hidden;
  
  :deep(.el-table) {
    --el-table-border-color: var(--border-secondary);
    --el-table-header-bg-color: var(--bg-tertiary);
    --el-table-tr-bg-color: var(--card-bg);
    --el-table-row-hover-bg-color: var(--bg-tertiary);
    --el-table-text-color: var(--text-primary);
    --el-table-header-text-color: var(--text-secondary);
    background-color: var(--card-bg) !important;
    
    th.el-table__cell {
      font-weight: 500;
      font-size: 0.75rem;
      background: var(--bg-tertiary) !important;
      color: var(--text-secondary) !important;
    }
    
    td.el-table__cell {
      font-size: 0.75rem;
      color: var(--text-primary) !important;
    }
    
    .el-table__body-wrapper {
      background: var(--card-bg) !important;
    }
  }
  
  // 斑马纹（单独选择器）
  :deep(.el-table--striped .el-table__body tr.el-table__row--striped td.el-table__cell) {
    background: var(--bg-tertiary) !important;
  }
}

.preview-more {
  padding: 0.5rem;
  text-align: center;
  font-size: 0.75rem;
  color: var(--text-tertiary);
  background: var(--bg-tertiary);
}

// 底部按钮
.dialog-footer {
  display: flex;
  justify-content: flex-end;
  gap: 0.5rem;
}

// 选择框样式修复
:deep(.el-select) {
  .el-select__wrapper {
    background: var(--input-bg) !important;
    border: 1px solid var(--input-border) !important;
    box-shadow: none !important;
    
    &:hover {
      border-color: var(--border-hover) !important;
    }
    
    &.is-focused {
      border-color: var(--accent) !important;
    }
  }
  
  .el-select__selected-item {
    color: var(--text-primary) !important;
  }
  
  .el-select__placeholder {
    color: var(--text-tertiary) !important;
  }
}

// 输入框样式修复
:deep(.el-input) {
  .el-input__wrapper {
    background: var(--input-bg) !important;
    border: 1px solid var(--input-border) !important;
    box-shadow: none !important;
    
    &:hover {
      border-color: var(--border-hover) !important;
    }
    
    &.is-focus {
      border-color: var(--accent) !important;
    }
  }
  
  .el-input__inner {
    color: var(--text-primary) !important;
    
    &::placeholder {
      color: var(--text-tertiary) !important;
    }
  }
}
</style>

