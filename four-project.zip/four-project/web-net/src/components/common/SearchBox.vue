<script setup>
import { ref, computed, watch, onMounted, onUnmounted } from 'vue'
import { useRouter } from 'vue-router'
import { getSearchSuggestions, clickWebsite } from '@/api'
import { debounce, trackWebsiteVisit } from '@/utils/helpers'

const props = defineProps({
  placeholder: {
    type: String,
    default: '搜索网站、工具...'
  },
  size: {
    type: String,
    default: 'normal'
  }
})

const emit = defineEmits(['search', 'focus', 'blur'])

const router = useRouter()
const inputRef = ref(null)
const keyword = ref('')
const isFocused = ref(false)
const showDropdown = ref(false)
const suggestions = ref([])
const hotKeywords = ref([])
const selectedIndex = ref(-1)
const isLoading = ref(false)

// 获取建议
const fetchSuggestions = debounce(async (value) => {
  if (!value.trim()) {
    suggestions.value = []
    return
  }
  
  isLoading.value = true
  try {
    const data = await getSearchSuggestions(value)
    suggestions.value = data.suggestions || []
    hotKeywords.value = data.hot_keywords || []
  } catch (e) {
    suggestions.value = []
  } finally {
    isLoading.value = false
  }
}, 200)

// 监听输入
watch(keyword, (value) => {
  selectedIndex.value = -1
  fetchSuggestions(value)
})

// 执行搜索
const handleSearch = () => {
  const value = keyword.value.trim()
  if (!value) return
  
  emit('search', value)
  router.push({ path: '/search', query: { q: value } })
  showDropdown.value = false
}

// 选择建议
const selectSuggestion = async (suggestion) => {
  if (typeof suggestion === 'string') {
    keyword.value = suggestion
    handleSearch()
  } else {
    // 记录本地访问（SmartQuickAccess）
    trackWebsiteVisit(suggestion)
    
    // 调用服务端 API 增加点击数
    try {
      await clickWebsite(suggestion.id)
    } catch (e) {
      // 忽略错误
    }
    
    // 直接跳转到网站
    window.open(suggestion.url, '_blank')
    showDropdown.value = false
  }
}

// 键盘导航
const handleKeydown = (e) => {
  const items = [...suggestions.value, ...hotKeywords.value]
  
  switch (e.key) {
    case 'ArrowDown':
      e.preventDefault()
      selectedIndex.value = Math.min(selectedIndex.value + 1, items.length - 1)
      break
    case 'ArrowUp':
      e.preventDefault()
      selectedIndex.value = Math.max(selectedIndex.value - 1, -1)
      break
    case 'Enter':
      if (selectedIndex.value >= 0 && selectedIndex.value < items.length) {
        selectSuggestion(items[selectedIndex.value])
      } else {
        handleSearch()
      }
      break
    case 'Escape':
      showDropdown.value = false
      inputRef.value?.blur()
      break
  }
}

// 焦点处理
const handleFocus = () => {
  isFocused.value = true
  showDropdown.value = true
  emit('focus')
}

const handleBlur = () => {
  // 延迟关闭以允许点击下拉项
  setTimeout(() => {
    isFocused.value = false
    showDropdown.value = false
    emit('blur')
  }, 150)
}

// 清空输入
const clearInput = () => {
  keyword.value = ''
  suggestions.value = []
  inputRef.value?.focus()
}

// 快捷键 Cmd/Ctrl + K
const handleGlobalKeydown = (e) => {
  if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
    e.preventDefault()
    inputRef.value?.focus()
  }
}

onMounted(() => {
  window.addEventListener('keydown', handleGlobalKeydown)
})

onUnmounted(() => {
  window.removeEventListener('keydown', handleGlobalKeydown)
})
</script>

<template>
  <div 
    class="search-box"
    :class="[`size-${size}`, { 'is-focused': isFocused }]"
  >
    <!-- 搜索输入框 -->
    <div class="search-input-wrapper">
      <el-icon class="search-icon"><Search /></el-icon>
      
      <input
        ref="inputRef"
        v-model="keyword"
        type="text"
        class="search-input"
        :placeholder="placeholder"
        @focus="handleFocus"
        @blur="handleBlur"
        @keydown="handleKeydown"
      />
      
      <!-- 清空按钮 -->
      <button 
        v-if="keyword" 
        class="clear-btn"
        @mousedown.prevent="clearInput"
      >
        <el-icon><Close /></el-icon>
      </button>
      
      <!-- 快捷键提示 -->
      <kbd v-if="!isFocused && !keyword" class="shortcut-hint">
        <span>⌘</span>K
      </kbd>
    </div>
    
    <!-- 下拉建议 -->
    <transition name="dropdown">
      <div 
        v-if="showDropdown && (suggestions.length > 0 || hotKeywords.length > 0 || isLoading)"
        class="search-dropdown"
      >
        <!-- 加载状态 -->
        <div v-if="isLoading" class="loading-state">
          <div class="loading-spinner"></div>
          <span>搜索中...</span>
        </div>
        
        <!-- 搜索建议 -->
        <div v-if="suggestions.length > 0" class="dropdown-section">
          <div class="section-title">搜索建议</div>
          <div
            v-for="(item, index) in suggestions"
            :key="item.id"
            class="dropdown-item"
            :class="{ 'is-selected': selectedIndex === index }"
            @mousedown.prevent="selectSuggestion(item)"
          >
            <div class="item-icon" v-if="item.icon">
              <img :src="item.icon" :alt="item.name" />
            </div>
            <div class="item-icon item-initial" v-else>
              {{ item.name?.charAt(0) }}
            </div>
            <div class="item-info">
              <span class="item-name">{{ item.name }}</span>
              <span class="item-url">{{ item.url }}</span>
            </div>
            <el-icon class="item-arrow"><Right /></el-icon>
          </div>
        </div>
        
        <!-- 热门搜索 -->
        <div v-if="hotKeywords.length > 0 && !keyword" class="dropdown-section">
          <div class="section-title">热门搜索</div>
          <div class="hot-keywords">
            <button
              v-for="(kw, index) in hotKeywords"
              :key="kw"
              class="hot-keyword"
              :class="{ 'is-selected': selectedIndex === suggestions.length + index }"
              @mousedown.prevent="selectSuggestion(kw)"
            >
              {{ kw }}
            </button>
          </div>
        </div>
      </div>
    </transition>
  </div>
</template>

<style lang="scss" scoped>
.search-box {
  position: relative;
  width: 100%;
  max-width: 560px;
}

.search-input-wrapper {
  position: relative;
  display: flex;
  align-items: center;
  background: var(--glass-bg);
  backdrop-filter: blur(20px);
  -webkit-backdrop-filter: blur(20px);
  border: 1px solid var(--glass-border);
  border-radius: 16px;
  padding: 0 1rem;
  transition: all 0.3s ease;
  
  .is-focused & {
    background: var(--card-bg);
    border-color: var(--border-primary);
    box-shadow: var(--shadow-lg);
  }
}

.search-icon {
  color: var(--text-tertiary);
  font-size: 18px;
  flex-shrink: 0;
}

.search-input {
  flex: 1;
  padding: 0.875rem 0.75rem;
  font-size: 0.9375rem;
  color: var(--text-primary);
  background: transparent;
  
  &::placeholder {
    color: var(--text-tertiary);
  }
}

.clear-btn {
  width: 24px;
  height: 24px;
  border-radius: 6px;
  color: var(--text-tertiary);
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.15s ease;
  
  &:hover {
    background: var(--bg-tertiary);
    color: var(--text-primary);
  }
}

.shortcut-hint {
  display: flex;
  align-items: center;
  gap: 2px;
  padding: 4px 8px;
  background: var(--bg-tertiary);
  border-radius: 6px;
  font-size: 0.75rem;
  font-family: inherit;
  color: var(--text-tertiary);
  border: 1px solid var(--border-primary);
  
  span {
    font-size: 0.875rem;
  }
}

// 下拉框
.search-dropdown {
  position: absolute;
  top: calc(100% + 8px);
  left: 0;
  right: 0;
  background: var(--card-bg);
  border: 1px solid var(--border-primary);
  border-radius: 16px;
  box-shadow: var(--shadow-xl);
  overflow: hidden;
  z-index: 100;
}

.dropdown-section {
  padding: 0.75rem;
  
  &:not(:last-child) {
    border-bottom: 1px solid var(--border-secondary);
  }
}

.section-title {
  font-size: 0.75rem;
  font-weight: 600;
  color: var(--text-tertiary);
  text-transform: uppercase;
  letter-spacing: 0.5px;
  margin-bottom: 0.5rem;
  padding: 0 0.5rem;
}

.dropdown-item {
  display: flex;
  align-items: center;
  gap: 0.75rem;
  padding: 0.625rem 0.5rem;
  border-radius: 10px;
  cursor: pointer;
  transition: all 0.15s ease;
  
  &:hover,
  &.is-selected {
    background: var(--bg-tertiary);
  }
  
  .item-icon {
    width: 32px;
    height: 32px;
    border-radius: 8px;
    overflow: hidden;
    flex-shrink: 0;
    
    img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }
    
    &.item-initial {
      background: var(--accent);
      color: white;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 0.875rem;
      font-weight: 600;
    }
  }
  
  .item-info {
    flex: 1;
    min-width: 0;
    display: flex;
    flex-direction: column;
    
    .item-name {
      font-size: 0.875rem;
      font-weight: 500;
      color: var(--text-primary);
    }
    
    .item-url {
      font-size: 0.75rem;
      color: var(--text-tertiary);
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
  }
  
  .item-arrow {
    color: var(--text-tertiary);
    opacity: 0;
    transition: opacity 0.15s ease;
  }
  
  &:hover .item-arrow,
  &.is-selected .item-arrow {
    opacity: 1;
  }
}

.hot-keywords {
  display: flex;
  flex-wrap: wrap;
  gap: 0.5rem;
}

.hot-keyword {
  padding: 0.375rem 0.75rem;
  font-size: 0.8125rem;
  color: var(--text-secondary);
  background: var(--bg-tertiary);
  border-radius: 8px;
  transition: all 0.15s ease;
  
  &:hover,
  &.is-selected {
    background: var(--accent-light);
    color: var(--accent);
  }
}

// 加载状态
.loading-state {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.5rem;
  padding: 1.5rem;
  color: var(--text-tertiary);
  font-size: 0.875rem;
  
  .loading-spinner {
    width: 16px;
    height: 16px;
    border: 2px solid var(--border-primary);
    border-top-color: var(--accent);
    border-radius: 50%;
    animation: spin 0.8s linear infinite;
  }
}

@keyframes spin {
  to {
    transform: rotate(360deg);
  }
}

// 尺寸变体
.size-large {
  .search-input-wrapper {
    border-radius: 20px;
    padding: 0 1.25rem;
  }
  
  .search-input {
    padding: 1rem 0.875rem;
    font-size: 1rem;
  }
  
  .search-icon {
    font-size: 20px;
  }
}

// 动画
.dropdown-enter-active,
.dropdown-leave-active {
  transition: all 0.2s ease;
}

.dropdown-enter-from,
.dropdown-leave-to {
  opacity: 0;
  transform: translateY(-8px);
}
</style>
