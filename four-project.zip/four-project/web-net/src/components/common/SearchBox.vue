<script setup>
import { ref, computed, watch, onMounted, onUnmounted } from 'vue'
import { useRouter } from 'vue-router'
import { useStore } from 'vuex'
import { search, clickWebsite } from '@/api'
import { debounce, trackWebsiteVisit } from '@/utils/helpers'
import { ElMessage } from 'element-plus'

const props = defineProps({
  placeholder: {
    type: String,
    default: '搜索网站、人员... (⌘K)'
  },
  size: {
    type: String,
    default: 'normal'
  }
})

const emit = defineEmits(['search', 'focus', 'blur'])

const router = useRouter()
const store = useStore()
const inputRef = ref(null)
const keyword = ref('')
const isFocused = ref(false)
const showDropdown = ref(false)
const selectedIndex = ref(-1)
const isLoading = ref(false)

// 搜索结果
const websites = ref([])
const employees = ref([])

// 组合结果
const allResults = computed(() => {
  const results = []
  
  websites.value.forEach(site => {
    results.push({ type: 'website', data: site })
  })
  
  employees.value.forEach(emp => {
    results.push({ type: 'employee', data: emp })
  })
  
  return results
})

// 统计
const counts = computed(() => ({
  websites: websites.value.length,
  employees: employees.value.length,
  total: websites.value.length + employees.value.length
}))

// 搜索函数 - 使用与 CommandPalette 相同的 API
const doSearch = debounce(async (value) => {
  if (!value.trim()) {
    websites.value = []
    employees.value = []
    isLoading.value = false
    return
  }
  
  isLoading.value = true
  
  try {
    // 调用统一搜索接口，支持拼音搜索
    const results = await search(value, 15)
    
    // 正确解析后端返回的数据结构: { websites: [], employees: [], files: [] }
    websites.value = results?.websites || []
    employees.value = results?.employees || []
  } catch (e) {
    console.error('Search failed:', e)
    websites.value = []
    employees.value = []
  } finally {
    isLoading.value = false
  }
}, 200)

// 监听输入
watch(keyword, (value) => {
  selectedIndex.value = -1
  doSearch(value)
})

// 选择结果
const selectResult = async (item) => {
  if (item.type === 'website') {
    // 记录本地访问（SmartQuickAccess）
    trackWebsiteVisit(item.data)
    
    // 调用服务端 API 增加点击数
    try {
      await clickWebsite(item.data.id)
    } catch (e) {
      // 忽略错误
    }
    
    // 打开链接
    window.open(item.data.url || item.data.custom_url, '_blank')
  } else if (item.type === 'employee') {
    // 跳转到人员所属科室页面
    if (item.data.department_id) {
      router.push(`/department/${item.data.department_id}`)
    }
  }
  
  // 关闭下拉框
  showDropdown.value = false
  keyword.value = ''
}

// 添加到工作台
const addToWorkspace = async (website, event) => {
  // 阻止事件冒泡，防止触发 selectResult
  event?.stopPropagation()
  
  try {
    await store.dispatch('addToWorkspace', { website_id: website.id })
    ElMessage.success(`已将 "${website.name}" 添加到工作台`)
  } catch (e) {
    ElMessage.error(e.message || '添加失败')
  }
}

// 检查网站是否已在工作台
const isInWorkspace = (websiteId) => {
  const workspace = store.state.workspace || []
  return workspace.some(item => item.website_id === websiteId)
}

// 键盘导航
const handleKeydown = (e) => {
  const total = allResults.value.length
  
  switch (e.key) {
    case 'ArrowDown':
      e.preventDefault()
      selectedIndex.value = Math.min(selectedIndex.value + 1, total - 1)
      scrollToSelected()
      break
    case 'ArrowUp':
      e.preventDefault()
      selectedIndex.value = Math.max(selectedIndex.value - 1, -1)
      scrollToSelected()
      break
    case 'Enter':
      e.preventDefault()
      if (selectedIndex.value >= 0 && allResults.value[selectedIndex.value]) {
        selectResult(allResults.value[selectedIndex.value])
      }
      break
    case 'Escape':
      showDropdown.value = false
      inputRef.value?.blur()
      break
  }
}

// 滚动到选中项
const scrollToSelected = () => {
  setTimeout(() => {
    const selected = document.querySelector('.search-dropdown .dropdown-item.is-selected')
    selected?.scrollIntoView({ block: 'nearest', behavior: 'smooth' })
  }, 0)
}

// 焦点处理
const handleFocus = () => {
  isFocused.value = true
  showDropdown.value = true
  emit('focus')
}

const handleBlur = () => {
  // 延迟关闭以允许点击下拉项
  setTimeout(() => {
    isFocused.value = false
    showDropdown.value = false
    emit('blur')
  }, 200)
}

// 清空输入
const clearInput = () => {
  keyword.value = ''
  websites.value = []
  employees.value = []
  inputRef.value?.focus()
}

// 快捷键 Cmd/Ctrl + K（触发全局命令面板，这里不处理）
const handleGlobalKeydown = (e) => {
  // 留空，全局快捷键由 CommandPalette 处理
}

// 首字母
const getInitial = (name) => (name || '?').charAt(0).toUpperCase()

// 颜色
const getBgColor = (name) => {
  const colors = ['#3B82F6', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6', '#EC4899', '#06B6D4', '#84CC16']
  let hash = 0
  for (let i = 0; i < (name || '').length; i++) {
    hash = name.charCodeAt(i) + ((hash << 5) - hash)
  }
  return colors[Math.abs(hash) % colors.length]
}

// 高亮关键词
const highlightKeyword = (text, kw) => {
  if (!text || !kw) return text
  const regex = new RegExp(`(${kw.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi')
  return text.replace(regex, '<mark>$1</mark>')
}

onMounted(() => {
  window.addEventListener('keydown', handleGlobalKeydown)
})

onUnmounted(() => {
  window.removeEventListener('keydown', handleGlobalKeydown)
})
</script>

<template>
  <div 
    class="search-box"
    :class="[`size-${size}`, { 'is-focused': isFocused }]"
  >
    <!-- 搜索输入框 -->
    <div class="search-input-wrapper">
      <el-icon class="search-icon"><Search /></el-icon>
      
      <input
        ref="inputRef"
        v-model="keyword"
        type="text"
        class="search-input"
        :placeholder="placeholder"
        @focus="handleFocus"
        @blur="handleBlur"
        @keydown="handleKeydown"
      />
      
      <!-- 清空按钮 -->
      <button 
        v-if="keyword" 
        class="clear-btn"
        @mousedown.prevent="clearInput"
      >
        <el-icon><Close /></el-icon>
      </button>
      
      <!-- 快捷键提示 -->
      <kbd v-if="!isFocused && !keyword" class="shortcut-hint">
        <span>⌘</span>K
      </kbd>
    </div>
    
    <!-- 下拉结果 -->
    <transition name="dropdown">
      <div 
        v-if="showDropdown && (keyword || isLoading)"
        class="search-dropdown"
      >
        <!-- 加载状态 -->
        <div v-if="isLoading" class="loading-state">
          <div class="loading-spinner"></div>
          <span>搜索中...</span>
        </div>
        
        <!-- 空状态 -->
        <div v-else-if="keyword && allResults.length === 0" class="empty-state">
          <el-icon><Search /></el-icon>
          <span>未找到 "{{ keyword }}" 相关结果</span>
        </div>
        
        <!-- 搜索结果 -->
        <template v-else>
          <!-- 网站结果 -->
          <div v-if="websites.length > 0" class="dropdown-section">
            <div class="section-title">
              <el-icon><Link /></el-icon>
              <span>应用</span>
              <span class="count">{{ counts.websites }}</span>
            </div>
            <div
              v-for="(site, index) in websites"
              :key="`website-${site.id}`"
              class="dropdown-item"
              :class="{ 'is-selected': selectedIndex === index }"
              @mousedown.prevent="selectResult({ type: 'website', data: site })"
              @mouseenter="selectedIndex = index"
            >
              <div class="item-icon" :style="{ backgroundColor: getBgColor(site.name) }">
                <img v-if="site.icon" :src="site.icon" :alt="site.name" @error="$event.target.style.display = 'none'" />
                <span v-else>{{ getInitial(site.name) }}</span>
              </div>
              <div class="item-info">
                <span class="item-name" v-html="highlightKeyword(site.name, keyword)"></span>
                <span class="item-url">{{ site.url }}</span>
              </div>
              <!-- 添加到工作台按钮 -->
              <button 
                v-if="!isInWorkspace(site.id)"
                class="add-workspace-btn"
                title="添加到工作台"
                @mousedown.prevent.stop="addToWorkspace(site, $event)"
              >
                <el-icon><Plus /></el-icon>
              </button>
              <span v-else class="in-workspace-badge">已添加</span>
              <div class="item-type website">应用</div>
            </div>
          </div>
          
          <!-- 员工结果 -->
          <div v-if="employees.length > 0" class="dropdown-section">
            <div class="section-title">
              <el-icon><User /></el-icon>
              <span>人员</span>
              <span class="count">{{ counts.employees }}</span>
            </div>
            <div
              v-for="(emp, index) in employees"
              :key="`employee-${emp.id}`"
              class="dropdown-item"
              :class="{ 'is-selected': selectedIndex === websites.length + index }"
              @mousedown.prevent="selectResult({ type: 'employee', data: emp })"
              @mouseenter="selectedIndex = websites.length + index"
            >
              <div class="item-icon employee" :style="{ backgroundColor: getBgColor(emp.name) }">
                <el-icon><User /></el-icon>
              </div>
              <div class="item-info">
                <span class="item-name" v-html="highlightKeyword(emp.name, keyword)"></span>
                <span class="item-url">
                  {{ emp.position }}
                  <template v-if="emp.phone"> · {{ emp.phone }}</template>
                </span>
              </div>
              <div class="item-type employee">人员</div>
            </div>
          </div>
        </template>
        
        <!-- 底部提示 -->
        <div v-if="allResults.length > 0" class="dropdown-footer">
          <span><kbd>↑</kbd><kbd>↓</kbd> 导航</span>
          <span><kbd>Enter</kbd> 打开</span>
          <span><kbd>Esc</kbd> 关闭</span>
        </div>
      </div>
    </transition>
  </div>
</template>

<style lang="scss" scoped>
.search-box {
  position: relative;
  width: 100%;
  max-width: 560px;
}

.search-input-wrapper {
  position: relative;
  display: flex;
  align-items: center;
  background: var(--glass-bg);
  backdrop-filter: blur(20px);
  -webkit-backdrop-filter: blur(20px);
  border: 1px solid var(--glass-border);
  border-radius: 16px;
  padding: 0 1rem;
  transition: all 0.3s ease;
  
  .is-focused & {
    background: var(--card-bg);
    border-color: var(--border-primary);
    box-shadow: var(--shadow-lg);
  }
}

.search-icon {
  color: var(--text-tertiary);
  font-size: 18px;
  flex-shrink: 0;
}

.search-input {
  flex: 1;
  padding: 0.875rem 0.75rem;
  font-size: 0.9375rem;
  color: var(--text-primary);
  background: transparent;
  
  &::placeholder {
    color: var(--text-tertiary);
  }
}

.clear-btn {
  width: 24px;
  height: 24px;
  border-radius: 6px;
  color: var(--text-tertiary);
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.15s ease;
  
  &:hover {
    background: var(--bg-tertiary);
    color: var(--text-primary);
  }
}

.shortcut-hint {
  display: flex;
  align-items: center;
  gap: 2px;
  padding: 4px 8px;
  background: var(--bg-tertiary);
  border-radius: 6px;
  font-size: 0.75rem;
  font-family: inherit;
  color: var(--text-tertiary);
  border: 1px solid var(--border-primary);
  
  span {
    font-size: 0.875rem;
  }
}

// 下拉框
.search-dropdown {
  position: absolute;
  top: calc(100% + 8px);
  left: 0;
  right: 0;
  background: var(--card-bg);
  border: 1px solid var(--border-primary);
  border-radius: 16px;
  box-shadow: var(--shadow-xl);
  overflow: hidden;
  z-index: 100;
  max-height: 420px;
  overflow-y: auto;
}

.dropdown-section {
  padding: 0.625rem;
  
  &:not(:last-child) {
    border-bottom: 1px solid var(--border-secondary);
  }
}

.section-title {
  display: flex;
  align-items: center;
  gap: 0.375rem;
  font-size: 0.6875rem;
  font-weight: 600;
  color: var(--text-tertiary);
  text-transform: uppercase;
  letter-spacing: 0.5px;
  margin-bottom: 0.375rem;
  padding: 0 0.5rem;
  
  .el-icon {
    font-size: 12px;
  }
  
  .count {
    margin-left: auto;
    padding: 0 4px;
    background: var(--bg-tertiary);
    border-radius: 4px;
  }
}

.dropdown-item {
  display: flex;
  align-items: center;
  gap: 0.75rem;
  padding: 0.5rem;
  border-radius: 10px;
  cursor: pointer;
  transition: all 0.15s ease;
  
  &:hover,
  &.is-selected {
    background: var(--bg-tertiary);
  }
  
  &.is-selected {
    background: var(--accent-light);
    
    .item-name {
      color: var(--accent);
    }
  }
}

.item-icon {
  width: 36px;
  height: 36px;
  border-radius: 10px;
  overflow: hidden;
  flex-shrink: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  font-weight: 700;
  font-size: 0.875rem;
  
  img {
    width: 100%;
    height: 100%;
    object-fit: cover;
  }
  
  &.employee {
    .el-icon {
      font-size: 16px;
    }
  }
}

.item-info {
  flex: 1;
  min-width: 0;
  display: flex;
  flex-direction: column;
  gap: 0.125rem;
  
  .item-name {
    font-size: 0.875rem;
    font-weight: 500;
    color: var(--text-primary);
    
    :deep(mark) {
      background: var(--accent-light);
      color: var(--accent);
      padding: 0 2px;
      border-radius: 2px;
    }
  }
  
  .item-url {
    font-size: 0.75rem;
    color: var(--text-tertiary);
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
}

.item-type {
  font-size: 0.625rem;
  font-weight: 500;
  padding: 0.2rem 0.4rem;
  border-radius: 4px;
  background: var(--bg-tertiary);
  color: var(--text-tertiary);
  flex-shrink: 0;
  
  &.website {
    background: rgba(59, 130, 246, 0.1);
    color: #3b82f6;
  }
  
  &.employee {
    background: rgba(16, 185, 129, 0.1);
    color: #10b981;
  }
}

// 添加到工作台按钮
.add-workspace-btn {
  width: 28px;
  height: 28px;
  border-radius: 6px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: var(--text-tertiary);
  background: var(--bg-tertiary);
  border: 1px solid var(--border-secondary);
  transition: all 0.15s ease;
  flex-shrink: 0;
  opacity: 0;
  
  .dropdown-item:hover &,
  .dropdown-item.is-selected & {
    opacity: 1;
  }
  
  &:hover {
    color: white;
    background: var(--accent);
    border-color: var(--accent);
    transform: scale(1.05);
  }
  
  .el-icon {
    font-size: 14px;
  }
}

// 已添加到工作台标记
.in-workspace-badge {
  font-size: 0.625rem;
  color: var(--text-tertiary);
  padding: 0.2rem 0.4rem;
  background: var(--bg-tertiary);
  border-radius: 4px;
  flex-shrink: 0;
}

// 加载状态
.loading-state {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.5rem;
  padding: 2rem;
  color: var(--text-tertiary);
  font-size: 0.875rem;
  
  .loading-spinner {
    width: 16px;
    height: 16px;
    border: 2px solid var(--border-primary);
    border-top-color: var(--accent);
    border-radius: 50%;
    animation: spin 0.8s linear infinite;
  }
}

// 空状态
.empty-state {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 0.5rem;
  padding: 2rem;
  color: var(--text-tertiary);
  font-size: 0.875rem;
  
  .el-icon {
    font-size: 24px;
    opacity: 0.5;
  }
}

// 底部提示
.dropdown-footer {
  display: flex;
  justify-content: center;
  gap: 1rem;
  padding: 0.5rem;
  border-top: 1px solid var(--border-secondary);
  background: var(--bg-tertiary);
  font-size: 0.6875rem;
  color: var(--text-tertiary);
  
  span {
    display: flex;
    align-items: center;
    gap: 0.25rem;
  }
  
  kbd {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-width: 16px;
    height: 16px;
    padding: 0 4px;
    font-family: inherit;
    font-size: 0.625rem;
    font-weight: 600;
    color: var(--text-tertiary);
    background: var(--card-bg);
    border: 1px solid var(--border-primary);
    border-radius: 3px;
  }
}

@keyframes spin {
  to {
    transform: rotate(360deg);
  }
}

// 尺寸变体
.size-large {
  .search-input-wrapper {
    border-radius: 20px;
    padding: 0 1.25rem;
  }
  
  .search-input {
    padding: 1rem 0.875rem;
    font-size: 1rem;
  }
  
  .search-icon {
    font-size: 20px;
  }
}

// 动画
.dropdown-enter-active,
.dropdown-leave-active {
  transition: all 0.2s ease;
}

.dropdown-enter-from,
.dropdown-leave-to {
  opacity: 0;
  transform: translateY(-8px);
}
</style>
