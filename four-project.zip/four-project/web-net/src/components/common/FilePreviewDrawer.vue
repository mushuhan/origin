<script setup>
import { ref, computed, watch } from 'vue'
import { gsap } from 'gsap'

const props = defineProps({
  visible: {
    type: Boolean,
    default: false
  },
  file: {
    type: Object,
    default: null
  },
  data: {
    type: Object,
    default: null
  },
  loading: {
    type: Boolean,
    default: false
  }
})

const emit = defineEmits(['close', 'go-dashboard', 'download', 'delete'])

// 抽屉引用
const drawerRef = ref(null)
const overlayRef = ref(null)

// 计算属性
const previewHeaders = computed(() => props.data?.preview?.headers || [])
const previewRows = computed(() => props.data?.preview?.rows || [])
const stats = computed(() => props.data?.stats || {})
const fileInfo = computed(() => props.data?.file || props.file)

// 格式化文件类型标签
const fileTypeLabel = computed(() => {
  const labels = {
    csv: 'CSV 文件',
    xlsx: 'Excel 文件',
    xls: 'Excel 文件',
    parquet: 'Parquet 文件'
  }
  return labels[props.file?.file_type] || '数据文件'
})

// 格式化日期
const formatDate = (dateStr) => {
  if (!dateStr) return '-'
  return new Date(dateStr).toLocaleString('zh-CN', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit'
  })
}

// 动画效果
watch(() => props.visible, (newVal) => {
  if (newVal) {
    // 打开动画
    gsap.fromTo(overlayRef.value, 
      { opacity: 0 },
      { opacity: 1, duration: 0.2 }
    )
    gsap.fromTo(drawerRef.value,
      { x: '100%' },
      { x: '0%', duration: 0.3, ease: 'power2.out' }
    )
  }
})

// 关闭抽屉
const handleClose = () => {
  gsap.to(drawerRef.value, {
    x: '100%',
    duration: 0.25,
    ease: 'power2.in',
    onComplete: () => emit('close')
  })
  gsap.to(overlayRef.value, {
    opacity: 0,
    duration: 0.2
  })
}

// 点击遮罩关闭
const handleOverlayClick = (e) => {
  if (e.target === overlayRef.value) {
    handleClose()
  }
}

// 操作处理
const handleGoDashboard = () => {
  emit('go-dashboard', props.file)
  handleClose()
}

const handleDownload = () => {
  emit('download', props.file)
}

const handleDelete = () => {
  emit('delete', props.file)
}
</script>

<template>
  <Teleport to="body">
    <div 
      v-if="visible" 
      ref="overlayRef"
      class="drawer-overlay"
      @click="handleOverlayClick"
    >
      <aside ref="drawerRef" class="preview-drawer">
        <!-- 头部 -->
        <header class="drawer-header">
          <div class="header-info">
            <span class="file-type-badge" :class="`type-${file?.file_type}`">
              {{ fileTypeLabel }}
            </span>
            <h3 class="file-title">{{ file?.filename }}</h3>
          </div>
          <button class="close-btn" @click="handleClose">
            <el-icon><Close /></el-icon>
          </button>
        </header>

        <!-- 内容区 -->
        <div class="drawer-body">
          <!-- 加载状态 -->
          <div v-if="loading" class="loading-state">
            <el-icon class="is-loading"><Loading /></el-icon>
            <span>加载预览中...</span>
          </div>

          <template v-else-if="data">
            <!-- 文件摘要 -->
            <section class="info-section">
              <h4 class="section-title">文件信息</h4>
              <div class="info-grid">
                <div class="info-item">
                  <span class="info-label">文件大小</span>
                  <span class="info-value">{{ fileInfo?.file_size_formatted }}</span>
                </div>
                <div class="info-item">
                  <span class="info-label">数据行数</span>
                  <span class="info-value">{{ stats.total_rows?.toLocaleString() }} 行</span>
                </div>
                <div class="info-item">
                  <span class="info-label">数据列数</span>
                  <span class="info-value">{{ stats.total_columns }} 列</span>
                </div>
                <div class="info-item">
                  <span class="info-label">修改时间</span>
                  <span class="info-value">{{ formatDate(fileInfo?.updated_at) }}</span>
                </div>
              </div>
            </section>

            <!-- 列信息 -->
            <section class="info-section">
              <h4 class="section-title">列信息</h4>
              <div class="columns-list">
                <div 
                  v-for="(col, index) in previewHeaders" 
                  :key="index"
                  class="column-item"
                >
                  <span class="column-name">{{ col }}</span>
                  <span class="column-type">{{ stats.column_types?.[col] || 'object' }}</span>
                </div>
              </div>
            </section>

            <!-- 数据预览 -->
            <section class="preview-section">
              <div class="section-header">
                <h4 class="section-title">数据预览</h4>
                <span class="preview-count">前 {{ stats.preview_rows }} 行</span>
              </div>
              
              <div class="preview-table-wrapper">
                <table class="preview-table">
                  <thead>
                    <tr>
                      <th class="row-index">#</th>
                      <th v-for="header in previewHeaders" :key="header">
                        {{ header }}
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr v-for="(row, index) in previewRows" :key="index">
                      <td class="row-index">{{ index + 1 }}</td>
                      <td v-for="header in previewHeaders" :key="header">
                        {{ row[header] }}
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </section>
          </template>

          <!-- 无数据状态 -->
          <div v-else class="empty-state">
            <el-icon><Warning /></el-icon>
            <span>无法加载预览</span>
          </div>
        </div>

        <!-- 底部操作按钮 -->
        <footer class="drawer-footer">
          <button class="footer-btn primary" @click="handleGoDashboard">
            <el-icon><DataAnalysis /></el-icon>
            去画图
          </button>
          <button class="footer-btn" @click="handleDownload">
            <el-icon><Download /></el-icon>
            下载
          </button>
          <button class="footer-btn danger" @click="handleDelete">
            <el-icon><Delete /></el-icon>
            删除
          </button>
        </footer>
      </aside>
    </div>
  </Teleport>
</template>

<style lang="scss" scoped>
.drawer-overlay {
  position: fixed;
  inset: 0;
  background: rgba(0, 0, 0, 0.3);
  z-index: 1000;
  backdrop-filter: blur(2px);
}

.preview-drawer {
  position: absolute;
  top: 0;
  right: 0;
  bottom: 0;
  width: 560px;
  max-width: 90vw;
  background: #ffffff;
  display: flex;
  flex-direction: column;
  box-shadow: -4px 0 24px rgba(0, 0, 0, 0.1);
  
  :root.dark & {
    background: var(--card-bg);
  }
}

// 头部
.drawer-header {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  padding: 1.25rem 1.5rem;
  border-bottom: 1px solid #e5e7eb;
  
  :root.dark & {
    border-bottom-color: var(--border-secondary);
  }
}

.header-info {
  flex: 1;
  min-width: 0;
}

.file-type-badge {
  display: inline-block;
  padding: 0.25rem 0.625rem;
  font-size: 0.6875rem;
  font-weight: 500;
  border-radius: 4px;
  margin-bottom: 0.5rem;
  
  &.type-csv {
    background: rgba(34, 197, 94, 0.1);
    color: #16a34a;
  }
  
  &.type-xlsx, &.type-xls {
    background: rgba(22, 163, 74, 0.1);
    color: #15803d;
  }
  
  &.type-parquet {
    background: rgba(99, 102, 241, 0.1);
    color: #4f46e5;
  }
}

.file-title {
  font-size: 1rem;
  font-weight: 600;
  color: #111827;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  
  :root.dark & {
    color: var(--text-primary);
  }
}

.close-btn {
  width: 32px;
  height: 32px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 8px;
  color: #9ca3af;
  transition: all 0.15s ease;
  flex-shrink: 0;
  margin-left: 1rem;
  
  &:hover {
    background: #f3f4f6;
    color: #374151;
  }
  
  :root.dark & {
    color: var(--text-tertiary);
    
    &:hover {
      background: var(--bg-tertiary);
      color: var(--text-primary);
    }
  }
}

// 内容区
.drawer-body {
  flex: 1;
  overflow-y: auto;
  padding: 1.25rem 1.5rem;
}

.loading-state,
.empty-state {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 3rem;
  color: var(--text-tertiary);
  
  .el-icon {
    font-size: 32px;
    margin-bottom: 0.75rem;
  }
}

// 信息区块
.info-section {
  margin-bottom: 1.5rem;
}

.section-title {
  font-size: 0.8125rem;
  font-weight: 600;
  color: #111827;
  margin-bottom: 0.75rem;
  
  :root.dark & {
    color: var(--text-primary);
  }
}

.section-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 0.75rem;
}

.preview-count {
  font-size: 0.75rem;
  color: var(--text-tertiary);
}

.info-grid {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 0.75rem;
}

.info-item {
  background: #f9fafb;
  padding: 0.75rem 1rem;
  border-radius: 8px;
  
  :root.dark & {
    background: var(--bg-tertiary);
  }
}

.info-label {
  display: block;
  font-size: 0.6875rem;
  color: #6b7280;
  margin-bottom: 0.25rem;
  
  :root.dark & {
    color: var(--text-tertiary);
  }
}

.info-value {
  font-size: 0.875rem;
  color: #111827;
  font-weight: 500;
  
  :root.dark & {
    color: var(--text-primary);
  }
}

// 列信息
.columns-list {
  display: flex;
  flex-wrap: wrap;
  gap: 0.5rem;
}

.column-item {
  display: inline-flex;
  align-items: center;
  gap: 0.375rem;
  padding: 0.375rem 0.625rem;
  background: #f3f4f6;
  border-radius: 6px;
  font-size: 0.75rem;
  
  :root.dark & {
    background: var(--bg-tertiary);
  }
}

.column-name {
  color: #111827;
  font-weight: 500;
  
  :root.dark & {
    color: var(--text-primary);
  }
}

.column-type {
  color: #6b7280;
  
  :root.dark & {
    color: var(--text-tertiary);
  }
  
  &::before {
    content: '·';
    margin-right: 0.375rem;
  }
}

// 数据预览表格
.preview-section {
  margin-bottom: 1.5rem;
}

.preview-table-wrapper {
  overflow-x: auto;
  border: 1px solid #e5e7eb;
  border-radius: 8px;
  
  :root.dark & {
    border-color: var(--border-secondary);
  }
}

.preview-table {
  width: 100%;
  border-collapse: collapse;
  font-size: 0.75rem;
  
  th, td {
    padding: 0.5rem 0.75rem;
    text-align: left;
    border-bottom: 1px solid #e5e7eb;
    white-space: nowrap;
    max-width: 200px;
    overflow: hidden;
    text-overflow: ellipsis;
    
    :root.dark & {
      border-bottom-color: var(--border-secondary);
    }
  }
  
  th {
    background: #f9fafb;
    font-weight: 600;
    color: #6b7280;
    position: sticky;
    top: 0;
    
    :root.dark & {
      background: var(--bg-tertiary);
      color: var(--text-secondary);
    }
  }
  
  td {
    color: #374151;
    
    :root.dark & {
      color: var(--text-primary);
    }
  }
  
  tr:last-child td {
    border-bottom: none;
  }
  
  tr:hover td {
    background: #f9fafb;
    
    :root.dark & {
      background: var(--bg-tertiary);
    }
  }
  
  .row-index {
    width: 40px;
    text-align: center;
    color: #9ca3af;
    background: #f9fafb;
    
    :root.dark & {
      color: var(--text-tertiary);
      background: var(--bg-tertiary);
    }
  }
}

// 底部按钮
.drawer-footer {
  display: flex;
  gap: 0.75rem;
  padding: 1rem 1.5rem;
  border-top: 1px solid #e5e7eb;
  
  :root.dark & {
    border-top-color: var(--border-secondary);
  }
}

.footer-btn {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.5rem;
  padding: 0.625rem 1rem;
  font-size: 0.8125rem;
  font-weight: 500;
  border-radius: 8px;
  background: #f3f4f6;
  color: #374151;
  transition: all 0.15s ease;
  
  :root.dark & {
    background: var(--bg-tertiary);
    color: var(--text-primary);
  }
  
  &:hover {
    background: #e5e7eb;
    
    :root.dark & {
      background: var(--border-primary);
    }
  }
  
  &.primary {
    background: #3b82f6;
    color: white;
    
    :root.dark & {
      background: var(--accent);
    }
    
    &:hover {
      opacity: 0.9;
    }
  }
  
  &.danger {
    color: #ef4444;
    
    :root.dark & {
      color: var(--error);
    }
    
    &:hover {
      background: rgba(239, 68, 68, 0.1);
    }
  }
  
  .el-icon {
    font-size: 16px;
  }
}
</style>

