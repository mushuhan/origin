<script setup>
import { ref, computed, onMounted, onUnmounted, watch } from 'vue'

const props = defineProps({
  items: {
    type: Array,
    default: () => []
  },
  autoPlay: {
    type: Boolean,
    default: true
  },
  interval: {
    type: Number,
    default: 5000
  }
})

const emit = defineEmits(['change', 'click'])

const currentIndex = ref(0)
const isHovering = ref(false)
const containerRef = ref(null)
let autoPlayTimer = null

// 可见的卡片（当前 + 左右各2张）
const visibleCards = computed(() => {
  if (props.items.length === 0) return []
  
  const result = []
  const total = props.items.length
  
  // 显示5张卡片：当前1张 + 左右各2张
  for (let i = -2; i <= 2; i++) {
    let index = (currentIndex.value + i + total) % total
    result.push({
      ...props.items[index],
      originalIndex: index,
      position: i
    })
  }
  
  return result
})

// 计算卡片样式 - 取消模糊效果
const getCardStyle = (position) => {
  const baseScale = 1
  const scaleDecrement = 0.1
  const baseOpacity = 1
  const opacityDecrement = 0.25
  const translateX = position * 200 // 水平偏移
  const translateZ = Math.abs(position) * -150 // 景深
  const rotateY = position * -5 // 轻微旋转
  
  const scale = baseScale - Math.abs(position) * scaleDecrement
  const opacity = position === 0 ? baseOpacity : baseOpacity - Math.abs(position) * opacityDecrement
  const zIndex = 10 - Math.abs(position)
  
  return {
    transform: `translateX(${translateX}px) translateZ(${translateZ}px) rotateY(${rotateY}deg) scale(${scale})`,
    opacity,
    filter: 'none', // 取消模糊效果
    zIndex,
    pointerEvents: position === 0 ? 'auto' : 'none'
  }
}

// 导航到指定索引
const goTo = (index) => {
  if (index < 0) {
    currentIndex.value = props.items.length - 1
  } else if (index >= props.items.length) {
    currentIndex.value = 0
  } else {
    currentIndex.value = index
  }
  emit('change', currentIndex.value)
}

// 上一张/下一张
const prev = () => goTo(currentIndex.value - 1)
const next = () => goTo(currentIndex.value + 1)

// 自动播放
const startAutoPlay = () => {
  if (props.autoPlay && props.items.length > 1) {
    autoPlayTimer = setInterval(next, props.interval)
  }
}

const stopAutoPlay = () => {
  if (autoPlayTimer) {
    clearInterval(autoPlayTimer)
    autoPlayTimer = null
  }
}

// 鼠标进入/离开
const handleMouseEnter = () => {
  isHovering.value = true
  stopAutoPlay()
}

const handleMouseLeave = () => {
  isHovering.value = false
  startAutoPlay()
}

// 点击卡片
const handleCardClick = (item) => {
  if (item.position === 0) {
    emit('click', item)
  } else {
    goTo(item.originalIndex)
  }
}

// 键盘导航
const handleKeydown = (e) => {
  if (e.key === 'ArrowLeft') {
    prev()
  } else if (e.key === 'ArrowRight') {
    next()
  }
}

onMounted(() => {
  startAutoPlay()
  window.addEventListener('keydown', handleKeydown)
})

onUnmounted(() => {
  stopAutoPlay()
  window.removeEventListener('keydown', handleKeydown)
})

watch(() => props.items, () => {
  currentIndex.value = 0
})
</script>

<template>
  <div 
    ref="containerRef"
    class="coverflow-carousel"
    @mouseenter="handleMouseEnter"
    @mouseleave="handleMouseLeave"
  >
    <!-- 3D舞台 -->
    <div class="carousel-stage">
      <!-- 卡片容器 -->
      <div class="cards-container">
        <div
          v-for="card in visibleCards"
          :key="card.originalIndex"
          class="carousel-card"
          :class="{ 'is-active': card.position === 0 }"
          :style="getCardStyle(card.position)"
          @click="handleCardClick(card)"
        >
          <!-- 卡片内容插槽 -->
          <slot name="card" :item="card" :isActive="card.position === 0">
            <!-- 默认卡片样式 -->
            <div class="default-card">
              <div class="card-image" v-if="card.image">
                <img :src="card.image" :alt="card.title" />
              </div>
              <div class="card-content">
                <h3 class="card-title">{{ card.title || card.name }}</h3>
                <p class="card-desc" v-if="card.description">{{ card.description }}</p>
              </div>
            </div>
          </slot>
        </div>
      </div>
      
      <!-- 悬停时显示的UI浮层 -->
      <transition name="fade-slide">
        <div v-if="isHovering" class="hover-overlay">
          <slot name="overlay">
            <!-- 默认浮层内容 -->
          </slot>
        </div>
      </transition>
    </div>
    
    <!-- 导航箭头 -->
    <button 
      class="nav-btn nav-prev"
      @click="prev"
      :disabled="items.length <= 1"
    >
      <el-icon><ArrowLeft /></el-icon>
    </button>
    <button 
      class="nav-btn nav-next"
      @click="next"
      :disabled="items.length <= 1"
    >
      <el-icon><ArrowRight /></el-icon>
    </button>
    
    <!-- 线性指示器 -->
    <div class="carousel-indicators" v-if="items.length > 1">
      <button
        v-for="(item, index) in items"
        :key="index"
        class="indicator"
        :class="{ active: index === currentIndex }"
        @click="goTo(index)"
      >
        <span class="indicator-progress" v-if="index === currentIndex && autoPlay && !isHovering"></span>
      </button>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.coverflow-carousel {
  position: relative;
  width: 100%;
  height: 400px;
  perspective: 1200px;
  overflow: hidden;
}

.carousel-stage {
  position: relative;
  width: 100%;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  transform-style: preserve-3d;
}

.cards-container {
  position: relative;
  width: 100%;
  height: 100%;
  transform-style: preserve-3d;
}

.carousel-card {
  position: absolute;
  left: 50%;
  top: 50%;
  width: 320px;
  height: 280px;
  margin-left: -160px;
  margin-top: -140px;
  background: var(--card-bg);
  border-radius: 20px;
  overflow: hidden;
  cursor: pointer;
  transition: all 0.5s cubic-bezier(0.16, 1, 0.3, 1);
  box-shadow: var(--shadow-lg);
  
  &.is-active {
    box-shadow: var(--shadow-xl);
    
    &:hover {
      transform: translateX(0) translateZ(20px) scale(1.02) !important;
    }
  }
}

.default-card {
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
  
  .card-image {
    flex: 1;
    overflow: hidden;
    
    img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }
  }
  
  .card-content {
    padding: 1.25rem;
    
    .card-title {
      font-size: 1.125rem;
      font-weight: 600;
      color: var(--text-primary);
      margin-bottom: 0.5rem;
    }
    
    .card-desc {
      font-size: 0.875rem;
      color: var(--text-secondary);
      line-height: 1.5;
      display: -webkit-box;
      -webkit-line-clamp: 2;
      -webkit-box-orient: vertical;
      overflow: hidden;
    }
  }
}

// 导航按钮
.nav-btn {
  position: absolute;
  top: 50%;
  transform: translateY(-50%);
  width: 48px;
  height: 48px;
  border-radius: 50%;
  background: var(--glass-bg);
  backdrop-filter: blur(10px);
  border: 1px solid var(--glass-border);
  color: var(--text-primary);
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.3s ease;
  z-index: 20;
  
  &:hover:not(:disabled) {
    background: var(--card-bg);
    box-shadow: var(--shadow-md);
  }
  
  &:disabled {
    opacity: 0.3;
    cursor: not-allowed;
  }
  
  .el-icon {
    font-size: 20px;
  }
}

.nav-prev {
  left: 20px;
}

.nav-next {
  right: 20px;
}

// 指示器
.carousel-indicators {
  position: absolute;
  bottom: 20px;
  left: 50%;
  transform: translateX(-50%);
  display: flex;
  gap: 8px;
  z-index: 20;
}

.indicator {
  position: relative;
  width: 32px;
  height: 4px;
  border-radius: 2px;
  background: var(--carousel-indicator);
  overflow: hidden;
  transition: all 0.3s ease;
  
  &:hover {
    background: rgba(255, 255, 255, 0.7);
  }
  
  &.active {
    background: var(--carousel-indicator-active);
    width: 48px;
  }
  
  .indicator-progress {
    position: absolute;
    left: 0;
    top: 0;
    height: 100%;
    background: var(--accent);
    animation: progress 5s linear forwards;
  }
}

@keyframes progress {
  from {
    width: 0;
  }
  to {
    width: 100%;
  }
}

// 悬停浮层
.hover-overlay {
  position: absolute;
  inset: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  background: var(--carousel-overlay);
  backdrop-filter: blur(10px);
  z-index: 15;
}

// 过渡动画
.fade-slide-enter-active,
.fade-slide-leave-active {
  transition: all 0.3s ease;
}

.fade-slide-enter-from,
.fade-slide-leave-to {
  opacity: 0;
  transform: translateY(10px);
}

// 响应式
@media (max-width: 768px) {
  .coverflow-carousel {
    height: 300px;
  }
  
  .carousel-card {
    width: 260px;
    height: 220px;
    margin-left: -130px;
    margin-top: -110px;
  }
  
  .nav-btn {
    width: 40px;
    height: 40px;
  }
}
</style>

