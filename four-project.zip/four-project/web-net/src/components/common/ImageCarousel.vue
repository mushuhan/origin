<script setup>
import { ref, computed, onMounted, onUnmounted } from 'vue'

const props = defineProps({
  images: {
    type: Array,
    default: () => []
  },
  autoPlay: {
    type: Boolean,
    default: true
  },
  interval: {
    type: Number,
    default: 5000
  },
  height: {
    type: String,
    default: '360px'
  }
})

const emit = defineEmits(['change', 'click'])

const currentIndex = ref(0)
const isHovering = ref(false)
let autoPlayTimer = null

// 当前显示的图片
const currentImage = computed(() => {
  return props.images[currentIndex.value] || null
})

// 导航到指定索引
const goTo = (index) => {
  if (index < 0) {
    currentIndex.value = props.images.length - 1
  } else if (index >= props.images.length) {
    currentIndex.value = 0
  } else {
    currentIndex.value = index
  }
  emit('change', currentIndex.value)
}

// 上一张/下一张
const prev = () => goTo(currentIndex.value - 1)
const next = () => goTo(currentIndex.value + 1)

// 自动播放
const startAutoPlay = () => {
  if (props.autoPlay && props.images.length > 1) {
    autoPlayTimer = setInterval(next, props.interval)
  }
}

const stopAutoPlay = () => {
  if (autoPlayTimer) {
    clearInterval(autoPlayTimer)
    autoPlayTimer = null
  }
}

// 鼠标进入/离开
const handleMouseEnter = () => {
  isHovering.value = true
  stopAutoPlay()
}

const handleMouseLeave = () => {
  isHovering.value = false
  startAutoPlay()
}

// 点击图片
const handleClick = () => {
  emit('click', currentImage.value)
}

onMounted(() => {
  startAutoPlay()
})

onUnmounted(() => {
  stopAutoPlay()
})
</script>

<template>
  <div 
    class="image-carousel"
    :style="{ height }"
    @mouseenter="handleMouseEnter"
    @mouseleave="handleMouseLeave"
  >
    <!-- 图片容器 -->
    <div class="carousel-viewport">
      <transition-group name="carousel-slide" tag="div" class="images-wrapper">
        <div
          v-for="(image, index) in images"
          :key="index"
          v-show="index === currentIndex"
          class="carousel-slide"
          @click="handleClick"
        >
          <img :src="image.src" :alt="image.alt || `图片 ${index + 1}`" />
          
          <!-- 图片信息叠加层 -->
          <div v-if="image.title || image.description" class="slide-overlay">
            <!-- <div class="slide-content">
              <h3 v-if="image.title" class="slide-title">{{ image.title }}</h3>
              <p v-if="image.description" class="slide-description">{{ image.description }}</p>
            </div> -->
          </div>
        </div>
      </transition-group>
    </div>
    
    <!-- 导航箭头 -->
    <button 
      v-show="images.length > 1"
      class="nav-btn nav-prev"
      @click.stop="prev"
    >
      <el-icon><ArrowLeft /></el-icon>
    </button>
    <button 
      v-show="images.length > 1"
      class="nav-btn nav-next"
      @click.stop="next"
    >
      <el-icon><ArrowRight /></el-icon>
    </button>
    
    <!-- 指示器 -->
    <div class="carousel-indicators" v-if="images.length > 1">
      <button
        v-for="(_, index) in images"
        :key="index"
        class="indicator"
        :class="{ active: index === currentIndex }"
        @click.stop="goTo(index)"
      >
        <span 
          v-if="index === currentIndex && autoPlay && !isHovering" 
          class="indicator-progress"
          :style="{ animationDuration: `${interval}ms` }"
        ></span>
      </button>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.image-carousel {
  position: relative;
  width: 100%;
  border-radius: 16px;
  overflow: hidden;
  background: var(--bg-tertiary);
}

.carousel-viewport {
  position: relative;
  width: 100%;
  height: 100%;
  overflow: hidden;
}

.images-wrapper {
  position: relative;
  width: 100%;
  height: 100%;
}

.carousel-slide {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  cursor: pointer;
  
  img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform 0.4s ease;
  }
  
  &:hover img {
    transform: scale(1.02);
  }
}

.slide-overlay {
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  padding: 3rem 2rem 2rem;
  background: linear-gradient(to top, rgba(0, 0, 0, 0.7), transparent);
}

.slide-content {
  max-width: 600px;
}

.slide-title {
  font-size: 1.5rem;
  font-weight: 700;
  color: white;
  margin-bottom: 0.5rem;
  text-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
}

.slide-description {
  font-size: 0.9375rem;
  color: rgba(255, 255, 255, 0.9);
  line-height: 1.6;
  text-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
}

// 导航按钮
.nav-btn {
  position: absolute;
  top: 50%;
  transform: translateY(-50%);
  width: 44px;
  height: 44px;
  border-radius: 50%;
  background: rgba(255, 255, 255, 0.9);
  backdrop-filter: blur(10px);
  border: none;
  color: #1f2937;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  opacity: 0;
  transition: all 0.3s ease;
  z-index: 10;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
  
  .image-carousel:hover & {
    opacity: 1;
  }
  
  &:hover {
    background: white;
    transform: translateY(-50%) scale(1.05);
  }
  
  .el-icon {
    font-size: 18px;
  }
}

.nav-prev {
  left: 16px;
}

.nav-next {
  right: 16px;
}

// 指示器
.carousel-indicators {
  position: absolute;
  bottom: 16px;
  left: 50%;
  transform: translateX(-50%);
  display: flex;
  gap: 8px;
  z-index: 10;
}

.indicator {
  position: relative;
  width: 32px;
  height: 4px;
  border-radius: 2px;
  background: rgba(255, 255, 255, 0.4);
  overflow: hidden;
  transition: all 0.3s ease;
  cursor: pointer;
  
  &:hover {
    background: rgba(255, 255, 255, 0.6);
  }
  
  &.active {
    background: rgba(255, 255, 255, 0.5);
    width: 48px;
  }
  
  .indicator-progress {
    position: absolute;
    left: 0;
    top: 0;
    height: 100%;
    background: white;
    border-radius: 2px;
    animation: progress-fill linear forwards;
  }
}

@keyframes progress-fill {
  from {
    width: 0;
  }
  to {
    width: 100%;
  }
}

// 切换动画
.carousel-slide-enter-active,
.carousel-slide-leave-active {
  transition: all 0.5s cubic-bezier(0.16, 1, 0.3, 1);
}

.carousel-slide-enter-from {
  opacity: 0;
  transform: translateX(30px);
}

.carousel-slide-leave-to {
  opacity: 0;
  transform: translateX(-30px);
}

// 响应式
@media (max-width: 768px) {
  .nav-btn {
    width: 36px;
    height: 36px;
    opacity: 1;
    background: rgba(255, 255, 255, 0.8);
  }
  
  .nav-prev {
    left: 10px;
  }
  
  .nav-next {
    right: 10px;
  }
  
  .slide-title {
    font-size: 1.25rem;
  }
  
  .slide-description {
    font-size: 0.875rem;
  }
}
</style>

