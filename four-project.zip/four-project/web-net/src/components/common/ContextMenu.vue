<script setup>
import { ref, watch, nextTick, onMounted, onUnmounted } from 'vue'

const props = defineProps({
  visible: {
    type: Boolean,
    default: false
  },
  position: {
    type: Object,
    default: () => ({ x: 0, y: 0 })
  },
  items: {
    type: Array,
    default: () => []
    // item: { key: string, label: string, icon?: string, danger?: boolean, disabled?: boolean }
    // or { type: 'divider' }
  }
})

const emit = defineEmits(['select', 'close'])

const menuRef = ref(null)
const adjustedPosition = ref({ x: 0, y: 0 })

// 调整菜单位置，确保不超出视口
const adjustPosition = async () => {
  await nextTick()
  
  if (!menuRef.value) return
  
  const rect = menuRef.value.getBoundingClientRect()
  const viewportWidth = window.innerWidth
  const viewportHeight = window.innerHeight
  
  let x = props.position.x
  let y = props.position.y
  
  // 水平方向调整
  if (x + rect.width > viewportWidth - 10) {
    x = viewportWidth - rect.width - 10
  }
  
  // 垂直方向调整
  if (y + rect.height > viewportHeight - 10) {
    y = viewportHeight - rect.height - 10
  }
  
  // 确保不小于0
  x = Math.max(10, x)
  y = Math.max(10, y)
  
  adjustedPosition.value = { x, y }
}

// 监听位置变化
watch(() => [props.visible, props.position], () => {
  if (props.visible) {
    adjustPosition()
  }
}, { immediate: true })

// 点击菜单项
const handleItemClick = (item) => {
  if (item.disabled || item.type === 'divider') return
  emit('select', item.key)
}

// ESC 关闭
const handleKeydown = (e) => {
  if (e.key === 'Escape' && props.visible) {
    emit('close')
  }
}

onMounted(() => {
  document.addEventListener('keydown', handleKeydown)
})

onUnmounted(() => {
  document.removeEventListener('keydown', handleKeydown)
})
</script>

<template>
  <Teleport to="body">
    <Transition name="context-menu">
      <div 
        v-if="visible"
        ref="menuRef"
        class="context-menu"
        :style="{
          left: `${adjustedPosition.x}px`,
          top: `${adjustedPosition.y}px`
        }"
        @click.stop
      >
        <template v-for="(item, index) in items" :key="index">
          <!-- 分隔线 -->
          <div v-if="item.type === 'divider'" class="menu-divider"></div>
          
          <!-- 菜单项 -->
          <button 
            v-else
            class="menu-item"
            :class="{
              'is-danger': item.danger,
              'is-disabled': item.disabled
            }"
            @click="handleItemClick(item)"
          >
            <el-icon v-if="item.icon" class="menu-icon">
              <component :is="item.icon" />
            </el-icon>
            <span class="menu-label">{{ item.label }}</span>
            <span v-if="item.shortcut" class="menu-shortcut">{{ item.shortcut }}</span>
          </button>
        </template>
      </div>
    </Transition>
  </Teleport>
</template>

<style lang="scss" scoped>
.context-menu {
  position: fixed;
  min-width: 160px;
  max-width: 240px;
  padding: 0.375rem;
  background: var(--card-bg);
  border: 1px solid var(--border-secondary);
  border-radius: 10px;
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.12), 0 2px 8px rgba(0, 0, 0, 0.08);
  z-index: 2000;
}

.menu-divider {
  height: 1px;
  background: var(--border-secondary);
  margin: 0.375rem 0.5rem;
}

.menu-item {
  display: flex;
  align-items: center;
  width: 100%;
  padding: 0.5rem 0.75rem;
  font-size: 0.8125rem;
  color: var(--text-primary);
  border-radius: 6px;
  transition: all 0.12s ease;
  text-align: left;
  
  &:hover:not(.is-disabled) {
    background: var(--bg-tertiary);
  }
  
  &.is-danger {
    color: var(--error);
    
    &:hover:not(.is-disabled) {
      background: rgba(239, 68, 68, 0.1);
    }
  }
  
  &.is-disabled {
    opacity: 0.4;
    cursor: not-allowed;
  }
}

.menu-icon {
  margin-right: 0.625rem;
  font-size: 16px;
  color: var(--text-secondary);
  flex-shrink: 0;
  
  .is-danger & {
    color: var(--error);
  }
}

.menu-label {
  flex: 1;
}

.menu-shortcut {
  margin-left: 1rem;
  font-size: 0.6875rem;
  color: var(--text-tertiary);
}

// 动画
.context-menu-enter-active,
.context-menu-leave-active {
  transition: all 0.15s ease;
}

.context-menu-enter-from,
.context-menu-leave-to {
  opacity: 0;
  transform: scale(0.95);
}
</style>

