<script setup>
import { ref, computed, toRaw, shallowRef } from 'vue'
import { ElMessage } from 'element-plus'
import { convertPdf } from '@/api'

const emit = defineEmits(['close'])

// 状态 - 使用shallowRef避免File对象被深度代理
const fileList = shallowRef([])
const targetFormat = ref('excel')
const converting = ref(false)
const dragOver = ref(false)

// 格式选项
const formatOptions = [
  { value: 'excel', label: 'Excel (.xlsx)', icon: 'DocumentChecked', color: '#217346' },
  { value: 'word', label: 'Word (.docx)', icon: 'Document', color: '#2B579A' }
]

// 当前选中的格式
const currentFormat = computed(() => {
  return formatOptions.find(f => f.value === targetFormat.value)
})

// 文件选择
const handleFileChange = (uploadFile) => {
  // el-upload传入的uploadFile对象包含raw属性（原始File对象）
  const rawFile = uploadFile.raw
  
  if (!rawFile) {
    ElMessage.warning('文件读取失败')
    return
  }
  
  if (!rawFile.type.includes('pdf') && !rawFile.name.toLowerCase().endsWith('.pdf')) {
    ElMessage.warning('请选择PDF文件')
    return
  }
  
  if (rawFile.size > 20 * 1024 * 1024) {
    ElMessage.warning('文件过大，最大支持20MB')
    return
  }
  
  // 直接存储原始文件对象，避免响应式代理问题
  fileList.value = [{ raw: rawFile, name: rawFile.name }]
}

// 移除文件
const handleRemove = () => {
  fileList.value = []
}

// 拖拽相关
const handleDragOver = (e) => {
  e.preventDefault()
  dragOver.value = true
}

const handleDragLeave = () => {
  dragOver.value = false
}

const handleDrop = (e) => {
  e.preventDefault()
  dragOver.value = false
  
  const files = e.dataTransfer.files
  if (files.length > 0) {
    const file = files[0]
    if (file.type === 'application/pdf') {
      if (file.size > 20 * 1024 * 1024) {
        ElMessage.warning('文件过大，最大支持20MB')
        return
      }
      fileList.value = [{ raw: file, name: file.name }]
    } else {
      ElMessage.warning('请选择PDF文件')
    }
  }
}

// 开始转换
const startConvert = async () => {
  if (fileList.value.length === 0) {
    ElMessage.warning('请先选择PDF文件')
    return
  }
  
  converting.value = true
  
  try {
    // 获取原始File对象（避免Vue响应式代理干扰）
    const fileItem = toRaw(fileList.value[0])
    const rawFile = toRaw(fileItem.raw)
    
    if (!rawFile || !(rawFile instanceof File)) {
      ElMessage.error('文件对象无效，请重新选择')
      return
    }
    
    const formData = new FormData()
    formData.append('file', rawFile, rawFile.name)
    formData.append('target_format', targetFormat.value)
    
    await convertPdf(formData)
    
    ElMessage.success('转换成功，文件已开始下载')
    fileList.value = []
  } catch (error) {
    ElMessage.error(error.message || '转换失败')
  } finally {
    converting.value = false
  }
}

// 格式化文件大小
const formatSize = (bytes) => {
  if (bytes < 1024) return bytes + ' B'
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB'
  return (bytes / (1024 * 1024)).toFixed(2) + ' MB'
}
</script>

<template>
  <div class="pdf-converter">
    <!-- 上传区域 -->
    <div 
      class="upload-zone"
      :class="{ 'drag-over': dragOver, 'has-file': fileList.length > 0 }"
      @dragover="handleDragOver"
      @dragleave="handleDragLeave"
      @drop="handleDrop"
    >
      <template v-if="fileList.length === 0">
        <el-upload
          class="upload-trigger"
          :auto-upload="false"
          :show-file-list="false"
          accept=".pdf"
          :on-change="handleFileChange"
        >
          <div class="upload-content">
            <div class="upload-icon">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                <path d="M7 18a4.6 4.4 0 0 1 0-9 5 4.5 0 0 1 11 2h1a3.5 3.5 0 0 1 0 7h-1" />
                <path d="M12 13v9" />
                <path d="m9 16 3-3 3 3" />
              </svg>
            </div>
            <div class="upload-text">
              <p class="main-text">拖拽PDF文件到此处，或 <span>点击上传</span></p>
              <p class="sub-text">支持单个PDF文件，最大20MB</p>
            </div>
          </div>
        </el-upload>
      </template>
      
      <template v-else>
        <div class="file-preview">
          <div class="file-icon">
            <svg viewBox="0 0 24 24" fill="none">
              <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" stroke="#E53935" stroke-width="1.5"/>
              <path d="M14 2v6h6" stroke="#E53935" stroke-width="1.5"/>
              <text x="7" y="17" fill="#E53935" font-size="5" font-weight="bold">PDF</text>
            </svg>
          </div>
          <div class="file-info">
            <p class="file-name">{{ fileList[0].name || fileList[0].raw?.name }}</p>
            <p class="file-size">{{ formatSize(fileList[0].raw?.size || 0) }}</p>
          </div>
          <button class="remove-btn" @click.stop="handleRemove">
            <el-icon><Close /></el-icon>
          </button>
        </div>
      </template>
    </div>
    
    <!-- 格式选择 -->
    <div class="format-section">
      <h4 class="section-title">选择目标格式</h4>
      <div class="format-options">
        <button
          v-for="option in formatOptions"
          :key="option.value"
          class="format-option"
          :class="{ active: targetFormat === option.value }"
          @click="targetFormat = option.value"
        >
          <div class="format-icon" :style="{ backgroundColor: option.color + '15', color: option.color }">
            <el-icon><component :is="option.icon" /></el-icon>
          </div>
          <span class="format-label">{{ option.label }}</span>
          <div class="check-mark" v-if="targetFormat === option.value">
            <el-icon><Check /></el-icon>
          </div>
        </button>
      </div>
    </div>
    
    <!-- 转换按钮 -->
    <div class="action-section">
      <el-button
        type="primary"
        size="large"
        :loading="converting"
        :disabled="fileList.length === 0"
        @click="startConvert"
        class="convert-btn"
      >
        <template #icon>
          <el-icon><Refresh /></el-icon>
        </template>
        {{ converting ? '正在转换...' : `转换为 ${currentFormat.label}` }}
      </el-button>
    </div>
    
    <!-- 提示信息 -->
    <div class="tips-section">
      <div class="tip-item">
        <el-icon><InfoFilled /></el-icon>
        <span>PDF中的表格将被智能识别并提取</span>
      </div>
      <div class="tip-item">
        <el-icon><InfoFilled /></el-icon>
        <span>转换后的文件将自动下载到本地</span>
      </div>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.pdf-converter {
  padding: 1.5rem;
}

.upload-zone {
  border: 2px dashed var(--border-secondary);
  border-radius: 12px;
  transition: all 0.25s ease;
  background: var(--bg-tertiary);
  
  &:hover, &.drag-over {
    border-color: var(--accent-primary);
    background: rgba(var(--accent-rgb), 0.05);
  }
  
  &.has-file {
    border-style: solid;
    border-color: var(--border-primary);
    background: var(--bg-secondary);
  }
}

.upload-trigger {
  width: 100%;
  
  :deep(.el-upload) {
    width: 100%;
  }
}

.upload-content {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 3rem 2rem;
  cursor: pointer;
}

.upload-icon {
  width: 64px;
  height: 64px;
  color: var(--text-tertiary);
  margin-bottom: 1rem;
  
  svg {
    width: 100%;
    height: 100%;
  }
}

.upload-text {
  text-align: center;
  
  .main-text {
    font-size: 0.9375rem;
    color: var(--text-secondary);
    margin-bottom: 0.5rem;
    
    span {
      color: var(--accent-primary);
      font-weight: 500;
    }
  }
  
  .sub-text {
    font-size: 0.8125rem;
    color: var(--text-tertiary);
  }
}

.file-preview {
  display: flex;
  align-items: center;
  gap: 1rem;
  padding: 1.25rem 1.5rem;
}

.file-icon {
  width: 48px;
  height: 48px;
  flex-shrink: 0;
  
  svg {
    width: 100%;
    height: 100%;
  }
}

.file-info {
  flex: 1;
  min-width: 0;
  
  .file-name {
    font-size: 0.9375rem;
    font-weight: 500;
    color: var(--text-primary);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    margin-bottom: 0.25rem;
  }
  
  .file-size {
    font-size: 0.8125rem;
    color: var(--text-tertiary);
  }
}

.remove-btn {
  width: 32px;
  height: 32px;
  border-radius: 8px;
  border: none;
  background: var(--bg-tertiary);
  color: var(--text-tertiary);
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.2s;
  
  &:hover {
    background: #fee2e2;
    color: #dc2626;
  }
}

.format-section {
  margin-top: 1.5rem;
}

.section-title {
  font-size: 0.875rem;
  font-weight: 600;
  color: var(--text-secondary);
  margin-bottom: 0.75rem;
}

.format-options {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 0.75rem;
}

.format-option {
  display: flex;
  align-items: center;
  gap: 0.75rem;
  padding: 1rem;
  border: 2px solid var(--border-secondary);
  border-radius: 10px;
  background: var(--bg-primary);
  cursor: pointer;
  transition: all 0.2s;
  position: relative;
  
  &:hover {
    border-color: var(--border-primary);
    background: var(--bg-secondary);
  }
  
  &.active {
    border-color: var(--accent-primary);
    background: rgba(var(--accent-rgb), 0.05);
  }
}

.format-icon {
  width: 40px;
  height: 40px;
  border-radius: 10px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 1.25rem;
}

.format-label {
  font-size: 0.875rem;
  font-weight: 500;
  color: var(--text-primary);
}

.check-mark {
  position: absolute;
  top: 0.5rem;
  right: 0.5rem;
  width: 20px;
  height: 20px;
  border-radius: 50%;
  background: var(--accent-primary);
  color: white;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 0.75rem;
}

.action-section {
  margin-top: 1.5rem;
}

.convert-btn {
  width: 100%;
  height: 48px;
  font-size: 0.9375rem;
  font-weight: 600;
  border-radius: 10px;
}

.tips-section {
  margin-top: 1.25rem;
  padding: 1rem;
  background: var(--bg-tertiary);
  border-radius: 8px;
}

.tip-item {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  font-size: 0.8125rem;
  color: var(--text-tertiary);
  
  & + & {
    margin-top: 0.5rem;
  }
  
  .el-icon {
    color: var(--accent-primary);
    font-size: 0.875rem;
  }
}
</style>

