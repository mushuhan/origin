<script setup>
import { ref } from 'vue'
import { useStore } from 'vuex'
import { gsap } from 'gsap'

const props = defineProps({
  item: {
    type: Object,
    required: true
  },
  draggable: {
    type: Boolean,
    default: true
  }
})

const emit = defineEmits(['edit', 'remove'])

const store = useStore()
const cardRef = ref(null)
const isHovered = ref(false)

// 点击网站
const handleClick = () => {
  if (props.item.url) {
    window.open(props.item.url, '_blank')
    if (props.item.website_id) {
      store.dispatch('clickWebsite', props.item.website_id)
    }
  }
}

// 编辑
const handleEdit = (e) => {
  e.stopPropagation()
  emit('edit', props.item)
}

// 移除
const handleRemove = (e) => {
  e.stopPropagation()
  emit('remove', props.item)
}

// 复制链接
const copyLink = async (e) => {
  e.stopPropagation()
  try {
    await navigator.clipboard.writeText(props.item.url)
    store.commit('SET_MESSAGE', { type: 'success', text: '链接已复制' })
  } catch (err) {
    store.commit('SET_MESSAGE', { type: 'error', text: '复制失败' })
  }
}

// 鼠标动画
const onMouseEnter = () => {
  isHovered.value = true
  gsap.to(cardRef.value, {
    scale: 1.05,
    y: -4,
    duration: 0.3,
    ease: 'power2.out'
  })
}

const onMouseLeave = () => {
  isHovered.value = false
  gsap.to(cardRef.value, {
    scale: 1,
    y: 0,
    duration: 0.3,
    ease: 'power2.out'
  })
}

// 图标加载失败
const onIconError = (e) => {
  e.target.src = `https://www.google.com/s2/favicons?domain=${props.item.url}&sz=64`
}
</script>

<template>
  <div 
    ref="cardRef"
    class="workspace-card relative rounded-2xl cursor-pointer shadow-card hover:shadow-card-hover transition-shadow"
    :class="{ 'cursor-grab': draggable }"
    @click="handleClick"
    @mouseenter="onMouseEnter"
    @mouseleave="onMouseLeave"
  >
    <div class="card-content p-4 flex flex-col items-center text-center">
      <!-- 图标 -->
      <div class="icon-wrapper w-14 h-14 mb-3 rounded-2xl flex items-center justify-center overflow-hidden">
        <img 
          :src="item.icon || `https://www.google.com/s2/favicons?domain=${item.url}&sz=64`"
          :alt="item.name"
          class="w-full h-full object-contain"
          @error="onIconError"
        />
      </div>
      
      <!-- 名称 -->
      <h4 class="text-sm font-medium truncate w-full">{{ item.name }}</h4>
      
      <!-- 描述 -->
      <transition name="fade">
        <p 
          v-if="isHovered && item.description" 
          class="text-xs text-gray-400 mt-1 line-clamp-2"
        >
          {{ item.description }}
        </p>
      </transition>
    </div>

    <!-- 操作按钮 -->
    <transition name="fade">
      <div 
        v-if="isHovered" 
        class="actions absolute top-2 right-2 flex gap-1"
      >
        <el-tooltip content="编辑" placement="top">
          <button 
            class="action-btn w-7 h-7 rounded-lg flex items-center justify-center transition-colors"
            @click="handleEdit"
          >
            <el-icon :size="14">
              <Edit />
            </el-icon>
          </button>
        </el-tooltip>
        <el-tooltip content="复制链接" placement="top">
          <button 
            class="action-btn w-7 h-7 rounded-lg flex items-center justify-center transition-colors"
            @click="copyLink"
          >
            <el-icon :size="14">
              <CopyDocument />
            </el-icon>
          </button>
        </el-tooltip>
        <el-tooltip content="移除" placement="top">
          <button 
            class="action-btn w-7 h-7 rounded-lg flex items-center justify-center transition-colors hover:!text-red-500"
            @click="handleRemove"
          >
            <el-icon :size="14">
              <Delete />
            </el-icon>
          </button>
        </el-tooltip>
      </div>
    </transition>

    <!-- 拖拽把手 -->
    <div 
      v-if="draggable && isHovered" 
      class="drag-handle absolute top-2 left-2 w-7 h-7 rounded-lg flex items-center justify-center text-gray-400 cursor-grab"
    >
      <el-icon :size="14">
        <Rank />
      </el-icon>
    </div>

    <!-- 自定义标签 -->
    <div 
      v-if="item.is_custom" 
      class="custom-badge absolute -top-1 -right-1 px-1.5 py-0.5 rounded-full bg-gradient-to-br from-purple-400 to-pink-500 text-white text-xs"
    >
      自定义
    </div>
  </div>
</template>

<style lang="scss" scoped>
.workspace-card {
  background: var(--card-bg);
  border: 1px solid var(--border-secondary);
  min-width: 100px;
}

.icon-wrapper {
  background: var(--bg-tertiary);
  padding: 8px;
}

.action-btn {
  background: var(--card-bg);
  color: var(--text-secondary);
  border: 1px solid var(--border-secondary);
  backdrop-filter: blur(4px);
  
  &:hover {
    background: var(--bg-tertiary);
    color: var(--accent);
  }
}

.drag-handle {
  background: var(--card-bg);
  color: var(--text-tertiary);
  border: 1px solid var(--border-secondary);
  backdrop-filter: blur(4px);
}

.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.2s ease;
}

.fade-enter-from,
.fade-leave-to {
  opacity: 0;
}
</style>

