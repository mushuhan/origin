<script setup>
import { ref, computed, watch, onMounted } from 'vue'

const props = defineProps({
  rankings: {
    type: Array,
    default: () => []
  },
  dimension: {
    type: String,
    default: 'all'
  },
  loading: {
    type: Boolean,
    default: false
  }
})

const emit = defineEmits(['click', 'dimensionChange'])

const dimensions = [
  { value: 'today', label: '今日' },
  { value: 'week', label: '本周' },
  { value: 'all', label: '全站' }
]

const activeDimension = ref(props.dimension)
const isAnimated = ref(false)

// 触发柱状图动画
const triggerAnimation = () => {
  isAnimated.value = false
  setTimeout(() => {
    isAnimated.value = true
  }, 50)
}

// 切换维度
const changeDimension = (value) => {
  activeDimension.value = value
  emit('dimensionChange', value)
}

// 点击排行项
const handleItemClick = (item) => {
  emit('click', item)
  // 波纹效果通过CSS实现
}

// 获取排名颜色
const getRankColor = (rank) => {
  if (rank === 1) return 'var(--text-primary)'
  if (rank === 2) return 'var(--text-secondary)'
  if (rank === 3) return 'var(--text-tertiary)'
  return 'var(--border-primary)'
}

watch(() => props.rankings, () => {
  triggerAnimation()
}, { immediate: true })

onMounted(() => {
  triggerAnimation()
})
</script>

<template>
  <div class="hot-ranking-chart">
    <!-- 头部筛选器 -->
    <div class="chart-header">
      <h3 class="chart-title">
        <el-icon><TrendCharts /></el-icon>
        热门排行
      </h3>
      <div class="dimension-tabs">
        <button
          v-for="dim in dimensions"
          :key="dim.value"
          class="tab-btn"
          :class="{ active: activeDimension === dim.value }"
          @click="changeDimension(dim.value)"
        >
          {{ dim.label }}
        </button>
      </div>
    </div>
    
    <!-- 加载状态 -->
    <div v-if="loading" class="loading-state">
      <div v-for="i in 5" :key="i" class="skeleton-item">
        <div class="skeleton skeleton-rank"></div>
        <div class="skeleton skeleton-bar"></div>
      </div>
    </div>
    
    <!-- 排行列表 -->
    <div v-else-if="rankings.length > 0" class="ranking-list">
      <div
        v-for="(item, index) in rankings"
        :key="item.id"
        class="ranking-item"
        :class="{ 'is-animated': isAnimated }"
        :style="{ '--delay': index * 0.08 + 's' }"
        @click="handleItemClick(item)"
      >
        <!-- 排名 -->
        <span class="rank" :style="{ color: getRankColor(item.rank) }">
          {{ item.rank }}
        </span>
        
        <!-- 网站信息 -->
        <div class="site-info">
          <span class="site-name">{{ item.name }}</span>
          <span class="click-count">{{ item.click_count }} 次点击</span>
        </div>
        
        <!-- 柱状图 -->
        <div class="bar-wrapper">
          <div 
            class="bar"
            :style="{ 
              '--width': item.percentage + '%',
              '--color': getRankColor(item.rank)
            }"
          ></div>
        </div>
        
        <!-- 波纹效果容器 -->
        <span class="ripple"></span>
      </div>
    </div>
    
    <!-- 空状态 -->
    <div v-else class="empty-state">
      <el-icon :size="40"><DataAnalysis /></el-icon>
      <p>暂无排行数据</p>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.hot-ranking-chart {
  background: var(--card-bg);
  border-radius: 16px;
  border: 1px solid var(--border-secondary);
  padding: 1.5rem;
  transition: all 0.3s ease;
}

.chart-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1.5rem;
}

.chart-title {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  font-size: 1rem;
  font-weight: 600;
  color: var(--text-primary);
  
  .el-icon {
    color: var(--text-secondary);
  }
}

.dimension-tabs {
  display: flex;
  gap: 4px;
  padding: 4px;
  background: var(--bg-tertiary);
  border-radius: 8px;
}

.tab-btn {
  padding: 0.375rem 0.75rem;
  font-size: 0.8rem;
  font-weight: 500;
  color: var(--text-secondary);
  border-radius: 6px;
  transition: all 0.2s ease;
  
  &:hover {
    color: var(--text-primary);
  }
  
  &.active {
    background: var(--card-bg);
    color: var(--text-primary);
    box-shadow: var(--shadow-sm);
  }
}

.ranking-list {
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
}

.ranking-item {
  position: relative;
  display: grid;
  grid-template-columns: 28px 1fr 1fr;
  gap: 1rem;
  align-items: center;
  padding: 0.75rem 1rem;
  background: var(--bg-secondary);
  border-radius: 10px;
  cursor: pointer;
  overflow: hidden;
  transition: all 0.2s ease;
  
  &:hover {
    background: var(--bg-tertiary);
    transform: translateX(4px);
  }
  
  &:active .ripple {
    animation: ripple 0.6s ease-out;
  }
}

.rank {
  font-size: 1rem;
  font-weight: 700;
  text-align: center;
}

.site-info {
  display: flex;
  flex-direction: column;
  gap: 2px;
  min-width: 0;
  
  .site-name {
    font-size: 0.875rem;
    font-weight: 500;
    color: var(--text-primary);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  
  .click-count {
    font-size: 0.75rem;
    color: var(--text-tertiary);
  }
}

.bar-wrapper {
  height: 8px;
  background: var(--border-secondary);
  border-radius: 4px;
  overflow: hidden;
}

.bar {
  height: 100%;
  width: 0;
  background: var(--color, var(--text-primary));
  border-radius: 4px;
  transition: width 0.8s cubic-bezier(0.16, 1, 0.3, 1);
  
  .is-animated & {
    width: var(--width);
    transition-delay: var(--delay);
  }
}

.ripple {
  position: absolute;
  width: 100%;
  height: 100%;
  left: 0;
  top: 0;
  background: radial-gradient(circle, var(--accent-light) 10%, transparent 10%);
  background-position: center;
  background-repeat: no-repeat;
  opacity: 0;
  pointer-events: none;
}

@keyframes ripple {
  from {
    transform: scale(0);
    opacity: 1;
  }
  to {
    transform: scale(2.5);
    opacity: 0;
  }
}

// 骨架屏
.loading-state {
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
}

.skeleton-item {
  display: grid;
  grid-template-columns: 28px 1fr;
  gap: 1rem;
  align-items: center;
  padding: 0.75rem 1rem;
  
  .skeleton-rank {
    width: 20px;
    height: 20px;
    border-radius: 4px;
  }
  
  .skeleton-bar {
    height: 32px;
    border-radius: 8px;
  }
}

// 空状态
.empty-state {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 3rem;
  color: var(--text-tertiary);
  
  .el-icon {
    margin-bottom: 1rem;
    opacity: 0.5;
  }
  
  p {
    font-size: 0.875rem;
  }
}
</style>

