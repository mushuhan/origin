<script setup>
import { ref, computed, onMounted, watch } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { 
  searchEmployees, 
  exportEmployees, 
  getEmailPresets, 
  saveEmailPreset, 
  deleteEmailPreset,
  getEmailDepartments,
  getEmailRoles
} from '@/api'

const emit = defineEmits(['close'])

// 筛选条件
const filters = ref({
  keyword: '',
  department_ids: [],
  roles: [],
  employee_type: 'all'
})

// 下拉选项
const departments = ref([])
const roles = ref([])

// 搜索结果
const searchResults = ref([])
const total = ref(0)
const page = ref(1)
const pageSize = ref(50)
const loading = ref(false)

// 选中的员工
const selectedIds = ref([])

// 预设管理
const presets = ref([])
const showPresetDialog = ref(false)
const newPresetName = ref('')
const newPresetDesc = ref('')

// 导出相关
const showExportDialog = ref(false)
const exportFormat = ref('email')
const exportResult = ref('')

// 员工类型选项
const employeeTypeOptions = [
  { value: 'all', label: '全部员工' },
  { value: 'regular', label: '正式员工 (00开头)' },
  { value: 'dispatch', label: '派遣员工 (8开头)' }
]

// 计算已选员工数
const selectedCount = computed(() => selectedIds.value.length)

// 计算已选员工列表
const selectedEmployees = computed(() => {
  return searchResults.value.filter(emp => selectedIds.value.includes(emp.id))
})

// 初始化
onMounted(async () => {
  await Promise.all([
    loadDepartments(),
    loadRoles(),
    loadPresets()
  ])
})

// 加载科室列表
const loadDepartments = async () => {
  try {
    const data = await getEmailDepartments()
    departments.value = data
  } catch (e) {
    console.error('加载科室失败:', e)
  }
}

// 加载职位列表
const loadRoles = async () => {
  try {
    const data = await getEmailRoles()
    roles.value = data
  } catch (e) {
    console.error('加载职位失败:', e)
  }
}

// 加载预设
const loadPresets = async () => {
  try {
    const data = await getEmailPresets()
    presets.value = data
  } catch (e) {
    console.error('加载预设失败:', e)
  }
}

// 搜索员工
const handleSearch = async () => {
  loading.value = true
  try {
    const data = await searchEmployees({
      ...filters.value,
      page: page.value,
      page_size: pageSize.value
    })
    searchResults.value = data.items
    total.value = data.total
  } catch (e) {
    ElMessage.error(e.message || '搜索失败')
  } finally {
    loading.value = false
  }
}

// 监听筛选条件变化
watch(() => filters.value, () => {
  page.value = 1
  selectedIds.value = []
}, { deep: true })

// 重置筛选
const resetFilters = () => {
  filters.value = {
    keyword: '',
    department_ids: [],
    roles: [],
    employee_type: 'all'
  }
  page.value = 1
  selectedIds.value = []
  searchResults.value = []
}

// 全选当前页
const handleSelectAll = () => {
  const currentPageIds = searchResults.value.map(e => e.id)
  const allSelected = currentPageIds.every(id => selectedIds.value.includes(id))
  
  if (allSelected) {
    // 取消全选
    selectedIds.value = selectedIds.value.filter(id => !currentPageIds.includes(id))
  } else {
    // 全选
    const newIds = currentPageIds.filter(id => !selectedIds.value.includes(id))
    selectedIds.value = [...selectedIds.value, ...newIds]
  }
}

// 切换选中
const toggleSelect = (id) => {
  const idx = selectedIds.value.indexOf(id)
  if (idx > -1) {
    selectedIds.value.splice(idx, 1)
  } else {
    selectedIds.value.push(id)
  }
}

// 移除已选
const removeSelected = (id) => {
  const idx = selectedIds.value.indexOf(id)
  if (idx > -1) {
    selectedIds.value.splice(idx, 1)
  }
}

// 分页变化
const handlePageChange = (newPage) => {
  page.value = newPage
  handleSearch()
}

// 导出
const handleExport = async (format) => {
  if (selectedIds.value.length === 0) {
    ElMessage.warning('请先选择要导出的员工')
    return
  }
  
  if (format === 'excel') {
    // Excel 导出
    try {
      await exportEmployees({
        employee_ids: selectedIds.value,
        format: 'excel'
      })
      ElMessage.success('导出成功')
    } catch (e) {
      ElMessage.error(e.message || '导出失败')
    }
  } else {
    // 字符串导出
    exportFormat.value = format
    try {
      const data = await exportEmployees({
        employee_ids: selectedIds.value,
        format: 'string',
        string_type: format
      })
      exportResult.value = data.string
      showExportDialog.value = true
    } catch (e) {
      ElMessage.error(e.message || '生成失败')
    }
  }
}

// 复制到剪贴板
const copyToClipboard = async () => {
  try {
    await navigator.clipboard.writeText(exportResult.value)
    ElMessage.success('已复制到剪贴板')
  } catch (e) {
    ElMessage.error('复制失败，请手动复制')
  }
}

// 保存预设
const handleSavePreset = async () => {
  if (!newPresetName.value.trim()) {
    ElMessage.warning('请输入预设名称')
    return
  }
  
  try {
    await saveEmailPreset({
      name: newPresetName.value,
      description: newPresetDesc.value,
      filters: filters.value
    })
    ElMessage.success('预设保存成功')
    showPresetDialog.value = false
    newPresetName.value = ''
    newPresetDesc.value = ''
    await loadPresets()
  } catch (e) {
    ElMessage.error(e.message || '保存失败')
  }
}

// 加载预设
const loadPreset = (preset) => {
  filters.value = { ...preset.filters }
  page.value = 1
  selectedIds.value = []
  handleSearch()
}

// 删除预设
const handleDeletePreset = async (preset) => {
  try {
    await ElMessageBox.confirm(
      `确定要删除预设"${preset.name}"吗？`,
      '删除确认',
      { type: 'warning' }
    )
    await deleteEmailPreset(preset.id)
    ElMessage.success('删除成功')
    await loadPresets()
  } catch (e) {
    if (e !== 'cancel') {
      ElMessage.error(e.message || '删除失败')
    }
  }
}

// 是否全选当前页
const isAllSelected = computed(() => {
  if (searchResults.value.length === 0) return false
  return searchResults.value.every(e => selectedIds.value.includes(e.id))
})
</script>

<template>
  <div class="email-generator">
    <div class="generator-layout">
      <!-- 左侧：筛选区 -->
      <div class="filter-panel">
        <div class="panel-header">
          <span class="panel-title">筛选条件</span>
          <el-button size="small" text @click="resetFilters">重置</el-button>
        </div>
        
        <div class="filter-form">
          <!-- 关键字搜索 -->
          <div class="filter-item">
            <label>关键字搜索</label>
            <el-input
              v-model="filters.keyword"
              placeholder="姓名/拼音/邮箱"
              clearable
              @keyup.enter="handleSearch"
            >
              <template #prefix>
                <el-icon><Search /></el-icon>
              </template>
            </el-input>
          </div>
          
          <!-- 科室筛选 -->
          <div class="filter-item">
            <label>科室</label>
            <el-select
              v-model="filters.department_ids"
              multiple
              collapse-tags
              collapse-tags-tooltip
              placeholder="选择科室"
              clearable
              class="w-full"
            >
              <el-option
                v-for="d in departments"
                :key="d.id"
                :label="d.name"
                :value="d.id"
              />
            </el-select>
          </div>
          
          <!-- 职位筛选 -->
          <div class="filter-item">
            <label>职位/角色</label>
            <el-select
              v-model="filters.roles"
              multiple
              collapse-tags
              collapse-tags-tooltip
              placeholder="选择职位"
              clearable
              filterable
              allow-create
              class="w-full"
            >
              <el-option
                v-for="r in roles"
                :key="r"
                :label="r"
                :value="r"
              />
            </el-select>
          </div>
          
          <!-- 员工类型 -->
          <div class="filter-item">
            <label>员工类型</label>
            <el-select
              v-model="filters.employee_type"
              placeholder="选择类型"
              class="w-full"
            >
              <el-option
                v-for="opt in employeeTypeOptions"
                :key="opt.value"
                :label="opt.label"
                :value="opt.value"
              />
            </el-select>
          </div>
          
          <el-button type="primary" class="search-btn" @click="handleSearch">
            <el-icon><Search /></el-icon>
            <span>搜索</span>
          </el-button>
        </div>
        
        <!-- 预设区域 -->
        <div class="presets-section">
          <div class="presets-header">
            <span class="presets-title">我的预设</span>
            <el-button size="small" text type="primary" @click="showPresetDialog = true">
              <el-icon><Plus /></el-icon>
              <span>保存当前</span>
            </el-button>
          </div>
          <div class="presets-list" v-if="presets.length > 0">
            <div
              v-for="p in presets"
              :key="p.id"
              class="preset-item"
            >
              <span class="preset-name" @click="loadPreset(p)">{{ p.name }}</span>
              <el-button
                size="small"
                text
                type="danger"
                @click.stop="handleDeletePreset(p)"
              >
                <el-icon><Delete /></el-icon>
              </el-button>
            </div>
          </div>
          <div v-else class="presets-empty">暂无预设</div>
        </div>
      </div>
      
      <!-- 中间：搜索结果 -->
      <div class="results-panel">
        <div class="panel-header">
          <span class="panel-title">搜索结果 ({{ total }})</span>
          <el-checkbox
            :model-value="isAllSelected"
            :indeterminate="selectedIds.length > 0 && !isAllSelected"
            @change="handleSelectAll"
          >
            全选当前页
          </el-checkbox>
        </div>
        
        <div class="results-list" v-loading="loading">
          <div
            v-for="emp in searchResults"
            :key="emp.id"
            class="employee-item"
            :class="{ selected: selectedIds.includes(emp.id) }"
            @click="toggleSelect(emp.id)"
          >
            <el-checkbox
              :model-value="selectedIds.includes(emp.id)"
              @click.stop
              @change="toggleSelect(emp.id)"
            />
            <div class="emp-info">
              <span class="emp-name">{{ emp.name }}</span>
              <span class="emp-dept">{{ emp.department_name }}</span>
            </div>
            <div class="emp-detail">
              <span class="emp-position">{{ emp.position }}</span>
              <span class="emp-email">{{ emp.email }}</span>
            </div>
          </div>
          
          <div v-if="searchResults.length === 0 && !loading" class="empty-tip">
            {{ total === 0 ? '请设置筛选条件后搜索' : '暂无匹配结果' }}
          </div>
        </div>
        
        <div class="pagination" v-if="total > pageSize">
          <el-pagination
            v-model:current-page="page"
            :page-size="pageSize"
            :total="total"
            layout="prev, pager, next"
            @current-change="handlePageChange"
          />
        </div>
      </div>
      
      <!-- 右侧：已选预览 -->
      <div class="selected-panel">
        <div class="panel-header">
          <span class="panel-title">已选人员 ({{ selectedCount }})</span>
          <el-button
            v-if="selectedCount > 0"
            size="small"
            text
            type="danger"
            @click="selectedIds = []"
          >
            清空
          </el-button>
        </div>
        
        <div class="selected-list">
          <div
            v-for="emp in selectedEmployees"
            :key="emp.id"
            class="selected-item"
          >
            <span class="s-name">{{ emp.name }}</span>
            <span class="s-email">{{ emp.email }}</span>
            <el-button
              size="small"
              text
              circle
              @click="removeSelected(emp.id)"
            >
              <el-icon><Close /></el-icon>
            </el-button>
          </div>
          
          <div v-if="selectedCount === 0" class="empty-tip">
            点击左侧员工添加到列表
          </div>
        </div>
        
        <!-- 导出操作 -->
        <div class="export-actions" v-if="selectedCount > 0">
          <el-button type="success" @click="handleExport('excel')">
            <el-icon><Download /></el-icon>
            <span>导出 Excel</span>
          </el-button>
          <div class="copy-actions">
            <el-button @click="handleExport('email')">
              <el-icon><Message /></el-icon>
              <span>复制邮箱</span>
            </el-button>
            <el-button @click="handleExport('id')">
              <el-icon><Tickets /></el-icon>
              <span>复制工号</span>
            </el-button>
          </div>
        </div>
      </div>
    </div>
    
    <!-- 保存预设弹窗 -->
    <el-dialog
      v-model="showPresetDialog"
      title="保存预设"
      width="400px"
    >
      <el-form label-position="top">
        <el-form-item label="预设名称" required>
          <el-input v-model="newPresetName" placeholder="如：所有检验员" />
        </el-form-item>
        <el-form-item label="描述（可选）">
          <el-input v-model="newPresetDesc" type="textarea" rows="2" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="showPresetDialog = false">取消</el-button>
        <el-button type="primary" @click="handleSavePreset">保存</el-button>
      </template>
    </el-dialog>
    
    <!-- 复制结果弹窗 -->
    <el-dialog
      v-model="showExportDialog"
      :title="exportFormat === 'email' ? '邮箱列表' : '工号列表'"
      width="600px"
    >
      <el-input
        v-model="exportResult"
        type="textarea"
        rows="8"
        readonly
      />
      <template #footer>
        <el-button @click="showExportDialog = false">关闭</el-button>
        <el-button type="primary" @click="copyToClipboard">
          <el-icon><CopyDocument /></el-icon>
          <span>复制</span>
        </el-button>
      </template>
    </el-dialog>
  </div>
</template>

<style lang="scss" scoped>
.email-generator {
  height: 70vh;
}

.generator-layout {
  display: grid;
  grid-template-columns: 280px 1fr 280px;
  gap: 1rem;
  height: 100%;
  padding: 1rem;
  
  @media (max-width: 1024px) {
    grid-template-columns: 1fr;
    height: auto;
  }
}

.filter-panel,
.results-panel,
.selected-panel {
  display: flex;
  flex-direction: column;
  background: var(--bg-secondary);
  border-radius: 12px;
  overflow: hidden;
}

.panel-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0.875rem 1rem;
  border-bottom: 1px solid var(--border-secondary);
  flex-shrink: 0;
  
  .panel-title {
    font-weight: 600;
    color: var(--text-primary);
  }
}

// 筛选区
.filter-panel {
  .filter-form {
    padding: 1rem;
    flex: 1;
    overflow-y: auto;
  }
  
  .filter-item {
    margin-bottom: 1rem;
    
    label {
      display: block;
      font-size: 0.8125rem;
      font-weight: 500;
      color: var(--text-secondary);
      margin-bottom: 0.375rem;
    }
  }
  
  .w-full {
    width: 100%;
  }
  
  .search-btn {
    width: 100%;
    margin-top: 0.5rem;
  }
}

.presets-section {
  border-top: 1px solid var(--border-secondary);
  padding: 1rem;
  
  .presets-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 0.75rem;
    
    .presets-title {
      font-size: 0.8125rem;
      font-weight: 600;
      color: var(--text-secondary);
    }
  }
  
  .presets-list {
    display: flex;
    flex-direction: column;
    gap: 0.375rem;
  }
  
  .preset-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0.5rem 0.75rem;
    background: var(--card-bg);
    border-radius: 6px;
    
    .preset-name {
      font-size: 0.8125rem;
      color: var(--text-primary);
      cursor: pointer;
      
      &:hover {
        color: var(--accent);
      }
    }
  }
  
  .presets-empty {
    font-size: 0.8125rem;
    color: var(--text-tertiary);
    text-align: center;
    padding: 0.5rem;
  }
}

// 结果区
.results-panel {
  .results-list {
    flex: 1;
    overflow-y: auto;
    padding: 0.5rem;
  }
  
  .employee-item {
    display: flex;
    align-items: center;
    gap: 0.75rem;
    padding: 0.625rem 0.75rem;
    border-radius: 8px;
    cursor: pointer;
    transition: all 0.15s ease;
    
    &:hover {
      background: var(--bg-tertiary);
    }
    
    &.selected {
      background: var(--accent-light);
    }
    
    .emp-info {
      flex: 1;
      min-width: 0;
      
      .emp-name {
        display: block;
        font-weight: 500;
        color: var(--text-primary);
      }
      
      .emp-dept {
        font-size: 0.75rem;
        color: var(--text-tertiary);
      }
    }
    
    .emp-detail {
      text-align: right;
      
      .emp-position {
        display: block;
        font-size: 0.75rem;
        color: var(--text-secondary);
      }
      
      .emp-email {
        font-size: 0.75rem;
        color: var(--text-tertiary);
      }
    }
  }
  
  .pagination {
    padding: 0.75rem;
    border-top: 1px solid var(--border-secondary);
    display: flex;
    justify-content: center;
  }
}

// 已选区
.selected-panel {
  .selected-list {
    flex: 1;
    overflow-y: auto;
    padding: 0.5rem;
  }
  
  .selected-item {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    padding: 0.5rem 0.75rem;
    background: var(--card-bg);
    border-radius: 6px;
    margin-bottom: 0.375rem;
    
    .s-name {
      font-size: 0.8125rem;
      font-weight: 500;
      color: var(--text-primary);
    }
    
    .s-email {
      flex: 1;
      font-size: 0.75rem;
      color: var(--text-tertiary);
      text-align: right;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
  }
  
  .export-actions {
    padding: 1rem;
    border-top: 1px solid var(--border-secondary);
    display: flex;
    flex-direction: column;
    gap: 0.5rem;
    
    .copy-actions {
      display: flex;
      gap: 0.5rem;
      
      .el-button {
        flex: 1;
      }
    }
  }
}

.empty-tip {
  text-align: center;
  padding: 2rem 1rem;
  color: var(--text-tertiary);
  font-size: 0.8125rem;
}
</style>

