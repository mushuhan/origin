<script setup>
import { computed } from 'vue'
import { useStore } from 'vuex'
import { useRouter, useRoute } from 'vue-router'

const store = useStore()
const router = useRouter()
const route = useRoute()

const sidebarCollapsed = computed(() => store.state.sidebarCollapsed)
const categories = computed(() => store.state.categories)
const workspace = computed(() => store.state.workspace)

// 导航项
const navItems = computed(() => {
  const items = [
    {
      id: 'home',
      name: '首页',
      icon: 'HomeFilled',
      path: '/'
    },
    {
      id: 'workspace',
      name: '我的工作台',
      icon: 'Briefcase',
      path: '/customize',
      badge: workspace.value.length || null
    },
    {
      id: 'hot',
      name: '热门网址',
      icon: 'TrendCharts',
      path: '/hot'
    },
    {
      id: 'search',
      name: '搜索',
      icon: 'Search',
      path: '/search'
    }
  ]
  
  return items
})

// 分类导航
const categoryItems = computed(() => {
  return categories.value
    .filter(c => !c.is_system)
    .map(c => ({
      id: c.id,
      name: c.name,
      icon: c.icon || 'Folder',
      path: `/category/${c.id}`
    }))
})

// 当前激活项
const isActive = (path) => {
  if (path === '/') {
    return route.path === '/'
  }
  return route.path.startsWith(path)
}

// 导航
const navigate = (item) => {
  router.push(item.path)
}
</script>

<template>
  <aside class="app-sidebar" :class="{ 'is-collapsed': sidebarCollapsed }">
    <!-- 主导航 -->
    <nav class="sidebar-nav">
      <div class="nav-section">
        <div
          v-for="item in navItems"
          :key="item.id"
          class="nav-item"
          :class="{ 'is-active': isActive(item.path) }"
          @click="navigate(item)"
        >
          <el-icon class="nav-icon">
            <component :is="item.icon" />
          </el-icon>
          <span class="nav-text">{{ item.name }}</span>
          <span v-if="item.badge" class="nav-badge">{{ item.badge }}</span>
        </div>
      </div>
      
      <!-- 分类导航 -->
      <div class="nav-section" v-if="categoryItems.length > 0">
        <div class="section-title" v-if="!sidebarCollapsed">分类</div>
        <div class="section-divider" v-else></div>
        
        <div
          v-for="item in categoryItems"
          :key="item.id"
          class="nav-item"
          :class="{ 'is-active': isActive(item.path) }"
          @click="navigate(item)"
        >
          <el-icon class="nav-icon">
            <component :is="item.icon" />
          </el-icon>
          <span class="nav-text">{{ item.name }}</span>
        </div>
      </div>
    </nav>
    
    <!-- 底部 -->
    <div class="sidebar-footer">
      <div class="nav-item" @click="$router.push('/about')">
        <el-icon class="nav-icon"><InfoFilled /></el-icon>
        <span class="nav-text">关于</span>
      </div>
    </div>
  </aside>
</template>

<style lang="scss" scoped>
.app-sidebar {
  display: flex;
  flex-direction: column;
  width: var(--sidebar-width, 260px);
  background: var(--sidebar-bg);
  border-right: 1px solid var(--border-secondary);
  padding: 1rem 0.75rem;
  transition: width 0.3s ease;
  
  &.is-collapsed {
    width: var(--sidebar-collapsed-width, 72px);
    
    .nav-text,
    .section-title,
    .nav-badge {
      display: none;
    }
    
    .nav-item {
      justify-content: center;
      padding: 0.75rem;
    }
  }
}

.sidebar-nav {
  flex: 1;
  overflow-y: auto;
  overflow-x: hidden;
}

.nav-section {
  margin-bottom: 1.5rem;
  
  &:last-child {
    margin-bottom: 0;
  }
}

.section-title {
  font-size: 0.6875rem;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  color: var(--text-tertiary);
  padding: 0 0.75rem;
  margin-bottom: 0.5rem;
}

.section-divider {
  height: 1px;
  background: var(--border-secondary);
  margin: 0.5rem 0.75rem;
}

.nav-item {
  display: flex;
  align-items: center;
  gap: 0.75rem;
  padding: 0.625rem 0.75rem;
  margin-bottom: 2px;
  border-radius: 10px;
  cursor: pointer;
  transition: all 0.15s ease;
  color: var(--text-secondary);
  
  &:hover {
    background: var(--bg-tertiary);
    color: var(--text-primary);
  }
  
  &.is-active {
    background: var(--accent-light);
    color: var(--accent);
    
    .nav-icon {
      color: var(--accent);
    }
  }
}

.nav-icon {
  font-size: 18px;
  flex-shrink: 0;
}

.nav-text {
  flex: 1;
  font-size: 0.875rem;
  font-weight: 500;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.nav-badge {
  font-size: 0.6875rem;
  font-weight: 600;
  padding: 2px 6px;
  background: var(--accent);
  color: white;
  border-radius: 10px;
  min-width: 18px;
  text-align: center;
}

.sidebar-footer {
  padding-top: 1rem;
  border-top: 1px solid var(--border-secondary);
}
</style>
