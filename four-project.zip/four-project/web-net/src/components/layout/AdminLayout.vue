<script setup>
/**
 * 管理后台布局组件
 * 
 * 【设计说明】
 * - 左侧固定侧边栏：导航菜单
 * - 顶部 Header：显示管理员信息和操作
 * - 主内容区：路由视图
 * - 复用现有的设计语言（TailwindCSS + Element Plus）
 */
import { computed, ref } from 'vue'
import { useStore } from 'vuex'
import { useRouter, useRoute } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'

const store = useStore()
const router = useRouter()
const route = useRoute()

// 侧边栏折叠状态
const isCollapsed = ref(false)

// 当前用户
const currentUser = computed(() => store.getters['admin/currentUser'])
const userName = computed(() => store.getters['admin/userName'])

// 导航菜单
const menuItems = [
  {
    index: '/admin',
    title: '仪表盘',
    icon: 'DataAnalysis'
  },
  {
    index: '/admin/users',
    title: '用户管理',
    icon: 'User'
  },
  {
    index: '/admin/import',
    title: '数据导入',
    icon: 'Upload'
  },
  {
    index: '/admin/settings',
    title: '系统设置',
    icon: 'Setting'
  }
]

// 当前激活菜单
const activeMenu = computed(() => {
  // 精确匹配或前缀匹配
  const path = route.path
  if (path === '/admin' || path === '/admin/') {
    return '/admin'
  }
  return path
})

// 切换侧边栏
const toggleSidebar = () => {
  isCollapsed.value = !isCollapsed.value
}

// 菜单点击
const handleMenuSelect = (index) => {
  router.push(index)
}

// 登出
const handleLogout = async () => {
  try {
    await ElMessageBox.confirm(
      '确定要退出登录吗？',
      '确认登出',
      {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }
    )
    
    await store.dispatch('admin/logout')
    ElMessage.success('已退出登录')
    router.push({ name: 'AdminLogin' })
  } catch (e) {
    // 用户取消
  }
}

// 返回前台
const goToFrontend = () => {
  router.push('/')
}
</script>

<template>
  <div class="admin-layout" :class="{ 'sidebar-collapsed': isCollapsed }">
    <!-- 侧边栏 -->
    <aside class="admin-sidebar">
      <!-- Logo -->
      <div class="sidebar-header">
        <div class="logo-wrapper">
          <el-icon class="logo-icon" :size="28">
            <DataBoard />
          </el-icon>
          <span class="logo-text" v-if="!isCollapsed">管理后台</span>
        </div>
        <el-button 
          class="collapse-btn"
          :icon="isCollapsed ? 'Expand' : 'Fold'"
          text
          @click="toggleSidebar"
        />
      </div>
      
      <!-- 导航菜单 -->
      <el-menu
        :default-active="activeMenu"
        class="admin-menu"
        :collapse="isCollapsed"
        :collapse-transition="false"
        @select="handleMenuSelect"
      >
        <el-menu-item 
          v-for="item in menuItems" 
          :key="item.index"
          :index="item.index"
        >
          <el-icon><component :is="item.icon" /></el-icon>
          <template #title>{{ item.title }}</template>
        </el-menu-item>
      </el-menu>
      
      <!-- 底部操作 -->
      <div class="sidebar-footer">
        <el-button 
          class="footer-btn"
          text
          @click="goToFrontend"
        >
          <el-icon><Back /></el-icon>
          <span v-if="!isCollapsed">返回前台</span>
        </el-button>
      </div>
    </aside>
    
    <!-- 主内容区 -->
    <div class="admin-main">
      <!-- 顶部 Header -->
      <header class="admin-header">
        <div class="header-left">
          <el-breadcrumb separator="/">
            <el-breadcrumb-item :to="{ path: '/admin' }">
              管理后台
            </el-breadcrumb-item>
            <el-breadcrumb-item v-if="route.meta.title && route.name !== 'AdminDashboard'">
              {{ route.meta.title }}
            </el-breadcrumb-item>
          </el-breadcrumb>
        </div>
        
        <div class="header-right">
          <!-- 用户信息 -->
          <el-dropdown trigger="click" @command="handleLogout">
            <div class="user-info">
              <el-avatar 
                :size="32" 
                :src="currentUser?.avatar"
              >
                {{ userName.charAt(0).toUpperCase() }}
              </el-avatar>
              <span class="user-name">{{ userName }}</span>
              <el-icon class="dropdown-icon"><ArrowDown /></el-icon>
            </div>
            <template #dropdown>
              <el-dropdown-menu>
                <el-dropdown-item disabled>
                  <el-icon><User /></el-icon>
                  {{ currentUser?.email }}
                </el-dropdown-item>
                <el-dropdown-item divided command="logout">
                  <el-icon><SwitchButton /></el-icon>
                  退出登录
                </el-dropdown-item>
              </el-dropdown-menu>
            </template>
          </el-dropdown>
        </div>
      </header>
      
      <!-- 内容区 -->
      <main class="admin-content">
        <router-view v-slot="{ Component }">
          <transition name="fade" mode="out-in">
            <component :is="Component" />
          </transition>
        </router-view>
      </main>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.admin-layout {
  display: flex;
  min-height: 100vh;
  background: var(--bg-primary, #f5f5f7);
}

// ==================== 侧边栏 ====================
.admin-sidebar {
  display: flex;
  flex-direction: column;
  width: 240px;
  background: var(--sidebar-bg, #ffffff);
  border-right: 1px solid var(--border-secondary, #e5e5e5);
  transition: width 0.3s ease;
  
  .sidebar-collapsed & {
    width: 64px;
  }
}

.sidebar-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 16px;
  border-bottom: 1px solid var(--border-secondary, #e5e5e5);
}

.logo-wrapper {
  display: flex;
  align-items: center;
  gap: 10px;
  
  .logo-icon {
    color: var(--accent, #3b82f6);
  }
  
  .logo-text {
    font-size: 16px;
    font-weight: 600;
    color: var(--text-primary, #171717);
    white-space: nowrap;
  }
}

.collapse-btn {
  padding: 8px;
  
  .sidebar-collapsed & {
    display: none;
  }
}

.admin-menu {
  flex: 1;
  border-right: none;
  padding: 8px;
  
  :deep(.el-menu-item) {
    margin-bottom: 4px;
    border-radius: 8px;
    height: 44px;
    
    &.is-active {
      background: var(--accent-light, rgba(59, 130, 246, 0.1));
      color: var(--accent, #3b82f6);
    }
    
    &:hover {
      background: var(--bg-tertiary, #f5f5f7);
    }
  }
}

.sidebar-footer {
  padding: 16px;
  border-top: 1px solid var(--border-secondary, #e5e5e5);
  
  .footer-btn {
    width: 100%;
    justify-content: flex-start;
    gap: 8px;
    color: var(--text-secondary, #737373);
    
    &:hover {
      color: var(--accent, #3b82f6);
    }
  }
}

// ==================== 主内容区 ====================
.admin-main {
  flex: 1;
  display: flex;
  flex-direction: column;
  min-width: 0;
}

.admin-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 64px;
  padding: 0 24px;
  background: var(--card-bg, #ffffff);
  border-bottom: 1px solid var(--border-secondary, #e5e5e5);
  position: sticky;
  top: 0;
  z-index: 100;
}

.header-left {
  display: flex;
  align-items: center;
}

.header-right {
  display: flex;
  align-items: center;
  gap: 16px;
}

.user-info {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 6px 12px;
  border-radius: 8px;
  cursor: pointer;
  transition: background 0.2s;
  
  &:hover {
    background: var(--bg-tertiary, #f5f5f7);
  }
  
  .user-name {
    font-size: 14px;
    font-weight: 500;
    color: var(--text-primary, #171717);
  }
  
  .dropdown-icon {
    color: var(--text-tertiary, #a3a3a3);
    font-size: 12px;
  }
}

.admin-content {
  flex: 1;
  padding: 24px;
  overflow-y: auto;
}

// ==================== 过渡动画 ====================
.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.2s ease;
}

.fade-enter-from,
.fade-leave-to {
  opacity: 0;
}

// ==================== 响应式 ====================
@media (max-width: 768px) {
  .admin-sidebar {
    position: fixed;
    left: 0;
    top: 0;
    height: 100vh;
    z-index: 1000;
    transform: translateX(-100%);
    
    &.is-open {
      transform: translateX(0);
    }
  }
  
  .admin-header {
    padding: 0 16px;
  }
  
  .admin-content {
    padding: 16px;
  }
}
</style>

