<script setup>
import { computed, ref } from 'vue'
import { useStore } from 'vuex'
import AppHeader from './AppHeader.vue'
import AppSidebar from './AppSidebar.vue'

const store = useStore()

const sidebarCollapsed = computed(() => store.state.sidebarCollapsed)
const isDark = computed(() => store.state.isDark)
</script>

<template>
  <div 
    class="main-layout"
    :class="{ 
      'sidebar-collapsed': sidebarCollapsed,
      'dark': isDark
    }"
  >
    <!-- 顶部导航 -->
    <AppHeader class="layout-header" />
    
    <!-- 侧边栏 -->
    <AppSidebar class="layout-sidebar" />
    
    <!-- 主内容区 -->
    <main class="layout-content">
      <div class="content-wrapper">
        <slot />
      </div>
    </main>
  </div>
</template>

<style lang="scss" scoped>
.main-layout {
  display: grid;
  grid-template-columns: var(--sidebar-width, 260px) 1fr;
  grid-template-rows: var(--header-height, 64px) 1fr;
  grid-template-areas:
    "header header"
    "sidebar content";
  min-height: 100vh;
  transition: grid-template-columns 0.3s ease;
  
  &.sidebar-collapsed {
    grid-template-columns: var(--sidebar-collapsed-width, 72px) 1fr;
  }
}

.layout-header {
  grid-area: header;
  position: sticky;
  top: 0;
  z-index: 100;
}

.layout-sidebar {
  grid-area: sidebar;
  position: sticky;
  top: var(--header-height, 64px);
  height: calc(100vh - var(--header-height, 64px));
  overflow-y: auto;
  overflow-x: hidden;
}

.layout-content {
  grid-area: content;
  min-height: calc(100vh - var(--header-height, 64px));
  background: var(--bg-primary);
  overflow-x: hidden;
}

.content-wrapper {
  max-width: 1600px;
  margin: 0 auto;
  padding: 1.5rem;
}

// 响应式
@media (max-width: 768px) {
  .main-layout {
    grid-template-columns: 1fr;
    grid-template-areas:
      "header"
      "content";
  }
  
  .layout-sidebar {
    display: none;
  }
  
  .content-wrapper {
    padding: 1rem;
  }
}
</style>
