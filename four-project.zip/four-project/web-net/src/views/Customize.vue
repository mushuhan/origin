<script setup>
import { ref, computed, onMounted, nextTick } from 'vue'
import { useRouter } from 'vue-router'
import { useStore } from 'vuex'
import { ElMessageBox, ElMessage } from 'element-plus'
import FolderTree from '@/components/common/FolderTree.vue'
import WebsiteCard from '@/components/common/WebsiteCard.vue'
import AddWebsiteDialog from '@/components/common/AddWebsiteDialog.vue'
import FilePreviewDrawer from '@/components/common/FilePreviewDrawer.vue'
import ContextMenu from '@/components/common/ContextMenu.vue'
import {
  getFileList,
  uploadFile,
  deleteFile,
  updateFile,
  previewFile as previewFileAPI,
  getUserToken
} from '@/api'

const router = useRouter()
const store = useStore()

// ==================== 标签页切换 ====================
const activeTab = ref('sites') // 'sites' | 'files'

// ==================== 网址管理状态 ====================
const workspace = computed(() => store.state.workspace)
const siteFolders = computed(() => store.state.folders)  // 网址文件夹
const loading = ref(false)

const selectedSiteFolderId = ref(null)
const expandedSiteFolderIds = ref([])
const showAddDialog = ref(false)

// ==================== 文件管理状态 ====================
const fileFolders = computed(() => store.state.fileFolders)  // 数据文件文件夹
const files = ref([])
const filesLoading = ref(false)
const viewMode = ref('list') // 'list' | 'grid'

const selectedFileFolderId = ref(null)
const expandedFileFolderIds = ref([])

// 拖拽上传
const isDragging = ref(false)
const uploadInputRef = ref(null)

// 预览抽屉
const previewDrawerVisible = ref(false)
const previewFile_ = ref(null)
const previewLoading = ref(false)
const previewData = ref(null)

// 右键菜单
const contextMenuVisible = ref(false)
const contextMenuPosition = ref({ x: 0, y: 0 })
const contextMenuItem = ref(null)

// 重命名
const renamingId = ref(null)
const renamingName = ref('')
const renameInputRef = ref(null)

// ==================== 通用工具函数 ====================

// 递归查找文件夹路径
const findFolderPath = (list, id, path = []) => {
  for (const folder of list) {
    if (folder.id === id) {
      return [...path, folder]
    }
    if (folder.children && folder.children.length > 0) {
      const result = findFolderPath(folder.children, id, [...path, folder])
      if (result) return result
    }
  }
  return null
}

const findFolderById = (list, id) => {
  for (const folder of list) {
    if (folder.id === id) return folder
    if (folder.children) {
      const found = findFolderById(folder.children, id)
      if (found) return found
    }
  }
  return null
}

// ==================== 网址计算属性 ====================

// 网址当前文件夹路径（面包屑用）
const siteFolderPath = computed(() => {
  if (!selectedSiteFolderId.value) return []
  return findFolderPath(siteFolders.value, selectedSiteFolderId.value) || []
})

const currentSiteFolder = computed(() => {
  if (!selectedSiteFolderId.value) return null
  return findFolderById(siteFolders.value, selectedSiteFolderId.value)
})

const currentSites = computed(() => {
  if (selectedSiteFolderId.value && currentSiteFolder.value) {
    return currentSiteFolder.value.sites || []
  }
  return workspace.value
})

// ==================== 文件计算属性 ====================

// 文件当前文件夹路径（面包屑用）
const fileFolderPath = computed(() => {
  if (!selectedFileFolderId.value) return []
  return findFolderPath(fileFolders.value, selectedFileFolderId.value) || []
})

const currentFileFolder = computed(() => {
  if (!selectedFileFolderId.value) return null
  return findFolderById(fileFolders.value, selectedFileFolderId.value)
})

// 文件图标
const fileTypeIcon = (type) => {
  const icons = { csv: 'Document', xlsx: 'Document', xls: 'Document', parquet: 'DataAnalysis' }
  return icons[type] || 'Document'
}

// 格式化日期
const formatDate = (dateStr) => {
  if (!dateStr) return '-'
  const date = new Date(dateStr)
  const now = new Date()
  const diff = now - date
  if (diff < 60000) return '刚刚'
  if (diff < 3600000) return `${Math.floor(diff / 60000)} 分钟前`
  if (diff < 86400000) return `${Math.floor(diff / 3600000)} 小时前`
  if (diff < 604800000) return `${Math.floor(diff / 86400000)} 天前`
  return date.toLocaleDateString('zh-CN')
}

// ==================== 网址文件夹操作 ====================

const handleSiteFolderSelect = (folder) => {
  selectedSiteFolderId.value = folder.id
}

const handleSiteFolderToggle = (id) => {
  const index = expandedSiteFolderIds.value.indexOf(id)
  if (index > -1) {
    expandedSiteFolderIds.value.splice(index, 1)
  } else {
    expandedSiteFolderIds.value.push(id)
  }
}

const handleSiteFolderCreate = async (data) => {
  try {
    // 创建网址分类的文件夹
    await store.dispatch('createFolder', { ...data, category: 'sites' })
    ElMessage.success('文件夹创建成功')
  } catch (e) {
    ElMessage.error('创建文件夹失败')
  }
}

const handleSiteFolderRename = async (id, name) => {
  try {
    await store.dispatch('updateFolder', { id, data: { name } })
    ElMessage.success('重命名成功')
  } catch (e) {
    ElMessage.error('重命名失败')
  }
}

const handleSiteFolderDelete = async (folder) => {
  try {
    await ElMessageBox.confirm(
      `确定要删除文件夹"${folder.name}"吗？文件夹中的网址将移至根目录。`,
      '删除确认',
      { confirmButtonText: '删除', cancelButtonText: '取消', type: 'warning' }
    )
    await store.dispatch('deleteFolder', folder.id)
    if (selectedSiteFolderId.value === folder.id) {
      selectedSiteFolderId.value = null
    }
    ElMessage.success('删除成功')
  } catch (e) {
    // 用户取消
  }
}

const viewAllSites = () => {
  selectedSiteFolderId.value = null
}

// 网址面包屑导航
const navigateToSiteFolder = (folder) => {
  if (!folder) {
    viewAllSites()
    return
  }
  selectedSiteFolderId.value = folder.id
  const path = findFolderPath(siteFolders.value, folder.id) || []
  path.forEach(f => {
    if (!expandedSiteFolderIds.value.includes(f.id)) {
      expandedSiteFolderIds.value.push(f.id)
    }
  })
}

// ==================== 文件文件夹操作 ====================

const handleFileFolderSelect = (folder) => {
  selectedFileFolderId.value = folder.id
  loadFiles(folder.id)
}

const handleFileFolderToggle = (id) => {
  const index = expandedFileFolderIds.value.indexOf(id)
  if (index > -1) {
    expandedFileFolderIds.value.splice(index, 1)
  } else {
    expandedFileFolderIds.value.push(id)
  }
}

const handleFileFolderCreate = async (data) => {
  try {
    // 创建数据文件分类的文件夹
    await store.dispatch('createFolder', { ...data, category: 'files' })
    ElMessage.success('文件夹创建成功')
    // 刷新文件夹列表
    await store.dispatch('fetchFileFolders')
  } catch (e) {
    ElMessage.error('创建文件夹失败')
  }
}

const handleFileFolderRename = async (id, name) => {
  try {
    await store.dispatch('updateFolder', { id, data: { name } })
    ElMessage.success('重命名成功')
    await store.dispatch('fetchFileFolders')
  } catch (e) {
    ElMessage.error('重命名失败')
  }
}

const handleFileFolderDelete = async (folder) => {
  try {
    await ElMessageBox.confirm(
      `确定要删除文件夹"${folder.name}"吗？文件夹中的文件将移至根目录。`,
      '删除确认',
      { confirmButtonText: '删除', cancelButtonText: '取消', type: 'warning' }
    )
    await store.dispatch('deleteFolder', folder.id)
    if (selectedFileFolderId.value === folder.id) {
      selectedFileFolderId.value = null
    }
    ElMessage.success('删除成功')
    await store.dispatch('fetchFileFolders')
    await loadFiles(selectedFileFolderId.value)
  } catch (e) {
    // 用户取消
  }
}

const viewAllFiles = () => {
  selectedFileFolderId.value = null
  loadFiles(null)
}

// 文件面包屑导航
const navigateToFileFolder = (folder) => {
  if (!folder) {
    viewAllFiles()
    return
  }
  selectedFileFolderId.value = folder.id
  const path = findFolderPath(fileFolders.value, folder.id) || []
  path.forEach(f => {
    if (!expandedFileFolderIds.value.includes(f.id)) {
      expandedFileFolderIds.value.push(f.id)
    }
  })
  loadFiles(folder.id)
}

// ==================== 网址操作 ====================

const handleRemoveWebsite = async (website) => {
  try {
    await ElMessageBox.confirm(
      `确定要从工作台移除"${website.name}"吗？`,
      '移除确认',
      { confirmButtonText: '移除', cancelButtonText: '取消', type: 'warning' }
    )
    await store.dispatch('removeFromWorkspace', website.id)
    ElMessage.success('移除成功')
  } catch (e) {
    // 用户取消
  }
}

const handleAddWebsite = async (data) => {
  try {
    await store.dispatch('addToWorkspace', {
      ...data,
      folder_id: selectedSiteFolderId.value
    })
    showAddDialog.value = false
    ElMessage.success('添加成功')
  } catch (e) {
    ElMessage.error('添加失败')
  }
}

// ==================== 文件操作 ====================

const loadFiles = async (folderId = null) => {
  filesLoading.value = true
  try {
    const data = await getFileList(folderId)
    files.value = data || []
  } catch (error) {
    console.error('加载文件失败:', error)
    ElMessage.error('加载文件失败')
  } finally {
    filesLoading.value = false
  }
}

// 上传相关
const triggerUpload = () => {
  uploadInputRef.value?.click()
}

const handleFileSelect = async (event) => {
  const selectedFiles = event.target.files
  if (!selectedFiles.length) return
  await uploadFiles(Array.from(selectedFiles))
  event.target.value = ''
}

const uploadFiles = async (fileList) => {
  for (const file of fileList) {
    try {
      await uploadFile(file, selectedFileFolderId.value)
      ElMessage.success(`${file.name} 上传成功`)
    } catch (error) {
      ElMessage.error(`${file.name} 上传失败: ${error.message}`)
    }
  }
  await loadFiles(selectedFileFolderId.value)
}

// 拖拽上传
const handleDragEnter = (e) => {
  if (activeTab.value !== 'files') return
  e.preventDefault()
  isDragging.value = true
}

const handleDragLeave = (e) => {
  e.preventDefault()
  if (!e.currentTarget.contains(e.relatedTarget)) {
    isDragging.value = false
  }
}

const handleDragOver = (e) => {
  e.preventDefault()
}

const handleDrop = async (e) => {
  e.preventDefault()
  isDragging.value = false
  if (activeTab.value !== 'files') return
  
  const droppedFiles = Array.from(e.dataTransfer.files)
  const validFiles = droppedFiles.filter(file => {
    const ext = file.name.split('.').pop().toLowerCase()
    return ['csv', 'xlsx', 'xls', 'parquet'].includes(ext)
  })
  
  if (validFiles.length === 0) {
    ElMessage.warning('仅支持 CSV、Excel、Parquet 文件')
    return
  }
  await uploadFiles(validFiles)
}

// 文件点击
const handleFileClick = async (file) => {
  if (['csv', 'xlsx', 'xls', 'parquet'].includes(file.file_type)) {
    await openPreview(file)
  }
}

// 预览
const openPreview = async (file) => {
  previewFile_.value = file
  previewDrawerVisible.value = true
  previewLoading.value = true
  previewData.value = null
  
  try {
    const data = await previewFileAPI(file.id)
    previewData.value = data
  } catch (error) {
    ElMessage.error('预览加载失败')
  } finally {
    previewLoading.value = false
  }
}

const closePreview = () => {
  previewDrawerVisible.value = false
  previewFile_.value = null
  previewData.value = null
}

const handleGoToDashboard = (file) => {
  router.push({ path: '/dashboard', query: { file_id: file.id } })
}

const handleDownload = async (file) => {
  try {
    // 使用 fetch 带 Token 下载
    const token = getUserToken()
    const response = await fetch(`/api/files/download/${file.id}`, {
      headers: {
        'X-User-Token': token
      }
    })
    
    if (!response.ok) {
      throw new Error('下载失败')
    }
    
    // 创建 Blob 并下载
    const blob = await response.blob()
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = file.filename
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    window.URL.revokeObjectURL(url)
    
    ElMessage.success('下载成功')
  } catch (error) {
    ElMessage.error('下载失败')
  }
}

const handleDeleteFile = async (file) => {
  try {
    await ElMessageBox.confirm(
      `确定要删除 "${file.filename}" 吗？此操作不可恢复。`,
      '删除确认',
      { type: 'warning' }
    )
    await deleteFile(file.id)
    ElMessage.success('删除成功')
    await loadFiles(selectedFileFolderId.value)
    if (previewFile_.value?.id === file.id) {
      closePreview()
    }
  } catch (error) {
    if (error !== 'cancel') {
      ElMessage.error(error.message || '删除失败')
    }
  }
}

// ==================== 右键菜单 ====================

const handleContextMenu = (e, file) => {
  e.preventDefault()
  contextMenuItem.value = file
  contextMenuPosition.value = { x: e.clientX, y: e.clientY }
  contextMenuVisible.value = true
}

const closeContextMenu = () => {
  contextMenuVisible.value = false
  contextMenuItem.value = null
}

const handleContextMenuAction = async (action) => {
  const file = contextMenuItem.value
  closeContextMenu()
  
  switch (action) {
    case 'preview':
      await openPreview(file)
      break
    case 'rename':
      startRename(file)
      break
    case 'dashboard':
      handleGoToDashboard(file)
      break
    case 'download':
      handleDownload(file)
      break
    case 'delete':
      await handleDeleteFile(file)
      break
  }
}

// ==================== 重命名 ====================

const startRename = (file) => {
  renamingId.value = file.id
  const nameWithoutExt = file.filename.replace(/\.[^/.]+$/, '')
  renamingName.value = nameWithoutExt
  nextTick(() => {
    renameInputRef.value?.focus()
    renameInputRef.value?.select()
  })
}

const confirmRename = async (file) => {
  if (!renamingName.value.trim()) {
    cancelRename()
    return
  }
  try {
    const newName = `${renamingName.value.trim()}.${file.file_type}`
    await updateFile(file.id, { filename: newName })
    ElMessage.success('重命名成功')
    await loadFiles(selectedFileFolderId.value)
  } catch (error) {
    ElMessage.error(error.message || '重命名失败')
  }
  cancelRename()
}

const cancelRename = () => {
  renamingId.value = null
  renamingName.value = ''
}

// ==================== 标签切换 ====================

const switchTab = (tab) => {
  activeTab.value = tab
  if (tab === 'files') {
    // 切换到文件标签时加载文件夹和文件
    store.dispatch('fetchFileFolders')
    loadFiles(selectedFileFolderId.value)
  }
}

// ==================== 生命周期 ====================

onMounted(() => {
  // 加载网址工作台数据（包括网址文件夹）
  store.dispatch('fetchWorkspace')
  // 预加载文件文件夹
  store.dispatch('fetchFileFolders')
})

// 点击空白处关闭右键菜单
const handleGlobalClick = () => {
  if (contextMenuVisible.value) {
    closeContextMenu()
  }
}
</script>

<template>
  <div class="customize-page" @click="handleGlobalClick">
    <!-- 页面标题 -->
    <header class="page-header">
      <div class="header-icon">
        <el-icon><Briefcase /></el-icon>
      </div>
      <div class="header-content">
        <h1>我的工作台</h1>
        <p>管理您收藏的网站和数据文件</p>
      </div>
      <div class="header-actions">
        <template v-if="activeTab === 'sites'">
          <button class="btn btn-primary" @click="showAddDialog = true">
            <el-icon><Plus /></el-icon>
            添加网址
          </button>
        </template>
        <template v-else>
          <button class="btn btn-primary" @click="triggerUpload">
            <el-icon><Upload /></el-icon>
            上传文件
          </button>
          <div class="view-toggle">
            <button 
              class="view-btn"
              :class="{ 'is-active': viewMode === 'list' }"
              @click="viewMode = 'list'"
            >
              <el-icon><List /></el-icon>
            </button>
            <button 
              class="view-btn"
              :class="{ 'is-active': viewMode === 'grid' }"
              @click="viewMode = 'grid'"
            >
              <el-icon><Grid /></el-icon>
            </button>
          </div>
        </template>
      </div>
    </header>

    <!-- 标签页切换 -->
    <div class="tab-switcher">
      <button 
        class="tab-btn"
        :class="{ 'is-active': activeTab === 'sites' }"
        @click="switchTab('sites')"
      >
        <el-icon><Link /></el-icon>
        网址收藏
        <span class="tab-count">{{ workspace.length }}</span>
      </button>
      <button 
        class="tab-btn"
        :class="{ 'is-active': activeTab === 'files' }"
        @click="switchTab('files')"
      >
        <el-icon><Document /></el-icon>
        数据文件
        <span class="tab-count">{{ files.length }}</span>
      </button>
    </div>

    <!-- 文件上传输入（隐藏） -->
    <input 
      ref="uploadInputRef"
      type="file"
      multiple
      accept=".csv,.xlsx,.xls,.parquet"
      style="display: none"
      @change="handleFileSelect"
    />
    
    <!-- 双栏布局 -->
    <div class="content-layout">
      <!-- 左侧：文件夹树 -->
      <aside class="folder-panel">
        <div class="panel-header">
          <h3>{{ activeTab === 'sites' ? '网址文件夹' : '文件夹' }}</h3>
        </div>
        
        <!-- 网址模式 -->
        <template v-if="activeTab === 'sites'">
          <div 
            class="all-sites-item"
            :class="{ 'is-active': !selectedSiteFolderId }"
            @click="viewAllSites"
          >
            <el-icon><Grid /></el-icon>
            <span>全部网址</span>
            <span class="count">{{ workspace.length }}</span>
          </div>
          
          <FolderTree
            :folders="siteFolders"
            :selected-id="selectedSiteFolderId"
            :expanded-ids="expandedSiteFolderIds"
            :editable="true"
            @select="handleSiteFolderSelect"
            @toggle="handleSiteFolderToggle"
            @create="handleSiteFolderCreate"
            @rename="handleSiteFolderRename"
            @delete="handleSiteFolderDelete"
          />
        </template>
        
        <!-- 文件模式 -->
        <template v-else>
          <div 
            class="all-sites-item"
            :class="{ 'is-active': !selectedFileFolderId }"
            @click="viewAllFiles"
          >
            <el-icon><Document /></el-icon>
            <span>全部文件</span>
            <span class="count">{{ files.length }}</span>
          </div>
          
          <FolderTree
            :folders="fileFolders"
            :selected-id="selectedFileFolderId"
            :expanded-ids="expandedFileFolderIds"
            :editable="true"
            @select="handleFileFolderSelect"
            @toggle="handleFileFolderToggle"
            @create="handleFileFolderCreate"
            @rename="handleFileFolderRename"
            @delete="handleFileFolderDelete"
          />
        </template>
      </aside>
      
      <!-- 右侧：内容区 -->
      <main 
        class="content-panel"
        @dragenter="handleDragEnter"
        @dragleave="handleDragLeave"
        @dragover="handleDragOver"
        @drop="handleDrop"
      >
        <!-- 面包屑导航 -->
        <div class="panel-header">
          <nav class="breadcrumb-nav">
            <!-- 网址模式面包屑 -->
            <template v-if="activeTab === 'sites'">
              <div 
                class="breadcrumb-home"
                :class="{ 'is-active': !selectedSiteFolderId }"
                @click="viewAllSites"
                title="返回首页"
              >
                <el-icon><HomeFilled /></el-icon>
                <span>首页</span>
              </div>
              
              <template v-for="(folder, index) in siteFolderPath" :key="folder.id">
                <el-icon class="breadcrumb-arrow"><ArrowRight /></el-icon>
                <div 
                  class="breadcrumb-item"
                  :class="{ 'is-current': index === siteFolderPath.length - 1 }"
                  @click="index < siteFolderPath.length - 1 && navigateToSiteFolder(folder)"
                >
                  <el-icon class="folder-icon"><Folder /></el-icon>
                  <span>{{ folder.name }}</span>
                </div>
              </template>
            </template>
            
            <!-- 文件模式面包屑 -->
            <template v-else>
              <div 
                class="breadcrumb-home"
                :class="{ 'is-active': !selectedFileFolderId }"
                @click="viewAllFiles"
                title="返回首页"
              >
                <el-icon><HomeFilled /></el-icon>
                <span>首页</span>
              </div>
              
              <template v-for="(folder, index) in fileFolderPath" :key="folder.id">
                <el-icon class="breadcrumb-arrow"><ArrowRight /></el-icon>
                <div 
                  class="breadcrumb-item"
                  :class="{ 'is-current': index === fileFolderPath.length - 1 }"
                  @click="index < fileFolderPath.length - 1 && navigateToFileFolder(folder)"
                >
                  <el-icon class="folder-icon"><Folder /></el-icon>
                  <span>{{ folder.name }}</span>
                </div>
              </template>
            </template>
          </nav>
          
          <span class="item-count">
            {{ activeTab === 'sites' ? `${currentSites.length} 个网址` : `${files.length} 个文件` }}
          </span>
        </div>

        <!-- ==================== 网址内容 ==================== -->
        <template v-if="activeTab === 'sites'">
          <!-- 网址网格 -->
          <div v-if="currentSites.length > 0" class="sites-grid">
            <div v-for="site in currentSites" :key="site.id" class="site-item">
              <WebsiteCard :website="site" />
              <button class="remove-btn" @click="handleRemoveWebsite(site)" title="移除">
                <el-icon><Close /></el-icon>
              </button>
            </div>
          </div>
          
          <!-- 空状态 -->
          <div v-else class="empty-state">
            <el-icon :size="48"><FolderOpened /></el-icon>
            <h3>暂无网址</h3>
            <p>点击"添加网址"按钮添加您喜欢的网站</p>
            <button class="btn btn-secondary" @click="showAddDialog = true">
              <el-icon><Plus /></el-icon>
              添加网址
            </button>
          </div>
        </template>

        <!-- ==================== 文件内容 ==================== -->
        <template v-else>
          <!-- 拖拽上传遮罩 -->
          <transition name="fade">
            <div v-if="isDragging" class="drop-overlay">
              <div class="drop-zone">
                <el-icon class="drop-icon"><Upload /></el-icon>
                <p class="drop-text">释放文件以上传</p>
                <p class="drop-hint">支持 CSV, Excel, Parquet 格式</p>
              </div>
            </div>
          </transition>

          <!-- 加载状态 -->
          <div v-if="filesLoading" class="loading-state">
            <el-icon class="is-loading"><Loading /></el-icon>
            <span>加载中...</span>
          </div>

          <!-- 空状态 -->
          <div v-else-if="files.length === 0" class="empty-state">
            <el-icon :size="48"><Document /></el-icon>
            <h3>暂无文件</h3>
            <p>拖拽文件到此处或点击上传按钮</p>
            <button class="btn btn-secondary" @click="triggerUpload">
              <el-icon><Upload /></el-icon>
              上传文件
            </button>
          </div>

          <!-- 列表视图 -->
          <div v-else-if="viewMode === 'list'" class="file-list">
            <div class="list-header">
              <span class="col-name">名称</span>
              <span class="col-size">大小</span>
              <span class="col-rows">行数</span>
              <span class="col-cols">列数</span>
              <span class="col-date">修改时间</span>
              <span class="col-actions">操作</span>
            </div>
            
            <div 
              v-for="file in files" 
              :key="file.id"
              class="list-item"
              @click="handleFileClick(file)"
              @contextmenu="handleContextMenu($event, file)"
            >
              <div class="col-name">
                <el-icon class="file-icon" :class="`type-${file.file_type}`">
                  <component :is="fileTypeIcon(file.file_type)" />
                </el-icon>
                
                <input 
                  v-if="renamingId === file.id"
                  ref="renameInputRef"
                  v-model="renamingName"
                  class="rename-input"
                  @click.stop
                  @keyup.enter="confirmRename(file)"
                  @keyup.esc="cancelRename"
                  @blur="confirmRename(file)"
                />
                <span v-else class="file-name">{{ file.filename }}</span>
              </div>
              <span class="col-size">{{ file.file_size_formatted }}</span>
              <span class="col-rows">{{ file.row_count?.toLocaleString() }}</span>
              <span class="col-cols">{{ file.column_count }}</span>
              <span class="col-date">{{ formatDate(file.updated_at) }}</span>
              <div class="col-actions" @click.stop>
                <el-tooltip content="预览">
                  <button class="icon-btn" @click="openPreview(file)">
                    <el-icon><View /></el-icon>
                  </button>
                </el-tooltip>
                <el-tooltip content="去画图">
                  <button class="icon-btn" @click="handleGoToDashboard(file)">
                    <el-icon><DataAnalysis /></el-icon>
                  </button>
                </el-tooltip>
                <el-tooltip content="下载">
                  <button class="icon-btn" @click="handleDownload(file)">
                    <el-icon><Download /></el-icon>
                  </button>
                </el-tooltip>
                <el-tooltip content="更多">
                  <button class="icon-btn" @click="handleContextMenu($event, file)">
                    <el-icon><More /></el-icon>
                  </button>
                </el-tooltip>
              </div>
            </div>
          </div>

          <!-- 网格视图 -->
          <div v-else class="file-grid">
            <div 
              v-for="file in files" 
              :key="file.id"
              class="grid-item"
              @click="handleFileClick(file)"
              @contextmenu="handleContextMenu($event, file)"
            >
              <div class="grid-icon">
                <el-icon :class="`type-${file.file_type}`">
                  <component :is="fileTypeIcon(file.file_type)" />
                </el-icon>
              </div>
              
              <input 
                v-if="renamingId === file.id"
                ref="renameInputRef"
                v-model="renamingName"
                class="rename-input grid"
                @click.stop
                @keyup.enter="confirmRename(file)"
                @keyup.esc="cancelRename"
                @blur="confirmRename(file)"
              />
              <span v-else class="grid-name">{{ file.filename }}</span>
              
              <span class="grid-meta">{{ file.file_size_formatted }} · {{ file.row_count }} 行</span>
            </div>
          </div>
        </template>
      </main>
    </div>
    
    <!-- 添加网址对话框 -->
    <AddWebsiteDialog
      v-model:visible="showAddDialog"
      :folder-id="selectedSiteFolderId"
      @submit="handleAddWebsite"
    />

    <!-- 文件预览抽屉 -->
    <FilePreviewDrawer
      :visible="previewDrawerVisible"
      :file="previewFile_"
      :data="previewData"
      :loading="previewLoading"
      @close="closePreview"
      @go-dashboard="handleGoToDashboard"
      @download="handleDownload"
      @delete="handleDeleteFile"
    />

    <!-- 右键菜单 -->
    <ContextMenu
      :visible="contextMenuVisible"
      :position="contextMenuPosition"
      :items="[
        { key: 'preview', label: '预览', icon: 'View' },
        { key: 'rename', label: '重命名', icon: 'Edit' },
        { key: 'dashboard', label: '去画图', icon: 'DataAnalysis' },
        { type: 'divider' },
        { key: 'download', label: '下载', icon: 'Download' },
        { type: 'divider' },
        { key: 'delete', label: '删除', icon: 'Delete', danger: true }
      ]"
      @select="handleContextMenuAction"
      @close="closeContextMenu"
    />
  </div>
</template>

<style lang="scss" scoped>
.customize-page {
  padding: 1rem 0;
}

.page-header {
  display: flex;
  align-items: center;
  gap: 1rem;
  margin-bottom: 1.5rem;
  
  .header-icon {
    width: 48px;
    height: 48px;
    border-radius: 14px;
    background: linear-gradient(135deg, #3B82F6, #8B5CF6);
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    box-shadow: 0 4px 16px rgba(59, 130, 246, 0.3);
    
    .el-icon {
      font-size: 24px;
    }
  }
  
  .header-content {
    flex: 1;
    
    h1 {
      font-size: 1.5rem;
      font-weight: 700;
      color: var(--text-primary);
      margin-bottom: 0.25rem;
    }
    
    p {
      font-size: 0.875rem;
      color: var(--text-tertiary);
    }
  }

  .header-actions {
    display: flex;
    align-items: center;
    gap: 0.75rem;
  }
}

// 标签切换
.tab-switcher {
  display: flex;
  gap: 0.5rem;
  margin-bottom: 1.5rem;
  padding: 0.375rem;
  background: var(--bg-tertiary);
  border-radius: 12px;
  width: fit-content;
}

.tab-btn {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.625rem 1.25rem;
  font-size: 0.875rem;
  font-weight: 500;
  color: var(--text-secondary);
  border-radius: 8px;
  transition: all 0.2s ease;
  
  &:hover {
    color: var(--text-primary);
  }
  
  &.is-active {
    background: var(--card-bg);
    color: var(--text-primary);
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
  }
  
  .el-icon {
    font-size: 16px;
  }
  
  .tab-count {
    font-size: 0.75rem;
    padding: 2px 6px;
    background: var(--bg-tertiary);
    border-radius: 4px;
    color: var(--text-tertiary);
    
    .is-active & {
      background: var(--accent-light);
      color: var(--accent);
    }
  }
}

// 视图切换
.view-toggle {
  display: flex;
  background: var(--bg-tertiary);
  border-radius: 8px;
  padding: 2px;
}

.view-btn {
  width: 32px;
  height: 32px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 6px;
  color: var(--text-tertiary);
  transition: all 0.15s ease;
  
  &:hover {
    color: var(--text-primary);
  }
  
  &.is-active {
    background: var(--card-bg);
    color: var(--accent);
    box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05);
  }
}

.btn {
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.625rem 1rem;
  font-size: 0.875rem;
  font-weight: 500;
  border-radius: 10px;
  transition: all 0.2s ease;
}

.btn-primary {
  background: var(--text-primary);
  color: var(--text-inverse);
  
  &:hover {
    opacity: 0.9;
  }
}

.btn-secondary {
  background: var(--bg-tertiary);
  color: var(--text-primary);
  
  &:hover {
    background: var(--border-primary);
  }
}

.content-layout {
  display: grid;
  grid-template-columns: 280px 1fr;
  gap: 1.5rem;
  
  @media (max-width: 768px) {
    grid-template-columns: 1fr;
  }
}

.folder-panel {
  background: var(--card-bg);
  border-radius: 16px;
  border: 1px solid var(--border-secondary);
  padding: 1rem;
  height: fit-content;
  position: sticky;
  top: calc(var(--header-height, 64px) + 1.5rem);
  
  .panel-header {
    margin-bottom: 1rem;
    
    h3 {
      font-size: 0.875rem;
      font-weight: 600;
      color: var(--text-primary);
    }
  }
}

.all-sites-item {
  display: flex;
  align-items: center;
  gap: 0.625rem;
  padding: 0.625rem 0.75rem;
  margin-bottom: 0.5rem;
  border-radius: 10px;
  cursor: pointer;
  color: var(--text-secondary);
  transition: all 0.15s ease;
  
  &:hover {
    background: var(--bg-tertiary);
    color: var(--text-primary);
  }
  
  &.is-active {
    background: var(--accent-light);
    color: var(--accent);
  }
  
  .el-icon {
    font-size: 16px;
  }
  
  span:not(.count) {
    flex: 1;
    font-size: 0.875rem;
    font-weight: 500;
  }
  
  .count {
    font-size: 0.75rem;
    padding: 2px 6px;
    background: var(--bg-tertiary);
    border-radius: 4px;
  }
}

.content-panel {
  position: relative;
  
  .panel-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 1.25rem;
    padding-bottom: 1rem;
    border-bottom: 1px solid #e5e7eb;
    
    :root.dark & {
      border-bottom-color: var(--border-secondary);
    }
  }
  
  .item-count {
    font-size: 0.8125rem;
    color: #6b7280;
    flex-shrink: 0;
    
    :root.dark & {
      color: var(--text-tertiary);
    }
  }
}

// 面包屑导航
.breadcrumb-nav {
  display: flex;
  align-items: center;
  gap: 0.25rem;
  flex-wrap: wrap;
  min-width: 0;
}

.breadcrumb-home {
  display: flex;
  align-items: center;
  gap: 0.375rem;
  padding: 0.375rem 0.75rem;
  font-size: 0.8125rem;
  font-weight: 500;
  color: #6b7280;
  background: #f3f4f6;
  border-radius: 6px;
  cursor: pointer;
  transition: all 0.15s ease;
  
  :root.dark & {
    color: var(--text-secondary);
    background: var(--bg-tertiary);
  }
  
  &:hover {
    background: #e5e7eb;
    color: #374151;
    
    :root.dark & {
      background: var(--border-secondary);
      color: var(--text-primary);
    }
  }
  
  &.is-active {
    background: #3b82f6;
    color: white;
    
    :root.dark & {
      background: var(--accent);
    }
  }
  
  .el-icon {
    font-size: 14px;
  }
}

.breadcrumb-arrow {
  font-size: 14px;
  color: #9ca3af;
  margin: 0 0.125rem;
  flex-shrink: 0;
  
  :root.dark & {
    color: var(--text-tertiary);
  }
}

.breadcrumb-item {
  display: flex;
  align-items: center;
  gap: 0.375rem;
  padding: 0.375rem 0.75rem;
  font-size: 0.8125rem;
  font-weight: 500;
  color: #6b7280;
  background: #f3f4f6;
  border-radius: 6px;
  cursor: pointer;
  transition: all 0.15s ease;
  max-width: 180px;
  
  :root.dark & {
    color: var(--text-secondary);
    background: var(--bg-tertiary);
  }
  
  &:hover:not(.is-current) {
    background: #e5e7eb;
    color: #374151;
    
    :root.dark & {
      background: var(--border-secondary);
      color: var(--text-primary);
    }
  }
  
  &.is-current {
    background: #3b82f6;
    color: white;
    cursor: default;
    
    :root.dark & {
      background: var(--accent);
    }
    
    .folder-icon {
      color: white;
    }
  }
  
  .folder-icon {
    font-size: 14px;
    color: #f59e0b;
    flex-shrink: 0;
  }
  
  span {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
}

// ==================== 网址样式 ====================

.sites-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(100px, 1fr));
  gap: 0.75rem;
}

.site-item {
  position: relative;
  
  &:hover .remove-btn {
    opacity: 1;
  }
}

.remove-btn {
  position: absolute;
  top: 4px;
  right: 4px;
  width: 24px;
  height: 24px;
  border-radius: 6px;
  background: var(--bg-secondary);
  border: 1px solid var(--border-primary);
  color: var(--text-tertiary);
  display: flex;
  align-items: center;
  justify-content: center;
  opacity: 0;
  transition: all 0.15s ease;
  z-index: 10;
  
  &:hover {
    background: rgba(239, 68, 68, 0.1);
    border-color: rgba(239, 68, 68, 0.2);
    color: var(--error);
  }
  
  .el-icon {
    font-size: 14px;
  }
}

// ==================== 文件样式 ====================

// 拖拽遮罩
.drop-overlay {
  position: absolute;
  inset: 0;
  background: rgba(var(--accent-rgb), 0.05);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 10;
  border-radius: 16px;
}

.drop-zone {
  text-align: center;
  padding: 3rem;
  border: 2px dashed var(--accent);
  border-radius: 16px;
  background: var(--card-bg);
}

.drop-icon {
  font-size: 48px;
  color: var(--accent);
  margin-bottom: 1rem;
}

.drop-text {
  font-size: 1.125rem;
  font-weight: 500;
  color: var(--text-primary);
  margin-bottom: 0.5rem;
}

.drop-hint {
  font-size: 0.875rem;
  color: var(--text-tertiary);
}

// 加载状态
.loading-state {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 4rem;
  color: var(--text-tertiary);
  
  .el-icon {
    font-size: 32px;
    margin-bottom: 1rem;
  }
}

// 空状态
.empty-state {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 4rem 2rem;
  text-align: center;
  background: var(--card-bg);
  border-radius: 16px;
  border: 1px solid var(--border-secondary);
  
  .el-icon {
    color: var(--border-primary);
    margin-bottom: 1rem;
  }
  
  h3 {
    font-size: 1.125rem;
    font-weight: 600;
    color: var(--text-secondary);
    margin-bottom: 0.5rem;
  }
  
  p {
    font-size: 0.875rem;
    color: var(--text-tertiary);
    margin-bottom: 1.5rem;
  }
}

// 文件列表
.file-list {
  background: #ffffff;
  border-radius: 12px;
  border: 1px solid #e5e7eb;
  overflow: hidden;
  
  :root.dark & {
    background: var(--card-bg);
    border-color: var(--border-secondary);
  }
}

.list-header {
  display: grid;
  grid-template-columns: 1fr 100px 80px 80px 120px 140px;
  gap: 1rem;
  padding: 0.75rem 1rem;
  background: #f9fafb;
  font-size: 0.75rem;
  font-weight: 600;
  color: #6b7280;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  border-bottom: 1px solid #e5e7eb;
  
  :root.dark & {
    background: var(--bg-tertiary);
    color: var(--text-tertiary);
    border-bottom-color: var(--border-secondary);
  }
}

.list-item {
  display: grid;
  grid-template-columns: 1fr 100px 80px 80px 120px 140px;
  gap: 1rem;
  padding: 0.875rem 1rem;
  align-items: center;
  border-bottom: 1px solid var(--border-secondary);
  cursor: pointer;
  transition: background 0.15s ease;
  
  &:last-child {
    border-bottom: none;
  }
  
  &:hover {
    background: rgba(0, 0, 0, 0.02);
    
    :root.dark & {
      background: var(--bg-tertiary);
    }
  }
}

.col-name {
  display: flex;
  align-items: center;
  gap: 0.75rem;
  min-width: 0;
}

.file-icon {
  font-size: 20px;
  flex-shrink: 0;
  
  &.type-csv { color: #22c55e; }
  &.type-xlsx, &.type-xls { color: #16a34a; }
  &.type-parquet { color: #6366f1; }
}

.file-name {
  font-size: 0.875rem;
  color: #111827;
  font-weight: 500;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  
  :root.dark & {
    color: var(--text-primary);
  }
}

.rename-input {
  flex: 1;
  padding: 0.375rem 0.5rem;
  font-size: 0.875rem;
  background: var(--bg-secondary);
  border: 1px solid var(--accent);
  border-radius: 4px;
  color: var(--text-primary);
  outline: none;
  
  &.grid {
    width: 100%;
    text-align: center;
  }
}

.col-size,
.col-rows,
.col-cols,
.col-date {
  font-size: 0.8125rem;
  color: #6b7280;
  
  :root.dark & {
    color: var(--text-secondary);
  }
}

.col-actions {
  display: flex;
  gap: 0.25rem;
}

.icon-btn {
  width: 32px;
  height: 32px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 8px;
  color: #6b7280;
  background: transparent;
  border: 1px solid transparent;
  transition: all 0.15s ease;
  
  &:hover {
    background: #f3f4f6;
    color: #3b82f6;
    border-color: #e5e7eb;
  }
  
  :root.dark & {
    color: var(--text-secondary);
    
    &:hover {
      background: var(--bg-tertiary);
      color: var(--accent);
      border-color: var(--border-secondary);
    }
  }
}

// 文件网格
.file-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(160px, 1fr));
  gap: 1rem;
}

.grid-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 1.5rem 1rem;
  background: var(--card-bg);
  border: 1px solid var(--border-secondary);
  border-radius: 12px;
  cursor: pointer;
  transition: all 0.15s ease;
  
  &:hover {
    border-color: var(--accent);
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
  }
}

.grid-icon {
  width: 56px;
  height: 56px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: var(--bg-tertiary);
  border-radius: 12px;
  margin-bottom: 0.75rem;
  
  .el-icon {
    font-size: 28px;
    
    &.type-csv { color: #22c55e; }
    &.type-xlsx, &.type-xls { color: #16a34a; }
    &.type-parquet { color: #6366f1; }
  }
}

.grid-name {
  font-size: 0.8125rem;
  color: var(--text-primary);
  text-align: center;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  max-width: 100%;
  margin-bottom: 0.25rem;
}

.grid-meta {
  font-size: 0.75rem;
  color: var(--text-tertiary);
}

// 动画
.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.2s ease;
}

.fade-enter-from,
.fade-leave-to {
  opacity: 0;
}
</style>
