<script setup>
import { ref, computed, onMounted, onUnmounted, nextTick, watch, reactive } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { gsap } from 'gsap'
import { ElMessage } from 'element-plus'
import { getDepartment, getOrgTree } from '@/api'

const route = useRoute()
const router = useRouter()

// 数据状态
const department = ref(null)
const orgTree = ref([])
const loading = ref(true)
const selectedEmployee = ref(null)
const showEmployeeCard = ref(false)

// 当前视图: intro / org
const activeView = ref('intro')

// 架构图状态
const svgContainer = ref(null)
const treeData = ref(null)
const collapsedNodes = ref(new Set())
const hoveredNode = ref(null)
const tooltipPos = ref({ x: 0, y: 0 })

// 画布状态
const canvas = reactive({
  scale: 1,
  translateX: 0,
  translateY: 0,
  isDragging: false,
  startX: 0,
  startY: 0
})

// 树节点配置
const NODE_WIDTH = 160
const NODE_HEIGHT = 60
const HORIZONTAL_GAP = 100
const VERTICAL_GAP = 30

// 扁平化员工列表
const flatEmployees = computed(() => {
  const result = []
  const flatten = (nodes, level = 0) => {
    nodes.forEach(node => {
      result.push({ ...node, level })
      if (node.children?.length) {
        flatten(node.children, level + 1)
      }
    })
  }
  flatten(orgTree.value)
  return result
})

// 计算树布局
const computeTreeLayout = (nodes, x = 0, y = 0, level = 0) => {
  const result = []
  let currentY = y
  
  nodes.forEach((node, index) => {
    const isCollapsed = collapsedNodes.value.has(node.id)
    const hasChildren = node.children && node.children.length > 0
    
    let nodeY = currentY
    let childrenNodes = []
    
    if (hasChildren && !isCollapsed) {
      const childrenLayout = computeTreeLayout(
        node.children,
        x + NODE_WIDTH + HORIZONTAL_GAP,
        currentY,
        level + 1
      )
      childrenNodes = childrenLayout.nodes
      
      // 垂直居中父节点：将父节点置于子节点群的垂直中心
      if (childrenNodes.length > 0) {
        const firstChild = childrenNodes[0]
        const lastChild = childrenNodes[childrenNodes.length - 1]
        nodeY = (firstChild.y + lastChild.y) / 2
      }
      
      currentY = childrenLayout.maxY
    } else {
      currentY += NODE_HEIGHT + VERTICAL_GAP
    }
    
    const nodeData = {
      ...node,
      x: x,
      y: nodeY,
      level,
      hasChildren,
      isCollapsed,
      children: childrenNodes
    }
    
    result.push(nodeData)
  })
  
  return {
    nodes: result,
    maxY: currentY
  }
}

// 计算的树布局
const layoutData = computed(() => {
  if (!orgTree.value || orgTree.value.length === 0) return { nodes: [], maxY: 0 }
  return computeTreeLayout(orgTree.value, 60, 60)
})

// 扁平化布局节点（用于渲染）
const flatLayoutNodes = computed(() => {
  const result = []
  const flatten = (nodes) => {
    nodes.forEach(node => {
      result.push(node)
      if (node.children && node.children.length > 0) {
        flatten(node.children)
      }
    })
  }
  flatten(layoutData.value.nodes)
  return result
})

// 计算连接线
const connectionLines = computed(() => {
  const lines = []
  
  const processNode = (node) => {
    if (node.children && node.children.length > 0 && !node.isCollapsed) {
      node.children.forEach(child => {
        // 起点：父节点右侧中间
        const startX = node.x + NODE_WIDTH
        const startY = node.y + NODE_HEIGHT / 2
        // 终点：子节点左侧中间
        const endX = child.x
        const endY = child.y + NODE_HEIGHT / 2
        
        // 控制点用于贝塞尔曲线
        const midX = (startX + endX) / 2
        
        lines.push({
          id: `${node.id}-${child.id}`,
          path: `M ${startX} ${startY} C ${midX} ${startY}, ${midX} ${endY}, ${endX} ${endY}`
        })
        
        processNode(child)
      })
    }
  }
  
  layoutData.value.nodes.forEach(processNode)
  return lines
})

// SVG视图框
const svgViewBox = computed(() => {
  const padding = 100
  let maxX = 0
  let maxY = 0
  
  flatLayoutNodes.value.forEach(node => {
    maxX = Math.max(maxX, node.x + NODE_WIDTH)
    maxY = Math.max(maxY, node.y + NODE_HEIGHT)
  })
  
  return `0 0 ${maxX + padding} ${maxY + padding}`
})

// 画布transform
const canvasTransform = computed(() => {
  return `translate(${canvas.translateX}px, ${canvas.translateY}px) scale(${canvas.scale})`
})

// 获取科室详情
const fetchDepartment = async () => {
  const deptId = route.params.id
  if (!deptId) {
    router.push('/')
    return
  }
  
  loading.value = true
  try {
    const [deptData, treeData] = await Promise.all([
      getDepartment(deptId),
      getOrgTree(deptId)
    ])
    
    department.value = deptData
    orgTree.value = treeData || []
  } catch (e) {
    console.error('获取科室信息失败:', e)
    ElMessage.error('获取科室信息失败')
  } finally {
    loading.value = false
    nextTick(() => {
      animateContent()
    })
  }
}

// 内容动画
const animateContent = () => {
  gsap.from('.content-section', {
    opacity: 0,
    y: 20,
    duration: 0.5,
    ease: 'power2.out'
  })
}

// 切换视图动画
watch(activeView, () => {
  nextTick(() => {
    animateContent()
    if (activeView.value === 'org') {
      resetCanvas()
      animateOrgChart()
    }
  })
})

// 组织架构图动画
const animateOrgChart = () => {
  gsap.from('.node-content', {
    opacity: 0,
    scale: 0.8,
    duration: 0.4,
    stagger: 0.03,
    transformOrigin: 'center center',
    ease: 'back.out(1.4)'
  })
  
  gsap.from('.connection-line', {
    strokeDashoffset: 1000,
    duration: 0.8,
    stagger: 0.02,
    ease: 'power2.out'
  })
}

// 切换节点折叠
const toggleNode = (node) => {
  if (!node.hasChildren) return
  
  if (collapsedNodes.value.has(node.id)) {
    collapsedNodes.value.delete(node.id)
  } else {
    collapsedNodes.value.add(node.id)
  }
  
  // 触发响应式更新
  collapsedNodes.value = new Set(collapsedNodes.value)
  
  nextTick(() => {
    animateOrgChart()
  })
}

// 点击员工显示卡片
const showEmployeeDetail = (employee) => {
  selectedEmployee.value = employee
  showEmployeeCard.value = true
  
  nextTick(() => {
    gsap.from('.employee-card-modal', {
      opacity: 0,
      scale: 0.9,
      y: 20,
      duration: 0.35,
      ease: 'back.out(1.7)'
    })
  })
}

// 关闭员工卡片
const closeEmployeeCard = () => {
  gsap.to('.employee-card-modal', {
    opacity: 0,
    scale: 0.9,
    y: 20,
    duration: 0.2,
    ease: 'power2.in',
    onComplete: () => {
      showEmployeeCard.value = false
      selectedEmployee.value = null
    }
  })
}

// 打开Outlook发送邮件
const openOutlook = (email) => {
  if (email) {
    window.location.href = `mailto:${email}`
  }
}

// 拨打电话
const callPhone = (phone) => {
  if (phone) {
    window.location.href = `tel:${phone}`
  }
}

// 返回首页
const goBack = () => {
  router.push('/')
}

// 获取员工的下属
const getSubordinates = (employee) => {
  return flatEmployees.value.filter(e => e.parent_id === employee.id)
}

// ============ 画布交互 ============

// 开始拖拽
const startDrag = (e) => {
  if (e.target.closest('.org-node')) return
  canvas.isDragging = true
  canvas.startX = e.clientX - canvas.translateX
  canvas.startY = e.clientY - canvas.translateY
}

// 拖拽中
const onDrag = (e) => {
  if (!canvas.isDragging) return
  canvas.translateX = e.clientX - canvas.startX
  canvas.translateY = e.clientY - canvas.startY
}

// 结束拖拽
const endDrag = () => {
  canvas.isDragging = false
}

// 滚轮缩放
const onWheel = (e) => {
  e.preventDefault()
  const delta = e.deltaY > 0 ? -0.1 : 0.1
  const newScale = Math.max(0.3, Math.min(2, canvas.scale + delta))
  
  // 以鼠标位置为中心缩放
  const rect = svgContainer.value.getBoundingClientRect()
  const mouseX = e.clientX - rect.left
  const mouseY = e.clientY - rect.top
  
  const scaleRatio = newScale / canvas.scale
  canvas.translateX = mouseX - (mouseX - canvas.translateX) * scaleRatio
  canvas.translateY = mouseY - (mouseY - canvas.translateY) * scaleRatio
  
  canvas.scale = newScale
}

// 重置画布
const resetCanvas = () => {
  canvas.scale = 1
  canvas.translateX = 0
  canvas.translateY = 0
}

// 缩放控制
const zoomIn = () => {
  canvas.scale = Math.min(2, canvas.scale + 0.2)
}

const zoomOut = () => {
  canvas.scale = Math.max(0.3, canvas.scale - 0.2)
}

// 显示tooltip
const showTooltip = (node, event) => {
  hoveredNode.value = node
  const rect = svgContainer.value.getBoundingClientRect()
  tooltipPos.value = {
    x: event.clientX - rect.left + 10,
    y: event.clientY - rect.top - 10
  }
}

// 隐藏tooltip
const hideTooltip = () => {
  hoveredNode.value = null
}

// 全部展开
const expandAll = () => {
  collapsedNodes.value = new Set()
}

// 全部折叠
const collapseAll = () => {
  flatEmployees.value.forEach(emp => {
    if (emp.children?.length) {
      collapsedNodes.value.add(emp.id)
    }
  })
  collapsedNodes.value = new Set(collapsedNodes.value)
}

onMounted(() => {
  fetchDepartment()
})
</script>

<template>
  <div class="department-page">
    <!-- 加载状态 -->
    <div v-if="loading" class="loading-container">
      <div class="loading-spinner"></div>
      <p>加载中...</p>
    </div>
    
    <template v-else-if="department">
      <!-- 顶部导航栏 -->
      <header class="dept-header">
        <div class="header-left">
          <button class="back-btn" @click="goBack">
            <el-icon><ArrowLeft /></el-icon>
          </button>
          <div class="header-title">
            <el-icon class="dept-icon"><component :is="department.icon || 'OfficeBuilding'" /></el-icon>
            <span>{{ department.name }}</span>
          </div>
        </div>
        
        <!-- 视图切换 -->
        <div class="view-tabs">
          <button 
            class="tab-btn" 
            :class="{ active: activeView === 'intro' }"
            @click="activeView = 'intro'"
          >
            <el-icon><Document /></el-icon>
            <span>科室介绍</span>
          </button>
          <button 
            class="tab-btn" 
            :class="{ active: activeView === 'org' }"
            @click="activeView = 'org'"
          >
            <el-icon><Connection /></el-icon>
            <span>人员架构</span>
          </button>
          <div class="tab-indicator" :class="activeView"></div>
        </div>
        
        <div class="header-right">
          <span class="contact-badge">
            <el-icon><Phone /></el-icon>
            {{ department.contact }}
          </span>
        </div>
      </header>
      
      <!-- 主内容区 -->
      <main class="main-content">
        <!-- 介绍视图 -->
        <section v-show="activeView === 'intro'" class="content-section intro-section">
          <div class="intro-card">
            <div class="intro-header">
              <div class="intro-icon">
                <el-icon :size="40"><component :is="department.icon || 'OfficeBuilding'" /></el-icon>
              </div>
              <div class="intro-meta">
                <h1>{{ department.name }}</h1>
                <div class="meta-tags">
                  <span class="tag"><el-icon><User /></el-icon>{{ flatEmployees.length }} 人</span>
                  <span class="tag"><el-icon><Phone /></el-icon>{{ department.contact }}</span>
                </div>
              </div>
            </div>
            
            <div class="intro-body">
              <h3 class="section-label">部门职责</h3>
              <p class="intro-description">{{ department.description }}</p>
            </div>
            
            <!-- 快速预览团队 -->
            <div class="team-preview" v-if="flatEmployees.length > 0">
              <h3 class="section-label">团队成员</h3>
              <div class="team-avatars">
                <div 
                  v-for="emp in flatEmployees.slice(0, 8)" 
                  :key="emp.id" 
                  class="avatar-item"
                  :title="emp.name"
                  @click="showEmployeeDetail(emp)"
                >
                  <img v-if="emp.avatar" :src="emp.avatar" :alt="emp.name" />
                  <span v-else class="avatar-text">{{ emp.name.charAt(0) }}</span>
                </div>
                <div v-if="flatEmployees.length > 8" class="avatar-more">
                  +{{ flatEmployees.length - 8 }}
                </div>
              </div>
              <button class="view-all-btn" @click="activeView = 'org'">
                <span>查看完整架构</span>
                <el-icon><ArrowRight /></el-icon>
              </button>
            </div>
          </div>
        </section>
        
        <!-- 架构视图 -->
        <section v-show="activeView === 'org'" class="content-section org-section">
          <!-- 工具栏 -->
          <div class="org-toolbar">
            <div class="toolbar-left">
              <span class="toolbar-hint">
                <el-icon><InfoFilled /></el-icon>
                拖拽移动 · 滚轮缩放 · 点击蓝色节点展开/折叠
              </span>
            </div>
            <div class="toolbar-actions">
              <button class="tool-btn" @click="expandAll" title="全部展开">
                <el-icon><Expand /></el-icon>
              </button>
              <button class="tool-btn" @click="collapseAll" title="全部折叠">
                <el-icon><Fold /></el-icon>
              </button>
              <div class="zoom-controls">
                <button class="tool-btn" @click="zoomOut" title="缩小">
                  <el-icon><ZoomOut /></el-icon>
                </button>
                <span class="zoom-level">{{ Math.round(canvas.scale * 100) }}%</span>
                <button class="tool-btn" @click="zoomIn" title="放大">
                  <el-icon><ZoomIn /></el-icon>
                </button>
              </div>
              <button class="tool-btn" @click="resetCanvas" title="重置视图">
                <el-icon><RefreshRight /></el-icon>
              </button>
            </div>
          </div>
          
          <!-- 架构图画布 -->
          <div 
            ref="svgContainer"
            class="org-canvas"
            @mousedown="startDrag"
            @mousemove="onDrag"
            @mouseup="endDrag"
            @mouseleave="endDrag"
            @wheel="onWheel"
            :class="{ dragging: canvas.isDragging }"
          >
            <div class="canvas-inner" :style="{ transform: canvasTransform }">
              <svg 
                class="org-svg"
                :viewBox="svgViewBox"
                preserveAspectRatio="xMinYMin meet"
              >
                <!-- 连接线 -->
                <g class="connections">
                  <path
                    v-for="line in connectionLines"
                    :key="line.id"
                    :d="line.path"
                    class="connection-line"
                    fill="none"
                    stroke="var(--border-primary)"
                    stroke-width="2"
                    stroke-dasharray="1000"
                    stroke-dashoffset="0"
                  />
                </g>
                
                <!-- 节点 -->
                <g class="nodes">
                  <g
                    v-for="node in flatLayoutNodes"
                    :key="node.id"
                    class="org-node"
                    :class="{ 
                      'has-children': node.hasChildren,
                      'is-collapsed': node.isCollapsed,
                      'is-root': node.level === 0
                    }"
                    :transform="`translate(${node.x}, ${node.y})`"
                    @click="toggleNode(node)"
                    @dblclick.stop="showEmployeeDetail(node)"
                    @mouseenter="showTooltip(node, $event)"
                    @mouseleave="hideTooltip"
                  >
                    <g class="node-content">
                      <!-- 节点背景 -->
                      <rect
                        :width="NODE_WIDTH"
                        :height="NODE_HEIGHT"
                        rx="14"
                        ry="14"
                        class="node-bg"
                      />
                      
                      <!-- 头像 -->
                      <clipPath :id="`avatar-clip-${node.id}`">
                        <rect x="12" y="10" width="40" height="40" rx="10" ry="10" />
                      </clipPath>
                      
                      <rect
                        x="12" y="10"
                        width="40" height="40"
                        rx="10" ry="10"
                        class="avatar-bg"
                      />
                      
                      <image
                        v-if="node.avatar"
                        :href="node.avatar"
                        x="12" y="10"
                        width="40" height="40"
                        :clip-path="`url(#avatar-clip-${node.id})`"
                        preserveAspectRatio="xMidYMid slice"
                      />
                      
                      <text
                        v-else
                        x="32" y="36"
                        class="avatar-text"
                        text-anchor="middle"
                        dominant-baseline="middle"
                      >{{ node.name.charAt(0) }}</text>
                      
                      <!-- 名字和职位 -->
                      <text x="60" y="26" class="node-name">{{ node.name }}</text>
                      <text x="60" y="44" class="node-position">{{ node.position }}</text>
                      
                      <!-- 展开/折叠指示器 -->
                      <g v-if="node.hasChildren" class="expand-indicator" :transform="`translate(${NODE_WIDTH - 20}, ${NODE_HEIGHT / 2})`">
                        <circle r="10" class="indicator-bg" />
                        <text 
                          x="0" y="1" 
                          class="indicator-icon"
                          text-anchor="middle" 
                          dominant-baseline="middle"
                        >{{ node.isCollapsed ? '+' : '−' }}</text>
                      </g>
                    </g>
                  </g>
                </g>
              </svg>
            </div>
            
            <!-- Tooltip -->
            <Transition name="tooltip">
              <div 
                v-if="hoveredNode" 
                class="node-tooltip"
                :style="{ left: tooltipPos.x + 'px', top: tooltipPos.y + 'px' }"
              >
                <div class="tooltip-name">{{ hoveredNode.name }}</div>
                <div class="tooltip-position">{{ hoveredNode.position }}</div>
                <div class="tooltip-hint" v-if="hoveredNode.hasChildren">
                  {{ hoveredNode.isCollapsed ? '点击展开' : '点击折叠' }} · 双击查看详情
                </div>
                <div class="tooltip-hint" v-else>双击查看详情</div>
              </div>
            </Transition>
          </div>
          
          <!-- 空状态 -->
          <div v-if="orgTree.length === 0" class="empty-org">
            <el-icon :size="48"><User /></el-icon>
            <p>暂无人员信息</p>
          </div>
        </section>
      </main>
    </template>
    
    <!-- 员工详情卡片弹窗 -->
    <Teleport to="body">
      <Transition name="fade">
        <div 
          v-if="showEmployeeCard && selectedEmployee" 
          class="employee-modal-overlay"
          @click.self="closeEmployeeCard"
        >
          <div class="employee-card-modal">
            <button class="close-btn" @click="closeEmployeeCard">
              <el-icon><Close /></el-icon>
            </button>
            
            <div class="card-header">
              <div class="card-avatar">
                <img v-if="selectedEmployee.avatar" :src="selectedEmployee.avatar" :alt="selectedEmployee.name" />
                <span v-else class="avatar-placeholder">{{ selectedEmployee.name.charAt(0) }}</span>
              </div>
              <h3 class="card-name">{{ selectedEmployee.name }}</h3>
              <span class="card-position">{{ selectedEmployee.position }}</span>
            </div>
            
            <div class="card-signature" v-if="selectedEmployee.signature">
              <el-icon><ChatDotRound /></el-icon>
              <p>"{{ selectedEmployee.signature }}"</p>
            </div>
            
            <div class="card-contacts">
              <div 
                class="contact-item" 
                v-if="selectedEmployee.phone" 
                @click="callPhone(selectedEmployee.phone)"
              >
                <div class="contact-icon phone">
                  <el-icon><Phone /></el-icon>
                </div>
                <div class="contact-detail">
                  <span class="label">电话</span>
                  <span class="value">{{ selectedEmployee.phone }}</span>
                </div>
              </div>
              
              <div 
                class="contact-item email" 
                v-if="selectedEmployee.email"
                @click="openOutlook(selectedEmployee.email)"
              >
                <div class="contact-icon email">
                  <el-icon><Message /></el-icon>
                </div>
                <div class="contact-detail">
                  <span class="label">邮箱</span>
                  <span class="value">{{ selectedEmployee.email }}</span>
                </div>
                <span class="outlook-tag">
                  <el-icon><TopRight /></el-icon>
                  Outlook
                </span>
              </div>
            </div>
            
            <!-- 下属成员 -->
            <div class="card-subordinates" v-if="getSubordinates(selectedEmployee).length > 0">
              <span class="sub-label">下属成员</span>
              <div class="sub-list">
                <div 
                  v-for="sub in getSubordinates(selectedEmployee)" 
                  :key="sub.id" 
                  class="sub-item"
                  @click="showEmployeeDetail(sub)"
                >
                  <div class="sub-avatar">
                    <img v-if="sub.avatar" :src="sub.avatar" :alt="sub.name" />
                    <span v-else>{{ sub.name.charAt(0) }}</span>
                  </div>
                  <span class="sub-name">{{ sub.name }}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Transition>
    </Teleport>
  </div>
</template>

<style lang="scss" scoped>
.department-page {
  min-height: 100vh;
  background: var(--bg-primary);
}

// 加载状态
.loading-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  min-height: 60vh;
  color: var(--text-tertiary);
  
  .loading-spinner {
    width: 36px;
    height: 36px;
    border: 2px solid var(--border-secondary);
    border-top-color: var(--text-primary);
    border-radius: 50%;
    animation: spin 0.7s linear infinite;
    margin-bottom: 1rem;
  }
  
  p { font-size: 0.8125rem; }
}

@keyframes spin {
  to { transform: rotate(360deg); }
}

// 顶部导航栏
.dept-header {
  position: sticky;
  top: 0;
  z-index: 100;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0.75rem 1.5rem;
  background: rgba(var(--bg-primary-rgb), 0.85);
  backdrop-filter: blur(20px);
  border-bottom: 1px solid var(--border-secondary);
}

.header-left {
  display: flex;
  align-items: center;
  gap: 1rem;
}

.back-btn {
  width: 36px;
  height: 36px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: var(--bg-tertiary);
  border: 1px solid var(--border-secondary);
  border-radius: 10px;
  color: var(--text-secondary);
  transition: all 0.2s ease;
  
  &:hover {
    background: var(--text-primary);
    border-color: var(--text-primary);
    color: var(--text-inverse);
  }
}

.header-title {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  font-size: 1rem;
  font-weight: 600;
  color: var(--text-primary);
  
  .dept-icon {
    font-size: 1.25rem;
    color: var(--text-secondary);
  }
}

// 视图切换标签
.view-tabs {
  position: relative;
  display: flex;
  background: var(--bg-tertiary);
  border-radius: 10px;
  padding: 4px;
}

.tab-btn {
  position: relative;
  z-index: 1;
  display: flex;
  align-items: center;
  gap: 0.375rem;
  padding: 0.5rem 1rem;
  font-size: 0.8125rem;
  font-weight: 500;
  color: var(--text-tertiary);
  border-radius: 8px;
  transition: color 0.2s ease;
  
  &:hover { color: var(--text-secondary); }
  &.active { color: var(--text-primary); }
}

.tab-indicator {
  position: absolute;
  top: 4px;
  left: 4px;
  width: calc(50% - 4px);
  height: calc(100% - 8px);
  background: var(--card-bg);
  border-radius: 8px;
  box-shadow: var(--shadow-sm);
  transition: transform 0.25s cubic-bezier(0.4, 0, 0.2, 1);
  
  &.org { transform: translateX(100%); }
}

.header-right {
  display: flex;
  align-items: center;
}

.contact-badge {
  display: flex;
  align-items: center;
  gap: 0.375rem;
  padding: 0.5rem 0.875rem;
  font-size: 0.75rem;
  color: var(--text-secondary);
  background: var(--bg-tertiary);
  border-radius: 8px;
  
  .el-icon { font-size: 0.875rem; }
}

// 主内容区
.main-content {
  height: calc(100vh - 60px);
  overflow: hidden;
}

.content-section {
  height: 100%;
}

// ==================== 介绍视图 ====================
.intro-section {
  display: flex;
  justify-content: center;
  padding: 2rem 1.5rem;
  overflow-y: auto;
}

.intro-card {
  width: 100%;
  max-width: 640px;
  background: var(--card-bg);
  border: 1px solid var(--border-secondary);
  border-radius: 20px;
  overflow: hidden;
  height: fit-content;
}

.intro-header {
  display: flex;
  align-items: center;
  gap: 1.25rem;
  padding: 2rem 2rem 1.5rem;
  background: linear-gradient(135deg, var(--bg-tertiary) 0%, transparent 100%);
  border-bottom: 1px solid var(--border-secondary);
}

.intro-icon {
  width: 72px;
  height: 72px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: var(--text-primary);
  color: var(--text-inverse);
  border-radius: 18px;
  flex-shrink: 0;
}

.intro-meta {
  h1 {
    font-family: 'Noto Serif SC', serif;
    font-size: 1.5rem;
    font-weight: 700;
    color: var(--text-primary);
    margin-bottom: 0.5rem;
  }
}

.meta-tags {
  display: flex;
  gap: 0.75rem;
  
  .tag {
    display: flex;
    align-items: center;
    gap: 0.25rem;
    font-size: 0.75rem;
    color: var(--text-tertiary);
    
    .el-icon { font-size: 0.875rem; }
  }
}

.intro-body {
  padding: 1.5rem 2rem;
}

.section-label {
  font-size: 0.6875rem;
  font-weight: 600;
  color: var(--text-tertiary);
  text-transform: uppercase;
  letter-spacing: 1px;
  margin-bottom: 0.75rem;
}

.intro-description {
  font-family: 'Noto Serif SC', serif;
  font-size: 0.9375rem;
  color: var(--text-secondary);
  line-height: 1.8;
}

// 团队预览
.team-preview {
  padding: 1.5rem 2rem 2rem;
  border-top: 1px solid var(--border-secondary);
}

.team-avatars {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  margin-bottom: 1rem;
}

.avatar-item {
  width: 40px;
  height: 40px;
  border-radius: 12px;
  overflow: hidden;
  cursor: pointer;
  transition: all 0.2s ease;
  border: 2px solid var(--card-bg);
  margin-left: -8px;
  
  &:first-child { margin-left: 0; }
  
  &:hover {
    transform: translateY(-4px) scale(1.1);
    z-index: 10;
    box-shadow: var(--shadow-md);
  }
  
  img {
    width: 100%;
    height: 100%;
    object-fit: cover;
  }
  
  .avatar-text {
    width: 100%;
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    background: var(--bg-tertiary);
    color: var(--text-secondary);
    font-size: 0.875rem;
    font-weight: 600;
  }
}

.avatar-more {
  width: 40px;
  height: 40px;
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: var(--text-primary);
  color: var(--text-inverse);
  font-size: 0.75rem;
  font-weight: 600;
  margin-left: -8px;
}

.view-all-btn {
  display: inline-flex;
  align-items: center;
  gap: 0.375rem;
  padding: 0.625rem 1rem;
  font-size: 0.8125rem;
  font-weight: 500;
  color: var(--text-secondary);
  background: var(--bg-tertiary);
  border-radius: 10px;
  transition: all 0.2s ease;
  
  &:hover {
    background: var(--text-primary);
    color: var(--text-inverse);
  }
}

// ==================== 架构视图 ====================
.org-section {
  display: flex;
  flex-direction: column;
  height: 100%;
}

// 工具栏
.org-toolbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0.75rem 1.5rem;
  background: var(--card-bg);
  border-bottom: 1px solid var(--border-secondary);
  flex-shrink: 0;
}

.toolbar-left {
  display: flex;
  align-items: center;
}

.toolbar-hint {
  display: flex;
  align-items: center;
  gap: 0.375rem;
  font-size: 0.75rem;
  color: var(--text-tertiary);
  
  .el-icon { font-size: 0.875rem; }
}

.toolbar-actions {
  display: flex;
  align-items: center;
  gap: 0.5rem;
}

.tool-btn {
  width: 32px;
  height: 32px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: var(--bg-tertiary);
  border: 1px solid var(--border-secondary);
  border-radius: 8px;
  color: var(--text-secondary);
  transition: all 0.15s ease;
  
  &:hover {
    background: var(--text-primary);
    border-color: var(--text-primary);
    color: var(--text-inverse);
  }
}

.zoom-controls {
  display: flex;
  align-items: center;
  gap: 0.25rem;
  padding: 0 0.5rem;
  
  .zoom-level {
    min-width: 48px;
    text-align: center;
    font-size: 0.75rem;
    font-weight: 500;
    color: var(--text-secondary);
  }
}

// 画布
.org-canvas {
  flex: 1;
  overflow: hidden;
  position: relative;
  background: 
    radial-gradient(circle at 1px 1px, var(--border-secondary) 1px, transparent 1px);
  background-size: 24px 24px;
  cursor: grab;
  
  &.dragging {
    cursor: grabbing;
  }
}

.canvas-inner {
  transform-origin: 0 0;
  will-change: transform;
}

.org-svg {
  display: block;
  min-width: 100%;
  min-height: 100%;
}

// 连接线
.connection-line {
  stroke: var(--border-primary);
  stroke-width: 2;
  fill: none;
  transition: stroke 0.2s ease;
}

// 节点
.org-node {
  cursor: pointer;
  
  .node-bg {
    fill: var(--card-bg);
    stroke: var(--border-secondary);
    stroke-width: 1;
    transition: all 0.2s ease;
  }
  
  .avatar-bg {
    fill: var(--bg-tertiary);
  }
  
  .avatar-text {
    fill: var(--text-secondary);
    font-size: 14px;
    font-weight: 600;
  }
  
  .node-name {
    fill: var(--text-primary);
    font-size: 12px;
    font-weight: 600;
  }
  
  .node-position {
    fill: var(--text-tertiary);
    font-size: 10px;
  }
  
  &:hover {
    .node-bg {
      stroke: var(--text-tertiary);
      filter: drop-shadow(0 4px 12px rgba(0, 0, 0, 0.1));
    }
  }
  
  // 有下属的节点 - 蓝色实心
  &.has-children {
    .node-bg {
      fill: #3b82f6;
      stroke: #3b82f6;
    }
    
    .avatar-bg {
      fill: rgba(255, 255, 255, 0.2);
    }
    
    .avatar-text {
      fill: white;
    }
    
    .node-name {
      fill: white;
    }
    
    .node-position {
      fill: rgba(255, 255, 255, 0.7);
    }
    
    &:hover .node-bg {
      fill: #2563eb;
      stroke: #2563eb;
    }
  }
  
  // 折叠状态
  &.is-collapsed {
    .node-bg {
      fill: #1d4ed8;
      stroke: #1d4ed8;
    }
  }
  
  // 根节点
  &.is-root {
    .node-bg {
      fill: var(--text-primary);
      stroke: var(--text-primary);
    }
    
    .avatar-bg {
      fill: rgba(255, 255, 255, 0.2);
    }
    
    .avatar-text,
    .node-name {
      fill: var(--text-inverse);
    }
    
    .node-position {
      fill: var(--text-inverse);
      opacity: 0.8;
    }
  }
}

.node-content {
  transform-box: fill-box;
  transform-origin: center center;
}

// 展开/折叠指示器
.expand-indicator {
  .indicator-bg {
    fill: rgba(255, 255, 255, 0.3);
    transition: all 0.2s ease;
  }
  
  .indicator-icon {
    fill: white;
    font-size: 14px;
    font-weight: bold;
  }
  
  &:hover .indicator-bg {
    fill: rgba(255, 255, 255, 0.5);
  }
}

// Tooltip
.node-tooltip {
  position: absolute;
  z-index: 1000;
  padding: 0.75rem 1rem;
  background: var(--tooltip-bg);
  color: var(--tooltip-text);
  border-radius: 10px;
  box-shadow: var(--shadow-lg);
  pointer-events: none;
  max-width: 200px;
}

.tooltip-name {
  font-size: 0.875rem;
  font-weight: 600;
  margin-bottom: 0.125rem;
}

.tooltip-position {
  font-size: 0.75rem;
  opacity: 0.8;
  margin-bottom: 0.5rem;
}

.tooltip-hint {
  font-size: 0.6875rem;
  opacity: 0.6;
  padding-top: 0.375rem;
  border-top: 1px solid var(--border-secondary);
}

.tooltip-enter-active,
.tooltip-leave-active {
  transition: all 0.15s ease;
}

.tooltip-enter-from,
.tooltip-leave-to {
  opacity: 0;
  transform: translateY(4px);
}

// 空状态
.empty-org {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 4rem 2rem;
  color: var(--text-tertiary);
  
  .el-icon { margin-bottom: 1rem; }
  p { font-size: 0.875rem; }
}

// ==================== 员工卡片弹窗 ====================
.employee-modal-overlay {
  position: fixed;
  inset: 0;
  z-index: 2000;
  display: flex;
  align-items: center;
  justify-content: center;
  background: var(--overlay-bg);
  backdrop-filter: blur(8px);
  padding: 1rem;
}

.employee-card-modal {
  position: relative;
  width: 100%;
  max-width: 360px;
  background: var(--card-bg);
  border-radius: 24px;
  overflow: hidden;
  box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.3);
}

.close-btn {
  position: absolute;
  top: 1rem;
  right: 1rem;
  width: 32px;
  height: 32px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: rgba(0, 0, 0, 0.1);
  border-radius: 50%;
  color: var(--text-inverse);
  transition: all 0.2s ease;
  z-index: 10;
  
  &:hover {
    background: rgba(0, 0, 0, 0.2);
    transform: rotate(90deg);
  }
}

.card-header {
  padding: 2.5rem 1.5rem 1.5rem;
  text-align: center;
  background: var(--text-primary);
  color: var(--text-inverse);
}

.card-avatar {
  width: 80px;
  height: 80px;
  margin: 0 auto 1rem;
  border-radius: 20px;
  overflow: hidden;
  border: 3px solid rgba(255, 255, 255, 0.2);
  
  img {
    width: 100%;
    height: 100%;
    object-fit: cover;
  }
  
  .avatar-placeholder {
    width: 100%;
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    background: rgba(255, 255, 255, 0.2);
    font-size: 1.75rem;
    font-weight: 700;
  }
}

.card-name {
  font-family: 'Noto Serif SC', serif;
  font-size: 1.25rem;
  font-weight: 700;
  margin-bottom: 0.25rem;
}

.card-position {
  font-size: 0.8125rem;
  opacity: 0.8;
}

.card-signature {
  display: flex;
  align-items: flex-start;
  gap: 0.625rem;
  margin: 1.25rem;
  padding: 1rem;
  background: var(--bg-tertiary);
  border-radius: 14px;
  
  .el-icon {
    flex-shrink: 0;
    color: var(--text-tertiary);
    font-size: 1rem;
  }
  
  p {
    font-family: 'Noto Serif SC', serif;
    font-size: 0.8125rem;
    font-style: italic;
    color: var(--text-secondary);
    line-height: 1.6;
  }
}

.card-contacts {
  padding: 0 1.25rem;
  display: flex;
  flex-direction: column;
  gap: 0.625rem;
}

.contact-item {
  display: flex;
  align-items: center;
  gap: 0.875rem;
  padding: 0.875rem 1rem;
  background: var(--bg-secondary);
  border: 1px solid var(--border-secondary);
  border-radius: 14px;
  cursor: pointer;
  transition: all 0.2s ease;
  
  &:hover {
    border-color: var(--border-primary);
    
    .contact-icon {
      transform: scale(1.1);
    }
  }
  
  &.email:hover {
    border-color: #0078d4;
    
    .contact-icon.email {
      background: #0078d4;
      color: white;
    }
  }
}

.contact-icon {
  width: 40px;
  height: 40px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: var(--bg-tertiary);
  border-radius: 12px;
  color: var(--text-secondary);
  flex-shrink: 0;
  transition: all 0.2s ease;
  
  &.phone:hover {
    background: var(--text-primary);
    color: var(--text-inverse);
  }
}

.contact-detail {
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 0.125rem;
  
  .label {
    font-size: 0.6875rem;
    color: var(--text-tertiary);
  }
  
  .value {
    font-size: 0.8125rem;
    font-weight: 500;
    color: var(--text-primary);
  }
}

.outlook-tag {
  display: flex;
  align-items: center;
  gap: 0.25rem;
  padding: 0.25rem 0.625rem;
  font-size: 0.625rem;
  font-weight: 600;
  color: #0078d4;
  background: rgba(0, 120, 212, 0.1);
  border-radius: 6px;
  
  .el-icon { font-size: 0.75rem; }
}

// 下属成员
.card-subordinates {
  padding: 1.25rem;
  border-top: 1px solid var(--border-secondary);
  margin-top: 0.625rem;
}

.sub-label {
  display: block;
  font-size: 0.6875rem;
  font-weight: 600;
  color: var(--text-tertiary);
  text-transform: uppercase;
  letter-spacing: 1px;
  margin-bottom: 0.75rem;
}

.sub-list {
  display: flex;
  flex-wrap: wrap;
  gap: 0.5rem;
}

.sub-item {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.375rem 0.75rem 0.375rem 0.375rem;
  background: var(--bg-tertiary);
  border-radius: 20px;
  cursor: pointer;
  transition: all 0.2s ease;
  
  &:hover {
    background: var(--text-primary);
    
    .sub-name { color: var(--text-inverse); }
    .sub-avatar span { 
      background: rgba(255, 255, 255, 0.2);
      color: var(--text-inverse);
    }
  }
}

.sub-avatar {
  width: 28px;
  height: 28px;
  border-radius: 50%;
  overflow: hidden;
  
  img {
    width: 100%;
    height: 100%;
    object-fit: cover;
  }
  
  span {
    width: 100%;
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    background: var(--card-bg);
    color: var(--text-secondary);
    font-size: 0.75rem;
    font-weight: 600;
  }
}

.sub-name {
  font-size: 0.75rem;
  font-weight: 500;
  color: var(--text-primary);
  transition: color 0.2s ease;
}

// 过渡动画
.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.3s ease;
}

.fade-enter-from,
.fade-leave-to {
  opacity: 0;
}

// 响应式
@media (max-width: 768px) {
  .dept-header {
    flex-wrap: wrap;
    gap: 0.75rem;
    padding: 0.75rem 1rem;
  }
  
  .header-left { order: 1; }
  
  .view-tabs {
    order: 3;
    width: 100%;
    justify-content: center;
  }
  
  .header-right {
    order: 2;
    margin-left: auto;
  }
  
  .org-toolbar {
    flex-direction: column;
    gap: 0.75rem;
    padding: 0.75rem 1rem;
  }
  
  .toolbar-hint {
    display: none;
  }
  
  .intro-header {
    flex-direction: column;
    text-align: center;
    padding: 1.5rem;
  }
  
  .meta-tags {
    justify-content: center;
  }
  
  .intro-body,
  .team-preview {
    padding: 1.25rem 1.5rem;
  }
  
  .employee-card-modal {
    max-width: 100%;
    margin: 0 1rem;
  }
}
</style>
