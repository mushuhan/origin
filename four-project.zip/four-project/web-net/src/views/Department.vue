<script setup>
import { ref, computed, onMounted, nextTick, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { gsap } from 'gsap'
import { ElMessage } from 'element-plus'
import { getDepartment, getOrgTree } from '@/api'
import ArchitectureTree from '@/components/ArchitectureTree.vue'

const route = useRoute()
const router = useRouter()

// 数据状态
const department = ref(null)
const orgTree = ref([])
const loading = ref(true)
const selectedEmployee = ref(null)
const showEmployeeCard = ref(false)

// 当前视图: intro / org
const activeView = ref('intro')

// 架构图组件引用
const treeRef = ref(null)

// 布局方向
const layoutDirection = ref('LR')  // 'LR' 或 'TB'

// 布局模式
const layoutMode = ref('balanced')  // 'compact' 或 'balanced'

// 当前缩放级别
const zoomLevel = ref(100)

// 扁平化员工列表
const flatEmployees = computed(() => {
  const result = []
  const flatten = (nodes, level = 0) => {
    nodes.forEach(node => {
      result.push({ ...node, level })
      if (node.children?.length) {
        flatten(node.children, level + 1)
      }
    })
  }
  flatten(orgTree.value)
  return result
})

// 获取科室详情
const fetchDepartment = async () => {
  const deptId = route.params.id
  if (!deptId) {
    router.push('/')
    return
  }
  
  loading.value = true
  try {
    const [deptData, treeData] = await Promise.all([
      getDepartment(deptId),
      getOrgTree(deptId)
    ])
    
    department.value = deptData
    orgTree.value = treeData || []
  } catch (e) {
    console.error('获取科室信息失败:', e)
    ElMessage.error('获取科室信息失败')
  } finally {
    loading.value = false
    nextTick(() => {
      animateContent()
    })
  }
}

// 内容动画
const animateContent = () => {
  gsap.from('.content-section', {
    opacity: 0,
    y: 20,
    duration: 0.5,
    ease: 'power2.out'
  })
}

// 切换视图动画
watch(activeView, () => {
  nextTick(() => {
    animateContent()
    if (activeView.value === 'org') {
      // 切换到架构视图时，调整画布大小
      nextTick(() => {
        treeRef.value?.resize()
      })
    }
  })
})

// 更新缩放级别显示
const updateZoomLevel = () => {
  if (treeRef.value) {
    zoomLevel.value = treeRef.value.getZoom()
  }
}

// 缩放控制
const zoomIn = () => {
  treeRef.value?.zoomIn()
  updateZoomLevel()
}

const zoomOut = () => {
  treeRef.value?.zoomOut()
  updateZoomLevel()
}

const resetView = () => {
  treeRef.value?.resetView()
  updateZoomLevel()
}

// 全部展开
const expandAll = () => {
  treeRef.value?.expandAll()
}

// 全部折叠
const collapseAll = () => {
  treeRef.value?.collapseAll()
}

// 切换布局方向
const toggleDirection = () => {
  layoutDirection.value = layoutDirection.value === 'LR' ? 'TB' : 'LR'
}

// 切换布局模式
const toggleLayoutMode = () => {
  layoutMode.value = layoutMode.value === 'balanced' ? 'compact' : 'balanced'
}

// 节点点击 - 显示员工卡片
const handleNodeClick = (employee) => {
  selectedEmployee.value = employee
  showEmployeeCard.value = true
  
  nextTick(() => {
    gsap.from('.employee-card-modal', {
      opacity: 0,
      scale: 0.9,
      y: 20,
      duration: 0.35,
      ease: 'back.out(1.7)'
    })
  })
}

// 关闭员工卡片
const closeEmployeeCard = () => {
  gsap.to('.employee-card-modal', {
    opacity: 0,
    scale: 0.9,
    y: 20,
    duration: 0.2,
    ease: 'power2.in',
    onComplete: () => {
      showEmployeeCard.value = false
      selectedEmployee.value = null
    }
  })
}

// 打开Outlook发送邮件
const openOutlook = (email) => {
  if (email) {
    window.location.href = `mailto:${email}`
  }
}

// 拨打电话
const callPhone = (phone) => {
  if (phone) {
    window.location.href = `tel:${phone}`
  }
}

// 返回首页
const goBack = () => {
  router.push('/')
}

// 获取员工的下属
const getSubordinates = (employee) => {
  return flatEmployees.value.filter(e => e.parent_id === employee.id)
}

onMounted(() => {
  fetchDepartment()
})
</script>

<template>
  <div class="department-page">
    <!-- 加载状态 -->
    <div v-if="loading" class="loading-container">
      <div class="loading-spinner"></div>
      <p>加载中...</p>
    </div>
    
    <template v-else-if="department">
      <!-- 顶部导航栏 -->
      <header class="dept-header">
        <div class="header-left">
          <button class="back-btn" @click="goBack">
            <el-icon><ArrowLeft /></el-icon>
          </button>
          <div class="header-title">
            <el-icon class="dept-icon"><component :is="department.icon || 'OfficeBuilding'" /></el-icon>
            <span>{{ department.name }}</span>
          </div>
        </div>
        
        <!-- 视图切换 -->
        <div class="view-tabs">
          <button 
            class="tab-btn" 
            :class="{ active: activeView === 'intro' }"
            @click="activeView = 'intro'"
          >
            <el-icon><Document /></el-icon>
            <span>科室介绍</span>
          </button>
          <button 
            class="tab-btn" 
            :class="{ active: activeView === 'org' }"
            @click="activeView = 'org'"
          >
            <el-icon><Connection /></el-icon>
            <span>人员架构</span>
          </button>
          <div class="tab-indicator" :class="activeView"></div>
        </div>
        
        <div class="header-right">
          <span class="contact-badge">
            <el-icon><Phone /></el-icon>
            {{ department.contact }}
          </span>
        </div>
      </header>
      
      <!-- 主内容区 -->
      <main class="main-content">
        <!-- 介绍视图 -->
        <section v-show="activeView === 'intro'" class="content-section intro-section">
          <div class="intro-card">
            <div class="intro-header">
              <div class="intro-icon">
                <el-icon :size="40"><component :is="department.icon || 'OfficeBuilding'" /></el-icon>
              </div>
              <div class="intro-meta">
                <h1>{{ department.name }}</h1>
                <div class="meta-tags">
                  <span class="tag"><el-icon><User /></el-icon>{{ flatEmployees.length }} 人</span>
                  <span class="tag"><el-icon><Phone /></el-icon>{{ department.contact }}</span>
                </div>
              </div>
            </div>
            
            <div class="intro-body">
              <h3 class="section-label">部门职责</h3>
              <p class="intro-description">{{ department.description }}</p>
            </div>
            
            <!-- 快速预览团队 -->
            <div class="team-preview" v-if="flatEmployees.length > 0">
              <h3 class="section-label">团队成员</h3>
              <div class="team-avatars">
                <div 
                  v-for="emp in flatEmployees.slice(0, 8)" 
                  :key="emp.id" 
                  class="avatar-item"
                  :title="emp.name"
                  @click="handleNodeClick(emp)"
                >
                  <img v-if="emp.avatar" :src="emp.avatar" :alt="emp.name" />
                  <span v-else class="avatar-text">{{ emp.name.charAt(0) }}</span>
                </div>
                <div v-if="flatEmployees.length > 8" class="avatar-more">
                  +{{ flatEmployees.length - 8 }}
                </div>
              </div>
              <button class="view-all-btn" @click="activeView = 'org'">
                <span>查看完整架构</span>
                <el-icon><ArrowRight /></el-icon>
              </button>
            </div>
          </div>
        </section>
        
        <!-- 架构视图 (使用 G6) -->
        <section v-show="activeView === 'org'" class="content-section org-section">
          <!-- 工具栏 -->
          <div class="org-toolbar">
            <div class="toolbar-left">
              <span class="toolbar-hint">
                <el-icon><InfoFilled /></el-icon>
                拖拽移动 · 滚轮缩放 · 点击节点展开/折叠
              </span>
            </div>
            <div class="toolbar-actions">
              <button class="tool-btn" @click="expandAll" title="全部展开">
                <el-icon><Expand /></el-icon>
              </button>
              <button class="tool-btn" @click="collapseAll" title="全部折叠">
                <el-icon><Fold /></el-icon>
              </button>
              <div class="layout-toggle">
                <button 
                  class="tool-btn" 
                  :class="{ active: layoutMode === 'balanced' }"
                  @click="toggleLayoutMode" 
                  :title="layoutMode === 'balanced' ? '当前：平衡布局（子节点分两侧）' : '当前：紧凑布局（子节点单侧）'"
                >
                  <el-icon><Grid /></el-icon>
                </button>
              </div>
              <button class="tool-btn" @click="toggleDirection" :title="layoutDirection === 'LR' ? '切换为纵向布局' : '切换为横向布局'">
                <el-icon><Switch /></el-icon>
              </button>
              <div class="zoom-controls">
                <button class="tool-btn" @click="zoomOut" title="缩小">
                  <el-icon><ZoomOut /></el-icon>
                </button>
                <span class="zoom-level">{{ zoomLevel }}%</span>
                <button class="tool-btn" @click="zoomIn" title="放大">
                  <el-icon><ZoomIn /></el-icon>
                </button>
              </div>
              <button class="tool-btn" @click="resetView" title="重置视图">
                <el-icon><RefreshRight /></el-icon>
              </button>
            </div>
          </div>
          
          <!-- G6 架构图容器 -->
          <div class="org-canvas">
            <ArchitectureTree
              ref="treeRef"
              :data="orgTree"
              :direction="layoutDirection"
              :layout-mode="layoutMode"
              :cols-per-row="4"
              @node-click="handleNodeClick"
              @node-dblclick="handleNodeClick"
            />
          </div>
          
          <!-- 空状态 -->
          <div v-if="orgTree.length === 0" class="empty-org">
            <el-icon :size="48"><User /></el-icon>
            <p>暂无人员信息</p>
          </div>
        </section>
      </main>
    </template>
    
    <!-- 员工详情卡片弹窗 -->
    <Teleport to="body">
      <Transition name="fade">
        <div 
          v-if="showEmployeeCard && selectedEmployee" 
          class="employee-modal-overlay"
          @click.self="closeEmployeeCard"
        >
          <div class="employee-card-modal">
            <button class="close-btn" @click="closeEmployeeCard">
              <el-icon><Close /></el-icon>
            </button>
            
            <div class="card-header">
              <div class="card-avatar">
                <img v-if="selectedEmployee.avatar" :src="selectedEmployee.avatar" :alt="selectedEmployee.name" />
                <span v-else class="avatar-placeholder">{{ selectedEmployee.name.charAt(0) }}</span>
              </div>
              <h3 class="card-name">{{ selectedEmployee.name }}</h3>
              <span class="card-position">{{ selectedEmployee.position }}</span>
            </div>
            
            <div class="card-signature" v-if="selectedEmployee.signature">
              <el-icon><ChatDotRound /></el-icon>
              <p>"{{ selectedEmployee.signature }}"</p>
            </div>
            
            <div class="card-contacts">
              <div 
                class="contact-item" 
                v-if="selectedEmployee.phone" 
                @click="callPhone(selectedEmployee.phone)"
              >
                <div class="contact-icon phone">
                  <el-icon><Phone /></el-icon>
                </div>
                <div class="contact-detail">
                  <span class="label">电话</span>
                  <span class="value">{{ selectedEmployee.phone }}</span>
                </div>
              </div>
              
              <div 
                class="contact-item email" 
                v-if="selectedEmployee.email"
                @click="openOutlook(selectedEmployee.email)"
              >
                <div class="contact-icon email">
                  <el-icon><Message /></el-icon>
                </div>
                <div class="contact-detail">
                  <span class="label">邮箱</span>
                  <span class="value">{{ selectedEmployee.email }}</span>
                </div>
                <span class="outlook-tag">
                  <el-icon><TopRight /></el-icon>
                  Outlook
                </span>
              </div>
            </div>
            
            <!-- 下属成员 -->
            <div class="card-subordinates" v-if="getSubordinates(selectedEmployee).length > 0">
              <span class="sub-label">下属成员</span>
              <div class="sub-list">
                <div 
                  v-for="sub in getSubordinates(selectedEmployee)" 
                  :key="sub.id" 
                  class="sub-item"
                  @click="handleNodeClick(sub)"
                >
                  <div class="sub-avatar">
                    <img v-if="sub.avatar" :src="sub.avatar" :alt="sub.name" />
                    <span v-else>{{ sub.name.charAt(0) }}</span>
                  </div>
                  <span class="sub-name">{{ sub.name }}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Transition>
    </Teleport>
  </div>
</template>

<style lang="scss" scoped>
.department-page {
  min-height: 100vh;
  background: var(--bg-primary);
}

// 加载状态
.loading-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  min-height: 60vh;
  color: var(--text-tertiary);
  
  .loading-spinner {
    width: 36px;
    height: 36px;
    border: 2px solid var(--border-secondary);
    border-top-color: var(--text-primary);
    border-radius: 50%;
    animation: spin 0.7s linear infinite;
    margin-bottom: 1rem;
  }
  
  p { font-size: 0.8125rem; }
}

@keyframes spin {
  to { transform: rotate(360deg); }
}

// 顶部导航栏
.dept-header {
  position: sticky;
  top: 0;
  z-index: 100;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0.75rem 1.5rem;
  background: rgba(var(--bg-primary-rgb), 0.85);
  backdrop-filter: blur(20px);
  border-bottom: 1px solid var(--border-secondary);
}

.header-left {
  display: flex;
  align-items: center;
  gap: 1rem;
}

.back-btn {
  width: 36px;
  height: 36px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: var(--bg-tertiary);
  border: 1px solid var(--border-secondary);
  border-radius: 10px;
  color: var(--text-secondary);
  transition: all 0.2s ease;
  
  &:hover {
    background: var(--text-primary);
    border-color: var(--text-primary);
    color: var(--text-inverse);
  }
}

.header-title {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  font-size: 1rem;
  font-weight: 600;
  color: var(--text-primary);
  
  .dept-icon {
    font-size: 1.25rem;
    color: var(--text-secondary);
  }
}

// 视图切换标签
.view-tabs {
  position: relative;
  display: flex;
  background: var(--bg-tertiary);
  border-radius: 10px;
  padding: 4px;
}

.tab-btn {
  position: relative;
  z-index: 1;
  display: flex;
  align-items: center;
  gap: 0.375rem;
  padding: 0.5rem 1rem;
  font-size: 0.8125rem;
  font-weight: 500;
  color: var(--text-tertiary);
  border-radius: 8px;
  transition: color 0.2s ease;
  
  &:hover { color: var(--text-secondary); }
  &.active { color: var(--text-primary); }
}

.tab-indicator {
  position: absolute;
  top: 4px;
  left: 4px;
  width: calc(50% - 4px);
  height: calc(100% - 8px);
  background: var(--card-bg);
  border-radius: 8px;
  box-shadow: var(--shadow-sm);
  transition: transform 0.25s cubic-bezier(0.4, 0, 0.2, 1);
  
  &.org { transform: translateX(100%); }
}

.header-right {
  display: flex;
  align-items: center;
}

.contact-badge {
  display: flex;
  align-items: center;
  gap: 0.375rem;
  padding: 0.5rem 0.875rem;
  font-size: 0.75rem;
  color: var(--text-secondary);
  background: var(--bg-tertiary);
  border-radius: 8px;
  
  .el-icon { font-size: 0.875rem; }
}

// 主内容区
.main-content {
  height: calc(100vh - 60px);
  overflow: hidden;
}

.content-section {
  height: 100%;
}

// ==================== 介绍视图 ====================
.intro-section {
  display: flex;
  justify-content: center;
  padding: 2rem 1.5rem;
  overflow-y: auto;
}

.intro-card {
  width: 100%;
  max-width: 640px;
  background: var(--card-bg);
  border: 1px solid var(--border-secondary);
  border-radius: 20px;
  overflow: hidden;
  height: fit-content;
}

.intro-header {
  display: flex;
  align-items: center;
  gap: 1.25rem;
  padding: 2rem 2rem 1.5rem;
  background: linear-gradient(135deg, var(--bg-tertiary) 0%, transparent 100%);
  border-bottom: 1px solid var(--border-secondary);
}

.intro-icon {
  width: 72px;
  height: 72px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: var(--text-primary);
  color: var(--text-inverse);
  border-radius: 18px;
  flex-shrink: 0;
}

.intro-meta {
  h1 {
    font-family: 'Noto Serif SC', serif;
    font-size: 1.5rem;
    font-weight: 700;
    color: var(--text-primary);
    margin-bottom: 0.5rem;
  }
}

.meta-tags {
  display: flex;
  gap: 0.75rem;
  
  .tag {
    display: flex;
    align-items: center;
    gap: 0.25rem;
    font-size: 0.75rem;
    color: var(--text-tertiary);
    
    .el-icon { font-size: 0.875rem; }
  }
}

.intro-body {
  padding: 1.5rem 2rem;
}

.section-label {
  font-size: 0.6875rem;
  font-weight: 600;
  color: var(--text-tertiary);
  text-transform: uppercase;
  letter-spacing: 1px;
  margin-bottom: 0.75rem;
}

.intro-description {
  font-family: 'Noto Serif SC', serif;
  font-size: 0.9375rem;
  color: var(--text-secondary);
  line-height: 1.8;
}

// 团队预览
.team-preview {
  padding: 1.5rem 2rem 2rem;
  border-top: 1px solid var(--border-secondary);
}

.team-avatars {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  margin-bottom: 1rem;
}

.avatar-item {
  width: 40px;
  height: 40px;
  border-radius: 12px;
  overflow: hidden;
  cursor: pointer;
  transition: all 0.2s ease;
  border: 2px solid var(--card-bg);
  margin-left: -8px;
  
  &:first-child { margin-left: 0; }
  
  &:hover {
    transform: translateY(-4px) scale(1.1);
    z-index: 10;
    box-shadow: var(--shadow-md);
  }
  
  img {
    width: 100%;
    height: 100%;
    object-fit: cover;
  }
  
  .avatar-text {
    width: 100%;
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    background: var(--bg-tertiary);
    color: var(--text-secondary);
    font-size: 0.875rem;
    font-weight: 600;
  }
}

.avatar-more {
  width: 40px;
  height: 40px;
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: var(--text-primary);
  color: var(--text-inverse);
  font-size: 0.75rem;
  font-weight: 600;
  margin-left: -8px;
}

.view-all-btn {
  display: inline-flex;
  align-items: center;
  gap: 0.375rem;
  padding: 0.625rem 1rem;
  font-size: 0.8125rem;
  font-weight: 500;
  color: var(--text-secondary);
  background: var(--bg-tertiary);
  border-radius: 10px;
  transition: all 0.2s ease;
  
  &:hover {
    background: var(--text-primary);
    color: var(--text-inverse);
  }
}

// ==================== 架构视图 (G6) ====================
.org-section {
  display: flex;
  flex-direction: column;
  height: 100%;
}

// 工具栏
.org-toolbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0.75rem 1.5rem;
  background: var(--card-bg);
  border-bottom: 1px solid var(--border-secondary);
  flex-shrink: 0;
}

.toolbar-left {
  display: flex;
  align-items: center;
}

.toolbar-hint {
  display: flex;
  align-items: center;
  gap: 0.375rem;
  font-size: 0.75rem;
  color: var(--text-tertiary);
  
  .el-icon { font-size: 0.875rem; }
}

.toolbar-actions {
  display: flex;
  align-items: center;
  gap: 0.5rem;
}

.tool-btn {
  width: 32px;
  height: 32px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: var(--bg-tertiary);
  border: 1px solid var(--border-secondary);
  border-radius: 8px;
  color: var(--text-secondary);
  transition: all 0.15s ease;
  
  &:hover {
    background: var(--text-primary);
    border-color: var(--text-primary);
    color: var(--text-inverse);
  }
  
  &.active {
    background: #3b82f6;
    border-color: #3b82f6;
    color: white;
  }
}

.layout-toggle {
  display: flex;
  align-items: center;
  padding-left: 0.25rem;
  border-left: 1px solid var(--border-secondary);
}

.zoom-controls {
  display: flex;
  align-items: center;
  gap: 0.25rem;
  padding: 0 0.5rem;
  
  .zoom-level {
    min-width: 48px;
    text-align: center;
    font-size: 0.75rem;
    font-weight: 500;
    color: var(--text-secondary);
  }
}

// G6 画布容器
.org-canvas {
  flex: 1;
  overflow: hidden;
  position: relative;
}

// 空状态
.empty-org {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 4rem 2rem;
  color: var(--text-tertiary);
  
  .el-icon { margin-bottom: 1rem; }
  p { font-size: 0.875rem; }
}

// ==================== 员工卡片弹窗 ====================
.employee-modal-overlay {
  position: fixed;
  inset: 0;
  z-index: 2000;
  display: flex;
  align-items: center;
  justify-content: center;
  background: var(--overlay-bg);
  backdrop-filter: blur(8px);
  padding: 1rem;
}

.employee-card-modal {
  position: relative;
  width: 100%;
  max-width: 360px;
  background: var(--card-bg);
  border-radius: 24px;
  overflow: hidden;
  box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.3);
}

.close-btn {
  position: absolute;
  top: 1rem;
  right: 1rem;
  width: 32px;
  height: 32px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: rgba(0, 0, 0, 0.1);
  border-radius: 50%;
  color: var(--text-inverse);
  transition: all 0.2s ease;
  z-index: 10;
  
  &:hover {
    background: rgba(0, 0, 0, 0.2);
    transform: rotate(90deg);
  }
}

.card-header {
  padding: 2.5rem 1.5rem 1.5rem;
  text-align: center;
  background: var(--text-primary);
  color: var(--text-inverse);
}

.card-avatar {
  width: 80px;
  height: 80px;
  margin: 0 auto 1rem;
  border-radius: 20px;
  overflow: hidden;
  border: 3px solid rgba(255, 255, 255, 0.2);
  
  img {
    width: 100%;
    height: 100%;
    object-fit: cover;
  }
  
  .avatar-placeholder {
    width: 100%;
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    background: rgba(255, 255, 255, 0.2);
    font-size: 1.75rem;
    font-weight: 700;
  }
}

.card-name {
  font-family: 'Noto Serif SC', serif;
  font-size: 1.25rem;
  font-weight: 700;
  margin-bottom: 0.25rem;
}

.card-position {
  font-size: 0.8125rem;
  opacity: 0.8;
}

.card-signature {
  display: flex;
  align-items: flex-start;
  gap: 0.625rem;
  margin: 1.25rem;
  padding: 1rem;
  background: var(--bg-tertiary);
  border-radius: 14px;
  
  .el-icon {
    flex-shrink: 0;
    color: var(--text-tertiary);
    font-size: 1rem;
  }
  
  p {
    font-family: 'Noto Serif SC', serif;
    font-size: 0.8125rem;
    font-style: italic;
    color: var(--text-secondary);
    line-height: 1.6;
  }
}

.card-contacts {
  padding: 0 1.25rem;
  display: flex;
  flex-direction: column;
  gap: 0.625rem;
}

.contact-item {
  display: flex;
  align-items: center;
  gap: 0.875rem;
  padding: 0.875rem 1rem;
  background: var(--bg-secondary);
  border: 1px solid var(--border-secondary);
  border-radius: 14px;
  cursor: pointer;
  transition: all 0.2s ease;
  
  &:hover {
    border-color: var(--border-primary);
    
    .contact-icon {
      transform: scale(1.1);
    }
  }
  
  &.email:hover {
    border-color: #0078d4;
    
    .contact-icon.email {
      background: #0078d4;
      color: white;
    }
  }
}

.contact-icon {
  width: 40px;
  height: 40px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: var(--bg-tertiary);
  border-radius: 12px;
  color: var(--text-secondary);
  flex-shrink: 0;
  transition: all 0.2s ease;
  
  &.phone:hover {
    background: var(--text-primary);
    color: var(--text-inverse);
  }
}

.contact-detail {
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 0.125rem;
  
  .label {
    font-size: 0.6875rem;
    color: var(--text-tertiary);
  }
  
  .value {
    font-size: 0.8125rem;
    font-weight: 500;
    color: var(--text-primary);
  }
}

.outlook-tag {
  display: flex;
  align-items: center;
  gap: 0.25rem;
  padding: 0.25rem 0.625rem;
  font-size: 0.625rem;
  font-weight: 600;
  color: #0078d4;
  background: rgba(0, 120, 212, 0.1);
  border-radius: 6px;
  
  .el-icon { font-size: 0.75rem; }
}

// 下属成员
.card-subordinates {
  padding: 1.25rem;
  border-top: 1px solid var(--border-secondary);
  margin-top: 0.625rem;
}

.sub-label {
  display: block;
  font-size: 0.6875rem;
  font-weight: 600;
  color: var(--text-tertiary);
  text-transform: uppercase;
  letter-spacing: 1px;
  margin-bottom: 0.75rem;
}

.sub-list {
  display: flex;
  flex-wrap: wrap;
  gap: 0.5rem;
}

.sub-item {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.375rem 0.75rem 0.375rem 0.375rem;
  background: var(--bg-tertiary);
  border-radius: 20px;
  cursor: pointer;
  transition: all 0.2s ease;
  
  &:hover {
    background: var(--text-primary);
    
    .sub-name { color: var(--text-inverse); }
    .sub-avatar span { 
      background: rgba(255, 255, 255, 0.2);
      color: var(--text-inverse);
    }
  }
}

.sub-avatar {
  width: 28px;
  height: 28px;
  border-radius: 50%;
  overflow: hidden;
  
  img {
    width: 100%;
    height: 100%;
    object-fit: cover;
  }
  
  span {
    width: 100%;
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    background: var(--card-bg);
    color: var(--text-secondary);
    font-size: 0.75rem;
    font-weight: 600;
  }
}

.sub-name {
  font-size: 0.75rem;
  font-weight: 500;
  color: var(--text-primary);
  transition: color 0.2s ease;
}

// 过渡动画
.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.3s ease;
}

.fade-enter-from,
.fade-leave-to {
  opacity: 0;
}

// 响应式
@media (max-width: 768px) {
  .dept-header {
    flex-wrap: wrap;
    gap: 0.75rem;
    padding: 0.75rem 1rem;
  }
  
  .header-left { order: 1; }
  
  .view-tabs {
    order: 3;
    width: 100%;
    justify-content: center;
  }
  
  .header-right {
    order: 2;
    margin-left: auto;
  }
  
  .org-toolbar {
    flex-direction: column;
    gap: 0.75rem;
    padding: 0.75rem 1rem;
  }
  
  .toolbar-hint {
    display: none;
  }
  
  .intro-header {
    flex-direction: column;
    text-align: center;
    padding: 1.5rem;
  }
  
  .meta-tags {
    justify-content: center;
  }
  
  .intro-body,
  .team-preview {
    padding: 1.25rem 1.5rem;
  }
  
  .employee-card-modal {
    max-width: 100%;
    margin: 0 1rem;
  }
}
</style>
