<script setup>
import { computed } from 'vue'
import { useStore } from 'vuex'

const store = useStore()
const settings = computed(() => store.state.settings)
</script>

<template>
  <div class="about-page">
    <div class="about-card">
      <!-- Logo -->
      <div class="logo-section">
        <div class="logo">
          <img v-if="settings.site_logo" :src="settings.site_logo" alt="Logo" />
          <span v-else class="logo-text">NH</span>
        </div>
        <h1>{{ settings.site_name || 'NavHub' }}</h1>
        <p class="tagline">企业级极简交互式网址导航系统</p>
      </div>
      
      <!-- 特性列表 -->
      <div class="features">
        <div class="feature">
          <div class="feature-icon">
            <el-icon><MagicStick /></el-icon>
          </div>
          <div class="feature-content">
            <h3>极简设计</h3>
            <p>高级单色调风格，毛玻璃拟态，沉浸式体验</p>
          </div>
        </div>
        
        <div class="feature">
          <div class="feature-icon">
            <el-icon><Search /></el-icon>
          </div>
          <div class="feature-content">
            <h3>智能搜索</h3>
            <p>支持拼音首字母模糊检索，实时联想建议</p>
          </div>
        </div>
        
        <div class="feature">
          <div class="feature-icon">
            <el-icon><User /></el-icon>
          </div>
          <div class="feature-content">
            <h3>用户隔离</h3>
            <p>基于UUID的无状态访客标识，数据完全隔离</p>
          </div>
        </div>
        
        <div class="feature">
          <div class="feature-icon">
            <el-icon><Folder /></el-icon>
          </div>
          <div class="feature-content">
            <h3>文件夹系统</h3>
            <p>支持多级嵌套的工作台分组管理</p>
          </div>
        </div>
      </div>
      
      <!-- 技术栈 -->
      <div class="tech-stack">
        <h2>技术栈</h2>
        <div class="tech-list">
          <span class="tech-tag">Vue 3</span>
          <span class="tech-tag">Vuex 4</span>
          <span class="tech-tag">Vue Router</span>
          <span class="tech-tag">Element Plus</span>
          <span class="tech-tag">GSAP</span>
          <span class="tech-tag">Flask</span>
          <span class="tech-tag">SQLAlchemy</span>
          <span class="tech-tag">MySQL</span>
        </div>
      </div>
      
      <!-- 版权信息 -->
      <div class="footer">
        <p>{{ settings.footer_copyright || '© 2024 NavHub. All rights reserved.' }}</p>
      </div>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.about-page {
  display: flex;
  justify-content: center;
  padding: 2rem 0;
}

.about-card {
  max-width: 600px;
  width: 100%;
  background: var(--card-bg);
  border-radius: 24px;
  border: 1px solid var(--border-secondary);
  padding: 3rem 2rem;
  text-align: center;
}

.logo-section {
  margin-bottom: 3rem;
  
  .logo {
    width: 80px;
    height: 80px;
    margin: 0 auto 1.5rem;
    border-radius: 20px;
    background: linear-gradient(135deg, #3B82F6, #8B5CF6);
    display: flex;
    align-items: center;
    justify-content: center;
    box-shadow: 0 8px 32px rgba(59, 130, 246, 0.3);
    
    img {
      width: 48px;
      height: 48px;
      object-fit: contain;
    }
    
    .logo-text {
      font-size: 2rem;
      font-weight: 800;
      color: white;
    }
  }
  
  h1 {
    font-size: 2rem;
    font-weight: 800;
    color: var(--text-primary);
    margin-bottom: 0.5rem;
    letter-spacing: -0.5px;
  }
  
  .tagline {
    font-size: 0.9375rem;
    color: var(--text-tertiary);
  }
}

.features {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 1.5rem;
  margin-bottom: 3rem;
  text-align: left;
  
  @media (max-width: 480px) {
    grid-template-columns: 1fr;
  }
}

.feature {
  display: flex;
  gap: 1rem;
  padding: 1.25rem;
  background: var(--bg-tertiary);
  border-radius: 16px;
  
  .feature-icon {
    width: 40px;
    height: 40px;
    border-radius: 10px;
    background: var(--accent-light);
    color: var(--accent);
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
    
    .el-icon {
      font-size: 18px;
    }
  }
  
  .feature-content {
    h3 {
      font-size: 0.9375rem;
      font-weight: 600;
      color: var(--text-primary);
      margin-bottom: 0.25rem;
    }
    
    p {
      font-size: 0.8125rem;
      color: var(--text-tertiary);
      line-height: 1.5;
    }
  }
}

.tech-stack {
  margin-bottom: 2rem;
  
  h2 {
    font-size: 0.875rem;
    font-weight: 600;
    color: var(--text-secondary);
    margin-bottom: 1rem;
    text-transform: uppercase;
    letter-spacing: 0.5px;
  }
  
  .tech-list {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    gap: 0.5rem;
  }
  
  .tech-tag {
    padding: 0.375rem 0.75rem;
    font-size: 0.8125rem;
    color: var(--text-secondary);
    background: var(--bg-tertiary);
    border-radius: 8px;
    transition: all 0.2s ease;
    
    &:hover {
      background: var(--accent-light);
      color: var(--accent);
    }
  }
}

.footer {
  padding-top: 2rem;
  border-top: 1px solid var(--border-secondary);
  
  p {
    font-size: 0.8125rem;
    color: var(--text-tertiary);
  }
}
</style>
