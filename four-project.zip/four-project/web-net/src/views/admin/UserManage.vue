<script setup>
/**
 * 用户管理页面
 * 
 * 功能：
 * - 用户列表展示（分页、搜索、筛选）
 * - 用户信息编辑
 * - 角色设置
 * - 账户状态管理
 * - 重置密码（仅DEV模式）
 * - 批量操作
 */
import { ref, reactive, computed, onMounted, watch } from 'vue'
import { useStore } from 'vuex'
import { ElMessage, ElMessageBox } from 'element-plus'

const store = useStore()

// 数据
const users = computed(() => store.state.admin.users)
const pagination = computed(() => store.state.admin.usersPagination)
const loading = computed(() => store.state.admin.usersLoading)
const authMode = computed(() => store.state.admin.authMode)

// 查询参数
const queryParams = reactive({
  page: 1,
  per_page: 20,
  search: '',
  role: 'all',
  status: 'all',
  sort: 'created_at',
  order: 'desc'
})

// 选中的用户
const selectedUsers = ref([])

// 对话框
const dialogVisible = ref(false)
const dialogType = ref('edit')  // 'edit' | 'create' | 'password'
const currentUser = ref(null)

// 表单数据
const formData = reactive({
  email: '',
  name: '',
  role: 'user',
  password: ''
})

// 表单引用
const formRef = ref(null)

// 表单验证规则
const formRules = {
  email: [
    { required: true, message: '请输入邮箱', trigger: 'blur' },
    { type: 'email', message: '请输入有效的邮箱', trigger: 'blur' }
  ],
  name: [
    { required: true, message: '请输入姓名', trigger: 'blur' }
  ],
  password: [
    { min: 6, message: '密码长度不能少于6位', trigger: 'blur' }
  ]
}

// 初始化
onMounted(() => {
  fetchUsers()
})

// 监听查询参数变化
watch([
  () => queryParams.search,
  () => queryParams.role,
  () => queryParams.status
], () => {
  queryParams.page = 1  // 重置页码
  fetchUsers()
}, { debounce: 300 })

// 获取用户列表
const fetchUsers = async () => {
  try {
    await store.dispatch('admin/fetchUsers', queryParams)
  } catch (e) {
    ElMessage.error('获取用户列表失败')
  }
}

// 分页变化
const handlePageChange = (page) => {
  queryParams.page = page
  fetchUsers()
}

// 排序变化
const handleSortChange = ({ prop, order }) => {
  queryParams.sort = prop || 'created_at'
  queryParams.order = order === 'ascending' ? 'asc' : 'desc'
  fetchUsers()
}

// 选择变化
const handleSelectionChange = (selection) => {
  selectedUsers.value = selection
}

// 打开创建对话框
const openCreateDialog = () => {
  dialogType.value = 'create'
  currentUser.value = null
  Object.assign(formData, {
    email: '',
    name: '',
    role: 'user',
    password: ''
  })
  dialogVisible.value = true
}

// 打开编辑对话框
const openEditDialog = (user) => {
  dialogType.value = 'edit'
  currentUser.value = user
  Object.assign(formData, {
    email: user.email,
    name: user.name,
    role: user.role,
    password: ''
  })
  dialogVisible.value = true
}

// 打开重置密码对话框
const openPasswordDialog = (user) => {
  dialogType.value = 'password'
  currentUser.value = user
  formData.password = ''
  dialogVisible.value = true
}

// 提交表单
const handleSubmit = async () => {
  try {
    await formRef.value.validate()
    
    if (dialogType.value === 'create') {
      await store.dispatch('admin/createUser', formData)
      ElMessage.success('用户创建成功')
    } else if (dialogType.value === 'edit') {
      await store.dispatch('admin/updateUser', {
        uuid: currentUser.value.uuid,
        data: {
          email: formData.email,
          name: formData.name,
          role: formData.role
        }
      })
      ElMessage.success('用户信息已更新')
    } else if (dialogType.value === 'password') {
      await store.dispatch('admin/resetUserPassword', {
        uuid: currentUser.value.uuid,
        newPassword: formData.password
      })
      ElMessage.success('密码已重置')
    }
    
    dialogVisible.value = false
    fetchUsers()
  } catch (e) {
    ElMessage.error(e.message || '操作失败')
  }
}

// 设置角色
const handleSetRole = async (user, role) => {
  try {
    await store.dispatch('admin/setUserRole', { uuid: user.uuid, role })
    ElMessage.success(`已设置为${role === 'admin' ? '管理员' : '普通用户'}`)
  } catch (e) {
    ElMessage.error(e.message || '设置失败')
  }
}

// 切换状态
const handleToggleStatus = async (user) => {
  try {
    await ElMessageBox.confirm(
      `确定要${user.is_active ? '禁用' : '启用'}用户 ${user.name || user.email} 吗？`,
      '确认操作',
      { type: 'warning' }
    )
    await store.dispatch('admin/toggleUserStatus', user.uuid)
    ElMessage.success(`用户已${user.is_active ? '禁用' : '启用'}`)
  } catch (e) {
    if (e !== 'cancel') {
      ElMessage.error(e.message || '操作失败')
    }
  }
}

// 删除用户
const handleDelete = async (user) => {
  try {
    await ElMessageBox.confirm(
      `确定要删除用户 ${user.name || user.email} 吗？此操作不可恢复！`,
      '确认删除',
      { type: 'error' }
    )
    await store.dispatch('admin/deleteUser', user.uuid)
    ElMessage.success('用户已删除')
  } catch (e) {
    if (e !== 'cancel') {
      ElMessage.error(e.message || '删除失败')
    }
  }
}

// 批量删除
const handleBatchDelete = async () => {
  if (selectedUsers.value.length === 0) {
    ElMessage.warning('请先选择要删除的用户')
    return
  }
  
  try {
    await ElMessageBox.confirm(
      `确定要删除选中的 ${selectedUsers.value.length} 个用户吗？`,
      '批量删除',
      { type: 'error' }
    )
    const uuids = selectedUsers.value.map(u => u.uuid)
    await store.dispatch('admin/batchDeleteUsers', uuids)
    ElMessage.success('批量删除成功')
    selectedUsers.value = []
  } catch (e) {
    if (e !== 'cancel') {
      ElMessage.error(e.message || '删除失败')
    }
  }
}

// 批量设置角色
const handleBatchSetRole = async (role) => {
  if (selectedUsers.value.length === 0) {
    ElMessage.warning('请先选择用户')
    return
  }
  
  try {
    const uuids = selectedUsers.value.map(u => u.uuid)
    await store.dispatch('admin/batchSetRole', { uuids, role })
    ElMessage.success(`已将 ${uuids.length} 个用户设置为${role === 'admin' ? '管理员' : '普通用户'}`)
    selectedUsers.value = []
  } catch (e) {
    ElMessage.error(e.message || '操作失败')
  }
}

// 格式化时间
const formatTime = (time) => {
  if (!time) return '-'
  return new Date(time).toLocaleString('zh-CN')
}
</script>

<template>
  <div class="user-manage">
    <!-- 页面标题 -->
    <div class="page-header">
      <div class="header-left">
        <h1 class="page-title">用户管理</h1>
        <p class="page-desc">管理系统用户、设置角色和权限</p>
      </div>
      <div class="header-right">
        <el-button type="primary" :icon="'Plus'" @click="openCreateDialog">
          创建用户
        </el-button>
      </div>
    </div>
    
    <!-- 搜索和筛选 -->
    <el-card class="filter-card">
      <div class="filter-row">
        <el-input
          v-model="queryParams.search"
          placeholder="搜索邮箱、姓名或UUID"
          prefix-icon="Search"
          clearable
          style="width: 280px"
        />
        
        <el-select v-model="queryParams.role" placeholder="角色筛选" style="width: 140px">
          <el-option label="全部角色" value="all" />
          <el-option label="管理员" value="admin" />
          <el-option label="普通用户" value="user" />
        </el-select>
        
        <el-select v-model="queryParams.status" placeholder="状态筛选" style="width: 140px">
          <el-option label="全部状态" value="all" />
          <el-option label="已启用" value="active" />
          <el-option label="已禁用" value="inactive" />
        </el-select>
        
        <div class="filter-spacer"></div>
        
        <!-- 批量操作 -->
        <template v-if="selectedUsers.length > 0">
          <span class="selected-count">已选 {{ selectedUsers.length }} 项</span>
          <el-dropdown @command="handleBatchSetRole">
            <el-button>
              批量设置角色 <el-icon class="el-icon--right"><ArrowDown /></el-icon>
            </el-button>
            <template #dropdown>
              <el-dropdown-menu>
                <el-dropdown-item command="admin">设为管理员</el-dropdown-item>
                <el-dropdown-item command="user">设为普通用户</el-dropdown-item>
              </el-dropdown-menu>
            </template>
          </el-dropdown>
          <el-button type="danger" plain @click="handleBatchDelete">
            批量删除
          </el-button>
        </template>
      </div>
    </el-card>
    
    <!-- 用户列表 -->
    <el-card class="table-card">
      <el-table
        :data="users"
        v-loading="loading"
        @selection-change="handleSelectionChange"
        @sort-change="handleSortChange"
        row-key="uuid"
        style="width: 100%"
      >
        <el-table-column type="selection" width="55" />
        
        <el-table-column label="用户" min-width="200">
          <template #default="{ row }">
            <div class="user-cell">
              <el-avatar :size="36" :src="row.avatar">
                {{ (row.name || row.email || '').charAt(0).toUpperCase() }}
              </el-avatar>
              <div class="user-info">
                <div class="user-name">{{ row.name || '-' }}</div>
                <div class="user-email">{{ row.email }}</div>
              </div>
            </div>
          </template>
        </el-table-column>
        
        <el-table-column label="角色" width="100" align="center">
          <template #default="{ row }">
            <el-tag :type="row.role === 'admin' ? 'danger' : 'info'" size="small">
              {{ row.role === 'admin' ? '管理员' : '用户' }}
            </el-tag>
          </template>
        </el-table-column>
        
        <el-table-column label="状态" width="90" align="center">
          <template #default="{ row }">
            <el-tag :type="row.is_active ? 'success' : 'warning'" size="small">
              {{ row.is_active ? '正常' : '禁用' }}
            </el-tag>
          </template>
        </el-table-column>
        
        <el-table-column label="认证方式" width="110" align="center">
          <template #default="{ row }">
            <el-tooltip :content="row.oauth_id ? `OAuth ID: ${row.oauth_id.substring(0, 16)}...` : ''">
              <el-tag 
                :type="row.oauth_id ? 'success' : (row.has_password ? 'warning' : 'info')" 
                size="small"
              >
                {{ row.oauth_id ? 'OAuth' : (row.has_password ? '密码' : '未设置') }}
              </el-tag>
            </el-tooltip>
          </template>
        </el-table-column>
        
        <el-table-column 
          label="创建时间" 
          prop="created_at" 
          width="170"
          sortable="custom"
        >
          <template #default="{ row }">
            {{ formatTime(row.created_at) }}
          </template>
        </el-table-column>
        
        <el-table-column 
          label="最后登录" 
          prop="last_login_at" 
          width="170"
          sortable="custom"
        >
          <template #default="{ row }">
            {{ formatTime(row.last_login_at) }}
          </template>
        </el-table-column>
        
        <el-table-column label="操作" width="200" fixed="right">
          <template #default="{ row }">
            <el-button size="small" link type="primary" @click="openEditDialog(row)">
              编辑
            </el-button>
            <el-dropdown trigger="click" @command="(cmd) => handleDropdownCommand(cmd, row)">
              <el-button size="small" link type="primary">
                更多 <el-icon class="el-icon--right"><ArrowDown /></el-icon>
              </el-button>
              <template #dropdown>
                <el-dropdown-menu>
                  <el-dropdown-item 
                    v-if="row.role !== 'admin'"
                    @click="handleSetRole(row, 'admin')"
                  >
                    <el-icon><Avatar /></el-icon>
                    设为管理员
                  </el-dropdown-item>
                  <el-dropdown-item 
                    v-if="row.role === 'admin'"
                    @click="handleSetRole(row, 'user')"
                  >
                    <el-icon><User /></el-icon>
                    设为普通用户
                  </el-dropdown-item>
                  <el-dropdown-item divided @click="handleToggleStatus(row)">
                    <el-icon><Switch /></el-icon>
                    {{ row.is_active ? '禁用账户' : '启用账户' }}
                  </el-dropdown-item>
                  <el-dropdown-item 
                    v-if="authMode === 'dev'"
                    @click="openPasswordDialog(row)"
                  >
                    <el-icon><Lock /></el-icon>
                    重置密码
                  </el-dropdown-item>
                  <el-dropdown-item divided @click="handleDelete(row)">
                    <el-icon color="#f56c6c"><Delete /></el-icon>
                    <span style="color: #f56c6c">删除用户</span>
                  </el-dropdown-item>
                </el-dropdown-menu>
              </template>
            </el-dropdown>
          </template>
        </el-table-column>
      </el-table>
      
      <!-- 分页 -->
      <div class="pagination-wrapper">
        <el-pagination
          v-model:current-page="queryParams.page"
          :page-size="pagination.per_page"
          :total="pagination.total"
          :page-sizes="[10, 20, 50, 100]"
          layout="total, sizes, prev, pager, next, jumper"
          @current-change="handlePageChange"
          @size-change="(size) => { queryParams.per_page = size; fetchUsers() }"
        />
      </div>
    </el-card>
    
    <!-- 对话框 -->
    <el-dialog
      v-model="dialogVisible"
      :title="dialogType === 'create' ? '创建用户' : (dialogType === 'edit' ? '编辑用户' : '重置密码')"
      width="500px"
    >
      <el-form
        ref="formRef"
        :model="formData"
        :rules="formRules"
        label-width="80px"
      >
        <template v-if="dialogType !== 'password'">
          <el-form-item label="邮箱" prop="email">
            <el-input v-model="formData.email" placeholder="user@example.com" />
          </el-form-item>
          
          <el-form-item label="姓名" prop="name">
            <el-input v-model="formData.name" placeholder="用户姓名" />
          </el-form-item>
          
          <el-form-item label="角色" prop="role">
            <el-radio-group v-model="formData.role">
              <el-radio value="user">普通用户</el-radio>
              <el-radio value="admin">管理员</el-radio>
            </el-radio-group>
          </el-form-item>
          
          <el-form-item v-if="dialogType === 'create' && authMode === 'dev'" label="密码" prop="password">
            <el-input 
              v-model="formData.password" 
              type="password" 
              placeholder="可选，留空则用户无法使用密码登录"
              show-password
            />
          </el-form-item>
        </template>
        
        <template v-else>
          <el-alert 
            title="重置密码"
            :description="`为用户 ${currentUser?.name || currentUser?.email} 设置新密码`"
            type="info"
            :closable="false"
            show-icon
            style="margin-bottom: 20px"
          />
          
          <el-form-item label="新密码" prop="password" :rules="[{ required: true, message: '请输入新密码' }, { min: 6, message: '密码长度不能少于6位' }]">
            <el-input 
              v-model="formData.password" 
              type="password" 
              placeholder="请输入新密码"
              show-password
            />
          </el-form-item>
        </template>
      </el-form>
      
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" @click="handleSubmit">
          {{ dialogType === 'create' ? '创建' : '确定' }}
        </el-button>
      </template>
    </el-dialog>
  </div>
</template>

<style lang="scss" scoped>
.user-manage {
  max-width: 1400px;
  margin: 0 auto;
}

// 页面头部
.page-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  margin-bottom: 24px;
  
  .page-title {
    font-size: 24px;
    font-weight: 600;
    color: var(--text-primary, #171717);
    margin: 0 0 4px;
  }
  
  .page-desc {
    font-size: 14px;
    color: var(--text-secondary, #737373);
    margin: 0;
  }
}

// 筛选卡片
.filter-card {
  margin-bottom: 16px;
  
  :deep(.el-card__body) {
    padding: 16px 20px;
  }
}

.filter-row {
  display: flex;
  align-items: center;
  gap: 12px;
  flex-wrap: wrap;
  
  .filter-spacer {
    flex: 1;
  }
  
  .selected-count {
    font-size: 14px;
    color: var(--text-secondary, #737373);
  }
}

// 表格卡片
.table-card {
  :deep(.el-card__body) {
    padding: 0;
  }
}

.user-cell {
  display: flex;
  align-items: center;
  gap: 12px;
  
  .user-info {
    .user-name {
      font-size: 14px;
      font-weight: 500;
      color: var(--text-primary, #171717);
    }
    
    .user-email {
      font-size: 12px;
      color: var(--text-secondary, #737373);
    }
  }
}

.pagination-wrapper {
  display: flex;
  justify-content: flex-end;
  padding: 16px 20px;
  border-top: 1px solid var(--border-secondary, #e5e5e5);
}

// 响应式
@media (max-width: 768px) {
  .page-header {
    flex-direction: column;
    gap: 16px;
  }
  
  .filter-row {
    flex-direction: column;
    align-items: stretch;
    
    .el-input,
    .el-select {
      width: 100% !important;
    }
    
    .filter-spacer {
      display: none;
    }
  }
}
</style>

