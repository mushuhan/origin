<script setup>
/**
 * 数据导入页面
 * 
 * 功能：
 * - 下载 Excel 导入模板
 * - 上传 Excel 批量导入用户
 * - 显示导入结果（成功/失败统计）
 */
import { ref, reactive } from 'vue'
import { ElMessage } from 'element-plus'
import * as adminApi from '@/api/admin'

// 上传状态
const uploading = ref(false)
const uploadProgress = ref(0)

// 导入结果
const importResult = ref(null)

// 上传组件引用
const uploadRef = ref(null)

// 文件列表
const fileList = ref([])

// 下载模板
const downloadTemplate = async () => {
  try {
    ElMessage.info('正在下载模板...')
    await adminApi.downloadImportTemplate()
    ElMessage.success('模板下载成功')
  } catch (e) {
    ElMessage.error('下载失败: ' + e.message)
  }
}

// 文件上传前校验
const beforeUpload = (file) => {
  const isExcel = file.type === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' ||
                  file.type === 'application/vnd.ms-excel' ||
                  file.name.endsWith('.xlsx') ||
                  file.name.endsWith('.xls')
  
  if (!isExcel) {
    ElMessage.error('只能上传 Excel 文件（.xlsx 或 .xls）')
    return false
  }
  
  const isLt10M = file.size / 1024 / 1024 < 10
  if (!isLt10M) {
    ElMessage.error('文件大小不能超过 10MB')
    return false
  }
  
  return true
}

// 处理上传
const handleUpload = async (options) => {
  const file = options.file
  uploading.value = true
  uploadProgress.value = 0
  importResult.value = null
  
  try {
    // 模拟上传进度
    const progressInterval = setInterval(() => {
      if (uploadProgress.value < 90) {
        uploadProgress.value += 10
      }
    }, 200)
    
    const result = await adminApi.importUsersFromExcel(file)
    
    clearInterval(progressInterval)
    uploadProgress.value = 100
    
    importResult.value = result
    
    if (result.failed === 0) {
      ElMessage.success(`导入成功！新增 ${result.created} 人，更新 ${result.updated} 人`)
    } else {
      ElMessage.warning(`导入完成，但有 ${result.failed} 条失败`)
    }
    
    // 清空文件列表
    fileList.value = []
    
  } catch (e) {
    ElMessage.error('导入失败: ' + e.message)
  } finally {
    uploading.value = false
  }
}

// 重新导入
const resetImport = () => {
  importResult.value = null
  fileList.value = []
  uploadProgress.value = 0
}
</script>

<template>
  <div class="data-import">
    <!-- 页面标题 -->
    <div class="page-header">
      <div class="header-left">
        <h1 class="page-title">数据导入</h1>
        <p class="page-desc">通过 Excel 批量导入用户数据</p>
      </div>
    </div>
    
    <!-- 导入说明 -->
    <el-card class="info-card">
      <div class="info-header">
        <el-icon :size="24" color="#3b82f6"><InfoFilled /></el-icon>
        <span class="info-title">导入说明</span>
      </div>
      <div class="info-content">
        <ul class="info-list">
          <li><strong>支持格式：</strong>.xlsx 和 .xls 格式的 Excel 文件</li>
          <li><strong>必填字段：</strong>email（邮箱地址）</li>
          <li><strong>可选字段：</strong>name（姓名）、role（角色：user/admin）、password（密码，仅开发模式有效）</li>
          <li><strong>导入逻辑：</strong>
            <ul>
              <li>如果邮箱已存在 → 更新该用户的信息</li>
              <li>如果邮箱不存在 → 创建新用户（系统自动生成 UUID）</li>
            </ul>
          </li>
          <li><strong>管理员自动识别：</strong>如果邮箱在系统管理员列表中，将自动设置为管理员</li>
        </ul>
      </div>
    </el-card>
    
    <!-- 模板下载 -->
    <el-card class="template-card">
      <div class="template-content">
        <div class="template-icon">
          <el-icon :size="48"><Document /></el-icon>
        </div>
        <div class="template-info">
          <h3 class="template-title">下载导入模板</h3>
          <p class="template-desc">请先下载模板，按照模板格式填写数据后上传</p>
        </div>
        <el-button type="primary" :icon="'Download'" @click="downloadTemplate">
          下载模板
        </el-button>
      </div>
    </el-card>
    
    <!-- 文件上传 -->
    <el-card class="upload-card">
      <template #header>
        <div class="card-header">
          <span class="card-title">上传文件</span>
          <el-button v-if="importResult" link type="primary" @click="resetImport">
            重新导入
          </el-button>
        </div>
      </template>
      
      <!-- 上传区域 -->
      <div v-if="!importResult" class="upload-area">
        <el-upload
          ref="uploadRef"
          v-model:file-list="fileList"
          class="upload-dragger"
          drag
          :auto-upload="true"
          :show-file-list="false"
          :before-upload="beforeUpload"
          :http-request="handleUpload"
          :disabled="uploading"
          accept=".xlsx,.xls"
        >
          <div class="upload-content" v-if="!uploading">
            <el-icon class="upload-icon" :size="48"><UploadFilled /></el-icon>
            <div class="upload-text">
              <p class="upload-main">将 Excel 文件拖到此处，或 <em>点击上传</em></p>
              <p class="upload-hint">支持 .xlsx 和 .xls 格式，文件大小不超过 10MB</p>
            </div>
          </div>
          
          <div class="upload-progress" v-else>
            <el-progress 
              type="circle" 
              :percentage="uploadProgress"
              :width="120"
            />
            <p class="progress-text">正在导入...</p>
          </div>
        </el-upload>
      </div>
      
      <!-- 导入结果 -->
      <div v-else class="import-result">
        <div class="result-header">
          <el-icon 
            class="result-icon" 
            :size="48"
            :color="importResult.failed === 0 ? '#10b981' : '#f59e0b'"
          >
            <component :is="importResult.failed === 0 ? 'CircleCheck' : 'Warning'" />
          </el-icon>
          <h3 class="result-title">
            {{ importResult.failed === 0 ? '导入成功' : '导入完成（有部分失败）' }}
          </h3>
        </div>
        
        <!-- 统计数据 -->
        <div class="result-stats">
          <div class="stat-item">
            <div class="stat-value">{{ importResult.total }}</div>
            <div class="stat-label">总记录数</div>
          </div>
          <div class="stat-item success">
            <div class="stat-value">{{ importResult.created }}</div>
            <div class="stat-label">新增用户</div>
          </div>
          <div class="stat-item info">
            <div class="stat-value">{{ importResult.updated }}</div>
            <div class="stat-label">更新用户</div>
          </div>
          <div class="stat-item" :class="{ error: importResult.failed > 0 }">
            <div class="stat-value">{{ importResult.failed }}</div>
            <div class="stat-label">失败记录</div>
          </div>
        </div>
        
        <!-- 错误详情 -->
        <div v-if="importResult.errors && importResult.errors.length > 0" class="error-details">
          <h4 class="error-title">
            <el-icon><Warning /></el-icon>
            失败记录详情
          </h4>
          <el-table :data="importResult.errors" size="small" max-height="300">
            <el-table-column prop="row" label="行号" width="80" />
            <el-table-column prop="email" label="邮箱" min-width="200" />
            <el-table-column prop="reason" label="失败原因" min-width="200" />
          </el-table>
        </div>
      </div>
    </el-card>
  </div>
</template>

<style lang="scss" scoped>
.data-import {
  max-width: 900px;
  margin: 0 auto;
}

// 页面头部
.page-header {
  margin-bottom: 24px;
  
  .page-title {
    font-size: 24px;
    font-weight: 600;
    color: var(--text-primary, #171717);
    margin: 0 0 4px;
  }
  
  .page-desc {
    font-size: 14px;
    color: var(--text-secondary, #737373);
    margin: 0;
  }
}

// 说明卡片
.info-card {
  margin-bottom: 20px;
  background: linear-gradient(135deg, #eff6ff 0%, #f0f9ff 100%);
  border: 1px solid #bfdbfe;
  
  :deep(.el-card__body) {
    padding: 20px 24px;
  }
  
  .info-header {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-bottom: 12px;
    
    .info-title {
      font-size: 16px;
      font-weight: 600;
      color: #1e40af;
    }
  }
  
  .info-list {
    margin: 0;
    padding-left: 20px;
    color: #1e3a8a;
    font-size: 14px;
    line-height: 1.8;
    
    li {
      margin-bottom: 4px;
    }
    
    ul {
      margin: 4px 0;
      padding-left: 20px;
    }
    
    strong {
      color: #1e40af;
    }
  }
}

// 模板下载卡片
.template-card {
  margin-bottom: 20px;
  
  .template-content {
    display: flex;
    align-items: center;
    gap: 20px;
    
    .template-icon {
      width: 80px;
      height: 80px;
      display: flex;
      align-items: center;
      justify-content: center;
      background: var(--bg-tertiary, #f5f5f7);
      border-radius: 16px;
      color: var(--accent, #3b82f6);
    }
    
    .template-info {
      flex: 1;
      
      .template-title {
        font-size: 16px;
        font-weight: 600;
        color: var(--text-primary, #171717);
        margin: 0 0 4px;
      }
      
      .template-desc {
        font-size: 14px;
        color: var(--text-secondary, #737373);
        margin: 0;
      }
    }
  }
}

// 上传卡片
.upload-card {
  .card-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    
    .card-title {
      font-size: 16px;
      font-weight: 600;
      color: var(--text-primary, #171717);
    }
  }
}

// 上传区域
.upload-area {
  .upload-dragger {
    width: 100%;
    
    :deep(.el-upload-dragger) {
      width: 100%;
      height: auto;
      padding: 60px 20px;
      border-radius: 12px;
      border: 2px dashed var(--border-secondary, #e5e5e5);
      background: var(--bg-tertiary, #fafafa);
      transition: all 0.2s;
      
      &:hover {
        border-color: var(--accent, #3b82f6);
        background: rgba(59, 130, 246, 0.02);
      }
    }
  }
  
  .upload-content {
    text-align: center;
    
    .upload-icon {
      color: var(--text-tertiary, #a3a3a3);
      margin-bottom: 16px;
    }
    
    .upload-main {
      font-size: 16px;
      color: var(--text-primary, #171717);
      margin: 0 0 8px;
      
      em {
        color: var(--accent, #3b82f6);
        font-style: normal;
      }
    }
    
    .upload-hint {
      font-size: 13px;
      color: var(--text-tertiary, #a3a3a3);
      margin: 0;
    }
  }
  
  .upload-progress {
    text-align: center;
    
    .progress-text {
      margin-top: 16px;
      font-size: 14px;
      color: var(--text-secondary, #737373);
    }
  }
}

// 导入结果
.import-result {
  .result-header {
    text-align: center;
    margin-bottom: 24px;
    
    .result-icon {
      margin-bottom: 12px;
    }
    
    .result-title {
      font-size: 18px;
      font-weight: 600;
      color: var(--text-primary, #171717);
      margin: 0;
    }
  }
  
  .result-stats {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 16px;
    margin-bottom: 24px;
    
    .stat-item {
      text-align: center;
      padding: 20px;
      background: var(--bg-tertiary, #f5f5f7);
      border-radius: 12px;
      
      &.success {
        background: rgba(16, 185, 129, 0.1);
        .stat-value { color: #10b981; }
      }
      
      &.info {
        background: rgba(59, 130, 246, 0.1);
        .stat-value { color: #3b82f6; }
      }
      
      &.error {
        background: rgba(239, 68, 68, 0.1);
        .stat-value { color: #ef4444; }
      }
      
      .stat-value {
        font-size: 28px;
        font-weight: 700;
        color: var(--text-primary, #171717);
        line-height: 1;
      }
      
      .stat-label {
        font-size: 13px;
        color: var(--text-secondary, #737373);
        margin-top: 8px;
      }
    }
  }
  
  .error-details {
    .error-title {
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 14px;
      font-weight: 600;
      color: #f59e0b;
      margin: 0 0 12px;
    }
  }
}

// 响应式
@media (max-width: 768px) {
  .template-content {
    flex-direction: column;
    text-align: center;
  }
  
  .result-stats {
    grid-template-columns: repeat(2, 1fr);
  }
}
</style>

