<script setup>
/**
 * 管理员登录页面
 * 
 * 【混合认证支持】
 * - DEV 模式：显示账号密码登录表单
 * - PROD 模式：显示 OAuth 登录按钮，点击跳转到 IDaaS
 */
import { ref, reactive, computed, onMounted } from 'vue'
import { useStore } from 'vuex'
import { useRouter, useRoute } from 'vue-router'
import { ElMessage } from 'element-plus'

const store = useStore()
const router = useRouter()
const route = useRoute()

// 表单数据
const form = reactive({
  email: '',
  password: '',
  name: ''  // 仅注册时使用
})

// 状态
const loading = computed(() => store.state.admin.loading)
const authMode = computed(() => store.state.admin.authMode)
const isDevMode = computed(() => authMode.value === 'dev')
const error = computed(() => store.state.admin.error)

// 是否显示注册表单
const isRegisterMode = ref(false)

// 错误提示
const errorMessage = computed(() => {
  if (route.query.error === 'no_permission') {
    return '您没有管理员权限，请联系系统管理员'
  }
  return error.value
})

// 初始化：获取认证模式
onMounted(async () => {
  try {
    await store.dispatch('admin/fetchAuthMode')
  } catch (e) {
    console.error('获取认证模式失败:', e)
  }
})

// 表单验证
const formRef = ref(null)
const rules = {
  email: [
    { required: true, message: '请输入邮箱', trigger: 'blur' },
    { type: 'email', message: '请输入有效的邮箱地址', trigger: 'blur' }
  ],
  password: [
    { required: true, message: '请输入密码', trigger: 'blur' },
    { min: 6, message: '密码长度不能少于6位', trigger: 'blur' }
  ],
  name: [
    { required: true, message: '请输入姓名', trigger: 'blur' }
  ]
}

// DEV 模式：登录
const handleLogin = async () => {
  try {
    await formRef.value.validate()
    await store.dispatch('admin/login', {
      email: form.email,
      password: form.password
    })
    
    ElMessage.success('登录成功')
    
    // 跳转到原来要访问的页面或后台首页
    const redirect = route.query.redirect || '/admin'
    router.push(redirect)
  } catch (e) {
    // 错误已在 store 中处理
    if (e.message) {
      ElMessage.error(e.message)
    }
  }
}

// DEV 模式：注册
const handleRegister = async () => {
  try {
    await formRef.value.validate()
    await store.dispatch('admin/register', {
      email: form.email,
      password: form.password,
      name: form.name
    })
    
    ElMessage.success('注册成功')
    
    const redirect = route.query.redirect || '/admin'
    router.push(redirect)
  } catch (e) {
    if (e.message) {
      ElMessage.error(e.message)
    }
  }
}

// PROD 模式：跳转 OAuth
const handleOAuthLogin = () => {
  store.dispatch('admin/redirectToOAuth')
}

// 切换登录/注册模式
const toggleMode = () => {
  isRegisterMode.value = !isRegisterMode.value
  form.name = ''
}
</script>

<template>
  <div class="admin-login-page">
    <!-- 背景装饰 -->
    <div class="bg-decoration">
      <div class="bg-circle bg-circle-1"></div>
      <div class="bg-circle bg-circle-2"></div>
      <div class="bg-circle bg-circle-3"></div>
    </div>
    
    <div class="login-container">
      <!-- Logo 和标题 -->
      <div class="login-header">
        <div class="logo">
          <el-icon :size="48"><DataBoard /></el-icon>
        </div>
        <h1 class="title">管理后台</h1>
        <p class="subtitle">NavHub Administration</p>
      </div>
      
      <!-- 错误提示 -->
      <el-alert 
        v-if="errorMessage"
        :title="errorMessage"
        type="error"
        show-icon
        :closable="false"
        class="error-alert"
      />
      
      <!-- DEV 模式：登录/注册表单 -->
      <div v-if="isDevMode" class="login-form-wrapper">
        <el-form
          ref="formRef"
          :model="form"
          :rules="rules"
          class="login-form"
          @submit.prevent="isRegisterMode ? handleRegister() : handleLogin()"
        >
          <!-- 邮箱 -->
          <el-form-item prop="email">
            <el-input
              v-model="form.email"
              placeholder="邮箱地址"
              size="large"
              prefix-icon="Message"
            />
          </el-form-item>
          
          <!-- 姓名（仅注册） -->
          <el-form-item v-if="isRegisterMode" prop="name">
            <el-input
              v-model="form.name"
              placeholder="您的姓名"
              size="large"
              prefix-icon="User"
            />
          </el-form-item>
          
          <!-- 密码 -->
          <el-form-item prop="password">
            <el-input
              v-model="form.password"
              type="password"
              placeholder="密码"
              size="large"
              prefix-icon="Lock"
              show-password
            />
          </el-form-item>
          
          <!-- 登录/注册按钮 -->
          <el-form-item>
            <el-button
              type="primary"
              size="large"
              class="submit-btn"
              :loading="loading"
              native-type="submit"
            >
              {{ isRegisterMode ? '注册' : '登录' }}
            </el-button>
          </el-form-item>
        </el-form>
        
        <!-- 切换登录/注册 -->
        <div class="form-footer">
          <span class="footer-text">
            {{ isRegisterMode ? '已有账号？' : '没有账号？' }}
          </span>
          <el-button type="primary" link @click="toggleMode">
            {{ isRegisterMode ? '立即登录' : '立即注册' }}
          </el-button>
        </div>
        
        <!-- 开发模式提示 -->
        <div class="dev-mode-hint">
          <el-tag type="warning" size="small">开发模式</el-tag>
          <span>使用账号密码登录</span>
        </div>
      </div>
      
      <!-- PROD 模式：OAuth 登录 -->
      <div v-else class="oauth-login-wrapper">
        <el-button
          type="primary"
          size="large"
          class="oauth-btn"
          :loading="loading"
          @click="handleOAuthLogin"
        >
          <el-icon class="btn-icon"><Link /></el-icon>
          使用企业账号登录
        </el-button>
        
        <div class="oauth-hint">
          <el-tag type="success" size="small">生产模式</el-tag>
          <span>通过企业 IDaaS 统一认证</span>
        </div>
      </div>
      
      <!-- 返回前台 -->
      <div class="back-link">
        <el-button type="info" link @click="$router.push('/')">
          <el-icon><Back /></el-icon>
          返回前台首页
        </el-button>
      </div>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.admin-login-page {
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 24px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  position: relative;
  overflow: hidden;
}

// 背景装饰
.bg-decoration {
  position: absolute;
  inset: 0;
  pointer-events: none;
  overflow: hidden;
}

.bg-circle {
  position: absolute;
  border-radius: 50%;
  background: rgba(255, 255, 255, 0.1);
  
  &.bg-circle-1 {
    width: 400px;
    height: 400px;
    top: -100px;
    right: -100px;
  }
  
  &.bg-circle-2 {
    width: 300px;
    height: 300px;
    bottom: -50px;
    left: -50px;
  }
  
  &.bg-circle-3 {
    width: 200px;
    height: 200px;
    top: 50%;
    left: 10%;
    background: rgba(255, 255, 255, 0.05);
  }
}

// 登录容器
.login-container {
  width: 100%;
  max-width: 400px;
  padding: 40px;
  background: rgba(255, 255, 255, 0.95);
  border-radius: 24px;
  box-shadow: 0 20px 60px rgba(0, 0, 0, 0.2);
  backdrop-filter: blur(10px);
  position: relative;
  z-index: 1;
}

// 头部
.login-header {
  text-align: center;
  margin-bottom: 32px;
  
  .logo {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 80px;
    height: 80px;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    border-radius: 20px;
    color: white;
    margin-bottom: 16px;
  }
  
  .title {
    font-size: 24px;
    font-weight: 700;
    color: #171717;
    margin: 0 0 8px;
  }
  
  .subtitle {
    font-size: 14px;
    color: #737373;
    margin: 0;
  }
}

// 错误提示
.error-alert {
  margin-bottom: 24px;
}

// 登录表单
.login-form-wrapper {
  .login-form {
    :deep(.el-input__wrapper) {
      padding: 4px 12px;
      border-radius: 12px;
    }
    
    :deep(.el-form-item) {
      margin-bottom: 20px;
    }
  }
  
  .submit-btn {
    width: 100%;
    height: 48px;
    border-radius: 12px;
    font-size: 16px;
    font-weight: 600;
  }
}

.form-footer {
  text-align: center;
  margin-top: 16px;
  
  .footer-text {
    color: #737373;
    font-size: 14px;
  }
}

.dev-mode-hint {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  margin-top: 24px;
  padding-top: 24px;
  border-top: 1px solid #e5e5e5;
  color: #737373;
  font-size: 13px;
}

// OAuth 登录
.oauth-login-wrapper {
  .oauth-btn {
    width: 100%;
    height: 52px;
    border-radius: 12px;
    font-size: 16px;
    font-weight: 600;
    
    .btn-icon {
      margin-right: 8px;
    }
  }
  
  .oauth-hint {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    margin-top: 24px;
    color: #737373;
    font-size: 13px;
  }
}

// 返回链接
.back-link {
  text-align: center;
  margin-top: 24px;
  padding-top: 24px;
  border-top: 1px solid #e5e5e5;
}

// 响应式
@media (max-width: 480px) {
  .login-container {
    padding: 24px;
    border-radius: 16px;
  }
  
  .login-header .logo {
    width: 64px;
    height: 64px;
    border-radius: 16px;
  }
}
</style>

