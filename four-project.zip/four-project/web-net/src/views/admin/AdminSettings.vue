<script setup>
/**
 * 系统设置页面
 * 
 * 显示当前系统配置信息（只读）
 */
import { ref, computed, onMounted } from 'vue'
import { useStore } from 'vuex'

const store = useStore()

// 统计数据（包含配置信息）
const stats = computed(() => store.state.admin.stats)

// 配置信息
const configItems = computed(() => [
  {
    group: '认证配置',
    items: [
      { 
        label: '认证模式', 
        value: stats.value?.auth_mode === 'prod' ? '生产模式 (OAuth2/OIDC)' : '开发模式 (账号密码)',
        type: stats.value?.auth_mode === 'prod' ? 'success' : 'warning'
      },
      { label: 'JWT Token 有效期', value: '24 小时' },
    ]
  },
  {
    group: '用户统计',
    items: [
      { label: '总用户数', value: stats.value?.total_users?.toLocaleString() || '0' },
      { label: '管理员数量', value: stats.value?.admin_users?.toLocaleString() || '0' },
      { label: '已设置密码用户', value: stats.value?.users_with_password?.toLocaleString() || '0' },
      { label: 'OAuth 认证用户', value: stats.value?.users_with_oauth?.toLocaleString() || '0' },
    ]
  }
])

// 安全建议
const securityTips = [
  {
    title: '生产环境建议',
    tips: [
      '使用 OAuth2/OIDC 模式，接入企业 IDaaS 统一认证',
      '配置 HTTPS，确保数据传输安全',
      '定期审查管理员列表，移除不必要的权限',
      '设置强密钥（SECRET_KEY 和 JWT_SECRET_KEY）'
    ]
  },
  {
    title: '管理员配置',
    tips: [
      '在 .env 文件中配置 ADMIN_EMAILS 指定管理员邮箱',
      '符合条件的用户登录时会自动获得管理员权限',
      '建议使用企业邮箱域名进行管理员识别'
    ]
  }
]

// 初始化
onMounted(() => {
  if (!stats.value) {
    store.dispatch('admin/fetchStats')
  }
})
</script>

<template>
  <div class="admin-settings">
    <!-- 页面标题 -->
    <div class="page-header">
      <h1 class="page-title">系统设置</h1>
      <p class="page-desc">查看系统配置和安全建议</p>
    </div>
    
    <!-- 配置信息 -->
    <div class="config-section">
      <el-card v-for="config in configItems" :key="config.group" class="config-card">
        <template #header>
          <span class="card-title">{{ config.group }}</span>
        </template>
        
        <div class="config-list">
          <div v-for="item in config.items" :key="item.label" class="config-item">
            <span class="config-label">{{ item.label }}</span>
            <span class="config-value">
              <el-tag v-if="item.type" :type="item.type" size="small">
                {{ item.value }}
              </el-tag>
              <template v-else>{{ item.value }}</template>
            </span>
          </div>
        </div>
      </el-card>
    </div>
    
    <!-- 安全建议 -->
    <div class="tips-section">
      <el-card v-for="section in securityTips" :key="section.title" class="tips-card">
        <template #header>
          <div class="tips-header">
            <el-icon color="#f59e0b"><Warning /></el-icon>
            <span class="card-title">{{ section.title }}</span>
          </div>
        </template>
        
        <ul class="tips-list">
          <li v-for="(tip, index) in section.tips" :key="index">
            {{ tip }}
          </li>
        </ul>
      </el-card>
    </div>
    
    <!-- 环境变量说明 -->
    <el-card class="env-card">
      <template #header>
        <div class="env-header">
          <el-icon color="#3b82f6"><Document /></el-icon>
          <span class="card-title">环境变量配置示例</span>
        </div>
      </template>
      
      <pre class="env-code"><code># 认证模式
AUTH_MODE=dev  # 或 prod

# JWT 配置
JWT_SECRET_KEY=your-secret-key
JWT_ACCESS_TOKEN_EXPIRES=86400

# OAuth 配置（prod 模式）
OAUTH_CLIENT_ID=your-client-id
OAUTH_CLIENT_SECRET=your-client-secret
OAUTH_ISSUER=https://your-idaas.com

# 管理员邮箱列表
ADMIN_EMAILS=admin@company.com,super@company.com</code></pre>
    </el-card>
  </div>
</template>

<style lang="scss" scoped>
.admin-settings {
  max-width: 900px;
  margin: 0 auto;
}

// 页面头部
.page-header {
  margin-bottom: 24px;
  
  .page-title {
    font-size: 24px;
    font-weight: 600;
    color: var(--text-primary, #171717);
    margin: 0 0 4px;
  }
  
  .page-desc {
    font-size: 14px;
    color: var(--text-secondary, #737373);
    margin: 0;
  }
}

// 卡片标题
.card-title {
  font-size: 16px;
  font-weight: 600;
  color: var(--text-primary, #171717);
}

// 配置区域
.config-section {
  display: grid;
  gap: 20px;
  margin-bottom: 20px;
}

.config-card {
  .config-list {
    display: flex;
    flex-direction: column;
    gap: 16px;
  }
  
  .config-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 12px 16px;
    background: var(--bg-tertiary, #f5f5f7);
    border-radius: 8px;
    
    .config-label {
      font-size: 14px;
      color: var(--text-secondary, #737373);
    }
    
    .config-value {
      font-size: 14px;
      font-weight: 500;
      color: var(--text-primary, #171717);
    }
  }
}

// 建议区域
.tips-section {
  display: grid;
  gap: 20px;
  margin-bottom: 20px;
}

.tips-card {
  background: linear-gradient(135deg, #fffbeb 0%, #fef3c7 100%);
  border: 1px solid #fcd34d;
  
  :deep(.el-card__header) {
    background: transparent;
    border-bottom-color: #fcd34d;
  }
  
  .tips-header {
    display: flex;
    align-items: center;
    gap: 8px;
  }
  
  .tips-list {
    margin: 0;
    padding-left: 20px;
    color: #92400e;
    font-size: 14px;
    line-height: 1.8;
    
    li {
      margin-bottom: 4px;
    }
  }
}

// 环境变量
.env-card {
  .env-header {
    display: flex;
    align-items: center;
    gap: 8px;
  }
  
  .env-code {
    margin: 0;
    padding: 16px;
    background: #1e293b;
    border-radius: 8px;
    overflow-x: auto;
    
    code {
      font-family: 'SF Mono', 'Fira Code', Consolas, monospace;
      font-size: 13px;
      line-height: 1.6;
      color: #e2e8f0;
      white-space: pre;
    }
  }
}
</style>

