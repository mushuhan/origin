<script setup>
/**
 * OAuth 回调处理页面
 * 
 * 【处理流程】
 * 1. 从 URL 参数获取授权码 (code) 和状态值 (state)
 * 2. 调用后端 API 完成认证
 * 3. 成功后跳转到管理后台，失败则显示错误并跳转登录页
 */
import { onMounted, ref } from 'vue'
import { useStore } from 'vuex'
import { useRouter, useRoute } from 'vue-router'
import { ElMessage } from 'element-plus'

const store = useStore()
const router = useRouter()
const route = useRoute()

const status = ref('processing')  // 'processing' | 'success' | 'error'
const errorMessage = ref('')

onMounted(async () => {
  const code = route.query.code
  const state = route.query.state
  const error = route.query.error
  
  // 检查是否有错误
  if (error) {
    status.value = 'error'
    errorMessage.value = route.query.error_description || '授权失败'
    setTimeout(() => {
      router.push({ name: 'AdminLogin', query: { error: 'oauth_failed' } })
    }, 2000)
    return
  }
  
  // 检查授权码
  if (!code) {
    status.value = 'error'
    errorMessage.value = '缺少授权码'
    setTimeout(() => {
      router.push({ name: 'AdminLogin' })
    }, 2000)
    return
  }
  
  try {
    // 调用后端完成认证
    const result = await store.dispatch('admin/handleOAuthCallback', { code, state })
    
    status.value = 'success'
    ElMessage.success(result.is_new_user ? '欢迎加入！' : '登录成功')
    
    // 跳转到管理后台
    setTimeout(() => {
      router.push({ name: 'AdminDashboard' })
    }, 1000)
  } catch (e) {
    status.value = 'error'
    errorMessage.value = e.message || '认证失败'
    
    setTimeout(() => {
      router.push({ name: 'AdminLogin', query: { error: 'oauth_failed' } })
    }, 2000)
  }
})
</script>

<template>
  <div class="callback-page">
    <div class="callback-card">
      <!-- 处理中 -->
      <template v-if="status === 'processing'">
        <el-icon class="status-icon processing" :size="64">
          <Loading />
        </el-icon>
        <h2 class="status-title">正在验证身份...</h2>
        <p class="status-desc">请稍候，正在完成登录</p>
      </template>
      
      <!-- 成功 -->
      <template v-else-if="status === 'success'">
        <el-icon class="status-icon success" :size="64">
          <CircleCheck />
        </el-icon>
        <h2 class="status-title">登录成功</h2>
        <p class="status-desc">正在跳转到管理后台...</p>
      </template>
      
      <!-- 失败 -->
      <template v-else>
        <el-icon class="status-icon error" :size="64">
          <CircleClose />
        </el-icon>
        <h2 class="status-title">登录失败</h2>
        <p class="status-desc">{{ errorMessage }}</p>
        <p class="redirect-hint">即将返回登录页...</p>
      </template>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.callback-page {
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
}

.callback-card {
  text-align: center;
  padding: 48px;
  background: white;
  border-radius: 24px;
  box-shadow: 0 20px 60px rgba(0, 0, 0, 0.2);
  max-width: 400px;
  width: 100%;
  margin: 24px;
}

.status-icon {
  margin-bottom: 24px;
  
  &.processing {
    color: #3b82f6;
    animation: spin 1s linear infinite;
  }
  
  &.success {
    color: #10b981;
  }
  
  &.error {
    color: #ef4444;
  }
}

@keyframes spin {
  from { transform: rotate(0deg); }
  to { transform: rotate(360deg); }
}

.status-title {
  font-size: 20px;
  font-weight: 600;
  color: #171717;
  margin: 0 0 8px;
}

.status-desc {
  font-size: 14px;
  color: #737373;
  margin: 0;
}

.redirect-hint {
  font-size: 12px;
  color: #a3a3a3;
  margin-top: 16px;
}
</style>

