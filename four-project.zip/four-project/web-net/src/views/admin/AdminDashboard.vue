<script setup>
/**
 * 管理后台仪表盘
 * 
 * 展示系统核心统计数据和趋势图表
 */
import { ref, computed, onMounted } from 'vue'
import { useStore } from 'vuex'
import * as echarts from 'echarts'

const store = useStore()

// 统计数据
const stats = computed(() => store.state.admin.stats)
const trends = computed(() => store.state.admin.trends)
const loading = computed(() => store.state.admin.statsLoading)

// 图表实例
const trendChartRef = ref(null)
let trendChart = null

// 统计卡片配置
const statCards = computed(() => [
  {
    title: '总用户数',
    value: stats.value?.total_users || 0,
    icon: 'User',
    color: '#3b82f6',
    bgColor: 'rgba(59, 130, 246, 0.1)'
  },
  {
    title: '活跃用户',
    value: stats.value?.active_users || 0,
    icon: 'UserFilled',
    color: '#10b981',
    bgColor: 'rgba(16, 185, 129, 0.1)'
  },
  {
    title: '管理员',
    value: stats.value?.admin_users || 0,
    icon: 'Avatar',
    color: '#8b5cf6',
    bgColor: 'rgba(139, 92, 246, 0.1)'
  },
  {
    title: '今日新增',
    value: stats.value?.new_users_today || 0,
    icon: 'Plus',
    color: '#f59e0b',
    bgColor: 'rgba(245, 158, 11, 0.1)'
  }
])

// 更多统计
const moreStats = computed(() => [
  { label: '本周新增', value: stats.value?.new_users_week || 0 },
  { label: '本月新增', value: stats.value?.new_users_month || 0 },
  { label: '今日活跃', value: stats.value?.active_today || 0 },
  { label: '本周活跃', value: stats.value?.active_week || 0 },
  { label: '有密码用户', value: stats.value?.users_with_password || 0 },
  { label: 'OAuth用户', value: stats.value?.users_with_oauth || 0 }
])

// 认证模式
const authModeText = computed(() => {
  return stats.value?.auth_mode === 'prod' ? '生产模式 (OAuth)' : '开发模式 (密码)'
})

// 初始化
onMounted(async () => {
  await Promise.all([
    store.dispatch('admin/fetchStats'),
    store.dispatch('admin/fetchTrends', 30)
  ])
  
  // 初始化图表
  initTrendChart()
})

// 初始化趋势图表
const initTrendChart = () => {
  if (!trendChartRef.value || !trends.value) return
  
  trendChart = echarts.init(trendChartRef.value)
  
  const option = {
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        type: 'cross'
      }
    },
    legend: {
      data: ['新增用户', '活跃用户'],
      bottom: 0
    },
    grid: {
      left: '3%',
      right: '4%',
      bottom: '15%',
      top: '10%',
      containLabel: true
    },
    xAxis: {
      type: 'category',
      boundaryGap: false,
      data: trends.value.dates,
      axisLabel: {
        formatter: (value) => {
          const date = new Date(value)
          return `${date.getMonth() + 1}/${date.getDate()}`
        }
      }
    },
    yAxis: {
      type: 'value',
      minInterval: 1
    },
    series: [
      {
        name: '新增用户',
        type: 'line',
        smooth: true,
        data: trends.value.new_users,
        itemStyle: { color: '#3b82f6' },
        areaStyle: {
          color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
            { offset: 0, color: 'rgba(59, 130, 246, 0.3)' },
            { offset: 1, color: 'rgba(59, 130, 246, 0.05)' }
          ])
        }
      },
      {
        name: '活跃用户',
        type: 'line',
        smooth: true,
        data: trends.value.active_users,
        itemStyle: { color: '#10b981' },
        areaStyle: {
          color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
            { offset: 0, color: 'rgba(16, 185, 129, 0.3)' },
            { offset: 1, color: 'rgba(16, 185, 129, 0.05)' }
          ])
        }
      }
    ]
  }
  
  trendChart.setOption(option)
  
  // 响应式
  window.addEventListener('resize', () => {
    trendChart?.resize()
  })
}

// 刷新数据
const refreshData = async () => {
  await Promise.all([
    store.dispatch('admin/fetchStats'),
    store.dispatch('admin/fetchTrends', 30)
  ])
  
  if (trendChart && trends.value) {
    trendChart.setOption({
      xAxis: { data: trends.value.dates },
      series: [
        { data: trends.value.new_users },
        { data: trends.value.active_users }
      ]
    })
  }
}
</script>

<template>
  <div class="admin-dashboard">
    <!-- 页面标题 -->
    <div class="page-header">
      <div class="header-left">
        <h1 class="page-title">仪表盘</h1>
        <p class="page-desc">系统运营数据概览</p>
      </div>
      <div class="header-right">
        <el-tag :type="stats?.auth_mode === 'prod' ? 'success' : 'warning'">
          {{ authModeText }}
        </el-tag>
        <el-button 
          :icon="'Refresh'" 
          :loading="loading"
          @click="refreshData"
        >
          刷新
        </el-button>
      </div>
    </div>
    
    <!-- 统计卡片 -->
    <div class="stat-cards" v-loading="loading">
      <div 
        v-for="card in statCards" 
        :key="card.title"
        class="stat-card"
      >
        <div class="card-icon" :style="{ backgroundColor: card.bgColor }">
          <el-icon :size="24" :style="{ color: card.color }">
            <component :is="card.icon" />
          </el-icon>
        </div>
        <div class="card-content">
          <div class="card-value">{{ card.value.toLocaleString() }}</div>
          <div class="card-title">{{ card.title }}</div>
        </div>
      </div>
    </div>
    
    <!-- 图表区域 -->
    <div class="chart-section">
      <el-card class="chart-card">
        <template #header>
          <div class="chart-header">
            <span class="chart-title">用户趋势（最近30天）</span>
          </div>
        </template>
        <div ref="trendChartRef" class="trend-chart"></div>
      </el-card>
    </div>
    
    <!-- 更多统计 -->
    <div class="more-stats">
      <el-card>
        <template #header>
          <span class="card-title">详细统计</span>
        </template>
        <div class="stats-grid">
          <div 
            v-for="item in moreStats" 
            :key="item.label"
            class="stat-item"
          >
            <div class="stat-label">{{ item.label }}</div>
            <div class="stat-value">{{ item.value.toLocaleString() }}</div>
          </div>
        </div>
      </el-card>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.admin-dashboard {
  max-width: 1400px;
  margin: 0 auto;
}

// 页面头部
.page-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  margin-bottom: 24px;
  
  .page-title {
    font-size: 24px;
    font-weight: 600;
    color: var(--text-primary, #171717);
    margin: 0 0 4px;
  }
  
  .page-desc {
    font-size: 14px;
    color: var(--text-secondary, #737373);
    margin: 0;
  }
  
  .header-right {
    display: flex;
    align-items: center;
    gap: 12px;
  }
}

// 统计卡片
.stat-cards {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
  gap: 20px;
  margin-bottom: 24px;
}

.stat-card {
  display: flex;
  align-items: center;
  gap: 16px;
  padding: 24px;
  background: var(--card-bg, #ffffff);
  border-radius: 16px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);
  transition: transform 0.2s, box-shadow 0.2s;
  
  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 16px rgba(0, 0, 0, 0.08);
  }
  
  .card-icon {
    width: 56px;
    height: 56px;
    border-radius: 14px;
    display: flex;
    align-items: center;
    justify-content: center;
  }
  
  .card-value {
    font-size: 28px;
    font-weight: 700;
    color: var(--text-primary, #171717);
    line-height: 1.2;
  }
  
  .card-title {
    font-size: 14px;
    color: var(--text-secondary, #737373);
    margin-top: 4px;
  }
}

// 图表区域
.chart-section {
  margin-bottom: 24px;
  
  .chart-card {
    :deep(.el-card__header) {
      padding: 16px 20px;
      border-bottom: 1px solid var(--border-secondary, #e5e5e5);
    }
    
    :deep(.el-card__body) {
      padding: 20px;
    }
  }
  
  .chart-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    
    .chart-title {
      font-size: 16px;
      font-weight: 600;
      color: var(--text-primary, #171717);
    }
  }
  
  .trend-chart {
    height: 350px;
  }
}

// 更多统计
.more-stats {
  .card-title {
    font-size: 16px;
    font-weight: 600;
    color: var(--text-primary, #171717);
  }
  
  .stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
    gap: 24px;
  }
  
  .stat-item {
    text-align: center;
    padding: 16px;
    background: var(--bg-tertiary, #f5f5f7);
    border-radius: 12px;
    
    .stat-label {
      font-size: 13px;
      color: var(--text-secondary, #737373);
      margin-bottom: 8px;
    }
    
    .stat-value {
      font-size: 24px;
      font-weight: 600;
      color: var(--text-primary, #171717);
    }
  }
}

// 响应式
@media (max-width: 768px) {
  .page-header {
    flex-direction: column;
    gap: 16px;
    
    .header-right {
      width: 100%;
      justify-content: flex-end;
    }
  }
  
  .stat-cards {
    grid-template-columns: 1fr 1fr;
  }
  
  .stat-card {
    padding: 16px;
    
    .card-icon {
      width: 44px;
      height: 44px;
    }
    
    .card-value {
      font-size: 22px;
    }
  }
}
</style>

