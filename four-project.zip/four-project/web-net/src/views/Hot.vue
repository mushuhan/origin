<script setup>
import { ref, onMounted } from 'vue'
import { getHotRanking, getHotWebsites } from '@/api'
import HotRankingChart from '@/components/common/HotRankingChart.vue'
import WebsiteCard from '@/components/common/WebsiteCard.vue'

// 状态
const hotWebsites = ref([])
const rankings = ref([])
const dimension = ref('all')
const loading = ref(true)
const rankingLoading = ref(false)

// 获取热门网址
const fetchHotWebsites = async () => {
  loading.value = true
  try {
    hotWebsites.value = await getHotWebsites(50)
  } catch (e) {
    console.error('获取热门网址失败:', e)
  } finally {
    loading.value = false
  }
}

// 获取排行榜
const fetchRankings = async (dim = 'all') => {
  rankingLoading.value = true
  try {
    const data = await getHotRanking(dim, 10)
    rankings.value = data.rankings || []
  } catch (e) {
    console.error('获取排行榜失败:', e)
  } finally {
    rankingLoading.value = false
  }
}

// 切换维度
const handleDimensionChange = (dim) => {
  dimension.value = dim
  fetchRankings(dim)
}

// 点击排行项
const handleRankingClick = (item) => {
  window.open(item.url, '_blank')
}

onMounted(() => {
  fetchHotWebsites()
  fetchRankings()
})
</script>

<template>
  <div class="hot-page">
    <!-- 页面标题 -->
    <header class="page-header">
      <div class="header-icon">
        <el-icon><TrendCharts /></el-icon>
      </div>
      <div class="header-content">
        <h1>热门网址</h1>
        <p>发现大家都在用的优质网站</p>
      </div>
    </header>
    
    <!-- 双栏布局 -->
    <div class="content-grid">
      <!-- 左侧：排行榜 -->
      <aside class="ranking-panel">
        <HotRankingChart
          :rankings="rankings"
          :dimension="dimension"
          :loading="rankingLoading"
          @dimension-change="handleDimensionChange"
          @click="handleRankingClick"
        />
      </aside>
      
      <!-- 右侧：网站网格 -->
      <main class="websites-panel">
        <div class="panel-header">
          <h2>全部热门</h2>
          <span class="count">{{ hotWebsites.length }} 个网站</span>
        </div>
        
        <!-- 加载状态 -->
        <div v-if="loading" class="loading-grid">
          <div v-for="i in 12" :key="i" class="skeleton skeleton-card"></div>
        </div>
        
        <!-- 网站网格 -->
        <div v-else class="websites-grid">
          <WebsiteCard
            v-for="(website, index) in hotWebsites"
            :key="website.id"
            :website="website"
            :style="{ animationDelay: `${index * 0.03}s` }"
            class="animate-in"
          />
        </div>
      </main>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.hot-page {
  padding: 1rem 0;
}

.page-header {
  display: flex;
  align-items: center;
  gap: 1rem;
  margin-bottom: 2rem;
  
  .header-icon {
    width: 48px;
    height: 48px;
    border-radius: 14px;
    background: linear-gradient(135deg, #F59E0B, #EF4444);
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    box-shadow: 0 4px 16px rgba(245, 158, 11, 0.3);
    
    .el-icon {
      font-size: 24px;
    }
  }
  
  h1 {
    font-size: 1.5rem;
    font-weight: 700;
    color: var(--text-primary);
    margin-bottom: 0.25rem;
  }
  
  p {
    font-size: 0.875rem;
    color: var(--text-tertiary);
  }
}

.content-grid {
  display: grid;
  grid-template-columns: 380px 1fr;
  gap: 1.5rem;
  
  @media (max-width: 1024px) {
    grid-template-columns: 1fr;
  }
}

.ranking-panel {
  position: sticky;
  top: calc(var(--header-height, 64px) + 1.5rem);
  height: fit-content;
  
  @media (max-width: 1024px) {
    position: static;
  }
}

.websites-panel {
  .panel-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 1rem;
    
    h2 {
      font-size: 1rem;
      font-weight: 600;
      color: var(--text-primary);
    }
    
    .count {
      font-size: 0.8125rem;
      color: var(--text-tertiary);
    }
  }
}

.websites-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(100px, 1fr));
  gap: 0.75rem;
}

.loading-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(100px, 1fr));
  gap: 0.75rem;
  
  .skeleton-card {
    height: 100px;
    border-radius: 12px;
  }
}

.animate-in {
  animation: slideUpFade 0.4s ease forwards;
  opacity: 0;
}

@keyframes slideUpFade {
  from {
    opacity: 0;
    transform: translateY(10px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}
</style>
