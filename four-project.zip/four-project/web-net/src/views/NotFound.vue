<script setup>
import { useRouter } from 'vue-router'

const router = useRouter()

const goHome = () => {
  router.push('/')
}
</script>

<template>
  <div class="not-found-page">
    <div class="not-found-content">
      <!-- 404数字 -->
      <div class="error-code">
        <span class="digit">4</span>
        <span class="digit zero">0</span>
        <span class="digit">4</span>
      </div>
      
      <!-- 描述 -->
      <h1>页面未找到</h1>
      <p>抱歉，您访问的页面不存在或已被移除</p>
      
      <!-- 返回按钮 -->
      <button class="home-btn" @click="goHome">
        <el-icon><HomeFilled /></el-icon>
        返回首页
      </button>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.not-found-page {
  display: flex;
  align-items: center;
  justify-content: center;
  min-height: calc(100vh - var(--header-height, 64px) - 100px);
  padding: 2rem;
}

.not-found-content {
  text-align: center;
}

.error-code {
  display: flex;
  justify-content: center;
  gap: 0.5rem;
  margin-bottom: 2rem;
  
  .digit {
    font-size: 6rem;
    font-weight: 900;
    color: var(--text-primary);
    line-height: 1;
    letter-spacing: -0.05em;
    
    @media (max-width: 480px) {
      font-size: 4rem;
    }
  }
  
  .zero {
    color: var(--accent);
    animation: pulse 2s ease-in-out infinite;
  }
}

@keyframes pulse {
  0%, 100% {
    opacity: 1;
  }
  50% {
    opacity: 0.5;
  }
}

h1 {
  font-size: 1.5rem;
  font-weight: 700;
  color: var(--text-primary);
  margin-bottom: 0.5rem;
}

p {
  font-size: 0.9375rem;
  color: var(--text-tertiary);
  margin-bottom: 2rem;
}

.home-btn {
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.875rem 1.5rem;
  font-size: 0.9375rem;
  font-weight: 600;
  color: white;
  background: var(--text-primary);
  border-radius: 12px;
  transition: all 0.2s ease;
  
  &:hover {
    transform: translateY(-2px);
    box-shadow: var(--shadow-lg);
  }
  
  .el-icon {
    font-size: 18px;
  }
}
</style>
