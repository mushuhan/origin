<script setup>
import { ref, computed, watch, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useStore } from 'vuex'
import SearchBox from '@/components/common/SearchBox.vue'
import WebsiteCard from '@/components/common/WebsiteCard.vue'

const route = useRoute()
const router = useRouter()
const store = useStore()

// 状态
const searchResults = computed(() => store.state.searchResults)
const loading = computed(() => store.state.loading)
const searchKeyword = computed(() => store.state.searchKeyword)

// 初始搜索
const initialSearch = () => {
  const q = route.query.q
  if (q) {
    store.dispatch('search', q)
  }
}

// 监听路由查询参数变化
watch(() => route.query.q, (newQ) => {
  if (newQ) {
    store.dispatch('search', newQ)
  }
})

// 处理搜索
const handleSearch = (keyword) => {
  router.push({ path: '/search', query: { q: keyword } })
}

// 添加到工作台
const handleAddToWorkspace = async (website) => {
  try {
    await store.dispatch('addToWorkspace', { website_id: website.id })
  } catch (e) {
    console.error('添加失败:', e)
  }
}

onMounted(() => {
  initialSearch()
})
</script>

<template>
  <div class="search-page">
    <!-- 页面标题 -->
    <header class="page-header">
      <div class="header-icon">
        <el-icon><Search /></el-icon>
      </div>
      <div class="header-content">
        <h1>搜索</h1>
        <p>在全站网址库中快速查找</p>
      </div>
    </header>
    
    <!-- 搜索框 -->
    <div class="search-container">
      <SearchBox
        size="large"
        :placeholder="'搜索网站、工具...'"
        @search="handleSearch"
      />
    </div>
    
    <!-- 搜索结果 -->
    <div class="results-section">
      <!-- 结果统计 -->
      <div v-if="searchKeyword" class="results-header">
        <p class="results-info">
          搜索 "<strong>{{ searchKeyword }}</strong>" 
          <span v-if="!loading">找到 {{ searchResults.length }} 个结果</span>
        </p>
      </div>
      
      <!-- 加载状态 -->
      <div v-if="loading" class="loading-state">
        <div class="loading-spinner"></div>
        <p>搜索中...</p>
      </div>
      
      <!-- 结果网格 -->
      <div v-else-if="searchResults.length > 0" class="results-grid">
        <WebsiteCard
          v-for="(website, index) in searchResults"
          :key="website.id"
          :website="website"
          :style="{ animationDelay: `${index * 0.03}s` }"
          class="animate-in"
          @addToWorkspace="handleAddToWorkspace"
        />
      </div>
      
      <!-- 无结果 -->
      <div v-else-if="searchKeyword" class="empty-state">
        <el-icon :size="64"><Search /></el-icon>
        <h3>未找到相关网站</h3>
        <p>试试其他关键词，或使用拼音首字母搜索</p>
      </div>
      
      <!-- 初始状态 -->
      <div v-else class="initial-state">
        <el-icon :size="64"><Search /></el-icon>
        <h3>开始搜索</h3>
        <p>输入网站名称、URL、描述或拼音进行搜索</p>
        <div class="search-tips">
          <h4>搜索技巧</h4>
          <ul>
            <li><strong>名称搜索：</strong>直接输入网站名称，如"百度"</li>
            <li><strong>拼音搜索：</strong>支持拼音首字母，如"bd"搜索百度</li>
            <li><strong>URL搜索：</strong>输入域名关键词，如"github"</li>
            <li><strong>描述搜索：</strong>输入功能描述，如"翻译"</li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.search-page {
  padding: 1rem 0;
  max-width: 900px;
  margin: 0 auto;
}

.page-header {
  display: flex;
  align-items: center;
  gap: 1rem;
  margin-bottom: 2rem;
  
  .header-icon {
    width: 48px;
    height: 48px;
    border-radius: 14px;
    background: linear-gradient(135deg, #10B981, #3B82F6);
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    box-shadow: 0 4px 16px rgba(16, 185, 129, 0.3);
    
    .el-icon {
      font-size: 24px;
    }
  }
  
  h1 {
    font-size: 1.5rem;
    font-weight: 700;
    color: var(--text-primary);
    margin-bottom: 0.25rem;
  }
  
  p {
    font-size: 0.875rem;
    color: var(--text-tertiary);
  }
}

.search-container {
  margin-bottom: 2rem;
}

.results-section {
  min-height: 400px;
}

.results-header {
  margin-bottom: 1.5rem;
  
  .results-info {
    font-size: 0.9375rem;
    color: var(--text-secondary);
    
    strong {
      color: var(--text-primary);
    }
  }
}

.results-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(100px, 1fr));
  gap: 0.75rem;
}

.animate-in {
  animation: slideUpFade 0.4s ease forwards;
  opacity: 0;
}

@keyframes slideUpFade {
  from {
    opacity: 0;
    transform: translateY(10px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.loading-state {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 4rem;
  color: var(--text-tertiary);
  
  .loading-spinner {
    width: 40px;
    height: 40px;
    border: 3px solid var(--border-primary);
    border-top-color: var(--accent);
    border-radius: 50%;
    animation: spin 0.8s linear infinite;
    margin-bottom: 1rem;
  }
}

@keyframes spin {
  to {
    transform: rotate(360deg);
  }
}

.empty-state,
.initial-state {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 4rem 2rem;
  text-align: center;
  
  .el-icon {
    color: var(--border-primary);
    margin-bottom: 1.5rem;
  }
  
  h3 {
    font-size: 1.25rem;
    font-weight: 600;
    color: var(--text-secondary);
    margin-bottom: 0.5rem;
  }
  
  p {
    font-size: 0.875rem;
    color: var(--text-tertiary);
  }
}

.search-tips {
  margin-top: 2rem;
  text-align: left;
  padding: 1.5rem;
  background: var(--card-bg);
  border-radius: 12px;
  border: 1px solid var(--border-secondary);
  max-width: 400px;
  
  h4 {
    font-size: 0.875rem;
    font-weight: 600;
    color: var(--text-primary);
    margin-bottom: 1rem;
  }
  
  ul {
    display: flex;
    flex-direction: column;
    gap: 0.75rem;
    
    li {
      font-size: 0.8125rem;
      color: var(--text-secondary);
      line-height: 1.5;
      
      strong {
        color: var(--text-primary);
      }
    }
  }
}
</style>
