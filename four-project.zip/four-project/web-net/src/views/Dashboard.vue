<script setup>
import { ref, reactive, computed, onMounted, onUnmounted, nextTick, watch } from 'vue'
import { useRouter } from 'vue-router'
import * as XLSX from 'xlsx'
import * as echarts from 'echarts'
import { getCurrentThemeName } from '@/utils/echartsTheme'
import { ElMessage, ElMessageBox } from 'element-plus'
import { getDashboards, getDashboard, saveDashboardAPI, updateDashboard, deleteDashboardAPI, drillDownChart, calculateStatCard } from '@/api'
import StatCard from '@/components/common/StatCard.vue'
import DataJoinModal from '@/components/common/DataJoinModal.vue'

const router = useRouter()

// ==================== 状态管理 ====================

// Excel数据
const excelFile = ref(null)
const workbook = ref(null)
const sheetNames = ref([])
const activeSheet = ref('')
const sheetData = ref({}) // { sheetName: { headers: [], rows: [] } }

// 图表和统计卡片配置
const charts = ref([])
const statCards = ref([]) // 统计卡片
const chartInstances = ref({})

// 当前编辑
const editingChart = ref(null)
const editingStatCard = ref(null)
const showChartDialog = ref(false)
const showStatCardDialog = ref(false)

// 存储的看板
const savedDashboards = ref([])
const currentDashboardName = ref('')
const dashboardVisibility = ref('private') // private / public
const showSaveDialog = ref(false)
const showLoadDialog = ref(false)
const loadingDashboards = ref(false)
const currentDashboardId = ref(null) // 当前加载的看板ID
const isEditMode = ref(false) // 是否为编辑模式

// 多表关联
const showJoinDialog = ref(false)
const virtualDatasets = ref([]) // 虚拟数据集列表

// 组件类型选项
const componentTypes = [
  { value: 'chart', label: '图表', icon: 'PieChart' },
  { value: 'statCard', label: '统计卡片', icon: 'DataBoard' }
]

// 图表类型选项
const chartTypes = [
  { value: 'bar', label: '柱状图', icon: 'Histogram' },
  { value: 'line', label: '折线图', icon: 'TrendCharts' },
  { value: 'pie', label: '饼图', icon: 'PieChart' },
  { value: 'scatter', label: '散点图', icon: 'DataAnalysis' },
  { value: 'radar', label: '雷达图', icon: 'Coordinate' },
  { value: 'funnel', label: '漏斗图', icon: 'Filter' },
  { value: 'gauge', label: '仪表盘', icon: 'Odometer' }
]

// 筛选条件类型
const filterOperators = [
  { value: 'eq', label: '等于' },
  { value: 'neq', label: '不等于' },
  { value: 'gt', label: '大于' },
  { value: 'gte', label: '大于等于' },
  { value: 'lt', label: '小于' },
  { value: 'lte', label: '小于等于' },
  { value: 'contains', label: '包含' },
  { value: 'notContains', label: '不包含' },
  { value: 'empty', label: '为空' },
  { value: 'notEmpty', label: '不为空' }
]

// 聚合方式选项 - 添加不聚合
const aggregationOptions = [
  { value: 'none', label: '不聚合' },
  { value: 'sum', label: '求和' },
  { value: 'avg', label: '平均值' },
  { value: 'max', label: '最大值' },
  { value: 'min', label: '最小值' },
  { value: 'count', label: '计数' }
]

// 排序选项
const sortOptions = [
  { value: '', label: '不排序' },
  { value: 'x-asc', label: 'X轴 升序' },
  { value: 'x-desc', label: 'X轴 降序' },
  { value: 'y-asc', label: 'Y轴 升序' },
  { value: 'y-desc', label: 'Y轴 降序' }
]

// 限制类型选项
const limitTypeOptions = [
  { value: '', label: '不限制' },
  { value: 'top', label: '前 N 名' },
  { value: 'bottom', label: '后 N 名' }
]

// 下钻对话框状态
const showDrillDownDialog = ref(false)
const drillDownData = ref({ headers: [], rows: [], total: 0 })
const drillDownLoading = ref(false)
const drillDownTitle = ref('')
const drillDownParams = ref({})
const drillDownPage = ref(1)
const drillDownPageSize = ref(20)

// 计算字段运算符
const computedOperators = [
  { value: '>=', label: '大于等于' },
  { value: '<=', label: '小于等于' },
  { value: '==', label: '等于' },
  { value: '>', label: '大于' },
  { value: '<', label: '小于' },
  { value: '!=', label: '不等于' }
]

// 新图表默认配置 - 默认不聚合
const defaultChartConfig = () => ({
  id: Date.now().toString(),
  title: '新图表',
  type: 'bar',
  sheet: '',
  xField: '',
  yFields: [],
  yAxisConfig: {}, // { fieldName: 0(Left) | 1(Right) }
  filters: [],
  computedFields: [], // { name, source, operator, threshold }
  aggregation: 'none', // 默认不聚合
  // 新增：排序配置
  sortField: '', // 'x' | 'y' | 具体字段名
  sortOrder: '', // 'asc' | 'desc'
  // 新增：限制配置
  limitType: '', // 'top' | 'bottom'
  limitCount: 10,
  // 新增：分组字段（用于堆叠图）
  groupField: '',
  // 新增：启用下钻
  enableDrillDown: true,
  width: 6,
  height: 360,
  colors: ['#374151', '#6B7280', '#9CA3AF', '#D1D5DB', '#1f2937', '#4B5563'],
  showLegend: true,
  showLabel: false
})

// 新统计卡片默认配置
const defaultStatCardConfig = () => ({
  id: Date.now().toString(),
  title: '统计指标',
  sheet: '',
  field: '',
  aggregation: 'count',
  filters: [],
  width: 3,
  prefix: '',
  suffix: '',
  color: '#3b82f6',
  // 新增：趋势配置
  timeField: '', // 时间字段（用于计算趋势）
  trendPeriods: 7, // 趋势周期数
  showTrend: true, // 是否显示趋势
  showSparkline: true // 是否显示迷你图
})

// 统计卡片计算结果缓存
const statCardResults = ref({}) // { cardId: { value, trend, sparklineData, loading } }

// ==================== 计算属性 ====================

const currentFields = computed(() => {
  if (!activeSheet.value || !sheetData.value[activeSheet.value]) return []
  return sheetData.value[activeSheet.value].headers || []
})

const currentRows = computed(() => {
  if (!activeSheet.value || !sheetData.value[activeSheet.value]) return []
  return sheetData.value[activeSheet.value].rows || []
})

const editingChartFields = computed(() => {
  if (!editingChart.value?.sheet || !sheetData.value[editingChart.value.sheet]) return []
  const headers = sheetData.value[editingChart.value.sheet].headers || []
  // 加上计算字段
  const computedNames = editingChart.value.computedFields?.map(f => f.name).filter(Boolean) || []
  return [...headers, ...computedNames]
})

const editingStatCardFields = computed(() => {
  if (!editingStatCard.value?.sheet || !sheetData.value[editingStatCard.value.sheet]) return []
  return sheetData.value[editingStatCard.value.sheet].headers || []
})

// 统计卡片计算值 (简化版，用于向后兼容)
const getStatCardValue = (card) => {
  if (!card.sheet || !card.field || !sheetData.value[card.sheet]) return 0
  
  const rows = sheetData.value[card.sheet].rows || []
  const filteredRows = applyFilters(rows, card.filters)
  
  if (filteredRows.length === 0) return 0
  
  const values = filteredRows.map(r => Number(r[card.field]) || 0)
  
  switch (card.aggregation) {
    case 'count': return filteredRows.length
    case 'sum': return values.reduce((a, b) => a + b, 0)
    case 'avg': return (values.reduce((a, b) => a + b, 0) / values.length).toFixed(2)
    case 'max': return Math.max(...values)
    case 'min': return Math.min(...values)
    default: return filteredRows.length
  }
}

// 计算统计卡片完整数据（含趋势和迷你图）
const calculateStatCardData = async (card) => {
  if (!card.sheet || !card.field || !sheetData.value[card.sheet]) {
    statCardResults.value[card.id] = { value: 0, trend: null, sparklineData: [], loading: false }
    return
  }
  
  // 设置加载状态
  statCardResults.value[card.id] = { ...statCardResults.value[card.id], loading: true }
  
  const rows = sheetData.value[card.sheet].rows || []
  
  // 如果有时间字段且已保存到后端，使用后端计算
  if (card.timeField && currentDashboardId.value) {
    try {
      const result = await calculateStatCard({
        dashboardId: currentDashboardId.value,
        sheetName: card.sheet,
        field: card.field,
        aggregation: card.aggregation,
        timeField: card.timeField,
        trendPeriods: card.trendPeriods || 7,
        filters: card.filters
      })
      statCardResults.value[card.id] = { ...result, loading: false }
      return
    } catch (e) {
      console.warn('后端计算失败，回退到前端计算:', e)
    }
  }
  
  // 前端本地计算
  const filteredRows = applyFilters(rows, card.filters)
  const value = getStatCardValue(card)
  
  // 计算迷你图数据（按时间或序列分组）
  let sparklineData = []
  let trend = null
  
  if (card.showSparkline !== false && filteredRows.length > 0) {
    const periods = card.trendPeriods || 7
    
    if (card.timeField && filteredRows.some(r => r[card.timeField])) {
      // 按时间分组
      const grouped = {}
      filteredRows.forEach(row => {
        const timeVal = row[card.timeField]
        if (!timeVal) return
        const dateKey = String(timeVal).split(' ')[0] // 简化日期处理
        if (!grouped[dateKey]) grouped[dateKey] = []
        grouped[dateKey].push(Number(row[card.field]) || 0)
      })
      
      const sortedKeys = Object.keys(grouped).sort().slice(-periods)
      sparklineData = sortedKeys.map(key => {
        const values = grouped[key]
        switch (card.aggregation) {
          case 'count': return values.length
          case 'sum': return values.reduce((a, b) => a + b, 0)
          case 'avg': return values.reduce((a, b) => a + b, 0) / values.length
          case 'max': return Math.max(...values)
          case 'min': return Math.min(...values)
          default: return values.reduce((a, b) => a + b, 0)
        }
      })
    } else {
      // 按序列分组
      const chunkSize = Math.max(1, Math.floor(filteredRows.length / periods))
      for (let i = 0; i < periods && i * chunkSize < filteredRows.length; i++) {
        const chunk = filteredRows.slice(i * chunkSize, (i + 1) * chunkSize)
        const values = chunk.map(r => Number(r[card.field]) || 0)
        switch (card.aggregation) {
          case 'count': sparklineData.push(chunk.length); break
          case 'sum': sparklineData.push(values.reduce((a, b) => a + b, 0)); break
          case 'avg': sparklineData.push(values.reduce((a, b) => a + b, 0) / values.length); break
          case 'max': sparklineData.push(Math.max(...values)); break
          case 'min': sparklineData.push(Math.min(...values)); break
          default: sparklineData.push(values.reduce((a, b) => a + b, 0))
        }
      }
    }
    
    // 计算趋势
    if (sparklineData.length >= 2) {
      const prev = sparklineData[sparklineData.length - 2] || 0.001
      const curr = sparklineData[sparklineData.length - 1]
      if (prev !== 0) {
        trend = ((curr - prev) / Math.abs(prev)) * 100
      }
    }
  }
  
  statCardResults.value[card.id] = {
    value: Number(value) || 0,
    trend: card.showTrend !== false ? trend : null,
    sparklineData: sparklineData.map(v => Number(v.toFixed(2))),
    loading: false
  }
}

// 计算所有统计卡片数据
const calculateAllStatCards = () => {
  statCards.value.forEach(card => {
    calculateStatCardData(card)
  })
}

// 获取统计卡片结果
const getStatCardResult = (card) => {
  return statCardResults.value[card.id] || { value: 0, trend: null, sparklineData: [], loading: false }
}

// ==================== Excel处理 ====================

const handleFileUpload = (file) => {
  const reader = new FileReader()
  
  reader.onload = (e) => {
    try {
      const data = new Uint8Array(e.target.result)
      workbook.value = XLSX.read(data, { type: 'array' })
      sheetNames.value = workbook.value.SheetNames
      
      sheetNames.value.forEach(name => {
        parseSheet(name)
      })
      
      if (sheetNames.value.length > 0) {
        activeSheet.value = sheetNames.value[0]
      }
      
      ElMessage.success(`成功导入 ${sheetNames.value.length} 个工作表`)
    } catch (error) {
      console.error('解析Excel失败:', error)
      ElMessage.error('解析Excel文件失败')
    }
  }
  
  reader.readAsArrayBuffer(file.raw)
  return false
}

const parseSheet = (sheetName) => {
  const sheet = workbook.value.Sheets[sheetName]
  const json = XLSX.utils.sheet_to_json(sheet, { header: 1 })
  
  if (json.length === 0) {
    sheetData.value[sheetName] = { headers: [], rows: [] }
    return
  }
  
  const headers = json[0].map((h, i) => h || `列${i + 1}`)
  const rows = json.slice(1).map(row => {
    const obj = {}
    headers.forEach((header, i) => {
      obj[header] = row[i] !== undefined ? row[i] : ''
    })
    return obj
  })
  
  sheetData.value[sheetName] = { headers, rows }
}

// ==================== 图表管理 ====================

const addChart = () => {
  if (sheetNames.value.length === 0) {
    ElMessage.warning('请先导入Excel文件')
    return
  }
  
  editingChart.value = {
    ...defaultChartConfig(),
    sheet: activeSheet.value
  }
  showChartDialog.value = true
}

const editChart = (chart) => {
  const defaults = defaultChartConfig()
  const parsed = JSON.parse(JSON.stringify(chart))
  editingChart.value = {
    ...defaults,
    ...parsed,
    computedFields: parsed.computedFields || [],
    yAxisConfig: parsed.yAxisConfig || {}
  }
  showChartDialog.value = true
}

const saveChartConfig = () => {
  if (!editingChart.value.sheet || !editingChart.value.xField || editingChart.value.yFields.length === 0) {
    ElMessage.warning('请完善图表配置')
    return
  }
  
  const index = charts.value.findIndex(c => c.id === editingChart.value.id)
  
  if (index >= 0) {
    charts.value[index] = editingChart.value
  } else {
    charts.value.push(editingChart.value)
  }
  
  showChartDialog.value = false
  
  nextTick(() => {
    renderChart(editingChart.value.id)
  })
}

const deleteChart = async (chart) => {
  try {
    await ElMessageBox.confirm('确定删除？', '提示', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning'
    })
    
    if (chartInstances.value[chart.id]) {
      chartInstances.value[chart.id].dispose()
      delete chartInstances.value[chart.id]
    }
    
    charts.value = charts.value.filter(c => c.id !== chart.id)
  } catch {}
}

// ==================== 统计卡片管理 ====================

const addStatCard = () => {
  if (sheetNames.value.length === 0) {
    ElMessage.warning('请先导入Excel文件')
    return
  }
  
  editingStatCard.value = {
    ...defaultStatCardConfig(),
    sheet: activeSheet.value
  }
  showStatCardDialog.value = true
}

const editStatCard = (card) => {
  const defaults = defaultStatCardConfig()
  const parsed = JSON.parse(JSON.stringify(card))
  editingStatCard.value = {
    ...defaults,
    ...parsed,
    // 确保新字段有默认值
    timeField: parsed.timeField || '',
    trendPeriods: parsed.trendPeriods || 7,
    showTrend: parsed.showTrend !== false,
    showSparkline: parsed.showSparkline !== false
  }
  showStatCardDialog.value = true
}

const saveStatCardConfig = () => {
  if (!editingStatCard.value.sheet || !editingStatCard.value.field) {
    ElMessage.warning('请完善统计卡片配置')
    return
  }
  
  const index = statCards.value.findIndex(c => c.id === editingStatCard.value.id)
  
  if (index >= 0) {
    statCards.value[index] = editingStatCard.value
  } else {
    statCards.value.push(editingStatCard.value)
  }
  
  showStatCardDialog.value = false
  
  // 计算该卡片的数据
  nextTick(() => {
    calculateStatCardData(editingStatCard.value)
  })
}

const deleteStatCard = async (card) => {
  try {
    await ElMessageBox.confirm('确定删除？', '提示', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning'
    })
    
    statCards.value = statCards.value.filter(c => c.id !== card.id)
  } catch {}
}

// ==================== 筛选条件 ====================

const addFilter = (target) => {
  target.filters.push({
    field: '',
    operator: 'eq',
    value: ''
  })
}

const removeFilter = (target, index) => {
  target.filters.splice(index, 1)
}

const addComputedField = (target) => {
  if (!target.computedFields) target.computedFields = []
  target.computedFields.push({
    name: '',
    source: '',
    operator: '>=',
    threshold: '60'
  })
}

const removeComputedField = (target, index) => {
  target.computedFields.splice(index, 1)
}

// ==================== 数据处理 ====================

const applyComputedFields = (data, computedFields) => {
  if (!computedFields || computedFields.length === 0) return data
  
  // 浅拷贝数据以避免修改原始引用
  return data.map(row => {
    const newRow = { ...row }
    computedFields.forEach(field => {
      const { name, source, operator, threshold } = field
      if (!name || !source) return
      
      const val = Number(newRow[source]) || 0
      const thres = Number(threshold) || 0
      let result = 0
      
      switch (operator) {
        case '>=': result = val >= thres ? 1 : 0; break
        case '<=': result = val <= thres ? 1 : 0; break
        case '==': result = val == thres ? 1 : 0; break
        case '>': result = val > thres ? 1 : 0; break
        case '<': result = val < thres ? 1 : 0; break
        case '!=': result = val != thres ? 1 : 0; break
      }
      newRow[name] = result
    })
    return newRow
  })
}

const applyFilters = (data, filters) => {
  if (!filters || filters.length === 0) return data
  
  return data.filter(row => {
    return filters.every(filter => {
      if (!filter.field || !filter.operator) return true
      
      const value = row[filter.field]
      const filterValue = filter.value
      
      switch (filter.operator) {
        case 'eq': return value == filterValue
        case 'neq': return value != filterValue
        case 'gt': return Number(value) > Number(filterValue)
        case 'gte': return Number(value) >= Number(filterValue)
        case 'lt': return Number(value) < Number(filterValue)
        case 'lte': return Number(value) <= Number(filterValue)
        case 'contains': return String(value).includes(filterValue)
        case 'notContains': return !String(value).includes(filterValue)
        case 'empty': return value === '' || value === null || value === undefined
        case 'notEmpty': return value !== '' && value !== null && value !== undefined
        default: return true
      }
    })
  })
}

// 聚合数据 - 支持不聚合、排序、限制、分组
const aggregateData = (data, xField, yFields, aggregation, options = {}) => {
  const { sortField, sortOrder, limitType, limitCount, groupField } = options
  
  // 多维度分组（用于堆叠图）
  if (groupField && groupField !== xField) {
    return aggregateGroupedData(data, xField, yFields[0], groupField, aggregation, options)
  }
  
  // 不聚合时直接返回原始数据
  if (aggregation === 'none') {
    const result = { categories: [], series: {}, meta: {} }
    yFields.forEach(f => {
      result.series[f] = []
      result.meta[f] = { isRate: false }
    })
    
    data.forEach((row, i) => {
      result.categories.push(row[xField] || `项${i + 1}`)
      yFields.forEach(f => {
        result.series[f].push(Number(row[f]) || 0)
      })
    })
    
    return applyPostProcessing(result, yFields, options)
  }
  
  const grouped = {}
  
  data.forEach(row => {
    const key = row[xField]
    if (!grouped[key]) {
      grouped[key] = { values: {}, count: 0 }
      yFields.forEach(f => grouped[key].values[f] = [])
    }
    yFields.forEach(f => {
      const val = Number(row[f]) || 0
      grouped[key].values[f].push(val)
    })
    grouped[key].count++
  })
  
  const result = { categories: [], series: {}, meta: {} }
  yFields.forEach(f => {
    result.series[f] = []
    const isBoolean = data.every(row => {
      const v = Number(row[f])
      return v === 0 || v === 1 || isNaN(v)
    })
    result.meta[f] = { isRate: isBoolean && aggregation === 'avg' }
  })
  
  Object.keys(grouped).forEach(key => {
    result.categories.push(key)
    yFields.forEach(f => {
      const values = grouped[key].values[f]
      let value
      
      switch (aggregation) {
        case 'sum': value = values.reduce((a, b) => a + b, 0); break
        case 'avg': 
          value = values.reduce((a, b) => a + b, 0) / values.length;
          if (result.meta[f].isRate) value = value * 100
          break
        case 'max': value = Math.max(...values); break
        case 'min': value = Math.min(...values); break
        case 'count': value = grouped[key].count; break
        default: value = values.reduce((a, b) => a + b, 0)
      }
      
      result.series[f].push(Number(value.toFixed(2)))
    })
  })
  
  return applyPostProcessing(result, yFields, options)
}

// 多维度分组聚合（用于堆叠图）
const aggregateGroupedData = (data, xField, yField, groupField, aggregation, options) => {
  if (!yField) return { categories: [], series: {}, meta: {}, isGrouped: true }
  
  const grouped = {}
  const allGroups = new Set()
  
  data.forEach(row => {
    const xKey = String(row[xField] || '')
    const gKey = String(row[groupField] || '')
    allGroups.add(gKey)
    
    if (!grouped[xKey]) grouped[xKey] = {}
    if (!grouped[xKey][gKey]) grouped[xKey][gKey] = []
    
    grouped[xKey][gKey].push(Number(row[yField]) || 0)
  })
  
  const categories = Object.keys(grouped)
  const groupNames = Array.from(allGroups)
  const series = {}
  const meta = {}
  
  const isBoolean = data.every(row => {
    const v = Number(row[yField])
    return v === 0 || v === 1 || isNaN(v)
  })
  
  groupNames.forEach(g => {
    series[g] = []
    meta[g] = { isRate: isBoolean && aggregation === 'avg' }
  })
  
  categories.forEach(xKey => {
    groupNames.forEach(g => {
      const values = grouped[xKey][g] || [0]
      let value = 0
      
      switch (aggregation) {
        case 'sum': value = values.reduce((a, b) => a + b, 0); break
        case 'avg':
          value = values.reduce((a, b) => a + b, 0) / values.length
          if (isBoolean) value *= 100
          break
        case 'max': value = Math.max(...values); break
        case 'min': value = Math.min(...values); break
        case 'count': value = values.length; break
        case 'none': value = values[0] || 0; break
        default: value = values.reduce((a, b) => a + b, 0)
      }
      
      series[g].push(Number(value.toFixed(2)))
    })
  })
  
  return applyPostProcessing({ categories, series, meta, isGrouped: true, groupField }, Object.keys(series), options)
}

// 后处理：排序和限制
const applyPostProcessing = (result, yFields, options) => {
  const { sortField, sortOrder, limitType, limitCount } = options
  
  if (!result.categories.length) return result
  
  let indices = result.categories.map((_, i) => i)
  
  // 排序
  if (sortField && sortOrder) {
    if (sortField === 'x') {
      indices.sort((a, b) => {
        const cmp = String(result.categories[a]).localeCompare(String(result.categories[b]))
        return sortOrder === 'asc' ? cmp : -cmp
      })
    } else if (sortField === 'y' && yFields.length > 0) {
      const firstY = yFields[0]
      if (result.series[firstY]) {
        indices.sort((a, b) => {
          const diff = result.series[firstY][a] - result.series[firstY][b]
          return sortOrder === 'asc' ? diff : -diff
        })
      }
    }
  }
  
  // 重新排列
  result.categories = indices.map(i => result.categories[i])
  Object.keys(result.series).forEach(key => {
    result.series[key] = indices.map(i => result.series[key][i])
  })
  
  // 限制
  if (limitType && limitCount > 0 && result.categories.length > limitCount) {
    if (limitType === 'top') {
      result.categories = result.categories.slice(0, limitCount)
      Object.keys(result.series).forEach(key => {
        result.series[key] = result.series[key].slice(0, limitCount)
      })
    } else if (limitType === 'bottom') {
      result.categories = result.categories.slice(-limitCount)
      Object.keys(result.series).forEach(key => {
        result.series[key] = result.series[key].slice(-limitCount)
      })
    }
  }
  
  return result
}

// ==================== 图表下钻 ====================

const handleChartClick = async (chart, params) => {
  if (!chart.enableDrillDown) return
  
  const xValue = params.name
  const seriesName = params.seriesName
  const groupValue = chart.isGrouped ? seriesName : null
  
  drillDownTitle.value = `${chart.title} - ${xValue}${groupValue ? ` (${groupValue})` : ''} 详情`
  drillDownParams.value = {
    chart,
    xValue,
    seriesName,
    groupValue
  }
  drillDownPage.value = 1
  
  await loadDrillDownData()
  showDrillDownDialog.value = true
}

const loadDrillDownData = async () => {
  const { chart, xValue, groupValue } = drillDownParams.value
  if (!chart) return
  
  drillDownLoading.value = true
  
  try {
    // 获取原始数据
    let processData = sheetData.value[chart.sheet]?.rows || []
    processData = applyComputedFields(processData, chart.computedFields)
    
    // 如果有已保存的看板ID，可以使用后端 API
    if (currentDashboardId.value) {
      const result = await drillDownChart({
        dashboardId: currentDashboardId.value,
        sheetName: chart.sheet,
        chartConfig: {
          xField: chart.xField,
          filters: chart.filters,
          computedFields: chart.computedFields,
          groupField: chart.groupField
        },
        drillParams: {
          xValue,
          groupValue,
          page: drillDownPage.value,
          pageSize: drillDownPageSize.value
        }
      })
      drillDownData.value = result
    } else {
      // 前端本地过滤
      let filtered = applyFilters(processData, chart.filters)
      
      if (chart.xField && xValue !== undefined) {
        filtered = filtered.filter(row => String(row[chart.xField]) === String(xValue))
      }
      
      if (chart.groupField && groupValue) {
        filtered = filtered.filter(row => String(row[chart.groupField]) === String(groupValue))
      }
      
      const total = filtered.length
      const offset = (drillDownPage.value - 1) * drillDownPageSize.value
      const pageData = filtered.slice(offset, offset + drillDownPageSize.value)
      
      drillDownData.value = {
        headers: sheetData.value[chart.sheet]?.headers || [],
        rows: pageData,
        total,
        page: drillDownPage.value,
        pageSize: drillDownPageSize.value
      }
    }
  } catch (e) {
    console.error('下钻数据加载失败:', e)
    ElMessage.error('加载详情数据失败')
  } finally {
    drillDownLoading.value = false
  }
}

const handleDrillDownPageChange = (page) => {
  drillDownPage.value = page
  loadDrillDownData()
}

// ==================== 图表渲染 ====================

const isDark = ref(document.documentElement.classList.contains('dark'))

// 监听主题变化
const observer = new MutationObserver((mutations) => {
  mutations.forEach((mutation) => {
    if (mutation.attributeName === 'class') {
      isDark.value = document.documentElement.classList.contains('dark')
      renderAllCharts()
    }
  })
})

onMounted(() => {
  fetchSavedDashboards()
  observer.observe(document.documentElement, { attributes: true })
})

onUnmounted(() => {
  observer.disconnect()
})

const renderChart = (chartId) => {
  const chart = charts.value.find(c => c.id === chartId)
  if (!chart) return
  
  const container = document.getElementById(`chart-${chartId}`)
  if (!container) return
  
  if (chartInstances.value[chartId]) {
    chartInstances.value[chartId].dispose()
  }
  
  // 使用自定义主题（自动适配亮色/暗色）
  const theme = getCurrentThemeName()
  const instance = echarts.init(container, theme, {
    renderer: 'canvas',
    useDirtyRect: false
  })
  chartInstances.value[chartId] = instance
  
  // 1. 获取原始数据
  let processData = sheetData.value[chart.sheet]?.rows || []
  
  // 2. 应用计算字段
  processData = applyComputedFields(processData, chart.computedFields)
  
  // 3. 筛选
  const filteredData = applyFilters(processData, chart.filters)
  
  // 4. 聚合（包含排序、限制、分组配置）
  const aggregateOptions = {
    sortField: chart.sortField || '',
    sortOrder: chart.sortOrder || '',
    limitType: chart.limitType || '',
    limitCount: chart.limitCount || 10,
    groupField: chart.groupField || ''
  }
  const aggregated = aggregateData(filteredData, chart.xField, chart.yFields, chart.aggregation, aggregateOptions)
  
  // 保存分组状态到 chart 对象（用于下钻）
  chart.isGrouped = aggregated.isGrouped
  
  const option = generateChartOption(chart, aggregated)
  
  // 强制背景透明，以便适配卡片背景
  option.backgroundColor = 'transparent'
  
  instance.setOption(option)
  
  // 添加点击事件（下钻）
  instance.off('click')
  if (chart.enableDrillDown !== false) {
    instance.on('click', (params) => {
      if (params.componentType === 'series') {
        handleChartClick(chart, params)
      }
    })
  }
  
  window.addEventListener('resize', () => instance.resize())
}

const renderAllCharts = () => {
  nextTick(() => {
    charts.value.forEach(chart => renderChart(chart.id))
  })
}

// 颜色适配
const getAdaptiveColor = (color) => {
  if (!isDark.value) return color
  // 简单的深色模式颜色映射
  const colorMap = {
    '#374151': '#e5e7eb',
    '#1f2937': '#f3f4f6',
    '#000000': '#ffffff',
    '#111827': '#f9fafb'
  }
  return colorMap[color] || color
}

// 生成ECharts配置 - 适配深色模式
const generateChartOption = (chart, data) => {
  const { type, title, colors, showLegend, showLabel, yFields, yAxisConfig } = chart
  const isDarkMode = isDark.value
  
  // 适配图表颜色
  let chartColors = colors
  if (isDarkMode) {
    const defaultGrays = ['#374151', '#6B7280', '#9CA3AF', '#D1D5DB', '#1f2937', '#4B5563']
    const darkGrays = ['#e5e7eb', '#d1d5db', '#9ca3af', '#6b7280', '#f3f4f6', '#9ca3af']
    
    // 如果是默认配色，则进行映射
    if (colors.length === defaultGrays.length && colors[0] === defaultGrays[0]) {
      chartColors = darkGrays
    } else {
      // 尝试映射单个颜色
      chartColors = colors.map(c => getAdaptiveColor(c))
    }
  }
  
  const textColor = isDarkMode ? '#e5e5e5' : '#1f2937'
  const subTextColor = isDarkMode ? '#a3a3a3' : '#6b7280'
  const lineColor = isDarkMode ? '#404040' : '#e5e7eb'
  const splitLineColor = isDarkMode ? '#262626' : '#f3f4f6'
  const tooltipBg = isDarkMode ? 'rgba(0, 0, 0, 0.9)' : 'rgba(255, 255, 255, 0.98)'
  const tooltipBorder = isDarkMode ? '#404040' : '#e5e7eb'
  const tooltipText = isDarkMode ? '#e5e5e5' : '#374151'

  // 判断是否使用双Y轴
  const useDualAxis = yAxisConfig && Object.values(yAxisConfig).some(v => v === 1)
  
  const yAxisList = []
  
  if (useDualAxis) {
    // 左轴
    yAxisList.push({
      type: 'value',
      name: '',
      position: 'left',
      axisLine: { show: false }, // ECharts 默认不显示 value 轴线
      splitLine: { lineStyle: { color: splitLineColor } },
      axisLabel: { color: subTextColor, fontSize: 11 }
    })
    // 右轴
    yAxisList.push({
      type: 'value',
      name: '',
      position: 'right',
      axisLine: { show: false },
      splitLine: { show: false }, // 通常只显示左轴分割线
      axisLabel: { color: subTextColor, fontSize: 11, formatter: '{value}%' } // 假设右轴通常用于比率，默认加 %
    })
  } else {
    // 单轴
    yAxisList.push({
      type: 'value',
      axisLine: { show: false },
      splitLine: { lineStyle: { color: splitLineColor } },
      axisLabel: { color: subTextColor, fontSize: 11 }
    })
  }

  const baseOption = {
    title: {
      text: title,
      left: 'center',
      textStyle: {
        fontSize: 14,
        fontWeight: 600,
        color: textColor
      }
    },
    tooltip: {
      trigger: type === 'pie' ? 'item' : 'axis',
      backgroundColor: tooltipBg,
      borderColor: tooltipBorder,
      textStyle: { color: tooltipText, fontSize: 12 },
      formatter: (params) => {
        if (!Array.isArray(params)) return
        let res = `${params[0].name}<br/>`
        params.forEach(param => {
          const fieldName = param.seriesName
          const val = param.value
          const isRate = data.meta?.[fieldName]?.isRate
          res += `${param.marker} ${fieldName}: ${val}${isRate ? '%' : ''}<br/>`
        })
        return res
      }
    },
    legend: {
      show: showLegend,
      bottom: 8,
      textStyle: { color: subTextColor, fontSize: 11 }
    },
    color: chartColors,
    grid: {
      left: '3%',
      right: '4%',
      bottom: showLegend ? '15%' : '8%',
      top: '18%',
      containLabel: true
    }
  }
  
  switch (type) {
    case 'bar':
      // 处理分组数据（堆叠柱状图）
      const barSeriesKeys = data.isGrouped ? Object.keys(data.series) : yFields
      return {
        ...baseOption,
        xAxis: {
          type: 'category',
          data: data.categories,
          axisLine: { lineStyle: { color: lineColor } },
          axisLabel: { color: subTextColor, fontSize: 11 }
        },
        yAxis: yAxisList,
        series: barSeriesKeys.map((field, i) => {
          const yIndex = yAxisConfig?.[field] || 0
          const isRate = data.meta?.[field]?.isRate
          
          return {
            name: field,
            type: 'bar',
            yAxisIndex: useDualAxis ? yIndex : 0,
            data: data.series[field] || [],
            stack: data.isGrouped ? 'total' : undefined, // 分组数据使用堆叠
            itemStyle: { borderRadius: data.isGrouped ? 0 : [3, 3, 0, 0] },
            label: { 
              show: showLabel, 
              position: data.isGrouped ? 'inside' : 'top', 
              fontSize: 10, 
              color: data.isGrouped ? '#fff' : textColor,
              formatter: isRate ? '{c}%' : '{c}'
            },
            emphasis: {
              focus: data.isGrouped ? 'series' : 'self'
            }
          }
        })
      }
      
    case 'line':
      const lineSeriesKeys = data.isGrouped ? Object.keys(data.series) : yFields
      return {
        ...baseOption,
        xAxis: {
          type: 'category',
          data: data.categories,
          boundaryGap: false,
          axisLine: { lineStyle: { color: lineColor } },
          axisLabel: { color: subTextColor, fontSize: 11 }
        },
        yAxis: yAxisList,
        series: lineSeriesKeys.map((field) => {
          const yIndex = yAxisConfig?.[field] || 0
          const isRate = data.meta?.[field]?.isRate
          
          return {
            name: field,
            type: 'line',
            yAxisIndex: useDualAxis ? yIndex : 0,
            data: data.series[field] || [],
            smooth: true,
            symbol: 'circle',
            symbolSize: 5,
            lineStyle: { width: 2 },
            areaStyle: data.isGrouped ? { opacity: 0.3 } : { opacity: 0.05 },
            stack: data.isGrouped ? 'total' : undefined, // 分组数据使用堆叠面积
            label: { 
              show: showLabel, 
              position: 'top', 
              fontSize: 10, 
              color: textColor,
              formatter: isRate ? '{c}%' : '{c}'
            }
          }
        })
      }
      
    case 'pie':
      const pieData = data.categories.map((cat, i) => ({
        name: cat,
        value: data.series[yFields[0]][i]
      }))
      return {
        ...baseOption,
        series: [{
          type: 'pie',
          radius: ['40%', '65%'],
          center: ['50%', '50%'],
          data: pieData,
          itemStyle: { 
            borderRadius: 4, 
            borderColor: isDarkMode ? '#1f2937' : '#fff', 
            borderWidth: 2 
          },
          label: { show: showLabel, formatter: '{b}: {d}%', fontSize: 10, color: subTextColor },
          emphasis: { itemStyle: { shadowBlur: 10, shadowColor: 'rgba(0, 0, 0, 0.1)' } }
        }]
      }
      
    case 'scatter':
      return {
        ...baseOption,
        xAxis: { type: 'category', data: data.categories, axisLine: { lineStyle: { color: lineColor } }, axisLabel: { color: subTextColor, fontSize: 11 } },
        yAxis: { type: 'value', axisLine: { show: false }, splitLine: { lineStyle: { color: splitLineColor } }, axisLabel: { color: subTextColor, fontSize: 11 } },
        series: yFields.map(field => ({ name: field, type: 'scatter', data: data.series[field], symbolSize: 10 }))
      }
      
    case 'radar':
      const maxValue = Math.max(...yFields.flatMap(f => data.series[f]))
      return {
        ...baseOption,
        radar: { 
          indicator: data.categories.map(cat => ({ name: cat, max: maxValue * 1.2 })), 
          shape: 'polygon', 
          splitArea: { areaStyle: { color: isDarkMode ? ['#262626', '#171717'] : ['#fafafa', '#f5f5f5'] } },
          axisName: { color: subTextColor }
        },
        series: [{ type: 'radar', data: yFields.map((field) => ({ name: field, value: data.series[field], areaStyle: { opacity: 0.15 } })) }]
      }
      
    case 'funnel':
      const funnelData = data.categories.map((cat, i) => ({ name: cat, value: data.series[yFields[0]][i] })).sort((a, b) => b.value - a.value)
      return {
        ...baseOption,
        series: [{ 
          type: 'funnel', 
          left: '10%', 
          width: '80%', 
          gap: 2, 
          data: funnelData, 
          label: { show: showLabel, position: 'inside', formatter: '{b}: {c}', fontSize: 10, color: '#fff' }, 
          itemStyle: { borderColor: isDarkMode ? '#1f2937' : '#fff', borderWidth: 1 } 
        }]
      }
      
    case 'gauge':
      const gaugeValue = data.series[yFields[0]]?.reduce((a, b) => a + b, 0) || 0
      return {
        ...baseOption,
        series: [{ 
          type: 'gauge', 
          progress: { show: true, width: 14 }, 
          axisLine: { lineStyle: { width: 14, color: [[1, isDarkMode ? '#4b5563' : '#d1d5db']] } }, 
          axisTick: { show: false }, 
          splitLine: { length: 10, lineStyle: { width: 2, color: '#999' } }, 
          axisLabel: { distance: 20, color: '#999', fontSize: 10 }, 
          anchor: { show: true, showAbove: true, size: 14, itemStyle: { borderWidth: 6, borderColor: isDarkMode ? '#e5e5e5' : '#374151' } }, 
          title: { show: false }, 
          detail: { valueAnimation: true, fontSize: 20, fontWeight: 600, offsetCenter: [0, '70%'], color: textColor }, 
          data: [{ value: gaugeValue, name: yFields[0] }] 
        }]
      }
      
    default:
      return baseOption
  }
}

// ==================== 看板存储 (数据库) ====================

const fetchSavedDashboards = async () => {
  loadingDashboards.value = true
  try {
    const data = await getDashboards()
    savedDashboards.value = data || []
  } catch (e) {
    // 如果API不存在，使用localStorage
    const saved = localStorage.getItem('nav_dashboards')
    if (saved) {
      savedDashboards.value = JSON.parse(saved)
    }
  } finally {
    loadingDashboards.value = false
  }
}

const saveDashboard = async () => {
  if (!currentDashboardName.value.trim()) {
    ElMessage.warning('请输入看板名称')
    return
  }
  
  const dashboardData = {
    name: currentDashboardName.value,
    charts: JSON.parse(JSON.stringify(charts.value)),
    statCards: JSON.parse(JSON.stringify(statCards.value)),
    sheetData: JSON.parse(JSON.stringify(sheetData.value)),
    sheetNames: [...sheetNames.value],
    visibility: dashboardVisibility.value
  }
  
  try {
    if (isEditMode.value && currentDashboardId.value) {
      // 更新已有看板
      await updateDashboard(currentDashboardId.value, dashboardData)
      ElMessage.success('看板已更新')
    } else {
      // 创建新看板
      dashboardData.id = Date.now().toString()
      dashboardData.createdAt = new Date().toISOString()
      const result = await saveDashboardAPI(dashboardData)
      currentDashboardId.value = result.id
      isEditMode.value = true
      ElMessage.success('看板已保存')
    }
  } catch (e) {
    // 降级到localStorage
    const localDashboard = { ...dashboardData, id: currentDashboardId.value || Date.now().toString() }
    const existingIndex = savedDashboards.value.findIndex(d => d.name === currentDashboardName.value)
    if (existingIndex >= 0) {
      savedDashboards.value[existingIndex] = localDashboard
    } else {
      savedDashboards.value.push(localDashboard)
    }
    localStorage.setItem('nav_dashboards', JSON.stringify(savedDashboards.value))
    ElMessage.success(isEditMode.value ? '看板已更新(本地)' : '看板已保存(本地)')
  }
  
  showSaveDialog.value = false
  fetchSavedDashboards()
}

const loadDashboard = async (dashboard) => {
  loadingDashboards.value = true
  
  try {
    // 从 API 获取完整看板数据（包含 sheetData）
    const fullDashboard = await getDashboard(dashboard.id, true)
    
    console.log('加载的看板数据:', fullDashboard)
    console.log('sheetData:', fullDashboard.sheetData)
    console.log('sheetNames:', fullDashboard.sheetNames)
    
    sheetData.value = fullDashboard.sheetData || {}
    sheetNames.value = fullDashboard.sheetNames || []
    charts.value = fullDashboard.charts || []
    statCards.value = fullDashboard.statCards || []
    activeSheet.value = sheetNames.value[0] || ''
    
    // 设置编辑模式
    currentDashboardId.value = fullDashboard.id
    currentDashboardName.value = fullDashboard.name
    dashboardVisibility.value = fullDashboard.visibility || 'private'
    isEditMode.value = true
    
    showLoadDialog.value = false
    
    nextTick(() => {
      renderAllCharts()
      calculateAllStatCards() // 计算所有统计卡片
    })
    
    // 检查数据是否加载成功
    const dataLoaded = Object.keys(sheetData.value).length > 0
    if (dataLoaded) {
      ElMessage.success('看板加载成功，可直接编辑')
    } else {
      ElMessage.warning('看板结构已加载，但数据文件未找到')
    }
  } catch (e) {
    console.error('加载看板失败:', e)
    ElMessage.error('加载看板失败，请重试')
  } finally {
    loadingDashboards.value = false
  }
}

// 清除当前看板（新建）
const clearDashboard = () => {
  charts.value = []
  statCards.value = []
  currentDashboardId.value = null
  currentDashboardName.value = ''
  dashboardVisibility.value = 'private'
  isEditMode.value = false
  virtualDatasets.value = []
  statCardResults.value = {}
  
  // 清理图表实例
  Object.values(chartInstances.value).forEach(instance => {
    instance?.dispose()
  })
  chartInstances.value = {}
  
  ElMessage.success('已新建看板')
}

// ==================== 多表关联 ====================

// 获取可用于关联的数据源列表
const joinDataSources = computed(() => {
  const sources = []
  
  // 原始工作表
  sheetNames.value.forEach(name => {
    if (sheetData.value[name]) {
      sources.push({
        name: name,
        data: sheetData.value[name]
      })
    }
  })
  
  // 虚拟数据集
  virtualDatasets.value.forEach(vd => {
    sources.push({
      name: vd.name,
      data: vd.data
    })
  })
  
  return sources
})

// 处理多表关联结果
const handleJoinConfirm = (virtualDataset) => {
  // 添加到虚拟数据集列表
  virtualDatasets.value.push(virtualDataset)
  
  // 将合并结果添加到 sheetData，这样可以在图表中使用
  sheetData.value[virtualDataset.name] = virtualDataset.data
  
  // 添加到 sheetNames 中
  if (!sheetNames.value.includes(virtualDataset.name)) {
    sheetNames.value.push(virtualDataset.name)
  }
  
  // 切换到新数据集
  activeSheet.value = virtualDataset.name
  
  ElMessage.success(`虚拟数据集 "${virtualDataset.name}" 已创建`)
}

// 删除虚拟数据集
const deleteVirtualDataset = async (name) => {
  try {
    await ElMessageBox.confirm(`确定删除虚拟数据集 "${name}"？`, '提示', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning'
    })
    
    virtualDatasets.value = virtualDatasets.value.filter(vd => vd.name !== name)
    delete sheetData.value[name]
    sheetNames.value = sheetNames.value.filter(n => n !== name)
    
    if (activeSheet.value === name) {
      activeSheet.value = sheetNames.value[0] || ''
    }
    
    ElMessage.success('已删除')
  } catch {}
}

// 快速保存当前看板
const quickSaveDashboard = async () => {
  if (!isEditMode.value || !currentDashboardId.value) {
    showSaveDialog.value = true
    return
  }
  
  const dashboardData = {
    name: currentDashboardName.value,
    charts: JSON.parse(JSON.stringify(charts.value)),
    statCards: JSON.parse(JSON.stringify(statCards.value)),
    sheetData: JSON.parse(JSON.stringify(sheetData.value)),
    sheetNames: [...sheetNames.value],
    visibility: dashboardVisibility.value
  }
  
  try {
    await updateDashboard(currentDashboardId.value, dashboardData)
    ElMessage.success('看板已更新')
  } catch (e) {
    ElMessage.error('更新失败，请重试')
  }
}

const deleteDashboard = async (dashboard) => {
  try {
    await ElMessageBox.confirm('确定删除？', '提示', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning'
    })
    
    try {
      await deleteDashboardAPI(dashboard.id)
    } catch (e) {
      savedDashboards.value = savedDashboards.value.filter(d => d.id !== dashboard.id)
      localStorage.setItem('nav_dashboards', JSON.stringify(savedDashboards.value))
    }
    
    fetchSavedDashboards()
    ElMessage.success('已删除')
  } catch {}
}

// ==================== 生命周期 ====================

onMounted(() => {
  fetchSavedDashboards()
})
</script>

<template>
  <div class="dashboard-page">
    <!-- 顶部工具栏 - 简洁化 -->
    <header class="dashboard-header">
      <div class="header-left">
        <button class="back-btn" @click="router.push('/')">
          <el-icon><ArrowLeft /></el-icon>
        </button>
        <div class="title-group">
          <h1 class="page-title">看板生成器</h1>
          <div v-if="isEditMode" class="current-dashboard">
            <span class="dashboard-name">{{ currentDashboardName }}</span>
            <span class="edit-badge">编辑中</span>
          </div>
        </div>
      </div>
      
      <div class="header-actions">
        <el-upload :auto-upload="false" :show-file-list="false" accept=".xlsx,.xls,.csv" :on-change="handleFileUpload">
          <el-button size="small">导入</el-button>
        </el-upload>
        <el-button size="small" @click="addChart" :disabled="sheetNames.length === 0">图表</el-button>
        <el-button size="small" @click="addStatCard" :disabled="sheetNames.length === 0">统计</el-button>
        <el-button size="small" @click="showJoinDialog = true" :disabled="sheetNames.length < 2">关联</el-button>
        <el-divider direction="vertical" />
        <el-button size="small" @click="clearDashboard" v-if="isEditMode">新建</el-button>
        <el-button size="small" @click="showLoadDialog = true">加载</el-button>
        <el-button size="small" @click="quickSaveDashboard" v-if="isEditMode && (charts.length > 0 || statCards.length > 0)" type="primary">
          <el-icon><Check /></el-icon>保存
        </el-button>
        <el-button size="small" @click="showSaveDialog = true" v-else :disabled="charts.length === 0 && statCards.length === 0">另存为</el-button>
      </div>
    </header>
    
    <!-- Sheet选择器 - 简化 -->
    <div v-if="sheetNames.length > 0" class="sheet-tabs">
      <button 
        v-for="name in sheetNames" 
        :key="name" 
        class="sheet-tab" 
        :class="{ active: activeSheet === name, virtual: virtualDatasets.some(vd => vd.name === name) }" 
        @click="activeSheet = name"
      >
        <el-icon v-if="virtualDatasets.some(vd => vd.name === name)" class="virtual-icon"><Connection /></el-icon>
        {{ name }} <span class="count">{{ sheetData[name]?.rows?.length || 0 }}</span>
        <button 
          v-if="virtualDatasets.some(vd => vd.name === name)" 
          class="delete-virtual-btn"
          @click.stop="deleteVirtualDataset(name)"
        >
          <el-icon><Close /></el-icon>
        </button>
      </button>
    </div>
    
    <!-- 数据预览 - 简化 -->
    <div v-if="currentRows.length > 0" class="data-preview">
      <div class="preview-header">
        <span>数据预览</span>
        <span class="meta">{{ currentFields.length }} 字段 · {{ currentRows.length }} 行</span>
      </div>
      <div class="table-wrapper">
        <table class="preview-table">
          <thead><tr><th v-for="field in currentFields" :key="field">{{ field }}</th></tr></thead>
          <tbody><tr v-for="(row, i) in currentRows.slice(0, 8)" :key="i"><td v-for="field in currentFields" :key="field">{{ row[field] }}</td></tr></tbody>
        </table>
      </div>
    </div>
    
    <!-- 空状态 -->
    <div v-else-if="sheetNames.length === 0" class="empty-state">
      <p>导入Excel开始</p>
      <el-upload :auto-upload="false" :show-file-list="false" accept=".xlsx,.xls,.csv" :on-change="handleFileUpload" class="upload-area" drag>
        <div class="upload-content">
          <el-icon :size="32"><Upload /></el-icon>
          <span>拖拽或点击上传</span>
        </div>
      </el-upload>
    </div>
    
    <!-- 统计卡片网格 - 使用新的 StatCard 组件 -->
    <div v-if="statCards.length > 0" class="stat-cards-grid">
      <div v-for="card in statCards" :key="card.id" class="stat-card-wrapper" :style="{ gridColumn: `span ${card.width}` }">
        <StatCard
          :title="card.title"
          :value="getStatCardResult(card).value"
          :prefix="card.prefix"
          :suffix="card.suffix"
          :trend="getStatCardResult(card).trend"
          :trend-label="card.timeField ? '较上期' : ''"
          :sparkline-data="card.showSparkline !== false ? getStatCardResult(card).sparklineData : []"
          :color="card.color"
          :loading="getStatCardResult(card).loading"
        />
        <!-- 编辑/删除按钮悬浮层 -->
        <div class="stat-card-overlay">
          <button @click="editStatCard(card)" class="overlay-btn"><el-icon><Edit /></el-icon></button>
          <button @click="deleteStatCard(card)" class="overlay-btn overlay-btn--danger"><el-icon><Delete /></el-icon></button>
        </div>
      </div>
    </div>
    
    <!-- 图表网格 -->
    <div v-if="charts.length > 0" class="charts-grid">
      <div v-for="chart in charts" :key="chart.id" class="chart-card" :style="{ gridColumn: `span ${chart.width}` }">
        <div class="chart-toolbar">
          <span class="chart-title">{{ chart.title }}</span>
          <div class="chart-actions">
            <button @click="editChart(chart)"><el-icon><Edit /></el-icon></button>
            <button @click="deleteChart(chart)"><el-icon><Delete /></el-icon></button>
          </div>
        </div>
        <div :id="`chart-${chart.id}`" class="chart-container" :style="{ height: `${chart.height}px` }"></div>
      </div>
    </div>
    
    <!-- 图表配置对话框 -->
    <el-dialog v-model="showChartDialog" title="图表配置" width="600px" :close-on-click-modal="false">
      <div v-if="editingChart" class="config-form">
        <div class="form-row">
          <div class="form-field"><label>标题</label><el-input v-model="editingChart.title" size="small" /></div>
          <div class="form-field"><label>类型</label>
            <el-select v-model="editingChart.type" size="small">
              <el-option v-for="t in chartTypes" :key="t.value" :label="t.label" :value="t.value" />
            </el-select>
          </div>
        </div>
        <div class="form-row">
          <div class="form-field"><label>数据源</label>
            <el-select v-model="editingChart.sheet" size="small" @change="() => { editingChart.xField = ''; editingChart.yFields = []; editingChart.groupField = '' }">
              <el-option v-for="name in sheetNames" :key="name" :label="name" :value="name" />
            </el-select>
          </div>
          <div class="form-field"><label>聚合方式</label>
            <el-select v-model="editingChart.aggregation" size="small">
              <el-option v-for="a in aggregationOptions" :key="a.value" :label="a.label" :value="a.value" />
            </el-select>
          </div>
        </div>
        <div class="form-row">
          <div class="form-field"><label>X轴</label>
            <el-select v-model="editingChart.xField" size="small">
              <el-option v-for="f in editingChartFields" :key="f" :label="f" :value="f" />
            </el-select>
          </div>
          <div class="form-field"><label>Y轴</label>
            <el-select v-model="editingChart.yFields" multiple size="small" collapse-tags>
              <el-option v-for="f in editingChartFields" :key="f" :label="f" :value="f" />
            </el-select>
          </div>
        </div>
        
        <!-- 新增：分组字段（堆叠图） -->
        <div class="form-row">
          <div class="form-field"><label>分组字段 <span class="hint">(堆叠图)</span></label>
            <el-select v-model="editingChart.groupField" size="small" clearable placeholder="不分组">
              <el-option v-for="f in editingChartFields" :key="f" :label="f" :value="f" :disabled="f === editingChart.xField" />
            </el-select>
          </div>
          <div class="form-field"><label>启用下钻</label>
            <el-switch v-model="editingChart.enableDrillDown" size="small" />
          </div>
        </div>
        
        <!-- 新增：排序和限制 -->
        <div class="form-row">
          <div class="form-field"><label>排序</label>
            <el-select v-model="editingChart.sortField" size="small" clearable placeholder="不排序" @change="(v) => { if(!v) editingChart.sortOrder = '' }">
              <el-option label="按X轴" value="x" />
              <el-option label="按Y轴" value="y" />
            </el-select>
          </div>
          <div class="form-field" v-if="editingChart.sortField"><label>排序方向</label>
            <el-select v-model="editingChart.sortOrder" size="small">
              <el-option label="升序" value="asc" />
              <el-option label="降序" value="desc" />
            </el-select>
          </div>
          <div class="form-field"><label>限制</label>
            <el-select v-model="editingChart.limitType" size="small" clearable placeholder="不限制" @change="(v) => { if(!v) editingChart.limitCount = 10 }">
              <el-option label="前 N 名" value="top" />
              <el-option label="后 N 名" value="bottom" />
            </el-select>
          </div>
          <div class="form-field" v-if="editingChart.limitType"><label>数量</label>
            <el-input-number v-model="editingChart.limitCount" :min="1" :max="100" size="small" />
          </div>
        </div>
        
        <!-- Y轴配置 (左/右轴) -->
        <div v-if="editingChart.yFields.length > 0" class="filter-section" style="margin-top:0; margin-bottom:1rem; padding-bottom:0.5rem">
          <div class="filter-header" style="font-size:0.75rem; margin-bottom:0.5rem"><span>Y轴配置</span></div>
          <div v-for="field in editingChart.yFields" :key="field" class="filter-row">
            <span style="font-size:0.75rem; color:var(--text-secondary); flex:1">{{ field }}</span>
            <el-radio-group 
              v-model="editingChart.yAxisConfig[field]" 
              size="small" 
              @change="(val) => { if(!editingChart.yAxisConfig) editingChart.yAxisConfig = {}; editingChart.yAxisConfig[field] = val }"
            >
              <el-radio-button :label="0">左轴</el-radio-button>
              <el-radio-button :label="1">右轴</el-radio-button>
            </el-radio-group>
          </div>
        </div>

        <!-- 计算字段配置 -->
        <div class="filter-section">
          <div class="filter-header">
            <span>计算字段</span>
            <el-button type="primary" link size="small" @click="addComputedField(editingChart)">添加</el-button>
          </div>
          <div v-for="(field, idx) in editingChart.computedFields" :key="idx" class="filter-row">
            <el-input v-model="field.name" size="small" placeholder="新字段名" style="width:100px" />
            <span style="font-size:12px; color:var(--text-tertiary)">=</span>
            <el-select v-model="field.source" size="small" placeholder="来源字段" style="width:100px">
              <el-option v-for="f in editingChartFields" :key="f" :label="f" :value="f" />
            </el-select>
            <el-select v-model="field.operator" size="small" placeholder="运算" style="width:80px">
              <el-option v-for="op in computedOperators" :key="op.value" :label="op.value" :value="op.value" />
            </el-select>
            <el-input v-model="field.threshold" size="small" placeholder="阈值" style="width:80px" />
            <el-button type="danger" link size="small" @click="removeComputedField(editingChart, idx)"><el-icon><Delete /></el-icon></el-button>
          </div>
        </div>

        <div class="form-row">
          <div class="form-field flex-1"><label>宽度</label><el-slider v-model="editingChart.width" :min="3" :max="12" :step="1" /></div>
          <div class="form-field small"><label>图例</label><el-switch v-model="editingChart.showLegend" size="small" /></div>
          <div class="form-field small"><label>标签</label><el-switch v-model="editingChart.showLabel" size="small" /></div>
        </div>
        <div class="filter-section">
          <div class="filter-header"><span>筛选条件</span><el-button type="primary" link size="small" @click="addFilter(editingChart)">添加</el-button></div>
          <div v-for="(filter, idx) in editingChart.filters" :key="idx" class="filter-row">
            <el-select v-model="filter.field" size="small" placeholder="字段" style="width:120px"><el-option v-for="f in editingChartFields" :key="f" :label="f" :value="f" /></el-select>
            <el-select v-model="filter.operator" size="small" placeholder="条件" style="width:100px"><el-option v-for="op in filterOperators" :key="op.value" :label="op.label" :value="op.value" /></el-select>
            <el-input v-model="filter.value" size="small" placeholder="值" style="width:120px" :disabled="['empty','notEmpty'].includes(filter.operator)" />
            <el-button type="danger" link size="small" @click="removeFilter(editingChart, idx)"><el-icon><Delete /></el-icon></el-button>
          </div>
        </div>
      </div>
      <template #footer>
        <el-button size="small" @click="showChartDialog = false">取消</el-button>
        <el-button type="primary" size="small" @click="saveChartConfig">确定</el-button>
      </template>
    </el-dialog>
    
    <!-- 统计卡片配置对话框 -->
    <el-dialog v-model="showStatCardDialog" title="统计卡片配置" width="520px" :close-on-click-modal="false">
      <div v-if="editingStatCard" class="config-form">
        <div class="form-row">
          <div class="form-field"><label>标题</label><el-input v-model="editingStatCard.title" size="small" /></div>
          <div class="form-field"><label>宽度</label><el-slider v-model="editingStatCard.width" :min="2" :max="6" :step="1" /></div>
        </div>
        <div class="form-row">
          <div class="form-field"><label>数据源</label>
            <el-select v-model="editingStatCard.sheet" size="small" @change="() => { editingStatCard.field = ''; editingStatCard.timeField = '' }">
              <el-option v-for="name in sheetNames" :key="name" :label="name" :value="name" />
            </el-select>
          </div>
          <div class="form-field"><label>统计字段</label>
            <el-select v-model="editingStatCard.field" size="small">
              <el-option v-for="f in editingStatCardFields" :key="f" :label="f" :value="f" />
            </el-select>
          </div>
        </div>
        <div class="form-row">
          <div class="form-field"><label>聚合方式</label>
            <el-select v-model="editingStatCard.aggregation" size="small">
              <el-option label="计数" value="count" />
              <el-option label="求和" value="sum" />
              <el-option label="平均值" value="avg" />
              <el-option label="最大值" value="max" />
              <el-option label="最小值" value="min" />
            </el-select>
          </div>
          <div class="form-field"><label>前缀</label><el-input v-model="editingStatCard.prefix" size="small" placeholder="¥" /></div>
          <div class="form-field"><label>后缀</label><el-input v-model="editingStatCard.suffix" size="small" placeholder="元" /></div>
        </div>
        
        <!-- 新增：趋势配置 -->
        <div class="form-section-title">趋势图配置</div>
        <div class="form-row">
          <div class="form-field"><label>时间字段 <span class="hint">(用于趋势计算)</span></label>
            <el-select v-model="editingStatCard.timeField" size="small" clearable placeholder="可选">
              <el-option v-for="f in editingStatCardFields" :key="f" :label="f" :value="f" />
            </el-select>
          </div>
          <div class="form-field"><label>趋势周期</label>
            <el-input-number v-model="editingStatCard.trendPeriods" :min="2" :max="30" size="small" />
          </div>
        </div>
        <div class="form-row">
          <div class="form-field small"><label>显示趋势</label><el-switch v-model="editingStatCard.showTrend" size="small" /></div>
          <div class="form-field small"><label>显示迷你图</label><el-switch v-model="editingStatCard.showSparkline" size="small" /></div>
          <div class="form-field"><label>主题色</label>
            <el-color-picker v-model="editingStatCard.color" size="small" :predefine="['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899', '#374151']" />
          </div>
        </div>
        
        <div class="filter-section">
          <div class="filter-header"><span>筛选条件</span><el-button type="primary" link size="small" @click="addFilter(editingStatCard)">添加</el-button></div>
          <div v-for="(filter, idx) in editingStatCard.filters" :key="idx" class="filter-row">
            <el-select v-model="filter.field" size="small" placeholder="字段" style="width:120px"><el-option v-for="f in editingStatCardFields" :key="f" :label="f" :value="f" /></el-select>
            <el-select v-model="filter.operator" size="small" placeholder="条件" style="width:100px"><el-option v-for="op in filterOperators" :key="op.value" :label="op.label" :value="op.value" /></el-select>
            <el-input v-model="filter.value" size="small" placeholder="值" style="width:100px" :disabled="['empty','notEmpty'].includes(filter.operator)" />
            <el-button type="danger" link size="small" @click="removeFilter(editingStatCard, idx)"><el-icon><Delete /></el-icon></el-button>
          </div>
        </div>
      </div>
      <template #footer>
        <el-button size="small" @click="showStatCardDialog = false">取消</el-button>
        <el-button type="primary" size="small" @click="saveStatCardConfig">确定</el-button>
      </template>
    </el-dialog>
    
    <!-- 保存看板对话框 -->
    <el-dialog v-model="showSaveDialog" :title="isEditMode ? '更新看板' : '保存看板'" width="360px">
      <div class="save-form">
        <div class="form-field">
          <label>名称</label>
          <el-input v-model="currentDashboardName" size="small" placeholder="看板名称" />
        </div>
        <div class="form-field">
          <label>可见性</label>
          <el-radio-group v-model="dashboardVisibility" size="small">
            <el-radio-button label="private">仅自己</el-radio-button>
            <el-radio-button label="public">所有人</el-radio-button>
          </el-radio-group>
        </div>
        <div v-if="isEditMode" class="form-tip">
          <el-icon><InfoFilled /></el-icon>
          <span>将会覆盖原有看板数据</span>
        </div>
      </div>
      <template #footer>
        <el-button size="small" @click="showSaveDialog = false">取消</el-button>
        <el-button type="primary" size="small" @click="saveDashboard">{{ isEditMode ? '更新' : '保存' }}</el-button>
      </template>
    </el-dialog>
    
    <!-- 加载看板对话框 -->
    <el-dialog v-model="showLoadDialog" title="加载看板" width="480px">
      <div v-if="loadingDashboards" class="loading-state"><p>加载中...</p></div>
      <div v-else-if="savedDashboards.length === 0" class="empty-dashboards"><p>暂无看板</p></div>
      <div v-else class="dashboard-list">
        <div v-for="d in savedDashboards" :key="d.id" class="dashboard-item">
          <div class="info">
            <span class="name">{{ d.name }}</span>
            <span class="meta">{{ d.charts?.length || 0 }}图表 · {{ d.statCards?.length || 0 }}统计 · {{ d.visibility === 'public' ? '公开' : '私有' }}</span>
          </div>
          <div class="actions">
            <el-button type="primary" size="small" @click="loadDashboard(d)">加载</el-button>
            <el-button type="danger" size="small" @click="deleteDashboard(d)">删除</el-button>
          </div>
        </div>
      </div>
    </el-dialog>
    
    <!-- 下钻详情对话框 -->
    <el-dialog v-model="showDrillDownDialog" :title="drillDownTitle" width="900px" :close-on-click-modal="false">
      <div class="drill-down-content">
        <div v-if="drillDownLoading" class="loading-state"><p>加载中...</p></div>
        <div v-else-if="drillDownData.rows.length === 0" class="empty-state"><p>暂无数据</p></div>
        <div v-else>
          <div class="drill-down-info">
            <span>共 {{ drillDownData.total }} 条记录</span>
          </div>
          <div class="drill-down-table">
            <el-table :data="drillDownData.rows" stripe border size="small" max-height="400">
              <el-table-column v-for="header in drillDownData.headers" :key="header" :prop="header" :label="header" min-width="100" show-overflow-tooltip />
            </el-table>
          </div>
          <div class="drill-down-pagination" v-if="drillDownData.total > drillDownPageSize">
            <el-pagination 
              v-model:current-page="drillDownPage" 
              :page-size="drillDownPageSize" 
              :total="drillDownData.total" 
              layout="prev, pager, next, jumper"
              @current-change="handleDrillDownPageChange"
            />
          </div>
        </div>
      </div>
    </el-dialog>
    
    <!-- 多表关联对话框 -->
    <DataJoinModal 
      v-model="showJoinDialog"
      :data-sources="joinDataSources"
      :dashboard-id="currentDashboardId"
      @confirm="handleJoinConfirm"
    />
  </div>
</template>

<style lang="scss" scoped>
.dashboard-page {
  min-height: 100vh;
  background: var(--bg-primary);
  padding: 1.25rem 1.5rem 2rem;
}

// 头部 - 简洁化
.dashboard-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1.25rem;
  padding-bottom: 1rem;
  border-bottom: 1px solid var(--border-secondary);
}

.header-left {
  display: flex;
  align-items: center;
  gap: 0.75rem;
}

.back-btn {
  width: 32px;
  height: 32px;
  border-radius: 8px;
  background: var(--card-bg);
  border: 1px solid var(--border-secondary);
  display: flex;
  align-items: center;
  justify-content: center;
  color: var(--text-secondary);
  transition: all 0.15s ease;
  
  &:hover {
    background: var(--bg-tertiary);
    color: var(--text-primary);
  }
}

.title-group {
  display: flex;
  flex-direction: column;
  gap: 0.125rem;
}

.page-title {
  font-size: 1.125rem;
  font-weight: 600;
  color: var(--text-primary);
}

.current-dashboard {
  display: flex;
  align-items: center;
  gap: 0.5rem;
}

.dashboard-name {
  font-size: 0.75rem;
  color: var(--text-secondary);
}

.edit-badge {
  font-size: 0.625rem;
  padding: 2px 6px;
  background: var(--accent-light);
  color: var(--accent);
  border-radius: 4px;
  font-weight: 500;
}

.header-actions {
  display: flex;
  gap: 0.5rem;
}

// Sheet选择器
.sheet-tabs {
  display: flex;
  gap: 0.375rem;
  margin-bottom: 1rem;
  overflow-x: auto;
  
  &::-webkit-scrollbar { display: none; }
}

.sheet-tab {
  display: flex;
  align-items: center;
  gap: 0.375rem;
  padding: 0.5rem 0.875rem;
  background: var(--card-bg);
  border: 1px solid var(--border-secondary);
  border-radius: 6px;
  font-size: 0.8125rem;
  color: var(--text-secondary);
  white-space: nowrap;
  transition: all 0.15s ease;
  
  &:hover { border-color: var(--border-hover); color: var(--text-primary); }
  
  &.active {
    background: var(--text-primary);
    border-color: var(--text-primary);
    color: var(--text-inverse);
    
    .count { background: rgba(255, 255, 255, 0.2); }
  }
  
  // 虚拟数据集样式
  &.virtual {
    border-style: dashed;
    
    &.active {
      border-style: solid;
    }
  }
  
  .virtual-icon {
    font-size: 12px;
    opacity: 0.7;
  }
  
  .count {
    padding: 1px 6px;
    background: var(--bg-tertiary);
    border-radius: 4px;
    font-size: 0.6875rem;
  }
  
  .delete-virtual-btn {
    width: 16px;
    height: 16px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 4px;
    margin-left: 2px;
    opacity: 0;
    transition: opacity 0.15s ease;
    
    &:hover {
      background: rgba(239, 68, 68, 0.2);
      color: #ef4444;
    }
  }
  
  &:hover .delete-virtual-btn {
    opacity: 1;
  }
  
  &.active .delete-virtual-btn:hover {
    background: rgba(255, 255, 255, 0.2);
    color: inherit;
  }
}

// 数据预览
.data-preview {
  background: var(--card-bg);
  border: 1px solid var(--border-secondary);
  border-radius: 10px;
  margin-bottom: 1.25rem;
  overflow: hidden;
}

.preview-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0.75rem 1rem;
  background: var(--bg-tertiary);
  border-bottom: 1px solid var(--border-secondary);
  font-size: 0.8125rem;
  font-weight: 500;
  color: var(--text-primary);
  
  .meta { color: var(--text-tertiary); font-weight: 400; }
}

.table-wrapper {
  overflow-x: auto;
  max-height: 240px;
}

.preview-table {
  width: 100%;
  border-collapse: collapse;
  font-size: 0.75rem;
  
  th, td {
    padding: 0.5rem 0.75rem;
    text-align: left;
    border-bottom: 1px solid var(--border-secondary);
    white-space: nowrap;
  }
  
  th {
    background: var(--bg-secondary);
    font-weight: 500;
    color: var(--text-primary);
    position: sticky;
    top: 0;
  }
  
  td { color: var(--text-secondary); }
  tbody tr:hover { background: var(--bg-tertiary); }
}

// 空状态
.empty-state {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 3rem;
  text-align: center;
  
  p {
    color: var(--text-tertiary);
    margin-bottom: 1.5rem;
    font-size: 0.875rem;
  }
}

.upload-area {
  width: 100%;
  max-width: 320px;
  
  :deep(.el-upload-dragger) {
    padding: 2rem;
    border-radius: 10px;
    border: 1px dashed var(--border-primary);
    background: var(--card-bg);
    transition: all 0.15s ease;
    
    &:hover { border-color: var(--text-tertiary); }
  }
}

.upload-content {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 0.5rem;
  color: var(--text-tertiary);
  
  span { font-size: 0.8125rem; }
}

// 统计卡片网格
.stat-cards-grid {
  display: grid;
  grid-template-columns: repeat(12, 1fr);
  gap: 1rem;
  margin-bottom: 1.25rem;
}

// 统计卡片包装器（支持悬浮操作按钮）
.stat-card-wrapper {
  position: relative;
  
  &:hover .stat-card-overlay {
    opacity: 1;
    pointer-events: auto;
  }
}

// 悬浮操作层
.stat-card-overlay {
  position: absolute;
  top: 8px;
  right: 8px;
  display: flex;
  gap: 4px;
  opacity: 0;
  pointer-events: none;
  transition: opacity 0.2s ease;
  z-index: 10;
}

.overlay-btn {
  width: 28px;
  height: 28px;
  border-radius: 6px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: var(--card-bg);
  border: 1px solid var(--border-secondary);
  color: var(--text-secondary);
  transition: all 0.15s ease;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  
  &:hover {
    background: var(--bg-tertiary);
    color: var(--text-primary);
    border-color: var(--border-hover);
  }
  
  &--danger:hover {
    background: rgba(239, 68, 68, 0.1);
    color: #ef4444;
    border-color: rgba(239, 68, 68, 0.3);
  }
}

// 向后兼容旧的 stat-card 样式
.stat-card {
  background: var(--card-bg);
  border: 1px solid var(--border-secondary);
  border-radius: 10px;
  padding: 1rem 1.25rem;
  transition: all 0.15s ease;
  
  &:hover { box-shadow: var(--shadow-sm); }
}

.stat-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 0.75rem;
}

.stat-title {
  font-size: 0.75rem;
  font-weight: 500;
  color: var(--text-tertiary);
  text-transform: uppercase;
  letter-spacing: 0.5px;
}

.stat-actions {
  display: flex;
  gap: 0.25rem;
  opacity: 0;
  transition: opacity 0.15s ease;
  
  .stat-card:hover & { opacity: 1; }
  
  button {
    width: 24px;
    height: 24px;
    border-radius: 4px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: var(--text-tertiary);
    
    &:hover { background: var(--bg-tertiary); color: var(--text-primary); }
  }
}

.stat-value {
  font-size: 2rem;
  font-weight: 700;
  line-height: 1.2;
  margin-bottom: 0.25rem;
}

.stat-meta {
  font-size: 0.6875rem;
  color: var(--text-tertiary);
}

// 图表网格
.charts-grid {
  display: grid;
  grid-template-columns: repeat(12, 1fr);
  gap: 1rem;
}

.chart-card {
  background: var(--card-bg);
  border: 1px solid var(--border-secondary);
  border-radius: 10px;
  overflow: hidden;
  transition: all 0.15s ease;
  
  &:hover { box-shadow: var(--shadow-sm); }
}

.chart-toolbar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0.625rem 1rem;
  border-bottom: 1px solid var(--border-secondary);
}

.chart-title {
  font-size: 0.8125rem;
  font-weight: 500;
  color: var(--text-primary);
}

.chart-actions {
  display: flex;
  gap: 0.25rem;
  opacity: 0;
  transition: opacity 0.15s ease;
  
  .chart-card:hover & { opacity: 1; }
  
  button {
    width: 28px;
    height: 28px;
    border-radius: 6px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: var(--text-tertiary);
    transition: all 0.15s ease;
    
    &:hover { background: var(--bg-tertiary); color: var(--text-primary); }
  }
}

.chart-container {
  padding: 0.75rem;
}

// 配置表单
.config-form {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

.form-row {
  display: flex;
  gap: 0.75rem;
}

.form-field {
  flex: 1;
  
  &.small { flex: 0 0 auto; text-align: center; }
  &.flex-1 { flex: 2; }
  
  label {
    display: block;
    font-size: 0.75rem;
    font-weight: 500;
    color: var(--text-secondary);
    margin-bottom: 0.375rem;
  }
  
  .el-select, .el-input { width: 100%; }
}

.form-section-title {
  font-size: 0.8125rem;
  font-weight: 600;
  color: var(--text-primary);
  margin-top: 0.5rem;
  margin-bottom: 0.75rem;
  padding-bottom: 0.5rem;
  border-bottom: 1px solid var(--border-secondary);
}

.filter-section {
  background: var(--bg-tertiary);
  border-radius: 8px;
  padding: 0.75rem;
}

.filter-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 0.75rem;
  
  span {
    font-size: 0.8125rem;
    font-weight: 500;
    color: var(--text-primary);
  }
}

.filter-row {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  margin-bottom: 0.5rem;
  
  &:last-child { margin-bottom: 0; }
}

// 保存表单
.save-form {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

.form-tip {
  display: flex;
  align-items: center;
  gap: 0.375rem;
  font-size: 0.75rem;
  color: var(--text-tertiary);
  padding: 0.625rem 0.75rem;
  background: var(--bg-tertiary);
  border-radius: 6px;
}

// 看板列表
.loading-state, .empty-dashboards {
  padding: 2rem;
  text-align: center;
  color: var(--text-tertiary);
}

.dashboard-list {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}

.dashboard-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0.875rem 1rem;
  background: var(--bg-tertiary);
  border-radius: 8px;
  
  .info {
    display: flex;
    flex-direction: column;
    gap: 0.125rem;
  }
  
  .name {
    font-size: 0.875rem;
    font-weight: 500;
    color: var(--text-primary);
  }
  
  .meta {
    font-size: 0.6875rem;
    color: var(--text-tertiary);
  }
  
  .actions {
    display: flex;
    gap: 0.375rem;
  }
}

// 表单 hint
.hint {
  font-size: 0.625rem;
  color: var(--text-tertiary);
  font-weight: 400;
}

// 下钻内容
.drill-down-content {
  min-height: 200px;
}

.drill-down-info {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 0.75rem;
  font-size: 0.8125rem;
  color: var(--text-secondary);
}

.drill-down-table {
  border-radius: 8px;
  overflow: hidden;
  border: 1px solid var(--border-secondary);
  
  :deep(.el-table) {
    --el-table-border-color: var(--border-secondary);
    --el-table-header-bg-color: var(--bg-tertiary);
    --el-table-tr-bg-color: var(--card-bg);
    --el-table-row-hover-bg-color: var(--bg-tertiary);
    --el-table-text-color: var(--text-primary);
    --el-table-header-text-color: var(--text-secondary);
    background-color: var(--card-bg) !important;
    
    th.el-table__cell {
      font-weight: 500;
      font-size: 0.75rem;
      background: var(--bg-tertiary) !important;
      color: var(--text-secondary) !important;
    }
    
    td.el-table__cell {
      font-size: 0.75rem;
      color: var(--text-primary) !important;
    }
    
    .el-table__body-wrapper {
      background: var(--card-bg) !important;
    }
  }
}

.drill-down-pagination {
  display: flex;
  justify-content: center;
  margin-top: 1rem;
  
  :deep(.el-pagination) {
    --el-pagination-bg-color: transparent;
    --el-pagination-button-bg-color: var(--card-bg);
    --el-pagination-hover-color: var(--accent);
    
    .el-pagination__total,
    .el-pagination__goto,
    .el-pagination__classifier {
      color: var(--text-secondary);
    }
    
    .el-input__wrapper {
      background: var(--input-bg) !important;
      border-color: var(--input-border) !important;
      box-shadow: none !important;
    }
    
    .el-input__inner {
      color: var(--text-primary) !important;
    }
  }
}

// 配置表单弹窗样式修复
:deep(.el-dialog) {
  .el-dialog__header {
    background: var(--bg-tertiary);
    border-bottom: 1px solid var(--border-secondary);
  }
  
  .el-dialog__body {
    background: var(--card-bg);
  }
  
  .el-dialog__footer {
    background: var(--card-bg);
    border-top: 1px solid var(--border-secondary);
  }
}

// 选择框样式修复
:deep(.el-select) {
  .el-select__wrapper {
    background: var(--input-bg) !important;
    border: 1px solid var(--input-border) !important;
    box-shadow: none !important;
    
    &:hover {
      border-color: var(--border-hover) !important;
    }
    
    &.is-focused {
      border-color: var(--accent) !important;
    }
  }
  
  .el-select__selected-item {
    color: var(--text-primary) !important;
  }
  
  .el-select__placeholder {
    color: var(--text-tertiary) !important;
  }
}

// 输入框样式修复
:deep(.el-input) {
  .el-input__wrapper {
    background: var(--input-bg) !important;
    border: 1px solid var(--input-border) !important;
    box-shadow: none !important;
    
    &:hover {
      border-color: var(--border-hover) !important;
    }
    
    &.is-focus {
      border-color: var(--accent) !important;
    }
  }
  
  .el-input__inner {
    color: var(--text-primary) !important;
    
    &::placeholder {
      color: var(--text-tertiary) !important;
    }
  }
}

// 数字输入框样式修复
:deep(.el-input-number) {
  .el-input-number__decrease,
  .el-input-number__increase {
    background: var(--bg-tertiary) !important;
    border-color: var(--input-border) !important;
    color: var(--text-secondary) !important;
    
    &:hover {
      color: var(--text-primary) !important;
    }
  }
}

// 滑块样式修复
:deep(.el-slider) {
  .el-slider__runway {
    background: var(--bg-tertiary) !important;
  }
}

// 开关样式修复
:deep(.el-switch) {
  .el-switch__core {
    background: var(--border-primary) !important;
    border-color: var(--border-primary) !important;
  }
  
  &.is-checked .el-switch__core {
    background: var(--accent) !important;
    border-color: var(--accent) !important;
  }
}

// 颜色选择器样式修复
:deep(.el-color-picker) {
  .el-color-picker__trigger {
    border-color: var(--input-border) !important;
  }
}

// 响应式
@media (max-width: 1024px) {
  .charts-grid, .stat-cards-grid { grid-template-columns: repeat(6, 1fr); }
  .chart-card, .stat-card { grid-column: span 6 !important; }
}

@media (max-width: 768px) {
  .dashboard-header { flex-direction: column; gap: 0.75rem; align-items: flex-start; }
  .header-actions { width: 100%; flex-wrap: wrap; }
  .form-row { flex-direction: column; }
  .stat-card { grid-column: span 12 !important; }
}
</style>
