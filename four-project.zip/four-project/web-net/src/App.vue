<script setup>
import { onMounted, watch } from 'vue'
import { useStore } from 'vuex'
import MainLayout from '@/components/layout/MainLayout.vue'
import { ElMessage } from 'element-plus'

const store = useStore()

// 监听消息
watch(() => store.state.message, (message) => {
  if (message) {
    ElMessage({
      message: message.text,
      type: message.type,
      duration: 3000,
      customClass: 'custom-message'
    })
    store.commit('SET_MESSAGE', null)
  }
})

onMounted(async () => {
  // 初始化主题
  store.dispatch('initTheme')
  
  // 初始化用户
  await store.dispatch('initUser')
  
  // 获取首页数据
  store.dispatch('fetchHomeData')
  
  // 获取工作台数据
  store.dispatch('fetchWorkspace')
})
</script>

<template>
  <MainLayout>
    <router-view v-slot="{ Component, route }">
      <transition name="page" mode="out-in">
        <component :is="Component" :key="route.path" />
      </transition>
    </router-view>
  </MainLayout>
</template>

<style scoped>
.page-enter-active,
.page-leave-active {
  transition: opacity 0.25s ease, transform 0.25s ease;
}

.page-enter-from {
  opacity: 0;
  transform: translateY(8px);
}

.page-leave-to {
  opacity: 0;
  transform: translateY(-8px);
}
</style>

<style>
/* 全局Element Plus样式覆盖 */
.custom-message {
  border-radius: 12px !important;
  padding: 12px 16px !important;
}
</style>
