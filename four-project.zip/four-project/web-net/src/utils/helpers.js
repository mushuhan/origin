/**
 * 防抖函数
 * @param {Function} fn 要执行的函数
 * @param {number} delay 延迟时间（毫秒）
 * @returns {Function}
 */
export function debounce(fn, delay = 300) {
  let timer = null
  return function (...args) {
    if (timer) clearTimeout(timer)
    timer = setTimeout(() => {
      fn.apply(this, args)
    }, delay)
  }
}

/**
 * 节流函数
 * @param {Function} fn 要执行的函数
 * @param {number} limit 时间间隔（毫秒）
 * @returns {Function}
 */
export function throttle(fn, limit = 300) {
  let lastTime = 0
  return function (...args) {
    const now = Date.now()
    if (now - lastTime >= limit) {
      lastTime = now
      fn.apply(this, args)
    }
  }
}

/**
 * 深拷贝
 * @param {any} obj 要拷贝的对象
 * @returns {any}
 */
export function deepClone(obj) {
  if (obj === null || typeof obj !== 'object') {
    return obj
  }
  
  if (Array.isArray(obj)) {
    return obj.map(item => deepClone(item))
  }
  
  const cloned = {}
  for (const key in obj) {
    if (Object.prototype.hasOwnProperty.call(obj, key)) {
      cloned[key] = deepClone(obj[key])
    }
  }
  return cloned
}

/**
 * 格式化数字（添加千分位）
 * @param {number} num 数字
 * @returns {string}
 */
export function formatNumber(num) {
  if (num === null || num === undefined) return '0'
  return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')
}

/**
 * 格式化日期
 * @param {Date|string|number} date 日期
 * @param {string} format 格式
 * @returns {string}
 */
export function formatDate(date, format = 'YYYY-MM-DD') {
  const d = new Date(date)
  if (isNaN(d.getTime())) return ''
  
  const year = d.getFullYear()
  const month = String(d.getMonth() + 1).padStart(2, '0')
  const day = String(d.getDate()).padStart(2, '0')
  const hours = String(d.getHours()).padStart(2, '0')
  const minutes = String(d.getMinutes()).padStart(2, '0')
  const seconds = String(d.getSeconds()).padStart(2, '0')
  
  return format
    .replace('YYYY', year)
    .replace('MM', month)
    .replace('DD', day)
    .replace('HH', hours)
    .replace('mm', minutes)
    .replace('ss', seconds)
}

/**
 * 生成UUID
 * @returns {string}
 */
export function generateUUID() {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
    const r = Math.random() * 16 | 0
    const v = c === 'x' ? r : (r & 0x3 | 0x8)
    return v.toString(16)
  })
}

/**
 * 提取URL的域名
 * @param {string} url URL地址
 * @returns {string}
 */
export function extractDomain(url) {
  try {
    const u = new URL(url)
    return u.hostname
  } catch {
    return url
  }
}

/**
 * 检测是否为移动设备
 * @returns {boolean}
 */
export function isMobile() {
  return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)
}

/**
 * 复制文本到剪贴板
 * @param {string} text 要复制的文本
 * @returns {Promise<void>}
 */
export async function copyToClipboard(text) {
  if (navigator.clipboard) {
    await navigator.clipboard.writeText(text)
  } else {
    const textarea = document.createElement('textarea')
    textarea.value = text
    textarea.style.position = 'fixed'
    textarea.style.opacity = '0'
    document.body.appendChild(textarea)
    textarea.select()
    document.execCommand('copy')
    document.body.removeChild(textarea)
  }
}

/**
 * 获取相对时间描述
 * @param {Date|string|number} date 日期
 * @returns {string}
 */
export function getRelativeTime(date) {
  const now = new Date()
  const d = new Date(date)
  const diff = now - d
  
  const minute = 60 * 1000
  const hour = 60 * minute
  const day = 24 * hour
  const week = 7 * day
  const month = 30 * day
  const year = 365 * day
  
  if (diff < minute) {
    return '刚刚'
  } else if (diff < hour) {
    return Math.floor(diff / minute) + ' 分钟前'
  } else if (diff < day) {
    return Math.floor(diff / hour) + ' 小时前'
  } else if (diff < week) {
    return Math.floor(diff / day) + ' 天前'
  } else if (diff < month) {
    return Math.floor(diff / week) + ' 周前'
  } else if (diff < year) {
    return Math.floor(diff / month) + ' 个月前'
  } else {
    return Math.floor(diff / year) + ' 年前'
  }
}

/**
 * 树形数据扁平化
 * @param {Array} tree 树形数据
 * @param {string} childrenKey 子节点字段名
 * @returns {Array}
 */
export function flattenTree(tree, childrenKey = 'children') {
  const result = []
  
  function traverse(nodes, level = 0, parentId = null) {
    for (const node of nodes) {
      const { [childrenKey]: children, ...rest } = node
      result.push({ ...rest, level, parentId })
      if (children && children.length > 0) {
        traverse(children, level + 1, node.id)
      }
    }
  }
  
  traverse(tree)
  return result
}

/**
 * 扁平数据转树形
 * @param {Array} flat 扁平数据
 * @param {string} idKey ID字段名
 * @param {string} parentKey 父ID字段名
 * @param {string} childrenKey 子节点字段名
 * @returns {Array}
 */
export function buildTree(flat, idKey = 'id', parentKey = 'parentId', childrenKey = 'children') {
  const map = new Map()
  const roots = []
  
  // 创建映射
  for (const item of flat) {
    map.set(item[idKey], { ...item, [childrenKey]: [] })
  }
  
  // 构建树
  for (const item of flat) {
    const node = map.get(item[idKey])
    const parentId = item[parentKey]
    
    if (parentId === null || parentId === undefined) {
      roots.push(node)
    } else {
      const parent = map.get(parentId)
      if (parent) {
        parent[childrenKey].push(node)
      } else {
        roots.push(node)
      }
    }
  }
  
  return roots
}

// ==================== 智能快捷访问 - 本地访问记录 ====================

const QUICK_ACCESS_KEY = 'nav_quick_access_data'
const MAX_TRACKED_SITES = 50 // 最多跟踪的网站数量

// 自定义事件名
const QUICK_ACCESS_UPDATE_EVENT = 'quick-access-updated'

/**
 * 触发快捷访问更新事件
 */
function emitQuickAccessUpdate() {
  window.dispatchEvent(new CustomEvent(QUICK_ACCESS_UPDATE_EVENT))
}

/**
 * 监听快捷访问更新事件
 * @param {Function} callback 回调函数
 * @returns {Function} 取消监听的函数
 */
export function onQuickAccessUpdate(callback) {
  window.addEventListener(QUICK_ACCESS_UPDATE_EVENT, callback)
  return () => window.removeEventListener(QUICK_ACCESS_UPDATE_EVENT, callback)
}

/**
 * 获取快捷访问数据
 * @returns {Object} { [websiteId]: { website, clickCount, lastVisit } }
 */
export function getQuickAccessData() {
  try {
    const data = localStorage.getItem(QUICK_ACCESS_KEY)
    return data ? JSON.parse(data) : {}
  } catch {
    return {}
  }
}

/**
 * 记录网站访问（增加权重）
 * @param {Object} website 网站对象 { id, name, url, icon, description, ... }
 */
export function trackWebsiteVisit(website) {
  if (!website) return
  
  // 兼容不同数据源：优先使用 website_id（来自工作台），否则使用 id
  const siteId = website.website_id || website.id
  if (!siteId) {
    console.warn('trackWebsiteVisit: 无法获取网站ID', website)
    return
  }
  
  // 提取网站信息，兼容多种数据结构
  const siteName = website.custom_name || website.name || '未知'
  const siteUrl = website.custom_url || website.url || ''
  const siteIcon = website.custom_icon || website.icon || ''
  const siteDesc = website.custom_description || website.description || ''
  
  const data = getQuickAccessData()
  const now = Date.now()
  
  // 使用统一的 key（基于原始网站ID或自定义唯一标识）
  const key = String(siteId)
  
  if (data[key]) {
    // 已存在，增加计数
    data[key].clickCount += 1
    data[key].lastVisit = now
    // 更新网站信息（可能有变化）
    data[key].website = {
      id: siteId,
      name: siteName,
      url: siteUrl,
      icon: siteIcon,
      description: siteDesc
    }
  } else {
    // 新增
    data[key] = {
      website: {
        id: siteId,
        name: siteName,
        url: siteUrl,
        icon: siteIcon,
        description: siteDesc
      },
      clickCount: 1,
      lastVisit: now
    }
  }
  
  // 保存数据
  try {
    // 限制存储数量：只保留点击量最高的 MAX_TRACKED_SITES 个
    const entries = Object.entries(data)
    if (entries.length > MAX_TRACKED_SITES) {
      entries.sort((a, b) => b[1].clickCount - a[1].clickCount)
      const trimmed = Object.fromEntries(entries.slice(0, MAX_TRACKED_SITES))
      localStorage.setItem(QUICK_ACCESS_KEY, JSON.stringify(trimmed))
    } else {
      localStorage.setItem(QUICK_ACCESS_KEY, JSON.stringify(data))
    }
    
    // 触发更新事件，通知组件刷新
    emitQuickAccessUpdate()
  } catch (e) {
    console.error('trackWebsiteVisit: 保存失败', e)
  }
}

/**
 * 获取热门访问网站列表（按权重排序）
 * @param {number} limit 返回数量
 * @returns {Array} [{ website, clickCount, lastVisit }, ...]
 */
export function getFrequentlyVisited(limit = 6) {
  const data = getQuickAccessData()
  
  return Object.values(data)
    .sort((a, b) => {
      // 综合权重：点击次数 * 0.7 + 时间新鲜度 * 0.3
      const now = Date.now()
      const dayInMs = 24 * 60 * 60 * 1000
      
      const aTimeScore = Math.max(0, 1 - (now - a.lastVisit) / (30 * dayInMs)) // 30天内的时间衰减
      const bTimeScore = Math.max(0, 1 - (now - b.lastVisit) / (30 * dayInMs))
      
      const aScore = a.clickCount * 0.7 + aTimeScore * 10 * 0.3
      const bScore = b.clickCount * 0.7 + bTimeScore * 10 * 0.3
      
      return bScore - aScore
    })
    .slice(0, limit)
}

/**
 * 获取最近访问网站列表（按时间排序）
 * @param {number} limit 返回数量
 * @returns {Array}
 */
export function getRecentlyVisited(limit = 6) {
  const data = getQuickAccessData()
  
  return Object.values(data)
    .sort((a, b) => b.lastVisit - a.lastVisit)
    .slice(0, limit)
}

/**
 * 清除快捷访问数据
 */
export function clearQuickAccessData() {
  localStorage.removeItem(QUICK_ACCESS_KEY)
}

