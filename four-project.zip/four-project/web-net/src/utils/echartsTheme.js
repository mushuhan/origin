/**
 * ECharts 自定义主题配置
 * 支持亮色/暗色模式一键切换
 */
import * as echarts from 'echarts'

// 亮色主题配色
const lightColors = [
  '#374151', '#6366f1', '#22c55e', '#f59e0b', '#ef4444',
  '#8b5cf6', '#06b6d4', '#ec4899', '#84cc16', '#f97316'
]

// 暗色主题配色（更明亮）
const darkColors = [
  '#e5e7eb', '#818cf8', '#4ade80', '#fbbf24', '#f87171',
  '#a78bfa', '#22d3ee', '#f472b6', '#a3e635', '#fb923c'
]

// 亮色主题
export const lightTheme = {
  color: lightColors,
  backgroundColor: 'transparent',
  textStyle: {
    color: '#374151'
  },
  title: {
    textStyle: {
      color: '#1f2937',
      fontWeight: 600
    },
    subtextStyle: {
      color: '#6b7280'
    }
  },
  legend: {
    textStyle: {
      color: '#6b7280'
    }
  },
  tooltip: {
    backgroundColor: 'rgba(255, 255, 255, 0.98)',
    borderColor: '#e5e7eb',
    textStyle: {
      color: '#374151'
    },
    extraCssText: 'box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);'
  },
  axisPointer: {
    lineStyle: {
      color: '#9ca3af'
    },
    crossStyle: {
      color: '#9ca3af'
    }
  },
  categoryAxis: {
    axisLine: {
      lineStyle: {
        color: '#e5e7eb'
      }
    },
    axisTick: {
      lineStyle: {
        color: '#e5e7eb'
      }
    },
    axisLabel: {
      color: '#6b7280'
    },
    splitLine: {
      lineStyle: {
        color: '#f3f4f6'
      }
    }
  },
  valueAxis: {
    axisLine: {
      show: false
    },
    axisTick: {
      show: false
    },
    axisLabel: {
      color: '#6b7280'
    },
    splitLine: {
      lineStyle: {
        color: '#f3f4f6'
      }
    }
  },
  line: {
    symbol: 'circle',
    symbolSize: 5,
    lineStyle: {
      width: 2
    }
  },
  bar: {
    itemStyle: {
      borderRadius: [3, 3, 0, 0]
    }
  },
  pie: {
    itemStyle: {
      borderColor: '#fff',
      borderWidth: 2
    }
  },
  radar: {
    splitArea: {
      areaStyle: {
        color: ['#fafafa', '#f5f5f5']
      }
    },
    axisName: {
      color: '#6b7280'
    }
  },
  gauge: {
    axisLine: {
      lineStyle: {
        color: [[1, '#d1d5db']]
      }
    }
  }
}

// 暗色主题
export const darkTheme = {
  color: darkColors,
  backgroundColor: 'transparent',
  textStyle: {
    color: '#e5e5e5'
  },
  title: {
    textStyle: {
      color: '#f5f5f5',
      fontWeight: 600
    },
    subtextStyle: {
      color: '#a3a3a3'
    }
  },
  legend: {
    textStyle: {
      color: '#a3a3a3'
    }
  },
  tooltip: {
    backgroundColor: 'rgba(0, 0, 0, 0.9)',
    borderColor: '#404040',
    textStyle: {
      color: '#e5e5e5'
    },
    extraCssText: 'box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);'
  },
  axisPointer: {
    lineStyle: {
      color: '#525252'
    },
    crossStyle: {
      color: '#525252'
    }
  },
  categoryAxis: {
    axisLine: {
      lineStyle: {
        color: '#404040'
      }
    },
    axisTick: {
      lineStyle: {
        color: '#404040'
      }
    },
    axisLabel: {
      color: '#a3a3a3'
    },
    splitLine: {
      lineStyle: {
        color: '#262626'
      }
    }
  },
  valueAxis: {
    axisLine: {
      show: false
    },
    axisTick: {
      show: false
    },
    axisLabel: {
      color: '#a3a3a3'
    },
    splitLine: {
      lineStyle: {
        color: '#262626'
      }
    }
  },
  line: {
    symbol: 'circle',
    symbolSize: 5,
    lineStyle: {
      width: 2
    }
  },
  bar: {
    itemStyle: {
      borderRadius: [3, 3, 0, 0]
    }
  },
  pie: {
    itemStyle: {
      borderColor: '#1f2937',
      borderWidth: 2
    }
  },
  radar: {
    splitArea: {
      areaStyle: {
        color: ['#262626', '#171717']
      }
    },
    axisName: {
      color: '#a3a3a3'
    }
  },
  gauge: {
    axisLine: {
      lineStyle: {
        color: [[1, '#4b5563']]
      }
    }
  }
}

// 注册主题
export function registerThemes() {
  echarts.registerTheme('custom-light', lightTheme)
  echarts.registerTheme('custom-dark', darkTheme)
}

// 获取当前应该使用的主题名称
export function getCurrentThemeName() {
  return document.documentElement.classList.contains('dark') ? 'custom-dark' : 'custom-light'
}

// 初始化图表（自动选择主题）
export function initChart(container, options = {}) {
  const themeName = getCurrentThemeName()
  return echarts.init(container, themeName, {
    renderer: 'canvas',
    useDirtyRect: false,
    ...options
  })
}

// 主题切换 Hook（Vue Composable）
export function useEChartsTheme() {
  const isDark = () => document.documentElement.classList.contains('dark')
  
  const getTheme = () => isDark() ? 'custom-dark' : 'custom-light'
  
  const refreshChart = (chartInstance) => {
    if (!chartInstance) return
    
    const option = chartInstance.getOption()
    const container = chartInstance.getDom()
    
    chartInstance.dispose()
    
    const newInstance = echarts.init(container, getTheme())
    newInstance.setOption(option)
    
    return newInstance
  }
  
  return {
    isDark,
    getTheme,
    refreshChart
  }
}

export default {
  lightTheme,
  darkTheme,
  registerThemes,
  getCurrentThemeName,
  initChart,
  useEChartsTheme
}

