import { createRouter, createWebHistory } from 'vue-router'
import store from '@/store'
import { hasAdminToken } from '@/api/admin'

const routes = [
  // ==================== 前台路由 ====================
  {
    path: '/',
    name: 'Home',
    component: () => import('@/views/Home.vue'),
    meta: { title: '首页' }
  },
  {
    path: '/category/:id',
    name: 'Category',
    component: () => import('@/views/Category.vue'),
    meta: { title: '分类详情' }
  },
  {
    path: '/customize',
    name: 'Customize',
    component: () => import('@/views/Customize.vue'),
    meta: { title: '我的工作台' }
  },
  {
    path: '/hot',
    name: 'Hot',
    component: () => import('@/views/Hot.vue'),
    meta: { title: '热门网址' }
  },
  {
    path: '/about',
    name: 'About',
    component: () => import('@/views/About.vue'),
    meta: { title: '关于' }
  },
  {
    path: '/dashboard',
    name: 'Dashboard',
    component: () => import('@/views/Dashboard.vue'),
    meta: { title: '看板生成器' }
  },
  {
    path: '/department/:id',
    name: 'Department',
    component: () => import('@/views/Department.vue'),
    meta: { title: '科室详情' }
  },
  
  // ==================== 管理后台路由 ====================
  {
    path: '/admin/login',
    name: 'AdminLogin',
    component: () => import('@/views/admin/AdminLogin.vue'),
    meta: { 
      title: '管理员登录',
      isAdminAuth: true  // 标记为管理员认证页面
    }
  },
  {
    path: '/auth/callback',
    name: 'AuthCallback',
    component: () => import('@/views/admin/AuthCallback.vue'),
    meta: { 
      title: 'OAuth 回调',
      isAdminAuth: true
    }
  },
  {
    path: '/admin',
    component: () => import('@/components/layout/AdminLayout.vue'),
    meta: { 
      requiresAdmin: true,  // 标记需要管理员权限
      title: '管理后台'
    },
    children: [
      {
        path: '',
        name: 'AdminDashboard',
        component: () => import('@/views/admin/AdminDashboard.vue'),
        meta: { title: '仪表盘' }
      },
      {
        path: 'users',
        name: 'UserManage',
        component: () => import('@/views/admin/UserManage.vue'),
        meta: { title: '用户管理' }
      },
      {
        path: 'import',
        name: 'DataImport',
        component: () => import('@/views/admin/DataImport.vue'),
        meta: { title: '数据导入' }
      },
      {
        path: 'settings',
        name: 'AdminSettings',
        component: () => import('@/views/admin/AdminSettings.vue'),
        meta: { title: '系统设置' }
      }
    ]
  },
  
  // ==================== 404 页面 ====================
  {
    path: '/:pathMatch(.*)*',
    name: 'NotFound',
    component: () => import('@/views/NotFound.vue'),
    meta: { title: '页面未找到' }
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes,
  scrollBehavior(to, from, savedPosition) {
    if (savedPosition) {
      return savedPosition
    } else {
      return { top: 0 }
    }
  }
})

// ==================== 路由守卫 ====================

// 路由守卫 - 权限检查
router.beforeEach(async (to, from, next) => {
  // 设置页面标题
  const title = to.meta.title || 'NavHub'
  document.title = `${title} - NavHub`
  
  // 检查是否需要管理员权限
  const requiresAdmin = to.matched.some(record => record.meta.requiresAdmin)
  const isAdminAuth = to.matched.some(record => record.meta.isAdminAuth)
  
  // 如果是管理员认证页面（登录/回调），直接放行
  if (isAdminAuth) {
    // 如果已登录且尝试访问登录页，重定向到后台首页
    if (hasAdminToken() && to.name === 'AdminLogin') {
      try {
        // 验证 token 是否有效
        const isValid = await store.dispatch('admin/initAuth')
        if (isValid && store.getters['admin/isAdmin']) {
          return next({ name: 'AdminDashboard' })
        }
      } catch (e) {
        // token 无效，继续到登录页
      }
    }
    return next()
  }
  
  // 如果需要管理员权限
  if (requiresAdmin) {
    // 检查是否有 Token
    if (!hasAdminToken()) {
      return next({ 
        name: 'AdminLogin', 
        query: { redirect: to.fullPath } 
      })
    }
    
    // 验证 Token 并获取用户信息
    try {
      const isValid = await store.dispatch('admin/initAuth')
      
      if (!isValid) {
        return next({ 
          name: 'AdminLogin', 
          query: { redirect: to.fullPath } 
        })
      }
      
      // 验证是否是管理员
      if (!store.getters['admin/isAdmin']) {
        // 不是管理员，跳转到无权限提示或登录页
        return next({ 
          name: 'AdminLogin', 
          query: { error: 'no_permission' } 
        })
      }
      
      return next()
    } catch (error) {
      console.error('管理员认证失败:', error)
      return next({ 
        name: 'AdminLogin', 
        query: { redirect: to.fullPath } 
      })
    }
  }
  
  // 其他页面直接放行
  next()
})

export default router
