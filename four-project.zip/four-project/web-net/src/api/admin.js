/**
 * 管理员 API 模块
 * 
 * 包含认证和后台管理相关的所有 API 接口
 * 所有管理员接口都需要携带 JWT Token
 */
import axios from 'axios'

// ==================== Token 管理 ====================

const ADMIN_TOKEN_KEY = 'admin_auth_token'

/**
 * 获取管理员 Token
 */
export function getAdminToken() {
  return localStorage.getItem(ADMIN_TOKEN_KEY)
}

/**
 * 保存管理员 Token
 */
export function setAdminToken(token) {
  localStorage.setItem(ADMIN_TOKEN_KEY, token)
}

/**
 * 清除管理员 Token
 */
export function clearAdminToken() {
  localStorage.removeItem(ADMIN_TOKEN_KEY)
}

/**
 * 检查是否有管理员 Token
 */
export function hasAdminToken() {
  return !!getAdminToken()
}

// ==================== Axios 实例 ====================

const adminApi = axios.create({
  baseURL: '/api',
  timeout: 15000,
  headers: {
    'Content-Type': 'application/json'
  }
})

// 请求拦截器 - 自动添加 JWT Token
adminApi.interceptors.request.use(
  config => {
    const token = getAdminToken()
    if (token) {
      config.headers['Authorization'] = `Bearer ${token}`
    }
    return config
  },
  error => Promise.reject(error)
)

// 响应拦截器
adminApi.interceptors.response.use(
  response => {
    const { data } = response
    if (data.code === 200 || data.code === 201) {
      return data.data
    }
    return Promise.reject(new Error(data.message || '请求失败'))
  },
  error => {
    // 401 错误自动清除 Token 并跳转登录
    if (error.response?.status === 401) {
      clearAdminToken()
      // 触发登出事件，让 store 处理
      window.dispatchEvent(new CustomEvent('admin-unauthorized'))
    }
    
    const message = error.response?.data?.message || error.message || '网络错误'
    return Promise.reject(new Error(message))
  }
)

// ==================== 认证相关 API ====================

/**
 * 获取认证模式
 * @returns {Promise<{mode: string, oauth_url?: string}>}
 */
export const getAuthMode = () => adminApi.get('/auth/mode')

/**
 * 账号密码登录（DEV 模式）
 * @param {string} email 
 * @param {string} password 
 */
export const login = (email, password) => 
  adminApi.post('/auth/login', { email, password })

/**
 * 注册账号（DEV 模式）
 * @param {string} email 
 * @param {string} password 
 * @param {string} name 
 */
export const register = (email, password, name) => 
  adminApi.post('/auth/register', { email, password, name })

/**
 * OAuth 回调处理（PROD 模式）
 * @param {string} code 授权码
 * @param {string} state CSRF 状态值
 */
export const oauthCallback = (code, state) => 
  adminApi.post('/auth/callback', { code, state })

/**
 * 获取当前登录用户信息
 */
export const getCurrentUser = () => adminApi.get('/auth/me')

/**
 * 刷新 Token
 */
export const refreshToken = () => adminApi.post('/auth/refresh')

/**
 * 登出
 */
export const logout = () => {
  clearAdminToken()
  return adminApi.post('/auth/logout')
}

/**
 * 重置用户密码（管理员操作）
 * @param {string} userUuid 
 * @param {string} newPassword 
 */
export const resetUserPassword = (userUuid, newPassword) => 
  adminApi.post(`/auth/reset-password/${userUuid}`, { new_password: newPassword })

// ==================== Dashboard 统计 API ====================

/**
 * 获取 Dashboard 统计数据
 */
export const getDashboardStats = () => adminApi.get('/admin/stats')

/**
 * 获取用户增长趋势
 * @param {number} days 天数（默认30）
 */
export const getUserTrends = (days = 30) => 
  adminApi.get('/admin/stats/trends', { params: { days } })

// ==================== 用户管理 API ====================

/**
 * 获取用户列表
 * @param {Object} params 查询参数
 * @param {number} params.page 页码
 * @param {number} params.per_page 每页数量
 * @param {string} params.search 搜索关键词
 * @param {string} params.role 角色筛选 (user/admin/all)
 * @param {string} params.status 状态筛选 (active/inactive/all)
 * @param {string} params.sort 排序字段
 * @param {string} params.order 排序方向 (asc/desc)
 */
export const getUsers = (params = {}) => 
  adminApi.get('/admin/users', { params })

/**
 * 获取单个用户详情
 * @param {string} userUuid 
 */
export const getUser = (userUuid) => adminApi.get(`/admin/users/${userUuid}`)

/**
 * 创建用户
 * @param {Object} data 用户数据
 */
export const createUser = (data) => adminApi.post('/admin/users', data)

/**
 * 更新用户信息
 * @param {string} userUuid 
 * @param {Object} data 
 */
export const updateUser = (userUuid, data) => 
  adminApi.put(`/admin/users/${userUuid}`, data)

/**
 * 删除用户
 * @param {string} userUuid 
 */
export const deleteUser = (userUuid) => 
  adminApi.delete(`/admin/users/${userUuid}`)

/**
 * 设置用户角色
 * @param {string} userUuid 
 * @param {string} role 'user' | 'admin'
 */
export const setUserRole = (userUuid, role) => 
  adminApi.put(`/admin/users/${userUuid}/role`, { role })

/**
 * 切换用户账户状态
 * @param {string} userUuid 
 */
export const toggleUserStatus = (userUuid) => 
  adminApi.post(`/admin/users/${userUuid}/toggle-status`)

/**
 * 批量删除用户
 * @param {string[]} userUuids 
 */
export const batchDeleteUsers = (userUuids) => 
  adminApi.post('/admin/users/batch-delete', { user_uuids: userUuids })

/**
 * 批量设置用户角色
 * @param {string[]} userUuids 
 * @param {string} role 
 */
export const batchSetRole = (userUuids, role) => 
  adminApi.post('/admin/users/batch-set-role', { user_uuids: userUuids, role })

// ==================== Excel 导入 API ====================

/**
 * 下载导入模板
 */
export const downloadImportTemplate = () => 
  adminApi.get('/admin/import/template', { responseType: 'blob' })
    .then(blob => {
      // 创建下载链接
      const url = window.URL.createObjectURL(blob)
      const link = document.createElement('a')
      link.href = url
      link.download = 'user_import_template.xlsx'
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)
      window.URL.revokeObjectURL(url)
    })

/**
 * 从 Excel 导入用户
 * @param {File} file Excel 文件
 */
export const importUsersFromExcel = (file) => {
  const formData = new FormData()
  formData.append('file', file)
  return adminApi.post('/admin/import/excel', formData, {
    headers: { 'Content-Type': 'multipart/form-data' }
  })
}

export default adminApi

