import axios from 'axios'

// ==================== 用户Token管理 ====================

const USER_TOKEN_KEY = 'nav_user_token'

/**
 * 生成UUID v4
 */
function generateUUID() {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
    const r = Math.random() * 16 | 0
    const v = c === 'x' ? r : (r & 0x3 | 0x8)
    return v.toString(16)
  })
}

/**
 * 获取或创建用户Token
 */
export function getUserToken() {
  let token = localStorage.getItem(USER_TOKEN_KEY)
  
  if (!token) {
    token = generateUUID()
    localStorage.setItem(USER_TOKEN_KEY, token)
  }
  
  return token
}

/**
 * 清除用户Token（用于重置）
 */
export function clearUserToken() {
  localStorage.removeItem(USER_TOKEN_KEY)
}

// ==================== Axios实例配置 ====================

const api = axios.create({
  baseURL: '/api',
  timeout: 15000,
  headers: {
    'Content-Type': 'application/json'
  }
})

// 请求拦截器 - 自动添加用户Token
api.interceptors.request.use(
  config => {
    // 添加用户Token到请求头
    const token = getUserToken()
    if (token) {
      config.headers['X-User-Token'] = token
    }
    return config
  },
  error => {
    return Promise.reject(error)
  }
)

// 响应拦截器
api.interceptors.response.use(
  response => {
    const { data } = response
    if (data.code === 200 || data.code === 201) {
      return data.data
    }
    return Promise.reject(new Error(data.message || '请求失败'))
  },
  error => {
    console.error('API Error:', error)
    const message = error.response?.data?.message || error.message || '网络错误'
    return Promise.reject(new Error(message))
  }
)

// ==================== 首页数据API ====================

export const getHomeData = () => api.get('/home')

export const getSiteStats = () => api.get('/home/stats')

// ==================== 分类相关API ====================

export const getCategories = (includeSections = false) => 
  api.get('/categories', { params: { include_sections: includeSections } })

export const getCategory = (id) => api.get(`/categories/${id}`)

export const createCategory = (data) => api.post('/categories', data)

export const updateCategory = (id, data) => api.put(`/categories/${id}`, data)

export const deleteCategory = (id) => api.delete(`/categories/${id}`)

export const reorderCategories = (items) => api.put('/categories/batch-reorder', { items })

// ==================== 分区相关API ====================

export const getSections = (categoryId, includeWebsites = false) => 
  api.get('/sections', { 
    params: { 
      category_id: categoryId, 
      include_websites: includeWebsites 
    } 
  })

export const getSection = (id) => api.get(`/sections/${id}`)

export const createSection = (data) => api.post('/sections', data)

export const updateSection = (id, data) => api.put(`/sections/${id}`, data)

export const deleteSection = (id) => api.delete(`/sections/${id}`)

export const reorderSections = (items) => api.put('/sections/batch-reorder', { items })

// ==================== 网址相关API ====================

export const getWebsites = (params) => api.get('/websites', { params })

export const getHotWebsites = (limit = 20) => api.get('/websites/hot', { params: { limit } })

export const getWebsite = (id) => api.get(`/websites/${id}`)

export const createWebsite = (data) => api.post('/websites', data)

export const updateWebsite = (id, data) => api.put(`/websites/${id}`, data)

export const deleteWebsite = (id) => api.delete(`/websites/${id}`)

export const clickWebsite = (id) => api.post(`/websites/${id}/click`)

export const reorderWebsites = (items) => api.put('/websites/batch-reorder', { items })

// ==================== 工作台相关API ====================

export const getWorkspace = (folderId) => 
  api.get('/workspace', { params: { folder_id: folderId } })

export const getAllWorkspace = () => api.get('/workspace/all')

export const addToWorkspace = (data) => api.post('/workspace', data)

export const updateWorkspaceItem = (id, data) => api.put(`/workspace/${id}`, data)

export const removeFromWorkspace = (id) => api.delete(`/workspace/${id}`)

export const reorderWorkspace = (items) => api.put('/workspace/reorder', { items })

// ==================== 文件夹相关API ====================

/**
 * 获取文件夹列表
 * @param {boolean} flat - 是否扁平化列表
 * @param {boolean} includeSites - 是否包含网址
 * @param {string} category - 文件夹分类: 'sites'(网址) 或 'files'(数据文件)，不传则获取全部
 */
export const getFolders = (flat = false, includeSites = false, category = null) => 
  api.get('/folders', { params: { flat, include_sites: includeSites, category } })

export const getFolder = (id, includeSites = true) => 
  api.get(`/folders/${id}`, { params: { include_sites: includeSites } })

/**
 * 创建文件夹
 * @param {object} data - 文件夹数据 { name, parent_id?, category? }
 * category: 'sites'(网址文件夹) 或 'files'(数据文件文件夹)
 */
export const createFolder = (data) => api.post('/folders', data)

export const updateFolder = (id, data) => api.put(`/folders/${id}`, data)

export const deleteFolder = (id, moveToParent = false) => 
  api.delete(`/folders/${id}`, { params: { move_to_parent: moveToParent } })

export const reorderFolders = (items) => api.put('/folders/reorder', { items })

// ==================== 文件管理API ====================

export const getFileList = (folderId = null) => 
  api.get('/files', { params: { folder_id: folderId } })

export const getAllFiles = () => api.get('/files/all')

export const uploadFile = (file, folderId = null) => {
  const formData = new FormData()
  formData.append('file', file)
  if (folderId) {
    formData.append('folder_id', folderId)
  }
  return api.post('/files/upload', formData, {
    headers: { 'Content-Type': 'multipart/form-data' }
  })
}

export const previewFile = (fileId, limit = 20) => 
  api.get(`/files/preview/${fileId}`, { params: { limit } })

export const downloadFile = (fileId) => 
  api.get(`/files/download/${fileId}`, { responseType: 'blob' })

export const updateFile = (fileId, data) => api.put(`/files/${fileId}`, data)

export const deleteFile = (fileId) => api.delete(`/files/${fileId}`)

export const reorderFiles = (items) => api.put('/files/reorder', { items })

// ==================== 搜索相关API ====================

export const search = (keyword, limit = 50) => 
  api.get('/search', { params: { keyword, limit } })

export const getSearchSuggestions = (keyword, limit = 10) => 
  api.get('/search/suggestions', { params: { keyword, limit } })

export const getSearchHistory = (limit = 20) => 
  api.get('/search/history', { params: { limit } })

export const clearSearchHistory = () => api.delete('/search/history')

// ==================== 语录相关API ====================

export const getQuotes = (category, page = 1, perPage = 20) => 
  api.get('/quotes', { params: { category, page, per_page: perPage } })

export const getRandomQuote = (count = 1) => 
  api.get('/quotes/random', { params: { count } })

export const getDailyQuote = () => api.get('/quotes/daily')

export const getQuoteCategories = () => api.get('/quotes/categories')

// ==================== 数据分析API ====================

export const getHotRanking = (dimension = 'all', limit = 10) => 
  api.get('/analytics/hot-ranking', { params: { dimension, limit } })

export const getCategoryStats = () => api.get('/analytics/category-stats')

export const getClickTrends = (days = 7) => 
  api.get('/analytics/click-trends', { params: { days } })

export const getAnalyticsOverview = () => api.get('/analytics/overview')

// ==================== 用户相关API ====================

export const registerUser = (uuid) => api.post('/users/register', { uuid })

export const getCurrentUser = () => api.get('/users/me')

export const getUserSettings = () => api.get('/users/me/settings')

export const updateUserSettings = (settings) => api.put('/users/me/settings', settings)

export const getUserStats = () => api.get('/users/me/stats')

// ==================== 系统设置API ====================

export const getSettings = () => api.get('/settings')

export const getSetting = (key) => api.get(`/settings/${key}`)

export const updateSetting = (key, value) => api.put(`/settings/${key}`, { value })

export const batchUpdateSettings = (settings) => api.put('/settings/batch', settings)

// ==================== 看板相关API ====================

export const getDashboards = (includeData = false) => 
  api.get('/dashboards', { params: { include_data: includeData } })

export const getDashboard = (id, includeData = true) => 
  api.get(`/dashboards/${id}`, { params: { include_data: includeData } })

export const getDashboardSheet = (dashboardId, sheetName) => 
  api.get(`/dashboards/${dashboardId}/sheet/${encodeURIComponent(sheetName)}`)

export const saveDashboardAPI = (data) => api.post('/dashboards', data)

export const updateDashboard = (id, data) => api.put(`/dashboards/${id}`, data)

export const deleteDashboardAPI = (id) => api.delete(`/dashboards/${id}`)

// 图表计算 API
export const calculateChart = (sheetData, chartConfig) => 
  api.post('/dashboards/calculate', { sheetData, chartConfig })

// 图表下钻 API
export const drillDownChart = (params) => api.post('/dashboards/drill-down', params)

// 获取字段唯一值（用于筛选器）
export const getFieldValues = (params) => api.post('/dashboards/field-values', params)

// 缓存统计（调试用）
export const getCacheStats = () => api.get('/dashboards/cache-stats')

// 统计卡片计算 API
export const calculateStatCard = (params) => api.post('/dashboards/stat-card', params)

// 批量计算统计卡片
export const calculateStatCards = (params) => api.post('/dashboards/stat-cards', params)

// 多表关联预览 API
export const previewJoin = (params) => api.post('/dashboards/preview-join', params)

// 执行多表关联 API
export const executeJoin = (params) => api.post('/dashboards/execute-join', params)

// ==================== 科室相关API ====================

export const getDepartments = () => api.get('/departments')

export const getDepartment = (id) => api.get(`/departments/${id}`)

export const createDepartment = (data) => api.post('/departments', data)

export const updateDepartment = (id, data) => api.put(`/departments/${id}`, data)

export const deleteDepartment = (id) => api.delete(`/departments/${id}`)

// ==================== 员工相关API ====================

export const getEmployees = (departmentId) => 
  api.get('/employees', { params: { department_id: departmentId } })

export const getEmployee = (id) => api.get(`/employees/${id}`)

export const getOrgTree = (departmentId) => api.get(`/employees/org-tree/${departmentId}`)

export const createEmployee = (data) => api.post('/employees', data)

export const updateEmployee = (id, data) => api.put(`/employees/${id}`, data)

export const deleteEmployee = (id) => api.delete(`/employees/${id}`)

export const batchCreateEmployees = (employees) => api.post('/employees/batch', { employees })

export default api
