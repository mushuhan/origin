# 企业级网址导航系统 - 前端应用

基于 Vue 3 的现代化网址导航系统前端，采用高级单色调设计风格。

## 设计理念

- **IMAX沉浸式体验**: 大屏展示，层叠式3D轮播
- **Bento Grid**: 可视化看板布局
- **极简主义**: High-End Monochromatic 高级单色调风格
- **毛玻璃拟态**: Glassmorphism 效果

## 功能特性

### 核心功能
- 🏠 首页聚合展示（轮播、排行、分类）
- 🔍 智能模糊搜索（支持拼音首字母）
- 📁 工作台文件夹系统（多级嵌套）
- 🌙 暗黑模式（系统自动 / 手动切换）
- 📊 数据可视化看板（热门排行柱状图）
- 💬 励志语录轮播

### UI 组件
- `CoverflowCarousel` - 层叠式3D轮播
- `HotRankingChart` - 热门排行图表
- `QuoteTicker` - 语录轮播
- `SearchBox` - 智能搜索框
- `WebsiteCard` - 极简网站卡片
- `FolderTree` - 文件夹树形组件

## 技术栈

- Vue 3 (Composition API)
- Vuex 4 (状态管理)
- Vue Router 4
- Element Plus
- GSAP (动画)
- Tailwind CSS
- Sass/SCSS
- Vite

## 快速开始

### 安装依赖

```bash
cd web-net
npm install
```

### 开发模式

```bash
npm run dev
```

访问 http://localhost:5173

### 生产构建

```bash
npm run build
```

构建产物在 `dist/` 目录

## 配置

### API 代理

开发环境下，API 请求会代理到后端服务：

```javascript
// vite.config.js
server: {
  proxy: {
    '/api': {
      target: 'http://localhost:5000',
      changeOrigin: true
    }
  }
}
```

### 环境变量

创建 `.env.local` 文件：

```env
VITE_API_BASE_URL=http://localhost:5000/api
```

## 目录结构

```
web-net/
├── public/                   # 静态资源
├── src/
│   ├── api/                  # API 接口
│   ├── components/
│   │   ├── common/           # 通用组件
│   │   └── layout/           # 布局组件
│   ├── router/               # 路由配置
│   ├── store/                # Vuex 状态
│   ├── styles/               # 样式文件
│   │   ├── variables.scss    # 设计变量
│   │   └── main.scss         # 主样式
│   ├── utils/                # 工具函数
│   ├── views/                # 页面视图
│   ├── App.vue               # 根组件
│   └── main.js               # 入口文件
├── index.html
├── package.json
├── tailwind.config.js
└── vite.config.js
```

## 设计规范

### 色板

```scss
// 主色调 - 仅黑白灰
$color-black: #000000;
$color-white: #FFFFFF;
$gray-100: #F5F5F7;  // 浅灰背景
$gray-900: #171717;  // 深色文字

// 强调色 - 仅交互反馈
$accent-color: #3B82F6;
```

### 毛玻璃效果

```scss
@mixin glassmorphism {
  background: rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(20px);
  border: 1px solid rgba(255, 255, 255, 0.2);
}
```

### 动画

- 页面切换: 0.25s ease
- 交互反馈: 0.15s ease
- 轮播切换: 0.5s cubic-bezier(0.16, 1, 0.3, 1)
- 柱状图加载: 0.8s ease

## 用户标识

系统使用 UUID v4 作为用户标识，存储在 LocalStorage：

```javascript
// 自动生成并持久化
const token = getUserToken()

// API 请求自动携带
headers: {
  'X-User-Token': token
}
```

## License

MIT
