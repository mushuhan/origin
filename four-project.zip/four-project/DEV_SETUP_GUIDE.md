# 🛠️ 开发环境配置指导书

> NavHub 企业级管理后台 + 混合认证系统

---

## 📋 目录

1. [环境要求](#1-环境要求)
2. [项目结构说明](#2-项目结构说明)
3. [后端配置 (Flask)](#3-后端配置-flask)
4. [数据库配置 (PostgreSQL)](#4-数据库配置-postgresql)
5. [前端配置 (Vue 3)](#5-前端配置-vue-3)
6. [环境变量配置](#6-环境变量配置)
7. [启动开发服务器](#7-启动开发服务器)
8. [创建管理员账号](#8-创建管理员账号)
9. [认证系统说明](#9-认证系统说明)
10. [常见问题解答](#10-常见问题解答)

---

## 1. 环境要求

### 必需软件

| 软件 | 版本要求 | 下载地址 |
|------|---------|---------|
| Python | 3.9+ | https://www.python.org/downloads/ |
| Node.js | 18+ | https://nodejs.org/ |
| PostgreSQL | 13+ | https://www.postgresql.org/download/ |
| Git | 最新版 | https://git-scm.com/ |

### 验证安装

```bash
# 检查 Python 版本
python --version
# 输出: Python 3.9.x 或更高

# 检查 Node.js 版本
node --version
# 输出: v18.x.x 或更高

# 检查 npm 版本
npm --version

# 检查 PostgreSQL
psql --version
```

---

## 2. 项目结构说明

```
second-project/
├── server-net/                 # Flask 后端
│   ├── app/
│   │   ├── __init__.py        # 应用工厂
│   │   ├── config.py          # 配置文件 ⭐
│   │   ├── controllers/       # 路由控制器
│   │   │   ├── auth.py        # 认证接口 ⭐
│   │   │   ├── admin.py       # 管理后台接口 ⭐
│   │   │   └── ...
│   │   ├── models/            # 数据模型
│   │   │   ├── user.py        # 用户模型 ⭐
│   │   │   └── ...
│   │   └── utils/             # 工具函数
│   │       ├── decorators.py  # 装饰器 ⭐
│   │       └── ...
│   ├── migrations/            # 数据库迁移脚本
│   │   └── add_auth_fields.sql ⭐
│   ├── requirements.txt       # Python 依赖
│   ├── run.py                 # 启动入口
│   └── .env                   # 环境变量（需创建）⭐
│
├── web-net/                    # Vue 3 前端
│   ├── src/
│   │   ├── api/
│   │   │   ├── index.js       # 通用 API
│   │   │   └── admin.js       # 管理后台 API ⭐
│   │   ├── components/
│   │   │   └── layout/
│   │   │       └── AdminLayout.vue ⭐
│   │   ├── views/
│   │   │   └── admin/         # 管理后台页面 ⭐
│   │   ├── store/
│   │   │   ├── index.js
│   │   │   └── admin.js       # 管理状态 ⭐
│   │   └── router/
│   │       └── index.js       # 路由配置 ⭐
│   ├── package.json
│   └── vite.config.js
│
└── DEV_SETUP_GUIDE.md         # 本文档
```

---

## 3. 后端配置 (Flask)

### 3.1 进入后端目录

```bash
cd server-net
```

### 3.2 创建 Python 虚拟环境（推荐）

```bash
# Windows
python -m venv venv
venv\Scripts\activate

# macOS/Linux
python3 -m venv venv
source venv/bin/activate
```

### 3.3 安装 Python 依赖

```bash
pip install -r requirements.txt
```

依赖包括：
- Flask 3.0.0 - Web 框架
- Flask-SQLAlchemy - ORM
- Flask-CORS - 跨域支持
- PyJWT - JWT Token 生成/验证
- psycopg2-binary - PostgreSQL 驱动
- pandas, openpyxl - Excel 处理
- requests - HTTP 请求（OAuth 回调）

### 3.4 创建 .env 文件

在 `server-net/` 目录下创建 `.env` 文件：

```bash
# Windows
copy NUL .env

# macOS/Linux
touch .env
```

---

## 4. 数据库配置 (PostgreSQL)

### 4.1 创建数据库

```bash
# 登录 PostgreSQL
psql -U postgres

# 创建数据库
CREATE DATABASE nav_system;

# 退出
\q
```

### 4.2 执行迁移脚本

```bash
# 添加认证相关字段
psql -U postgres -d nav_system -f migrations/add_auth_fields.sql
```

### 4.3 验证迁移结果

```bash
psql -U postgres -d nav_system

# 查看 users 表结构
\d users

# 应该看到以下字段：
# - uuid (主键)
# - oauth_id
# - role
# - password_hash
# - email
# - name
# - avatar
# - is_active
# - created_at
# - last_active_at
# - last_login_at
# - settings
```

---

## 5. 前端配置 (Vue 3)

### 5.1 进入前端目录

```bash
cd web-net
```

### 5.2 安装 Node.js 依赖

```bash
npm install
```

### 5.3 配置代理（已配置）

`vite.config.js` 中已配置开发代理：

```javascript
export default defineConfig({
  server: {
    proxy: {
      '/api': {
        target: 'http://localhost:5000',
        changeOrigin: true
      }
    }
  }
})
```

---

## 6. 环境变量配置

### 6.1 完整的 .env 配置文件

在 `server-net/.env` 中添加以下内容：

```env
# ============================================
# NavHub 开发环境配置
# ============================================

# ---------- 基础配置 ----------
# Flask 密钥（用于 session 加密）
SECRET_KEY=dev-secret-key-change-in-production

# JWT 密钥（用于 Token 签发）
JWT_SECRET_KEY=dev-jwt-secret-key-2024

# ---------- 数据库配置 ----------
PG_HOST=localhost
PG_PORT=5432
PG_USER=postgres
PG_PASSWORD=123456
PG_DATABASE=nav_system

# ---------- 认证系统配置 ----------
# 认证模式：dev = 账号密码登录，prod = OAuth/IDaaS 登录
# 开发环境使用 dev 模式，无需配置 IDaaS
AUTH_MODE=dev

# JWT Token 有效期（秒）
JWT_ACCESS_TOKEN_EXPIRES=86400
JWT_REFRESH_TOKEN_EXPIRES=604800

# ---------- 管理员配置 ----------
# 管理员邮箱列表（逗号分隔）
# 这些邮箱注册/登录时自动获得管理员权限
ADMIN_EMAILS=admin@example.com,your-email@example.com

# ---------- IDaaS 配置（仅 prod 模式需要）----------
# 开发环境可留空，生产环境必填
IDAAS_CLIENT_ID=
IDAAS_CLIENT_SECRET=
IDAAS_TOKEN_URL=
IDAAS_AUTHORIZE_URL=
IDAAS_USERINFO_URL=

# OAuth 回调地址
OAUTH_CALLBACK_URL=http://localhost:5173/auth/callback

# ---------- CORS 配置 ----------
CORS_ORIGINS=http://localhost:5173,http://127.0.0.1:5173

# ---------- 其他配置 ----------
FLASK_ENV=development
PROXY_COUNT=0
```

### 6.2 配置说明

| 配置项 | 说明 | 开发环境值 |
|-------|------|-----------|
| `AUTH_MODE` | 认证模式 | `dev`（使用账号密码） |
| `SECRET_KEY` | Flask 密钥 | 任意字符串 |
| `JWT_SECRET_KEY` | JWT 签名密钥 | 任意字符串 |
| `ADMIN_EMAILS` | 管理员邮箱 | 你的测试邮箱 |
| `PG_PASSWORD` | 数据库密码 | 你的 PostgreSQL 密码 |

---

## 7. 启动开发服务器

### 7.1 启动后端 (Flask)

```bash
# 进入后端目录
cd server-net

# 激活虚拟环境
venv\Scripts\activate  # Windows
# source venv/bin/activate  # macOS/Linux

# 启动 Flask 开发服务器
python run.py
```

后端运行在：`http://localhost:5000`

### 7.2 启动前端 (Vue)

新开一个终端窗口：

```bash
# 进入前端目录
cd web-net

# 启动 Vite 开发服务器
npm run dev
```

前端运行在：`http://localhost:5173`

### 7.3 访问应用

| 页面 | 地址 |
|-----|------|
| 前台首页 | http://localhost:5173 |
| 管理后台登录 | http://localhost:5173/admin/login |
| 管理后台首页 | http://localhost:5173/admin |

---

## 8. 创建管理员账号

### 方式一：通过注册页面（推荐）

1. 访问 http://localhost:5173/admin/login
2. 点击「立即注册」
3. 使用 `ADMIN_EMAILS` 中配置的邮箱注册
4. 系统自动识别为管理员

### 方式二：通过 API 创建

```bash
# 注册管理员账号
curl -X POST http://localhost:5000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "email": "admin@example.com",
    "password": "admin123",
    "name": "管理员"
  }'
```

### 方式三：直接操作数据库

```sql
-- 连接数据库
psql -U postgres -d nav_system

-- 查看现有用户
SELECT uuid, email, role FROM users;

-- 将用户提升为管理员
UPDATE users SET role = 'admin' WHERE email = 'your-email@example.com';
```

---

## 9. 认证系统说明

### 9.1 两种认证模式

```
┌─────────────────────────────────────────────────────────────┐
│                     混合认证系统                              │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  AUTH_MODE=dev                 AUTH_MODE=prod               │
│  ┌─────────────┐              ┌─────────────┐              │
│  │  账号密码   │              │   OAuth2    │              │
│  │   登录     │              │   IDaaS     │              │
│  └──────┬──────┘              └──────┬──────┘              │
│         │                            │                      │
│         │  email + password          │  授权码 code         │
│         ▼                            ▼                      │
│  ┌─────────────┐              ┌─────────────┐              │
│  │ 验证密码   │              │ 换取Token  │               │
│  │ 生成JWT   │              │ 获取用户   │               │
│  └──────┬──────┘              └──────┬──────┘              │
│         │                            │                      │
│         └────────────┬───────────────┘                      │
│                      ▼                                      │
│              ┌─────────────┐                                │
│              │  返回 JWT   │                                │
│              │  系统Token  │                                │
│              └─────────────┘                                │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### 9.2 用户角色

| 角色 | 值 | 权限 |
|-----|-----|-----|
| 普通用户 | `user` | 访问前台功能 |
| 管理员 | `admin` | 访问前台 + 后台管理 |

### 9.3 管理员自动识别

当用户邮箱在 `ADMIN_EMAILS` 列表中时：
- 注册时自动设置 `role = 'admin'`
- 登录时检查并更新角色

### 9.4 开发模式 vs 生产模式

| 特性 | DEV 模式 | PROD 模式 |
|-----|---------|----------|
| 登录方式 | 账号 + 密码 | OAuth2 跳转 |
| 注册功能 | ✅ 支持 | ❌ 禁用 |
| 密码重置 | ✅ 支持 | ❌ 禁用 |
| IDaaS 配置 | 不需要 | 必需 |
| 适用场景 | 本地开发、测试 | 生产环境 |

---

## 10. 常见问题解答

### Q1: 启动后端报错 "ModuleNotFoundError"

**原因**: 未安装依赖或虚拟环境未激活

**解决**:
```bash
cd server-net
venv\Scripts\activate  # 激活虚拟环境
pip install -r requirements.txt
```

### Q2: 数据库连接失败

**原因**: PostgreSQL 未启动或配置错误

**解决**:
1. 确保 PostgreSQL 服务已启动
2. 检查 `.env` 中的数据库配置
3. 确保数据库 `nav_system` 已创建

```bash
# 检查 PostgreSQL 状态
pg_isready

# 创建数据库
psql -U postgres -c "CREATE DATABASE nav_system;"
```

### Q3: 登录提示"用户不存在"

**原因**: 需要先注册账号

**解决**: 
1. 访问登录页，点击「立即注册」
2. 或使用 API 注册

### Q4: 登录成功但提示"没有管理员权限"

**原因**: 邮箱不在 `ADMIN_EMAILS` 列表中

**解决**:
1. 修改 `.env` 添加你的邮箱到 `ADMIN_EMAILS`
2. 重启后端服务
3. 重新登录

### Q5: 前端页面空白

**原因**: 前端依赖未安装或后端未启动

**解决**:
```bash
cd web-net
npm install
npm run dev
```

确保后端也在运行。

### Q6: CORS 跨域错误

**原因**: 后端 CORS 配置不正确

**解决**: 检查 `.env` 中的 `CORS_ORIGINS` 是否包含前端地址

```env
CORS_ORIGINS=http://localhost:5173,http://127.0.0.1:5173
```

### Q7: 如何切换到生产模式测试 OAuth?

**步骤**:
1. 在 IDaaS 控制台创建应用，获取配置
2. 修改 `.env`:

```env
AUTH_MODE=prod
IDAAS_CLIENT_ID=your-client-id
IDAAS_CLIENT_SECRET=your-secret
IDAAS_TOKEN_URL=https://your-idaas.com/oauth2/token
IDAAS_AUTHORIZE_URL=https://your-idaas.com/oauth2/authorize
IDAAS_USERINFO_URL=https://your-idaas.com/oauth2/userinfo
```

3. 在 IDaaS 控制台配置回调地址：`http://localhost:5173/auth/callback`
4. 重启后端服务

---

## 📚 相关文档

- [Flask 官方文档](https://flask.palletsprojects.com/)
- [Vue 3 官方文档](https://vuejs.org/)
- [Element Plus 组件库](https://element-plus.org/)
- [PostgreSQL 文档](https://www.postgresql.org/docs/)

---

## 🆘 获取帮助

如果遇到问题：
1. 检查终端输出的错误信息
2. 查看后端日志（`server-net/` 目录）
3. 确保所有环境变量配置正确
4. 确保数据库迁移已执行

---

*最后更新: 2024年12月*

