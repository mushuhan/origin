# -*- coding: utf-8 -*-
"""
企业级网址导航系统 - 启动入口
"""
import os
import click
from app import create_app, db

# 获取环境配置
config_name = os.environ.get('FLASK_ENV', 'development')

# 创建应用实例
app = create_app(config_name)


def init_database():
    """初始化数据库（创建表）"""
    with app.app_context():
        db.create_all()
        print('数据库表创建成功')

        # 初始化默认语录
        from app.services.quote_service import QuoteService
        QuoteService.init_default_quotes()
        print('默认语录初始化完成')


# ==================== Flask CLI 命令 ====================

@app.cli.command('update-pinyin')
@click.option('--model', '-m', type=click.Choice(['all', 'employee', 'website']), default='all', help='要更新的模型')
@click.option('--batch-size', '-b', default=100, help='每批处理数量')
@click.option('--force', '-f', is_flag=True, help='强制更新所有记录（包括已有拼音的）')
def update_pinyin_command(model, batch_size, force):
    """
    批量更新拼音字段
    
    使用方法:
        flask update-pinyin              # 更新所有模型
        flask update-pinyin -m employee  # 只更新员工
        flask update-pinyin -m website   # 只更新网站
        flask update-pinyin -f           # 强制更新所有记录
    """
    from app.utils.pinyin import generate_pinyin_fields
    from app.models.employee import Employee
    from app.models.website import Website
    
    def update_model(model_class, name):
        """更新单个模型的拼音"""
        if force:
            # 强制更新所有记录
            query = model_class.query
        else:
            # 只更新缺少拼音的记录
            query = model_class.query.filter(
                db.or_(
                    model_class.pinyin.is_(None),
                    model_class.pinyin == '',
                    model_class.pinyin_initials.is_(None),
                    model_class.pinyin_initials == ''
                )
            )
        
        total = query.count()
        if total == 0:
            click.echo(f'✓ {name}: 没有需要更新的记录')
            return 0
        
        click.echo(f'→ {name}: 找到 {total} 条需要更新的记录')
        
        updated = 0
        offset = 0
        
        with click.progressbar(length=total, label=f'  更新 {name}') as bar:
            while True:
                records = query.limit(batch_size).offset(offset).all()
                if not records:
                    break
                
                for record in records:
                    if hasattr(record, 'name') and record.name:
                        full_pinyin, initials = generate_pinyin_fields(record.name)
                        record.pinyin = full_pinyin
                        record.pinyin_initials = initials
                        updated += 1
                
                db.session.commit()
                bar.update(len(records))
                offset += batch_size
        
        click.echo(f'✓ {name}: 成功更新 {updated} 条记录')
        return updated
    
    click.echo('=' * 50)
    click.echo('🔤 拼音字段批量更新工具')
    click.echo('=' * 50)
    
    total_updated = 0
    
    if model in ('all', 'employee'):
        total_updated += update_model(Employee, '员工')
    
    if model in ('all', 'website'):
        total_updated += update_model(Website, '网站')
    
    click.echo('=' * 50)
    click.echo(f'✅ 完成！共更新 {total_updated} 条记录')


@app.cli.command('init-db')
def init_db_command():
    """初始化数据库"""
    init_database()
    click.echo('✅ 数据库初始化完成')


@app.cli.command('add-pinyin-columns')
def add_pinyin_columns_command():
    """
    添加拼音字段到数据库（用于现有数据库迁移）
    
    使用方法:
        flask add-pinyin-columns
    """
    from sqlalchemy import text
    
    click.echo('正在检查并添加拼音字段...')
    
    try:
        # 检查并添加 employees 表的拼音字段
        db.session.execute(text("""
            DO $$ 
            BEGIN
                IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                               WHERE table_name='employees' AND column_name='pinyin') THEN
                    ALTER TABLE employees ADD COLUMN pinyin VARCHAR(200);
                    RAISE NOTICE 'Added pinyin column to employees';
                END IF;
                
                IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                               WHERE table_name='employees' AND column_name='pinyin_initials') THEN
                    ALTER TABLE employees ADD COLUMN pinyin_initials VARCHAR(50);
                    RAISE NOTICE 'Added pinyin_initials column to employees';
                END IF;
            END $$;
        """))
        
        # 创建 GIN 索引（如果不存在）
        db.session.execute(text("""
            CREATE INDEX IF NOT EXISTS idx_employees_pinyin_gin 
            ON employees USING gin (pinyin gin_trgm_ops);
        """))
        
        db.session.execute(text("""
            CREATE INDEX IF NOT EXISTS idx_employees_pinyin_initials_gin 
            ON employees USING gin (pinyin_initials gin_trgm_ops);
        """))
        
        db.session.commit()
        click.echo('✅ 拼音字段和索引添加完成！')
        click.echo('💡 提示: 运行 "flask update-pinyin" 来填充拼音数据')
        
    except Exception as e:
        db.session.rollback()
        click.echo(f'❌ 错误: {e}')


if __name__ == '__main__':
    # 检查是否需要初始化数据库
    if os.environ.get('INIT_DB', 'false').lower() == 'true':
        init_database()

    # 启动开发服务器
    app.run(
        host=os.environ.get('HOST', '0.0.0.0'),
        port=int(os.environ.get('PORT', 5000)),
        debug=app.config.get('DEBUG', False)
    )
