-- ==========================================
-- 数据库迁移：添加认证系统字段
-- ==========================================
-- 
-- 【重要说明】
-- 此迁移为 User 表添加混合认证所需的字段
-- 保留原有的 uuid 作为主键（系统文件关联的基石）
-- 
-- 执行方式：
-- psql -U postgres -d nav_system -f migrations/add_auth_fields.sql
--
-- 或者在 psql 中执行：
-- \i migrations/add_auth_fields.sql
-- ==========================================

-- 开始事务
BEGIN;

-- ==========================================
-- 1. 添加 oauth_id 字段
-- ==========================================
-- IDaaS 返回的 sub 唯一标识，用于 PROD 模式下的用户映射
-- 为什么不替换 uuid？因为 uuid 已被文件系统、数据存储等模块引用
DO $$ 
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'users' AND column_name = 'oauth_id'
    ) THEN
        ALTER TABLE users ADD COLUMN oauth_id VARCHAR(255) UNIQUE;
        COMMENT ON COLUMN users.oauth_id IS 'IDaaS唯一标识(sub)，用于PROD模式用户映射';
        RAISE NOTICE '已添加 oauth_id 字段';
    ELSE
        RAISE NOTICE 'oauth_id 字段已存在，跳过';
    END IF;
END $$;

-- 创建索引加速 oauth_id 查询
CREATE INDEX IF NOT EXISTS idx_users_oauth_id ON users(oauth_id);

-- ==========================================
-- 2. 添加 role 字段
-- ==========================================
-- 用户角色：'user'(普通用户) 或 'admin'(管理员)
DO $$ 
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'users' AND column_name = 'role'
    ) THEN
        ALTER TABLE users ADD COLUMN role VARCHAR(20) DEFAULT 'user' NOT NULL;
        COMMENT ON COLUMN users.role IS '用户角色: user(普通用户) / admin(管理员)';
        RAISE NOTICE '已添加 role 字段';
    ELSE
        RAISE NOTICE 'role 字段已存在，跳过';
    END IF;
END $$;

-- ==========================================
-- 3. 添加 password_hash 字段
-- ==========================================
-- 仅用于 DEV 模式的密码认证
DO $$ 
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'users' AND column_name = 'password_hash'
    ) THEN
        ALTER TABLE users ADD COLUMN password_hash VARCHAR(256);
        COMMENT ON COLUMN users.password_hash IS '密码哈希，仅DEV模式使用';
        RAISE NOTICE '已添加 password_hash 字段';
    ELSE
        RAISE NOTICE 'password_hash 字段已存在，跳过';
    END IF;
END $$;

-- ==========================================
-- 4. 添加 email 字段
-- ==========================================
-- 用户邮箱，用于登录和管理员识别
DO $$ 
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'users' AND column_name = 'email'
    ) THEN
        ALTER TABLE users ADD COLUMN email VARCHAR(255) UNIQUE;
        COMMENT ON COLUMN users.email IS '用户邮箱';
        RAISE NOTICE '已添加 email 字段';
    ELSE
        RAISE NOTICE 'email 字段已存在，跳过';
    END IF;
END $$;

-- 创建索引加速 email 查询
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);

-- ==========================================
-- 5. 添加 name 字段
-- ==========================================
-- 用户显示名称
DO $$ 
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'users' AND column_name = 'name'
    ) THEN
        ALTER TABLE users ADD COLUMN name VARCHAR(100);
        COMMENT ON COLUMN users.name IS '用户显示名称';
        RAISE NOTICE '已添加 name 字段';
    ELSE
        RAISE NOTICE 'name 字段已存在，跳过';
    END IF;
END $$;

-- ==========================================
-- 6. 添加 avatar 字段
-- ==========================================
-- 用户头像 URL
DO $$ 
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'users' AND column_name = 'avatar'
    ) THEN
        ALTER TABLE users ADD COLUMN avatar VARCHAR(500);
        COMMENT ON COLUMN users.avatar IS '用户头像URL';
        RAISE NOTICE '已添加 avatar 字段';
    ELSE
        RAISE NOTICE 'avatar 字段已存在，跳过';
    END IF;
END $$;

-- ==========================================
-- 7. 添加 is_active 字段
-- ==========================================
-- 账户激活状态
DO $$ 
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'users' AND column_name = 'is_active'
    ) THEN
        ALTER TABLE users ADD COLUMN is_active BOOLEAN DEFAULT true NOT NULL;
        COMMENT ON COLUMN users.is_active IS '账户是否激活';
        RAISE NOTICE '已添加 is_active 字段';
    ELSE
        RAISE NOTICE 'is_active 字段已存在，跳过';
    END IF;
END $$;

-- ==========================================
-- 8. 添加 last_login_at 字段
-- ==========================================
-- 最后登录时间
DO $$ 
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'users' AND column_name = 'last_login_at'
    ) THEN
        ALTER TABLE users ADD COLUMN last_login_at TIMESTAMP;
        COMMENT ON COLUMN users.last_login_at IS '最后登录时间';
        RAISE NOTICE '已添加 last_login_at 字段';
    ELSE
        RAISE NOTICE 'last_login_at 字段已存在，跳过';
    END IF;
END $$;

-- 提交事务
COMMIT;

-- ==========================================
-- 验证迁移结果
-- ==========================================
SELECT '迁移完成！以下是 users 表的当前结构：' AS message;

SELECT 
    column_name AS "字段名",
    data_type AS "数据类型",
    is_nullable AS "可空",
    column_default AS "默认值"
FROM information_schema.columns 
WHERE table_name = 'users' 
ORDER BY ordinal_position;
