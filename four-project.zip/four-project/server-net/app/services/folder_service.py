# -*- coding: utf-8 -*-
"""
文件夹服务
处理文件夹相关的业务逻辑（递归、树形结构等）
"""
from app import db
from app.models.folder import Folder
from app.models.workspace import UserSite


class FolderService:
    """文件夹服务类"""
    
    @staticmethod
    def get_folder_tree(user_uuid, include_sites=False, category=None):
        """
        获取用户文件夹树形结构
        
        Args:
            user_uuid: 用户UUID
            include_sites: 是否包含网址
            category: 文件夹分类 ('sites' 或 'files')，None 表示获取所有
        
        Returns:
            树形结构数据
        """
        # 获取根文件夹
        query = Folder.query.filter_by(
            user_uuid=user_uuid,
            parent_id=None
        )
        
        # 按分类过滤
        if category:
            query = query.filter_by(category=category)
        
        root_folders = query.order_by(Folder.sort_order).all()
        
        return [f.to_dict(include_children=True, include_sites=include_sites) for f in root_folders]
    
    @staticmethod
    def get_all_descendants(folder):
        """
        获取文件夹的所有后代（子文件夹）
        
        Args:
            folder: 文件夹对象
        
        Returns:
            后代文件夹ID列表
        """
        descendants = []
        
        def collect_children(f):
            for child in f.children.all():
                descendants.append(child.id)
                collect_children(child)
        
        collect_children(folder)
        return descendants
    
    @staticmethod
    def is_descendant(potential_descendant, ancestor):
        """
        检查一个文件夹是否是另一个的后代
        用于防止循环引用
        
        Args:
            potential_descendant: 潜在后代
            ancestor: 祖先文件夹
        
        Returns:
            布尔值
        """
        descendants = FolderService.get_all_descendants(ancestor)
        return potential_descendant.id in descendants
    
    @staticmethod
    def move_children_to_parent(folder):
        """
        将文件夹的子项移动到父级
        用于删除文件夹时保留内容
        
        Args:
            folder: 要删除的文件夹
        """
        parent_id = folder.parent_id
        user_uuid = folder.user_uuid
        
        # 移动子文件夹
        for child in folder.children.all():
            child.parent_id = parent_id
        
        # 移动网址到父文件夹（或根目录）
        for site in folder.user_sites.all():
            site.folder_id = parent_id
        
        db.session.commit()
    
    @staticmethod
    def get_folder_path(folder):
        """
        获取文件夹路径（面包屑）
        
        Args:
            folder: 文件夹对象
        
        Returns:
            路径列表（从根到当前）
        """
        path = []
        current = folder
        
        while current:
            path.insert(0, {
                'id': current.id,
                'name': current.name
            })
            current = current.parent
        
        return path
    
    @staticmethod
    def count_folder_items(folder):
        """
        统计文件夹内的项目数量（递归）
        
        Args:
            folder: 文件夹对象
        
        Returns:
            项目数量
        """
        count = folder.user_sites.count()
        
        for child in folder.children.all():
            count += FolderService.count_folder_items(child)
        
        return count
