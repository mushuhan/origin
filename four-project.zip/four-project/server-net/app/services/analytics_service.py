# -*- coding: utf-8 -*-
"""
数据分析服务
支持统计卡片的趋势计算和增长率分析
"""
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Union
import pandas as pd
import numpy as np
from sqlalchemy import func
from app import db
from app.models.website import Website
from app.models.category import SidebarCategory
from app.models.section import Section


class AnalyticsService:
    """数据分析服务类"""
    
    @staticmethod
    def get_hot_ranking(dimension='all', limit=10):
        """
        获取热门网址排行
        
        Args:
            dimension: 维度 (today/week/all)
            limit: 返回数量
        
        Returns:
            排行榜数据
        """
        query = db.session.query(
            Website.id,
            Website.name,
            Website.url,
            Website.icon,
            Website.click_count,
            Website.section_id
        )
        
        # 按维度筛选
        if dimension == 'today':
            today = datetime.utcnow().date()
            query = query.filter(func.date(Website.updated_at) == today)
        elif dimension == 'week':
            week_ago = datetime.utcnow() - timedelta(days=7)
            query = query.filter(Website.updated_at >= week_ago)
        
        # 排序并限制数量
        results = query.order_by(Website.click_count.desc()).limit(limit).all()
        
        rankings = []
        for i, r in enumerate(results, 1):
            rankings.append({
                'rank': i,
                'id': r.id,
                'name': r.name,
                'url': r.url,
                'icon': r.icon,
                'click_count': r.click_count or 0,
                'section_id': r.section_id
            })
        
        return rankings
    
    @staticmethod
    def get_category_stats():
        """
        获取分类统计
        
        Returns:
            各分类的网址数量和点击量
        """
        stats = []
        
        categories = SidebarCategory.query.filter_by(is_system=False).all()
        
        for category in categories:
            # 获取该分类下的所有网址
            section_ids = [s.id for s in category.sections.all()]
            
            if section_ids:
                website_count = Website.query.filter(
                    Website.section_id.in_(section_ids)
                ).count()
                
                total_clicks = db.session.query(
                    func.sum(Website.click_count)
                ).filter(
                    Website.section_id.in_(section_ids)
                ).scalar() or 0
            else:
                website_count = 0
                total_clicks = 0
            
            stats.append({
                'category_id': category.id,
                'category_name': category.name,
                'icon': category.icon,
                'website_count': website_count,
                'total_clicks': total_clicks
            })
        
        # 按网址数量排序
        stats.sort(key=lambda x: x['website_count'], reverse=True)
        
        return stats
    
    @staticmethod
    def get_click_trends(days=7):
        """
        获取点击趋势
        
        Args:
            days: 天数
        
        Returns:
            每日点击趋势数据
        """
        trends = []
        today = datetime.utcnow().date()
        
        for i in range(days - 1, -1, -1):
            date = today - timedelta(days=i)
            
            # 这里简化处理，实际应该有点击日志表
            # 当前只返回示例数据结构
            trends.append({
                'date': date.isoformat(),
                'clicks': 0  # 需要点击日志表支持
            })
        
        return trends


class StatCardService:
    """
    统计卡片服务
    负责计算统计指标、趋势数据和增长率
    """
    
    @staticmethod
    def get_summary_stats(
        data: List[Dict],
        field: str,
        aggregation: str = 'sum',
        time_field: Optional[str] = None,
        trend_periods: int = 7,
        filters: Optional[List[Dict]] = None
    ) -> Dict[str, Any]:
        """
        计算统计卡片数据，包含趋势和增长率
        
        Args:
            data: 原始数据列表
            field: 统计字段
            aggregation: 聚合方式 (sum/count/avg/max/min)
            time_field: 时间字段（用于计算趋势）
            trend_periods: 趋势周期数（默认7个）
            filters: 筛选条件
        
        Returns:
            {
                'value': 123.45,          # 当前值
                'trend': 5.2,             # 增长率百分比
                'sparklineData': [1,2,3], # 趋势数据点
                'periodLabel': '较上期'   # 趋势标签
            }
        """
        if not data or not field:
            return {
                'value': 0,
                'trend': None,
                'sparklineData': [],
                'periodLabel': ''
            }
        
        df = pd.DataFrame(data)
        
        # 应用筛选
        if filters:
            from app.services.chart_service import ChartService
            df = ChartService._apply_filters(df, filters)
        
        if df.empty or field not in df.columns:
            return {
                'value': 0,
                'trend': None,
                'sparklineData': [],
                'periodLabel': ''
            }
        
        # 转换为数值
        df[field] = pd.to_numeric(df[field], errors='coerce').fillna(0)
        
        # 计算当前值
        current_value = StatCardService._aggregate_value(df[field], aggregation)
        
        # 计算趋势数据
        sparkline_data = []
        trend_value = None
        period_label = ''
        
        if time_field and time_field in df.columns:
            # 基于时间字段计算趋势
            result = StatCardService._calculate_time_trend(
                df, field, time_field, aggregation, trend_periods
            )
            sparkline_data = result['sparklineData']
            trend_value = result['trend']
            period_label = result['periodLabel']
        else:
            # 无时间字段时，按数据顺序分组计算趋势
            result = StatCardService._calculate_sequence_trend(
                df, field, aggregation, trend_periods
            )
            sparkline_data = result['sparklineData']
            trend_value = result['trend']
            period_label = '较上期'
        
        return {
            'value': round(current_value, 2),
            'trend': round(trend_value, 1) if trend_value is not None else None,
            'sparklineData': sparkline_data,
            'periodLabel': period_label
        }
    
    @staticmethod
    def _aggregate_value(series: pd.Series, aggregation: str) -> float:
        """计算聚合值"""
        if series.empty:
            return 0
        
        if aggregation == 'sum':
            return series.sum()
        elif aggregation == 'count':
            return len(series)
        elif aggregation == 'avg':
            return series.mean()
        elif aggregation == 'max':
            return series.max()
        elif aggregation == 'min':
            return series.min()
        else:
            return series.sum()
    
    @staticmethod
    def _calculate_time_trend(
        df: pd.DataFrame,
        field: str,
        time_field: str,
        aggregation: str,
        periods: int
    ) -> Dict:
        """基于时间字段计算趋势"""
        try:
            # 尝试解析时间
            df['_time'] = pd.to_datetime(df[time_field], errors='coerce')
            df = df.dropna(subset=['_time'])
            
            if df.empty:
                return {'sparklineData': [], 'trend': None, 'periodLabel': ''}
            
            # 按日期分组
            df['_date'] = df['_time'].dt.date
            
            # 获取最近 N 个周期的数据
            unique_dates = sorted(df['_date'].unique())[-periods:]
            
            sparkline_data = []
            for date in unique_dates:
                period_df = df[df['_date'] == date]
                val = StatCardService._aggregate_value(period_df[field], aggregation)
                sparkline_data.append(round(val, 2))
            
            # 计算增长率
            trend = None
            if len(sparkline_data) >= 2:
                prev_val = sparkline_data[-2] if sparkline_data[-2] != 0 else 0.001
                curr_val = sparkline_data[-1]
                if prev_val != 0:
                    trend = ((curr_val - prev_val) / abs(prev_val)) * 100
            
            return {
                'sparklineData': sparkline_data,
                'trend': trend,
                'periodLabel': '较昨日' if len(unique_dates) > 1 else ''
            }
        except Exception as e:
            print(f"时间趋势计算失败: {e}")
            return {'sparklineData': [], 'trend': None, 'periodLabel': ''}
    
    @staticmethod
    def _calculate_sequence_trend(
        df: pd.DataFrame,
        field: str,
        aggregation: str,
        periods: int
    ) -> Dict:
        """基于数据序列计算趋势（无时间字段时）"""
        try:
            total_rows = len(df)
            if total_rows < periods:
                periods = max(2, total_rows)
            
            # 将数据分成 N 个段
            chunk_size = max(1, total_rows // periods)
            sparkline_data = []
            
            for i in range(periods):
                start_idx = i * chunk_size
                end_idx = start_idx + chunk_size if i < periods - 1 else total_rows
                chunk_df = df.iloc[start_idx:end_idx]
                
                val = StatCardService._aggregate_value(chunk_df[field], aggregation)
                sparkline_data.append(round(val, 2))
            
            # 计算增长率
            trend = None
            if len(sparkline_data) >= 2:
                prev_val = sparkline_data[-2] if sparkline_data[-2] != 0 else 0.001
                curr_val = sparkline_data[-1]
                if prev_val != 0:
                    trend = ((curr_val - prev_val) / abs(prev_val)) * 100
            
            return {
                'sparklineData': sparkline_data,
                'trend': trend,
                'periodLabel': '较上期'
            }
        except Exception as e:
            print(f"序列趋势计算失败: {e}")
            return {'sparklineData': [], 'trend': None, 'periodLabel': ''}
    
    @staticmethod
    def calculate_multi_stats(
        data: List[Dict],
        configs: List[Dict]
    ) -> List[Dict]:
        """
        批量计算多个统计卡片数据
        
        Args:
            data: 原始数据
            configs: 统计配置列表，每个配置包含:
                - field: 统计字段
                - aggregation: 聚合方式
                - time_field: 时间字段（可选）
                - filters: 筛选条件（可选）
                - title: 卡片标题
                - prefix: 前缀
                - suffix: 后缀
        
        Returns:
            统计结果列表
        """
        results = []
        
        for config in configs:
            stat = StatCardService.get_summary_stats(
                data=data,
                field=config.get('field', ''),
                aggregation=config.get('aggregation', 'sum'),
                time_field=config.get('time_field'),
                trend_periods=config.get('trend_periods', 7),
                filters=config.get('filters')
            )
            
            results.append({
                'title': config.get('title', ''),
                'prefix': config.get('prefix', ''),
                'suffix': config.get('suffix', ''),
                **stat
            })
        
        return results


class DataJoinService:
    """
    数据关联服务
    提供类似 SQL Join 的多表关联功能
    """
    
    @staticmethod
    def preview_join(
        data1: List[Dict],
        data2: List[Dict],
        join_key1: str,
        join_key2: str,
        join_type: str = 'inner',
        preview_limit: int = 10
    ) -> Dict[str, Any]:
        """
        预览 Join 结果
        
        Args:
            data1: 表1数据
            data2: 表2数据
            join_key1: 表1关联字段
            join_key2: 表2关联字段
            join_type: 关联类型 (inner/left/right/outer)
            preview_limit: 预览行数限制
        
        Returns:
            {
                'columns': ['col1', 'col2', ...],
                'rows': [{...}, {...}],
                'totalRows': 100,
                'joinStats': {
                    'leftRows': 50,
                    'rightRows': 60,
                    'matchedRows': 45
                }
            }
        
        Raises:
            ValueError: 当关联字段不存在或类型不兼容时
        """
        if not data1 or not data2:
            raise ValueError('数据源不能为空')
        
        df1 = pd.DataFrame(data1)
        df2 = pd.DataFrame(data2)
        
        # 验证关联字段存在
        if join_key1 not in df1.columns:
            raise ValueError(f'表1中不存在字段: {join_key1}')
        if join_key2 not in df2.columns:
            raise ValueError(f'表2中不存在字段: {join_key2}')
        
        # 处理列名冲突
        common_cols = set(df1.columns) & set(df2.columns)
        if join_key1 == join_key2 and join_key1 in common_cols:
            common_cols.remove(join_key1)
        
        if common_cols:
            # 重命名冲突列
            rename_map = {col: f'{col}_right' for col in common_cols}
            df2 = df2.rename(columns=rename_map)
            if join_key2 in rename_map:
                join_key2 = rename_map[join_key2]
        
        # 尝试类型转换以提高匹配率
        try:
            # 尝试将两边的 key 转换为相同类型
            df1[join_key1] = df1[join_key1].astype(str).str.strip()
            df2[join_key2] = df2[join_key2].astype(str).str.strip()
        except Exception as e:
            print(f"类型转换警告: {e}")
        
        # 执行 Join
        how_map = {
            'inner': 'inner',
            'left': 'left',
            'right': 'right',
            'outer': 'outer'
        }
        how = how_map.get(join_type, 'inner')
        
        try:
            merged = pd.merge(
                df1, df2,
                left_on=join_key1,
                right_on=join_key2,
                how=how,
                suffixes=('', '_dup')
            )
        except Exception as e:
            raise ValueError(f'合并失败: {str(e)}')
        
        # 移除重复的 join key 列（如果有）
        if join_key1 != join_key2 and join_key2 in merged.columns:
            # 保留一个 key 列即可
            pass
        
        # 清理 _dup 后缀的列
        dup_cols = [col for col in merged.columns if col.endswith('_dup')]
        merged = merged.drop(columns=dup_cols, errors='ignore')
        
        # 处理 NaN 值
        merged = merged.fillna('')
        
        # 统计信息
        join_stats = {
            'leftRows': len(df1),
            'rightRows': len(df2),
            'matchedRows': len(merged)
        }
        
        # 返回结果
        return {
            'columns': merged.columns.tolist(),
            'rows': merged.head(preview_limit).to_dict('records'),
            'totalRows': len(merged),
            'joinStats': join_stats
        }
    
    @staticmethod
    def execute_join(
        data1: List[Dict],
        data2: List[Dict],
        join_key1: str,
        join_key2: str,
        join_type: str = 'inner'
    ) -> Dict[str, Any]:
        """
        执行完整的 Join 操作（不限制行数）
        
        Returns:
            {
                'headers': ['col1', 'col2', ...],
                'rows': [{...}, {...}, ...]
            }
        """
        if not data1 or not data2:
            return {'headers': [], 'rows': []}
        
        df1 = pd.DataFrame(data1)
        df2 = pd.DataFrame(data2)
        
        if join_key1 not in df1.columns or join_key2 not in df2.columns:
            return {'headers': [], 'rows': []}
        
        # 处理列名冲突
        common_cols = set(df1.columns) & set(df2.columns)
        if join_key1 == join_key2 and join_key1 in common_cols:
            common_cols.remove(join_key1)
        
        if common_cols:
            rename_map = {col: f'{col}_right' for col in common_cols}
            df2 = df2.rename(columns=rename_map)
            if join_key2 in rename_map:
                join_key2 = rename_map[join_key2]
        
        # 类型转换
        df1[join_key1] = df1[join_key1].astype(str).str.strip()
        df2[join_key2] = df2[join_key2].astype(str).str.strip()
        
        # 执行 Join
        how = {'inner': 'inner', 'left': 'left', 'right': 'right', 'outer': 'outer'}.get(join_type, 'inner')
        
        merged = pd.merge(
            df1, df2,
            left_on=join_key1,
            right_on=join_key2,
            how=how,
            suffixes=('', '_dup')
        )
        
        # 清理
        dup_cols = [col for col in merged.columns if col.endswith('_dup')]
        merged = merged.drop(columns=dup_cols, errors='ignore')
        merged = merged.fillna('')
        
        return {
            'headers': merged.columns.tolist(),
            'rows': merged.to_dict('records')
        }
    
    @staticmethod
    def get_join_preview_from_files(
        file_path1: str,
        file_path2: str,
        join_key1: str,
        join_key2: str,
        join_type: str = 'inner',
        preview_limit: int = 10
    ) -> Dict[str, Any]:
        """
        从文件加载数据并预览 Join 结果（优化大数据场景）
        """
        from app.services.data_storage_service import DataStorageService
        
        df1 = DataStorageService.load_sheet_data(file_path1)
        df2 = DataStorageService.load_sheet_data(file_path2)
        
        if df1.empty or df2.empty:
            raise ValueError('数据文件为空或不存在')
        
        return DataJoinService.preview_join(
            df1.to_dict('records'),
            df2.to_dict('records'),
            join_key1,
            join_key2,
            join_type,
            preview_limit
        )
