"""
数据存储服务
负责 Excel 数据的文件存储、读取和缓存管理
支持 CSV 和 Parquet 格式，使用 LRU 缓存提升性能
"""
import os
import json
import hashlib
from functools import lru_cache
from datetime import datetime
from typing import Optional, Dict, List, Any
import pandas as pd

# 数据存储根目录
DATA_STORAGE_ROOT = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'data_storage')

# 确保存储目录存在
os.makedirs(DATA_STORAGE_ROOT, exist_ok=True)


class DataStorageService:
    """数据文件存储服务"""
    
    # 支持的存储格式
    FORMATS = {
        'csv': {'extension': '.csv', 'reader': 'read_csv', 'writer': 'to_csv'},
        'parquet': {'extension': '.parquet', 'reader': 'read_parquet', 'writer': 'to_parquet'}
    }
    
    # 默认格式（Parquet 压缩率高、读取快）
    DEFAULT_FORMAT = 'parquet'
    
    @classmethod
    def generate_file_id(cls, user_uuid: str, dashboard_id: int) -> str:
        """生成唯一文件ID"""
        return f"{user_uuid}_{dashboard_id}_{datetime.now().strftime('%Y%m%d%H%M%S')}"
    
    @classmethod
    def get_storage_path(cls, file_id: str, sheet_name: str, format: str = None) -> str:
        """获取存储路径"""
        format = format or cls.DEFAULT_FORMAT
        ext = cls.FORMATS[format]['extension']
        # 清理 sheet_name 中的非法字符
        safe_sheet_name = "".join(c if c.isalnum() or c in ('_', '-') else '_' for c in sheet_name)
        return os.path.join(DATA_STORAGE_ROOT, f"{file_id}_{safe_sheet_name}{ext}")
    
    @classmethod
    def save_sheet_data(cls, file_id: str, sheet_name: str, data: List[Dict], format: str = None) -> str:
        """
        保存单个工作表数据到文件
        
        :param file_id: 文件ID
        :param sheet_name: 工作表名称
        :param data: 行数据列表 [{col1: val1, col2: val2}, ...]
        :param format: 存储格式 'csv' 或 'parquet'
        :return: 文件路径
        """
        format = format or cls.DEFAULT_FORMAT
        file_path = cls.get_storage_path(file_id, sheet_name, format)
        
        if not data:
            # 空数据创建空文件
            df = pd.DataFrame()
        else:
            df = pd.DataFrame(data)
        
        # 写入文件
        if format == 'parquet':
            df.to_parquet(file_path, index=False, compression='snappy')
        else:
            df.to_csv(file_path, index=False, encoding='utf-8-sig')
        
        # 清除该文件的缓存
        cls._invalidate_cache(file_path)
        
        return file_path
    
    @classmethod
    def save_dashboard_data(cls, file_id: str, sheet_data: Dict[str, Dict], format: str = None) -> Dict[str, str]:
        """
        保存整个看板的所有工作表数据
        
        :param file_id: 文件ID
        :param sheet_data: {sheet_name: {headers: [], rows: []}, ...}
        :param format: 存储格式
        :return: {sheet_name: file_path, ...}
        """
        file_paths = {}
        
        for sheet_name, data in sheet_data.items():
            rows = data.get('rows', [])
            file_path = cls.save_sheet_data(file_id, sheet_name, rows, format)
            file_paths[sheet_name] = file_path
        
        return file_paths
    
    @classmethod
    @lru_cache(maxsize=50)
    def _cached_read_file(cls, file_path: str, file_mtime: float) -> pd.DataFrame:
        """
        带缓存的文件读取（内部方法）
        file_mtime 参数用于缓存失效控制
        """
        if not os.path.exists(file_path):
            return pd.DataFrame()
        
        if file_path.endswith('.parquet'):
            return pd.read_parquet(file_path)
        else:
            return pd.read_csv(file_path, encoding='utf-8-sig')
    
    @classmethod
    def load_sheet_data(cls, file_path: str) -> pd.DataFrame:
        """
        加载工作表数据（带 LRU 缓存）
        
        :param file_path: 文件路径
        :return: DataFrame
        """
        if not os.path.exists(file_path):
            return pd.DataFrame()
        
        # 使用文件修改时间作为缓存 key 的一部分，实现自动失效
        file_mtime = os.path.getmtime(file_path)
        return cls._cached_read_file(file_path, file_mtime)
    
    @classmethod
    def load_sheet_data_as_dict(cls, file_path: str) -> Dict:
        """
        加载工作表数据并转换为前端格式
        
        :return: {headers: [], rows: []}
        """
        df = cls.load_sheet_data(file_path)
        
        if df.empty:
            return {'headers': [], 'rows': []}
        
        return {
            'headers': df.columns.tolist(),
            'rows': df.to_dict('records')
        }
    
    @classmethod
    def load_dashboard_data(cls, file_paths: Dict[str, str]) -> Dict[str, Dict]:
        """
        加载整个看板的所有工作表数据
        
        :param file_paths: {sheet_name: file_path, ...}
        :return: {sheet_name: {headers: [], rows: []}, ...}
        """
        result = {}
        
        for sheet_name, file_path in file_paths.items():
            result[sheet_name] = cls.load_sheet_data_as_dict(file_path)
        
        return result
    
    @classmethod
    def find_dashboard_files(cls, file_id: str) -> Dict[str, str]:
        """
        根据 file_id 扫描存储目录找回文件（用于元数据丢失恢复）
        
        :param file_id: 文件ID
        :return: {sheet_name: file_path, ...}
        """
        if not file_id:
            return {}
            
        file_paths = {}
        prefix = f"{file_id}_"
        
        try:
            for filename in os.listdir(DATA_STORAGE_ROOT):
                if filename.startswith(prefix) and (filename.endswith('.parquet') or filename.endswith('.csv')):
                    # 解析 sheet_name
                    # 格式: {file_id}_{sheet_name}.{ext}
                    # 注意 sheet_name 可能包含 _，所以要去掉 prefix 和 suffix
                    ext = '.parquet' if filename.endswith('.parquet') else '.csv'
                    sheet_part = filename[len(prefix):-len(ext)]
                    
                    if sheet_part:
                        # 尝试恢复原始 sheet_name (目前只能恢复 safe_sheet_name)
                        # 如果需要精确恢复，需要在文件名中编码，或者依赖 safe_sheet_name 足够可读
                        file_paths[sheet_part] = os.path.join(DATA_STORAGE_ROOT, filename)
        except Exception as e:
            print(f"Error scanning files for {file_id}: {e}")
            
        return file_paths

    @classmethod
    def delete_dashboard_files(cls, file_paths: Dict[str, str]):
        """删除看板相关的所有数据文件"""
        for file_path in file_paths.values():
            cls._delete_file(file_path)
    
    @classmethod
    def _delete_file(cls, file_path: str):
        """删除单个文件"""
        if os.path.exists(file_path):
            os.remove(file_path)
            cls._invalidate_cache(file_path)
    
    @classmethod
    def _invalidate_cache(cls, file_path: str):
        """清除指定文件的缓存"""
        # LRU 缓存没有直接的删除方法，这里清除整个缓存
        # 生产环境可以使用 Redis 实现更精细的缓存控制
        cls._cached_read_file.cache_clear()
    
    @classmethod
    def get_cache_stats(cls) -> Dict:
        """获取缓存统计信息"""
        cache_info = cls._cached_read_file.cache_info()
        return {
            'hits': cache_info.hits,
            'misses': cache_info.misses,
            'maxsize': cache_info.maxsize,
            'currsize': cache_info.currsize
        }


class DataQueryService:
    """
    数据查询服务
    提供按需加载、列筛选等优化查询功能
    """
    
    @classmethod
    def query_sheet(
        cls, 
        file_path: str, 
        columns: Optional[List[str]] = None,
        filters: Optional[List[Dict]] = None,
        limit: Optional[int] = None,
        offset: int = 0
    ) -> pd.DataFrame:
        """
        按需查询工作表数据
        
        :param file_path: 文件路径
        :param columns: 需要的列（None 表示全部）
        :param filters: 筛选条件
        :param limit: 返回行数限制
        :param offset: 偏移量
        :return: DataFrame
        """
        # Parquet 支持列裁剪（只读取需要的列）
        if file_path.endswith('.parquet') and columns:
            df = pd.read_parquet(file_path, columns=columns)
        else:
            df = DataStorageService.load_sheet_data(file_path)
            if columns:
                existing_cols = [c for c in columns if c in df.columns]
                df = df[existing_cols]
        
        # 应用筛选
        if filters:
            from app.services.chart_service import ChartService
            df = ChartService._apply_filters(df, filters)
        
        # 分页
        if offset > 0:
            df = df.iloc[offset:]
        if limit:
            df = df.head(limit)
        
        return df
    
    @classmethod
    def get_column_stats(cls, file_path: str, column: str) -> Dict:
        """
        获取列的统计信息（用于筛选器下拉选项）
        """
        df = DataStorageService.load_sheet_data(file_path)
        
        if column not in df.columns:
            return {'unique_values': [], 'count': 0}
        
        col_data = df[column]
        
        return {
            'unique_values': col_data.dropna().unique().tolist()[:100],  # 限制 100 个
            'count': len(col_data),
            'null_count': col_data.isna().sum(),
            'dtype': str(col_data.dtype)
        }

