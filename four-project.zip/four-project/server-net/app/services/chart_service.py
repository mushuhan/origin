"""
图表数据处理服务
负责数据计算、聚合和格式化，使用 Pandas 进行向量化操作

优化版本：
1. 支持文件存储的数据读取
2. 添加排序、限制、多维度分组功能
3. 支持图表下钻数据查询
"""
import pandas as pd
import numpy as np
from typing import Dict, List, Optional, Any
from functools import lru_cache


class ChartService:
    """图表数据处理服务"""
    
    @staticmethod
    def process_chart_data(sheet_data: List[Dict], config: Dict) -> Dict:
        """
        处理图表数据（主入口）
        
        :param sheet_data: list of dict, 原始数据
        :param config: dict, 图表配置，支持以下字段：
            - xField: X轴字段
            - yFields: Y轴字段列表
            - aggregation: 聚合方式 (none/sum/avg/max/min/count)
            - filters: 筛选条件列表
            - computedFields: 计算字段列表
            - sort: 排序配置 {field: 'x'/'y'/字段名, order: 'asc'/'desc'}
            - limit: 限制数量 {type: 'top'/'bottom', count: 10}
            - groupField: 分组字段（用于堆叠/分组图表）
        :return: dict, ECharts option series & categories
        """
        if not sheet_data:
            return {'categories': [], 'series': {}, 'meta': {}}
        
        # 1. 转换为 DataFrame
        df = pd.DataFrame(sheet_data)
        
        # 2. 动态计算列 (Computed Fields)
        computed_fields = config.get('computedFields', [])
        for field in computed_fields:
            ChartService._apply_computed_field(df, field)
        
        # 3. 筛选 (Filters)
        filters = config.get('filters', [])
        if filters:
            df = ChartService._apply_filters(df, filters)
        
        if df.empty:
            return {'categories': [], 'series': {}, 'meta': {}}
        
        # 4. 获取配置
        x_field = config.get('xField')
        y_fields = config.get('yFields', [])
        aggregation = config.get('aggregation', 'none')
        group_field = config.get('groupField')  # 新增：分组字段
        sort_config = config.get('sort')  # 新增：排序配置
        limit_config = config.get('limit')  # 新增：限制配置
        
        # 5. 聚合处理
        if group_field and group_field != x_field:
            # 多维度分组（用于堆叠图）
            result = ChartService._aggregate_grouped_data(
                df, x_field, y_fields, group_field, aggregation
            )
        else:
            # 普通聚合
            result = ChartService._aggregate_data(df, x_field, y_fields, aggregation)
        
        # 6. 排序
        if sort_config:
            result = ChartService._apply_sort(result, sort_config, y_fields)
        
        # 7. 限制数量
        if limit_config:
            result = ChartService._apply_limit(result, limit_config)
        
        return result
    
    @staticmethod
    def process_chart_data_from_file(file_path: str, config: Dict) -> Dict:
        """
        从文件读取数据并处理（优化版本，利用缓存）
        
        :param file_path: 数据文件路径
        :param config: 图表配置
        """
        from app.services.data_storage_service import DataStorageService
        
        df = DataStorageService.load_sheet_data(file_path)
        if df.empty:
            return {'categories': [], 'series': {}, 'meta': {}}
        
        return ChartService.process_chart_data(df.to_dict('records'), config)
    
    @staticmethod
    def get_drill_down_data(
        sheet_data: List[Dict], 
        config: Dict,
        drill_params: Dict
    ) -> Dict:
        """
        获取下钻详情数据
        
        :param sheet_data: 原始数据
        :param config: 图表配置
        :param drill_params: 下钻参数
            - xValue: 点击的X轴值（如"一班"）
            - seriesName: 点击的系列名（可选）
            - groupValue: 分组值（可选，用于堆叠图）
        :return: 详情数据 {headers: [], rows: [], total: int}
        """
        if not sheet_data:
            return {'headers': [], 'rows': [], 'total': 0}
        
        df = pd.DataFrame(sheet_data)
        
        # 应用计算字段
        computed_fields = config.get('computedFields', [])
        for field in computed_fields:
            ChartService._apply_computed_field(df, field)
        
        # 应用基础筛选
        filters = config.get('filters', [])
        if filters:
            df = ChartService._apply_filters(df, filters)
        
        # 应用下钻筛选
        x_field = config.get('xField')
        x_value = drill_params.get('xValue')
        group_field = config.get('groupField')
        group_value = drill_params.get('groupValue')
        
        if x_field and x_value is not None:
            # 统一转为字符串比较，并处理浮点数 .0 后缀问题
            x_value_str = str(x_value)
            if x_value_str.endswith('.0'):
                x_value_str = x_value_str[:-2]
            
            # 将 DataFrame 列转换为字符串
            series_str = df[x_field].astype(str)
            
            # 如果列是浮点型，转换后的字符串会带 .0，需要去掉以便匹配
            if df[x_field].dtype in ['float64', 'float32']:
                series_str = series_str.str.replace(r'\.0$', '', regex=True)
                
            df = df[series_str == x_value_str]
        
        if group_field and group_value is not None:
            # 分组字段同理处理
            group_value_str = str(group_value)
            if group_value_str.endswith('.0'):
                group_value_str = group_value_str[:-2]
                
            series_str = df[group_field].astype(str)
            if df[group_field].dtype in ['float64', 'float32']:
                series_str = series_str.str.replace(r'\.0$', '', regex=True)
                
            df = df[series_str == group_value_str]
        
        # 分页参数
        page = drill_params.get('page', 1)
        page_size = drill_params.get('pageSize', 20)
        offset = (page - 1) * page_size
        
        total = len(df)
        df_page = df.iloc[offset:offset + page_size]
        
        return {
            'headers': df.columns.tolist(),
            'rows': df_page.to_dict('records'),
            'total': total,
            'page': page,
            'pageSize': page_size
        }
    
    # 表达式计算允许使用的安全函数白名单
    _SAFE_FUNCTIONS = {
        'abs': np.abs,
        'round': np.round,
        'floor': np.floor,
        'ceil': np.ceil,
        'sqrt': np.sqrt,
        'log': np.log,
        'log10': np.log10,
        'exp': np.exp,
        'sin': np.sin,
        'cos': np.cos,
        'tan': np.tan,
        'min': np.minimum,
        'max': np.maximum,
        'sum': np.sum,
        'mean': np.mean,
        'std': np.std,
        'isna': pd.isna,
        'notna': pd.notna,
        'fillna': lambda x, v: np.where(pd.isna(x), v, x),
    }
    
    # 表达式中禁止的危险关键词
    _FORBIDDEN_KEYWORDS = [
        'import', 'exec', 'eval', 'compile', 'open', 'file', '__',
        'globals', 'locals', 'getattr', 'setattr', 'delattr',
        'os.', 'sys.', 'subprocess', 'shutil', 'pathlib'
    ]
    
    @staticmethod
    def _apply_computed_field(df: pd.DataFrame, rule: Dict):
        """
        应用计算字段规则（支持 Legacy 和 Advanced 两种模式）
        
        Legacy 模式（旧版兼容）:
            配置格式: { "name": "is_qualified", "source": "score", "operator": ">=", "threshold": 60 }
            
        Advanced 模式（表达式计算）:
            配置格式: { "name": "total_price", "expression": "price * quantity", "type": "expression" }
            
        支持的表达式类型:
            - 四则运算: "price * quantity", "(a + b) / 2"
            - 条件表达式: "'High' if score > 90 else 'Normal'"
            - 多条件表达式: "'A' if score >= 90 else ('B' if score >= 80 else 'C')"
            - 日期差计算: 需要 type="date_diff"
        """
        name = rule.get('name')
        if not name:
            print(f"计算字段配置缺少 name 字段")
            return
        
        rule_type = rule.get('type', 'legacy')
        
        try:
            if rule_type == 'expression':
                # Advanced 模式：表达式计算
                ChartService._apply_expression_field(df, rule)
            elif rule_type == 'date_diff':
                # 日期差计算
                ChartService._apply_date_diff_field(df, rule)
            elif rule_type == 'case_when':
                # 多条件分支（类似 SQL CASE WHEN）
                ChartService._apply_case_when_field(df, rule)
            elif rule_type == 'extraction':
                # 字段提取/转换
                ChartService._apply_extraction_field(df, rule)
            else:
                # Legacy 模式：旧版兼容
                ChartService._apply_legacy_computed_field(df, rule)
        except Exception as e:
            print(f"计算字段 {name} 失败: {type(e).__name__}: {e}")
    
    @staticmethod
    def _validate_expression(expression: str) -> bool:
        """验证表达式安全性"""
        expr_lower = expression.lower()
        for keyword in ChartService._FORBIDDEN_KEYWORDS:
            if keyword in expr_lower:
                raise ValueError(f"表达式包含禁止的关键词: {keyword}")
        return True
    
    @staticmethod
    def _apply_legacy_computed_field(df: pd.DataFrame, rule: Dict):
        """
        Legacy 模式：旧版计算字段逻辑（保持兼容性）
        
        配置示例:
        {
            "name": "is_qualified",
            "source": "score",
            "operator": ">=",
            "threshold": 60
        }
        """
        name = rule.get('name')
        source = rule.get('source')
        op = rule.get('operator')
        threshold = rule.get('threshold')
        
        if not source or source not in df.columns:
            print(f"计算字段 {name}: 源字段 '{source}' 不存在")
            return
        
        source_vals = pd.to_numeric(df[source], errors='coerce').fillna(0)
        threshold_val = float(threshold) if threshold is not None else 0
        
        ops = {
            '>=': lambda x: x >= threshold_val,
            '<=': lambda x: x <= threshold_val,
            '==': lambda x: x == threshold_val,
            '>': lambda x: x > threshold_val,
            '<': lambda x: x < threshold_val,
            '!=': lambda x: x != threshold_val
        }
        
        if op in ops:
            df[name] = ops[op](source_vals).astype(int)
        else:
            print(f"计算字段 {name}: 不支持的操作符 '{op}'")
    
    @staticmethod
    def _apply_expression_field(df: pd.DataFrame, rule: Dict):
        """
        Advanced 模式：表达式计算
        
        支持两种表达式语法：
        1. 简单四则运算（使用 pd.eval 加速）:
           { "name": "total", "expression": "price * quantity", "type": "expression" }
           
        2. 条件表达式（使用 np.where/np.select）:
           { "name": "level", "expression": "'High' if score > 90 else 'Normal'", "type": "expression" }
        """
        name = rule.get('name')
        expression = rule.get('expression', '')
        
        if not expression:
            print(f"计算字段 {name}: 缺少 expression 配置")
            return
        
        # 安全性验证
        ChartService._validate_expression(expression)
        
        # 检测表达式类型
        if ' if ' in expression and ' else ' in expression:
            # 条件表达式
            ChartService._apply_conditional_expression(df, name, expression)
        else:
            # 简单四则运算 - 使用 pd.eval 进行向量化计算
            ChartService._apply_arithmetic_expression(df, name, expression)
    
    @staticmethod
    def _apply_arithmetic_expression(df: pd.DataFrame, name: str, expression: str):
        """
        应用四则运算表达式（使用 pd.eval 向量化计算）
        
        示例表达式:
        - "price * quantity"
        - "(revenue - cost) / revenue * 100"
        - "column_a + column_b + column_c"
        """
        try:
            # 首先尝试使用 df.eval()，性能最好
            df[name] = df.eval(expression)
        except Exception as eval_error:
            # 如果 eval 失败，尝试手动解析
            try:
                # 构建局部变量字典，包含 DataFrame 的所有列
                local_dict = {col: df[col] for col in df.columns}
                # 添加安全函数
                local_dict.update(ChartService._SAFE_FUNCTIONS)
                local_dict['np'] = np
                local_dict['pd'] = pd
                
                # 使用 pd.eval 计算
                result = pd.eval(expression, local_dict=local_dict)
                df[name] = result
            except Exception as e:
                print(f"四则运算表达式 '{expression}' 计算失败: {e}")
                raise
    
    @staticmethod
    def _apply_conditional_expression(df: pd.DataFrame, name: str, expression: str):
        """
        应用条件表达式（支持嵌套三元表达式）
        
        示例表达式:
        - "'High' if score > 90 else 'Normal'"
        - "'A' if score >= 90 else ('B' if score >= 80 else 'C')"
        - "price * 0.9 if quantity > 100 else price"
        """
        try:
            # 解析条件表达式
            conditions, values, default = ChartService._parse_conditional_expression(expression)
            
            # 构建局部变量字典
            local_dict = {col: df[col] for col in df.columns}
            local_dict.update(ChartService._SAFE_FUNCTIONS)
            local_dict['np'] = np
            local_dict['pd'] = pd
            
            if len(conditions) == 1:
                # 简单条件：使用 np.where
                cond_result = pd.eval(conditions[0], local_dict=local_dict)
                true_val = ChartService._eval_value(values[0], local_dict)
                false_val = ChartService._eval_value(default, local_dict)
                df[name] = np.where(cond_result, true_val, false_val)
            else:
                # 多条件：使用 np.select
                cond_arrays = [pd.eval(c, local_dict=local_dict) for c in conditions]
                val_arrays = [ChartService._eval_value(v, local_dict) for v in values]
                default_val = ChartService._eval_value(default, local_dict)
                df[name] = np.select(cond_arrays, val_arrays, default=default_val)
                
        except Exception as e:
            print(f"条件表达式 '{expression}' 解析失败: {e}")
            raise
    
    @staticmethod
    def _parse_conditional_expression(expression: str) -> tuple:
        """
        解析条件表达式，提取条件、值和默认值
        
        支持格式:
        - "value_if_true if condition else value_if_false"
        - "val1 if cond1 else (val2 if cond2 else val3)"
        
        返回: (conditions_list, values_list, default_value)
        """
        conditions = []
        values = []
        default = None
        
        # 简单解析：处理嵌套的条件表达式
        current = expression.strip()
        
        while ' if ' in current and ' else ' in current:
            # 找到第一个 if 和对应的 else
            if_pos = current.find(' if ')
            
            # 找到对应的 else（需要处理嵌套括号）
            else_pos = ChartService._find_matching_else(current, if_pos)
            
            if else_pos == -1:
                break
            
            # 提取各部分
            value_part = current[:if_pos].strip()
            condition_part = current[if_pos + 4:else_pos].strip()
            rest_part = current[else_pos + 6:].strip()
            
            conditions.append(condition_part)
            values.append(value_part)
            
            # 处理剩余部分
            if rest_part.startswith('(') and rest_part.endswith(')'):
                current = rest_part[1:-1].strip()
            else:
                default = rest_part
                break
        else:
            if default is None:
                default = current
        
        return conditions, values, default
    
    @staticmethod
    def _find_matching_else(expr: str, if_pos: int) -> int:
        """找到与 if 匹配的 else 位置（处理嵌套）"""
        depth = 0
        i = if_pos + 4
        while i < len(expr):
            if expr[i] == '(':
                depth += 1
            elif expr[i] == ')':
                depth -= 1
            elif expr[i:i+6] == ' else ' and depth == 0:
                return i
            i += 1
        return -1
    
    @staticmethod
    def _eval_value(value_expr: str, local_dict: dict):
        """计算值表达式（可能是常量、字符串或表达式）"""
        value_expr = value_expr.strip()
        
        # 检查是否是字符串常量
        if (value_expr.startswith("'") and value_expr.endswith("'")) or \
           (value_expr.startswith('"') and value_expr.endswith('"')):
            return value_expr[1:-1]
        
        # 检查是否是数值常量
        try:
            if '.' in value_expr:
                return float(value_expr)
            return int(value_expr)
        except ValueError:
            pass
        
        # 否则当作表达式计算
        try:
            return pd.eval(value_expr, local_dict=local_dict)
        except:
            # 最后尝试直接从 local_dict 获取
            if value_expr in local_dict:
                return local_dict[value_expr]
            return value_expr
    
    @staticmethod
    def _apply_date_diff_field(df: pd.DataFrame, rule: Dict):
        """
        日期差计算
        
        配置示例:
        {
            "name": "days_since",
            "type": "date_diff",
            "start_date": "order_date",
            "end_date": "delivery_date",  # 可选，默认为当前日期
            "unit": "days"  # days/hours/minutes/seconds
        }
        """
        name = rule.get('name')
        start_date_col = rule.get('start_date')
        end_date_col = rule.get('end_date')
        unit = rule.get('unit', 'days')
        
        if not start_date_col or start_date_col not in df.columns:
            print(f"日期差计算 {name}: 起始日期字段 '{start_date_col}' 不存在")
            return
        
        # 转换为日期类型
        start_dates = pd.to_datetime(df[start_date_col], errors='coerce')
        
        if end_date_col and end_date_col in df.columns:
            end_dates = pd.to_datetime(df[end_date_col], errors='coerce')
        else:
            # 默认使用当前日期
            end_dates = pd.Timestamp.now()
        
        # 计算差值
        diff = end_dates - start_dates
        
        # 根据单位转换
        unit_map = {
            'days': lambda d: d.dt.days,
            'hours': lambda d: d.dt.total_seconds() / 3600,
            'minutes': lambda d: d.dt.total_seconds() / 60,
            'seconds': lambda d: d.dt.total_seconds()
        }
        
        if unit in unit_map:
            df[name] = unit_map[unit](diff)
        else:
            df[name] = diff.dt.days
    
    @staticmethod
    def _apply_case_when_field(df: pd.DataFrame, rule: Dict):
        """
        多条件分支计算（类似 SQL CASE WHEN）
        
        配置示例:
        {
            "name": "grade",
            "type": "case_when",
            "cases": [
                {"when": "score >= 90", "then": "'A'"},
                {"when": "score >= 80", "then": "'B'"},
                {"when": "score >= 70", "then": "'C'"},
                {"when": "score >= 60", "then": "'D'"}
            ],
            "default": "'F'"
        }
        """
        name = rule.get('name')
        cases = rule.get('cases', [])
        default_value = rule.get('default', 'None')
        
        if not cases:
            print(f"CASE WHEN 计算 {name}: 缺少 cases 配置")
            return
        
        # 构建局部变量字典
        local_dict = {col: df[col] for col in df.columns}
        local_dict.update(ChartService._SAFE_FUNCTIONS)
        local_dict['np'] = np
        local_dict['pd'] = pd
        
        # 构建条件数组和值数组
        conditions = []
        values = []
        
        for case in cases:
            when_expr = case.get('when', '')
            then_expr = case.get('then', '')
            
            if not when_expr:
                continue
            
            # 安全性验证
            ChartService._validate_expression(when_expr)
            ChartService._validate_expression(then_expr)
            
            # 计算条件
            cond = pd.eval(when_expr, local_dict=local_dict)
            conditions.append(cond)
            
            # 计算值
            val = ChartService._eval_value(then_expr, local_dict)
            values.append(val)
        
        # 计算默认值
        default_val = ChartService._eval_value(default_value, local_dict)
        
        # 使用 np.select 应用多条件
        df[name] = np.select(conditions, values, default=default_val)
    
    @staticmethod
    def _apply_extraction_field(df: pd.DataFrame, rule: Dict):
        """
        字段提取/转换
        
        配置示例:
        {
            "name": "year",
            "type": "extraction",
            "source": "birth_date",
            "method": "year",  # year/month/day/quarter/week/substr
            "params": { "start": 0, "length": 4 } # 仅 substr 需要
        }
        """
        name = rule.get('name')
        source = rule.get('source')
        method = rule.get('method')
        
        if not source or source not in df.columns:
            print(f"提取字段 {name}: 源字段 '{source}' 不存在")
            return
            
        try:
            if method in ['year', 'month', 'day', 'quarter', 'week']:
                # 日期提取
                # 先尝试转换为日期，无效值设为 NaT
                dates = pd.to_datetime(df[source], errors='coerce')
                
                if method == 'year':
                    # 提取年份，填充为0然后转字符串，最后把'0'替换为空字符串
                    df[name] = dates.dt.year.fillna(0).astype(int).astype(str).replace('0', '')
                elif method == 'month':
                    df[name] = dates.dt.month.fillna(0).astype(int).astype(str).replace('0', '')
                elif method == 'day':
                    df[name] = dates.dt.day.fillna(0).astype(int).astype(str).replace('0', '')
                elif method == 'quarter':
                    df[name] = dates.dt.quarter.fillna(0).astype(int).astype(str).replace('0', '')
                elif method == 'week':
                    # isocalendar().week 返回的是 UInt32，fillna 需要处理
                    week_series = dates.dt.isocalendar().week
                    # 将 NAT/NaN 填充为 0
                    if pd.isna(week_series).any():
                        week_series = week_series.fillna(0)
                    df[name] = week_series.astype(int).astype(str).replace('0', '')
                    
            elif method == 'substr':
                # 字符串截取
                params = rule.get('params', {})
                start = int(params.get('start', 0))
                length = int(params.get('length', 0))
                
                # 转为字符串
                series_str = df[source].astype(str)
                
                if length > 0:
                    df[name] = series_str.str.slice(start, start + length)
                else:
                    df[name] = series_str.str.slice(start)
            else:
                print(f"提取字段 {name}: 不支持的方法 '{method}'")
                
        except Exception as e:
            print(f"提取字段 {name} 失败: {e}")
            df[name] = ''

    @staticmethod
    def _apply_filters(df: pd.DataFrame, filters: List[Dict]) -> pd.DataFrame:
        """应用筛选条件"""
        for f in filters:
            field = f.get('field')
            op = f.get('operator')
            val = f.get('value')
            
            if not field or field not in df.columns:
                continue
            
            try:
                if op in ['eq', 'neq']:
                    # 字符串或数值相等比较
                    str_match = df[field].astype(str) == str(val)
                    try:
                        num_val = float(val)
                        num_series = pd.to_numeric(df[field], errors='coerce')
                        num_match = num_series == num_val
                        if op == 'eq':
                            df = df[str_match | num_match]
                        else:
                            df = df[~(str_match | num_match)]
                    except:
                        if op == 'eq':
                            df = df[str_match]
                        else:
                            df = df[~str_match]
                
                elif op in ['gt', 'gte', 'lt', 'lte']:
                    series = pd.to_numeric(df[field], errors='coerce')
                    target = float(val) if val else 0
                    
                    ops = {
                        'gt': lambda s: s > target,
                        'gte': lambda s: s >= target,
                        'lt': lambda s: s < target,
                        'lte': lambda s: s <= target
                    }
                    df = df[ops[op](series)]
                
                elif op == 'contains':
                    df = df[df[field].astype(str).str.contains(str(val), na=False, case=False)]
                elif op == 'notContains':
                    df = df[~df[field].astype(str).str.contains(str(val), na=False, case=False)]
                elif op == 'empty':
                    df = df[df[field].isna() | (df[field].astype(str).str.strip() == '')]
                elif op == 'notEmpty':
                    df = df[df[field].notna() & (df[field].astype(str).str.strip() != '')]
                elif op == 'in':
                    # 新增：in 操作符
                    values = val if isinstance(val, list) else str(val).split(',')
                    df = df[df[field].astype(str).isin([str(v).strip() for v in values])]
                elif op == 'notIn':
                    values = val if isinstance(val, list) else str(val).split(',')
                    df = df[~df[field].astype(str).isin([str(v).strip() for v in values])]
            except Exception as e:
                print(f"筛选条件应用失败: {field} {op} {val}, 错误: {e}")
                continue
        
        return df
    
    @staticmethod
    def _aggregate_data(
        df: pd.DataFrame, 
        x_field: str, 
        y_fields: List[str], 
        aggregation: str
    ) -> Dict:
        """普通聚合数据"""
        meta = {}
        
        if aggregation == 'none' or not x_field:
            # 不聚合
            categories = df[x_field].astype(str).tolist() if x_field else df.index.astype(str).tolist()
            series = {}
            for f in y_fields:
                if f in df.columns:
                    series[f] = pd.to_numeric(df[f], errors='coerce').fillna(0).round(2).tolist()
                    meta[f] = {'isRate': False}
                else:
                    series[f] = [0] * len(categories)
                    meta[f] = {'isRate': False}
            
            return {'categories': categories, 'series': series, 'meta': meta}
        
        # 转换 Y 轴字段为数值
        for f in y_fields:
            if f in df.columns:
                df[f] = pd.to_numeric(df[f], errors='coerce').fillna(0)
        
        # 分组聚合
        grouped = df.groupby(x_field, sort=False)
        result_series = {}
        
        for f in y_fields:
            if f not in df.columns:
                continue
            
            is_boolean = df[f].isin([0, 1]).all()
            meta[f] = {'isRate': is_boolean and aggregation == 'avg'}
            
            if aggregation == 'sum':
                series_data = grouped[f].sum()
            elif aggregation == 'avg':
                series_data = grouped[f].mean()
                if is_boolean:
                    series_data = series_data * 100
            elif aggregation == 'max':
                series_data = grouped[f].max()
            elif aggregation == 'min':
                series_data = grouped[f].min()
            elif aggregation == 'count':
                series_data = grouped[f].count()
            else:
                series_data = grouped[f].sum()
            
            result_series[f] = series_data.round(2).tolist()
        
        categories = list(grouped.groups.keys())
        categories = [str(c) for c in categories]
        
        return {
            'categories': categories,
            'series': result_series,
            'meta': meta
        }
    
    @staticmethod
    def _aggregate_grouped_data(
        df: pd.DataFrame,
        x_field: str,
        y_fields: List[str],
        group_field: str,
        aggregation: str
    ) -> Dict:
        """
        多维度分组聚合（用于堆叠图）
        
        返回格式：
        {
            categories: ['1月', '2月', ...],
            series: {
                '产品A': [100, 200, ...],
                '产品B': [150, 180, ...]
            },
            groupField: 'product_type',
            meta: {...}
        }
        """
        meta = {}
        
        if not x_field or not group_field:
            return ChartService._aggregate_data(df, x_field, y_fields, aggregation)
        
        # 转换 Y 轴字段为数值
        y_field = y_fields[0] if y_fields else None
        if not y_field or y_field not in df.columns:
            return {'categories': [], 'series': {}, 'meta': {}, 'groupField': group_field}
        
        df[y_field] = pd.to_numeric(df[y_field], errors='coerce').fillna(0)
        
        # 判断是否为比率
        is_boolean = df[y_field].isin([0, 1]).all()
        
        # 双重分组
        if aggregation == 'none':
            pivot = df.pivot_table(
                index=x_field,
                columns=group_field,
                values=y_field,
                aggfunc='first'
            )
        else:
            agg_func = {
                'sum': 'sum', 'avg': 'mean', 'max': 'max', 
                'min': 'min', 'count': 'count'
            }.get(aggregation, 'sum')
            
            pivot = df.pivot_table(
                index=x_field,
                columns=group_field,
                values=y_field,
                aggfunc=agg_func,
                fill_value=0
            )
            
            if aggregation == 'avg' and is_boolean:
                pivot = pivot * 100
        
        # 构建结果
        categories = [str(c) for c in pivot.index.tolist()]
        series = {}
        
        for col in pivot.columns:
            col_name = str(col)
            series[col_name] = pivot[col].round(2).tolist()
            meta[col_name] = {'isRate': is_boolean and aggregation == 'avg'}
        
        return {
            'categories': categories,
            'series': series,
            'meta': meta,
            'groupField': group_field,
            'isGrouped': True
        }
    
    @staticmethod
    def _apply_sort(result: Dict, sort_config: Dict, y_fields: List[str]) -> Dict:
        """
        应用排序
        
        :param sort_config: {field: 'x'/'y'/字段名, order: 'asc'/'desc'}
        """
        if not result.get('categories'):
            return result
        
        sort_field = sort_config.get('field', 'x')
        sort_order = sort_config.get('order', 'asc')
        ascending = sort_order == 'asc'
        
        categories = result['categories']
        series = result['series']
        n = len(categories)
        
        if sort_field == 'x':
            # 按 X 轴（类别名）排序
            indices = sorted(range(n), key=lambda i: str(categories[i]), reverse=not ascending)
        elif sort_field == 'y' and y_fields:
            # 按第一个 Y 轴字段排序
            first_y = y_fields[0]
            if first_y in series:
                indices = sorted(range(n), key=lambda i: series[first_y][i], reverse=not ascending)
            else:
                return result
        elif sort_field in series:
            # 按指定字段排序
            indices = sorted(range(n), key=lambda i: series[sort_field][i], reverse=not ascending)
        else:
            return result
        
        # 重新排列
        result['categories'] = [categories[i] for i in indices]
        for key in series:
            result['series'][key] = [series[key][i] for i in indices]
        
        return result
    
    @staticmethod
    def _apply_limit(result: Dict, limit_config: Dict) -> Dict:
        """
        应用数量限制
        
        :param limit_config: {type: 'top'/'bottom', count: 10}
        """
        if not result.get('categories'):
            return result
        
        limit_type = limit_config.get('type', 'top')
        count = int(limit_config.get('count', 10))
        
        categories = result['categories']
        series = result['series']
        n = len(categories)
        
        if count >= n:
            return result
        
        if limit_type == 'top':
            # 取前 N 个
            result['categories'] = categories[:count]
            for key in series:
                result['series'][key] = series[key][:count]
        else:
            # 取后 N 个
            result['categories'] = categories[-count:]
            for key in series:
                result['series'][key] = series[key][-count:]
        
        return result
    
    @staticmethod
    def get_field_unique_values(sheet_data: List[Dict], field: str, limit: int = 100) -> List:
        """获取字段的唯一值（用于筛选器下拉）"""
        if not sheet_data or not field:
            return []
        
        df = pd.DataFrame(sheet_data)
        if field not in df.columns:
            return []
        
        return df[field].dropna().unique().tolist()[:limit]
