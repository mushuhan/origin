"""
图表数据处理服务
负责数据计算、聚合和格式化，使用 Pandas 进行向量化操作

优化版本：
1. 支持文件存储的数据读取
2. 添加排序、限制、多维度分组功能
3. 支持图表下钻数据查询
"""
import pandas as pd
import numpy as np
from typing import Dict, List, Optional, Any
from functools import lru_cache


class ChartService:
    """图表数据处理服务"""
    
    @staticmethod
    def process_chart_data(sheet_data: List[Dict], config: Dict) -> Dict:
        """
        处理图表数据（主入口）
        
        :param sheet_data: list of dict, 原始数据
        :param config: dict, 图表配置，支持以下字段：
            - xField: X轴字段
            - yFields: Y轴字段列表
            - aggregation: 聚合方式 (none/sum/avg/max/min/count)
            - filters: 筛选条件列表
            - computedFields: 计算字段列表
            - sort: 排序配置 {field: 'x'/'y'/字段名, order: 'asc'/'desc'}
            - limit: 限制数量 {type: 'top'/'bottom', count: 10}
            - groupField: 分组字段（用于堆叠/分组图表）
        :return: dict, ECharts option series & categories
        """
        if not sheet_data:
            return {'categories': [], 'series': {}, 'meta': {}}
        
        # 1. 转换为 DataFrame
        df = pd.DataFrame(sheet_data)
        
        # 2. 动态计算列 (Computed Fields)
        computed_fields = config.get('computedFields', [])
        for field in computed_fields:
            ChartService._apply_computed_field(df, field)
        
        # 3. 筛选 (Filters)
        filters = config.get('filters', [])
        if filters:
            df = ChartService._apply_filters(df, filters)
        
        if df.empty:
            return {'categories': [], 'series': {}, 'meta': {}}
        
        # 4. 获取配置
        x_field = config.get('xField')
        y_fields = config.get('yFields', [])
        aggregation = config.get('aggregation', 'none')
        group_field = config.get('groupField')  # 新增：分组字段
        sort_config = config.get('sort')  # 新增：排序配置
        limit_config = config.get('limit')  # 新增：限制配置
        
        # 5. 聚合处理
        if group_field and group_field != x_field:
            # 多维度分组（用于堆叠图）
            result = ChartService._aggregate_grouped_data(
                df, x_field, y_fields, group_field, aggregation
            )
        else:
            # 普通聚合
            result = ChartService._aggregate_data(df, x_field, y_fields, aggregation)
        
        # 6. 排序
        if sort_config:
            result = ChartService._apply_sort(result, sort_config, y_fields)
        
        # 7. 限制数量
        if limit_config:
            result = ChartService._apply_limit(result, limit_config)
        
        return result
    
    @staticmethod
    def process_chart_data_from_file(file_path: str, config: Dict) -> Dict:
        """
        从文件读取数据并处理（优化版本，利用缓存）
        
        :param file_path: 数据文件路径
        :param config: 图表配置
        """
        from app.services.data_storage_service import DataStorageService
        
        df = DataStorageService.load_sheet_data(file_path)
        if df.empty:
            return {'categories': [], 'series': {}, 'meta': {}}
        
        return ChartService.process_chart_data(df.to_dict('records'), config)
    
    @staticmethod
    def get_drill_down_data(
        sheet_data: List[Dict], 
        config: Dict,
        drill_params: Dict
    ) -> Dict:
        """
        获取下钻详情数据
        
        :param sheet_data: 原始数据
        :param config: 图表配置
        :param drill_params: 下钻参数
            - xValue: 点击的X轴值（如"一班"）
            - seriesName: 点击的系列名（可选）
            - groupValue: 分组值（可选，用于堆叠图）
        :return: 详情数据 {headers: [], rows: [], total: int}
        """
        if not sheet_data:
            return {'headers': [], 'rows': [], 'total': 0}
        
        df = pd.DataFrame(sheet_data)
        
        # 应用计算字段
        computed_fields = config.get('computedFields', [])
        for field in computed_fields:
            ChartService._apply_computed_field(df, field)
        
        # 应用基础筛选
        filters = config.get('filters', [])
        if filters:
            df = ChartService._apply_filters(df, filters)
        
        # 应用下钻筛选
        x_field = config.get('xField')
        x_value = drill_params.get('xValue')
        group_field = config.get('groupField')
        group_value = drill_params.get('groupValue')
        
        if x_field and x_value is not None:
            # 处理数值和字符串的匹配
            if df[x_field].dtype in ['int64', 'float64']:
                try:
                    x_value = float(x_value)
                except:
                    pass
            df = df[df[x_field].astype(str) == str(x_value)]
        
        if group_field and group_value is not None:
            df = df[df[group_field].astype(str) == str(group_value)]
        
        # 分页参数
        page = drill_params.get('page', 1)
        page_size = drill_params.get('pageSize', 20)
        offset = (page - 1) * page_size
        
        total = len(df)
        df_page = df.iloc[offset:offset + page_size]
        
        return {
            'headers': df.columns.tolist(),
            'rows': df_page.to_dict('records'),
            'total': total,
            'page': page,
            'pageSize': page_size
        }
    
    @staticmethod
    def _apply_computed_field(df: pd.DataFrame, rule: Dict):
        """应用计算字段规则"""
        name = rule.get('name')
        source = rule.get('source')
        op = rule.get('operator')
        threshold = rule.get('threshold')
        
        if not name or not source or source not in df.columns:
            return
        
        try:
            source_vals = pd.to_numeric(df[source], errors='coerce').fillna(0)
            threshold_val = float(threshold)
            
            ops = {
                '>=': lambda x: x >= threshold_val,
                '<=': lambda x: x <= threshold_val,
                '==': lambda x: x == threshold_val,
                '>': lambda x: x > threshold_val,
                '<': lambda x: x < threshold_val,
                '!=': lambda x: x != threshold_val
            }
            
            if op in ops:
                df[name] = ops[op](source_vals).astype(int)
        except Exception as e:
            print(f"计算字段 {name} 失败: {e}")
    
    @staticmethod
    def _apply_filters(df: pd.DataFrame, filters: List[Dict]) -> pd.DataFrame:
        """应用筛选条件"""
        for f in filters:
            field = f.get('field')
            op = f.get('operator')
            val = f.get('value')
            
            if not field or field not in df.columns:
                continue
            
            try:
                if op in ['eq', 'neq']:
                    # 字符串或数值相等比较
                    str_match = df[field].astype(str) == str(val)
                    try:
                        num_val = float(val)
                        num_series = pd.to_numeric(df[field], errors='coerce')
                        num_match = num_series == num_val
                        if op == 'eq':
                            df = df[str_match | num_match]
                        else:
                            df = df[~(str_match | num_match)]
                    except:
                        if op == 'eq':
                            df = df[str_match]
                        else:
                            df = df[~str_match]
                
                elif op in ['gt', 'gte', 'lt', 'lte']:
                    series = pd.to_numeric(df[field], errors='coerce')
                    target = float(val) if val else 0
                    
                    ops = {
                        'gt': lambda s: s > target,
                        'gte': lambda s: s >= target,
                        'lt': lambda s: s < target,
                        'lte': lambda s: s <= target
                    }
                    df = df[ops[op](series)]
                
                elif op == 'contains':
                    df = df[df[field].astype(str).str.contains(str(val), na=False, case=False)]
                elif op == 'notContains':
                    df = df[~df[field].astype(str).str.contains(str(val), na=False, case=False)]
                elif op == 'empty':
                    df = df[df[field].isna() | (df[field].astype(str).str.strip() == '')]
                elif op == 'notEmpty':
                    df = df[df[field].notna() & (df[field].astype(str).str.strip() != '')]
                elif op == 'in':
                    # 新增：in 操作符
                    values = val if isinstance(val, list) else str(val).split(',')
                    df = df[df[field].astype(str).isin([str(v).strip() for v in values])]
                elif op == 'notIn':
                    values = val if isinstance(val, list) else str(val).split(',')
                    df = df[~df[field].astype(str).isin([str(v).strip() for v in values])]
            except Exception as e:
                print(f"筛选条件应用失败: {field} {op} {val}, 错误: {e}")
                continue
        
        return df
    
    @staticmethod
    def _aggregate_data(
        df: pd.DataFrame, 
        x_field: str, 
        y_fields: List[str], 
        aggregation: str
    ) -> Dict:
        """普通聚合数据"""
        meta = {}
        
        if aggregation == 'none' or not x_field:
            # 不聚合
            categories = df[x_field].astype(str).tolist() if x_field else df.index.astype(str).tolist()
            series = {}
            for f in y_fields:
                if f in df.columns:
                    series[f] = pd.to_numeric(df[f], errors='coerce').fillna(0).round(2).tolist()
                    meta[f] = {'isRate': False}
                else:
                    series[f] = [0] * len(categories)
                    meta[f] = {'isRate': False}
            
            return {'categories': categories, 'series': series, 'meta': meta}
        
        # 转换 Y 轴字段为数值
        for f in y_fields:
            if f in df.columns:
                df[f] = pd.to_numeric(df[f], errors='coerce').fillna(0)
        
        # 分组聚合
        grouped = df.groupby(x_field, sort=False)
        result_series = {}
        
        for f in y_fields:
            if f not in df.columns:
                continue
            
            is_boolean = df[f].isin([0, 1]).all()
            meta[f] = {'isRate': is_boolean and aggregation == 'avg'}
            
            if aggregation == 'sum':
                series_data = grouped[f].sum()
            elif aggregation == 'avg':
                series_data = grouped[f].mean()
                if is_boolean:
                    series_data = series_data * 100
            elif aggregation == 'max':
                series_data = grouped[f].max()
            elif aggregation == 'min':
                series_data = grouped[f].min()
            elif aggregation == 'count':
                series_data = grouped[f].count()
            else:
                series_data = grouped[f].sum()
            
            result_series[f] = series_data.round(2).tolist()
        
        categories = list(grouped.groups.keys())
        categories = [str(c) for c in categories]
        
        return {
            'categories': categories,
            'series': result_series,
            'meta': meta
        }
    
    @staticmethod
    def _aggregate_grouped_data(
        df: pd.DataFrame,
        x_field: str,
        y_fields: List[str],
        group_field: str,
        aggregation: str
    ) -> Dict:
        """
        多维度分组聚合（用于堆叠图）
        
        返回格式：
        {
            categories: ['1月', '2月', ...],
            series: {
                '产品A': [100, 200, ...],
                '产品B': [150, 180, ...]
            },
            groupField: 'product_type',
            meta: {...}
        }
        """
        meta = {}
        
        if not x_field or not group_field:
            return ChartService._aggregate_data(df, x_field, y_fields, aggregation)
        
        # 转换 Y 轴字段为数值
        y_field = y_fields[0] if y_fields else None
        if not y_field or y_field not in df.columns:
            return {'categories': [], 'series': {}, 'meta': {}, 'groupField': group_field}
        
        df[y_field] = pd.to_numeric(df[y_field], errors='coerce').fillna(0)
        
        # 判断是否为比率
        is_boolean = df[y_field].isin([0, 1]).all()
        
        # 双重分组
        if aggregation == 'none':
            pivot = df.pivot_table(
                index=x_field,
                columns=group_field,
                values=y_field,
                aggfunc='first'
            )
        else:
            agg_func = {
                'sum': 'sum', 'avg': 'mean', 'max': 'max', 
                'min': 'min', 'count': 'count'
            }.get(aggregation, 'sum')
            
            pivot = df.pivot_table(
                index=x_field,
                columns=group_field,
                values=y_field,
                aggfunc=agg_func,
                fill_value=0
            )
            
            if aggregation == 'avg' and is_boolean:
                pivot = pivot * 100
        
        # 构建结果
        categories = [str(c) for c in pivot.index.tolist()]
        series = {}
        
        for col in pivot.columns:
            col_name = str(col)
            series[col_name] = pivot[col].round(2).tolist()
            meta[col_name] = {'isRate': is_boolean and aggregation == 'avg'}
        
        return {
            'categories': categories,
            'series': series,
            'meta': meta,
            'groupField': group_field,
            'isGrouped': True
        }
    
    @staticmethod
    def _apply_sort(result: Dict, sort_config: Dict, y_fields: List[str]) -> Dict:
        """
        应用排序
        
        :param sort_config: {field: 'x'/'y'/字段名, order: 'asc'/'desc'}
        """
        if not result.get('categories'):
            return result
        
        sort_field = sort_config.get('field', 'x')
        sort_order = sort_config.get('order', 'asc')
        ascending = sort_order == 'asc'
        
        categories = result['categories']
        series = result['series']
        n = len(categories)
        
        if sort_field == 'x':
            # 按 X 轴（类别名）排序
            indices = sorted(range(n), key=lambda i: str(categories[i]), reverse=not ascending)
        elif sort_field == 'y' and y_fields:
            # 按第一个 Y 轴字段排序
            first_y = y_fields[0]
            if first_y in series:
                indices = sorted(range(n), key=lambda i: series[first_y][i], reverse=not ascending)
            else:
                return result
        elif sort_field in series:
            # 按指定字段排序
            indices = sorted(range(n), key=lambda i: series[sort_field][i], reverse=not ascending)
        else:
            return result
        
        # 重新排列
        result['categories'] = [categories[i] for i in indices]
        for key in series:
            result['series'][key] = [series[key][i] for i in indices]
        
        return result
    
    @staticmethod
    def _apply_limit(result: Dict, limit_config: Dict) -> Dict:
        """
        应用数量限制
        
        :param limit_config: {type: 'top'/'bottom', count: 10}
        """
        if not result.get('categories'):
            return result
        
        limit_type = limit_config.get('type', 'top')
        count = int(limit_config.get('count', 10))
        
        categories = result['categories']
        series = result['series']
        n = len(categories)
        
        if count >= n:
            return result
        
        if limit_type == 'top':
            # 取前 N 个
            result['categories'] = categories[:count]
            for key in series:
                result['series'][key] = series[key][:count]
        else:
            # 取后 N 个
            result['categories'] = categories[-count:]
            for key in series:
                result['series'][key] = series[key][-count:]
        
        return result
    
    @staticmethod
    def get_field_unique_values(sheet_data: List[Dict], field: str, limit: int = 100) -> List:
        """获取字段的唯一值（用于筛选器下拉）"""
        if not sheet_data or not field:
            return []
        
        df = pd.DataFrame(sheet_data)
        if field not in df.columns:
            return []
        
        return df[field].dropna().unique().tolist()[:limit]
