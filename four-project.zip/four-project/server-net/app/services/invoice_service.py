# -*- coding: utf-8 -*-
"""
发票服务 - OCR 提取和校验逻辑
支持从图片/PDF中提取发票信息并与标准库比对
"""
import re
import io
import os
import shutil
from typing import List, Dict, Tuple, Optional


def get_tesseract_path():
    """
    获取 Tesseract 可执行文件路径
    优先级：环境变量 TESSERACT_CMD > 常见安装路径 > PATH
    """
    # 1. 检查环境变量
    env_path = os.environ.get('TESSERACT_CMD')
    if env_path and os.path.isfile(env_path):
        return env_path
    
    # 2. Windows 常见安装路径
    common_paths = [
        r'C:\Program Files\Tesseract-OCR\tesseract.exe',
        r'C:\Program Files (x86)\Tesseract-OCR\tesseract.exe',
        r'C:\Tesseract-OCR\tesseract.exe',
        os.path.expanduser(r'~\AppData\Local\Tesseract-OCR\tesseract.exe'),
    ]
    
    for path in common_paths:
        if os.path.isfile(path):
            return path
    
    # 3. 检查 PATH
    tesseract_in_path = shutil.which('tesseract')
    if tesseract_in_path:
        return tesseract_in_path
    
    return None


# 初始化 Tesseract 路径
TESSERACT_PATH = get_tesseract_path()

# 图片处理最小分辨率阈值（宽度），低于此值需要放大
IMAGE_MIN_WIDTH_THRESHOLD = 1200
# 图片放大目标分辨率
IMAGE_TARGET_WIDTH = 2400


class InvoiceOCRService:
    """
    发票 OCR 服务
    使用正则表达式提取发票关键信息
    如需更高精度，可替换为 PaddleOCR
    """
    
    # 税号正则：固定18位，以1、5、9开头的数字/字母组合
    TAX_NUMBER_PATTERN = re.compile(r'[159][0-9A-Z]{17}')
    
    # 宽松匹配模式（用于从文本中提取可能的税号，后续再验证）
    TAX_NUMBER_LOOSE_PATTERN = re.compile(r'[0-9A-Z]{18}')
    
    # "识别号"后的税号匹配
    TAX_AFTER_IDENTIFIER_PATTERN = re.compile(r'(?:识别号|纳税人识别号|税号)[：:\s]*([0-9A-Z]{18})')
    
    # "名称"后"公司"前的抬头匹配
    TITLE_BETWEEN_PATTERN = re.compile(r'名称[：:\s]*(.+?(?:有限公司|股份有限公司|有限责任公司|公司|集团))')
    
    # 个体工商户名称匹配（用于92开头的税号）
    INDIVIDUAL_BUSINESS_PATTERN = re.compile(r'名称[：:\s]*(.+?)(?:\s|$|纳税)')
    
    # 常见公司名称后缀
    COMPANY_SUFFIXES = ['有限公司', '股份有限公司', '集团', '公司', '有限责任公司']
    
    # 个体工商户后缀（不以"公司"结尾）
    INDIVIDUAL_SUFFIXES = ['店', '部', '行', '馆', '坊', '庄', '铺', '摊', '厂', '社', '站', '所', '中心', '工作室']
    
    @classmethod
    def extract_from_text(cls, text: str) -> Dict:
        """
        从文本中提取发票抬头和税号
        
        Args:
            text: OCR 识别后的文本或手动输入的文本
        
        Returns:
            {
                'titles': ['公司名称1', '公司名称2'],
                'tax_numbers': ['税号1', '税号2'],
                'raw_text': text,
                'is_individual': bool  # 是否为个体工商户
            }
        """
        if not text:
            return {'titles': [], 'tax_numbers': [], 'raw_text': '', 'is_individual': False}
        
        # 提取税号 - 优先从"识别号"后提取
        tax_numbers = cls._extract_tax_numbers(text)
        
        # 判断是否为个体工商户（税号以92开头）
        is_individual = any(tn.startswith('92') for tn in tax_numbers)
        
        # 提取公司名称
        titles = cls._extract_company_names(text, is_individual=is_individual)
        
        return {
            'titles': titles,
            'tax_numbers': tax_numbers,
            'raw_text': text,
            'is_individual': is_individual
        }
    
    @classmethod
    def _extract_tax_numbers(cls, text: str) -> List[str]:
        """
        提取税号
        优先级：
        1. "识别号"/"纳税人识别号"/"税号"后的18位字符
        2. 符合规则的18位数字串（以1、5、9开头）
        """
        tax_numbers = []
        
        # 方法1：从"识别号"后提取
        matches = cls.TAX_AFTER_IDENTIFIER_PATTERN.findall(text)
        for match in matches:
            clean_match = match.strip().upper()
            if cls._is_valid_tax_number(clean_match):
                tax_numbers.append(clean_match)
        
        # 方法2：使用宽松模式匹配18位字符，然后验证
        if not tax_numbers:
            loose_matches = cls.TAX_NUMBER_LOOSE_PATTERN.findall(text)
            for match in loose_matches:
                clean_match = match.strip().upper()
                if cls._is_valid_tax_number(clean_match):
                    tax_numbers.append(clean_match)
        
        # 方法3：使用严格模式（以1、5、9开头）
        if not tax_numbers:
            strict_matches = cls.TAX_NUMBER_PATTERN.findall(text)
            tax_numbers.extend(strict_matches)
        
        # 去重保持顺序
        return list(dict.fromkeys(tax_numbers))
    
    @classmethod
    def _is_valid_tax_number(cls, tax_number: str) -> bool:
        """
        验证税号是否符合规则
        规则：固定18位，以1、5、9开头
        """
        if not tax_number or len(tax_number) != 18:
            return False
        if tax_number[0] not in ('1', '5', '9'):
            return False
        return bool(re.match(r'^[0-9A-Z]+$', tax_number))
    
    @classmethod
    def _extract_company_names(cls, text: str, is_individual: bool = False) -> List[str]:
        """
        提取公司/商户名称
        
        Args:
            text: OCR识别的文本
            is_individual: 是否为个体工商户（税号以92开头）
        
        Returns:
            提取的名称列表
        """
        titles = []
        
        # 方法1：从"名称"后提取（优先级最高）
        if is_individual:
            # 个体工商户：名称不以"公司"结尾
            individual_matches = cls.INDIVIDUAL_BUSINESS_PATTERN.findall(text)
            for match in individual_matches:
                clean_name = cls._clean_company_name(match)
                # 个体工商户名称不应以"公司"结尾
                if clean_name and len(clean_name) >= 4:
                    # 检查是否以个体工商户常见后缀结尾
                    if any(clean_name.endswith(suffix) for suffix in cls.INDIVIDUAL_SUFFIXES):
                        titles.append(clean_name)
                    elif not any(clean_name.endswith(suffix) for suffix in cls.COMPANY_SUFFIXES):
                        # 如果不以公司结尾，也可能是个体工商户
                        titles.append(clean_name)
        else:
            # 企业：从"名称"后"公司"前提取
            title_matches = cls.TITLE_BETWEEN_PATTERN.findall(text)
            for match in title_matches:
                clean_name = cls._clean_company_name(match)
                if clean_name and len(clean_name) >= 4:
                    titles.append(clean_name)
        
        # 方法2：按行扫描提取（备用方法）
        if not titles:
            lines = text.replace('\r', '\n').split('\n')
            
            for line in lines:
                line = line.strip()
                if not line:
                    continue
                
                if is_individual:
                    # 个体工商户：检查是否包含个体工商户后缀
                    for suffix in cls.INDIVIDUAL_SUFFIXES:
                        if suffix in line and '公司' not in line:
                            idx = line.index(suffix)
                            start = max(0, idx - 50)
                            potential_name = line[start:idx + len(suffix)]
                            potential_name = cls._clean_company_name(potential_name)
                            if potential_name and len(potential_name) >= 2:
                                titles.append(potential_name)
                            break
                else:
                    # 企业：检查是否包含公司后缀
                    for suffix in cls.COMPANY_SUFFIXES:
                        if suffix in line:
                            idx = line.index(suffix)
                            start = max(0, idx - 50)
                            potential_name = line[start:idx + len(suffix)]
                            potential_name = cls._clean_company_name(potential_name)
                            if potential_name and len(potential_name) >= 4:
                                titles.append(potential_name)
                            break
        
        return list(dict.fromkeys(titles))  # 去重
    
    @classmethod
    def _clean_company_name(cls, name: str) -> str:
        """
        清理公司名称中的噪声
        1. 移除常见前缀噪声
        2. 如果以"称"开头则去除（OCR误识别"名称"时可能漏掉"名"字）
        3. 统一括号格式（英文括号转中文括号）
        4. 清理非法字符
        """
        if not name:
            return ''
        
        # 移除常见前缀噪声
        noise_prefixes = ['名称：', '名称:', '抬头：', '抬头:', '购买方：', '购买方:', 
                         '销售方：', '销售方:', '发票抬头：', '发票抬头:', 
                         '称：', '称:']  # 也处理只有"称"的情况
        for prefix in noise_prefixes:
            if prefix in name:
                name = name.split(prefix)[-1]
        
        # 如果以"称"字开头，去除第一个"称"字（OCR误识别导致）
        name = name.strip()
        if name.startswith('称'):
            name = name[1:]
        
        # 统一括号格式：英文括号转中文括号
        name = name.replace('(', '（').replace(')', '）')
        
        # 清理括号内的空格和异常字符，但保留括号结构
        # 匹配括号内容并清理
        def clean_bracket_content(match):
            content = match.group(1)
            # 清理括号内的非法字符，只保留中文、字母、数字
            cleaned = re.sub(r'[^\u4e00-\u9fa5a-zA-Z0-9]', '', content)
            if cleaned:
                return f'（{cleaned}）'
            return ''  # 如果括号内容清理后为空，则移除整个括号
        
        name = re.sub(r'（([^）]*)）', clean_bracket_content, name)
        
        # 移除非中文/字母/数字/中文括号的字符
        name = re.sub(r'[^\u4e00-\u9fa5a-zA-Z0-9（）]', '', name)
        
        # 最终清理：去除首尾空白
        name = name.strip()
        
        # 再次检查：如果清理后仍以"称"开头
        if name.startswith('称'):
            name = name[1:]
        
        return name
    
    @classmethod
    def _preprocess_image(cls, image) -> 'Image':
        """
        预处理图片以提高OCR识别率
        1. 截取上半部分（发票抬头和税号通常在上半部分）
        2. 根据分辨率判断是否需要放大
        3. 锐化处理
        
        Args:
            image: PIL Image 对象
        
        Returns:
            处理后的 PIL Image 对象
        """
        from PIL import Image, ImageFilter, ImageEnhance
        
        width, height = image.size
        
        # 1. 截取上半部分（约55%，确保包含发票头信息）
        # 发票的抬头、税号通常在上半部分
        crop_ratio = 0.55
        upper_half = image.crop((0, 0, width, int(height * crop_ratio)))
        
        # 2. 根据分辨率判断是否需要放大
        current_width = upper_half.size[0]
        if current_width < IMAGE_MIN_WIDTH_THRESHOLD:
            # 计算放大比例
            scale_factor = IMAGE_TARGET_WIDTH / current_width
            new_width = int(current_width * scale_factor)
            new_height = int(upper_half.size[1] * scale_factor)
            # 使用高质量重采样进行放大
            upper_half = upper_half.resize((new_width, new_height), Image.Resampling.LANCZOS)
        
        # 3. 锐化处理 - 使用 UnsharpMask 滤镜
        # 参数：radius=2, percent=150, threshold=3
        try:
            sharpened = upper_half.filter(ImageFilter.UnsharpMask(radius=2, percent=150, threshold=3))
        except Exception:
            # 如果 UnsharpMask 不可用，使用基本锐化
            sharpened = upper_half.filter(ImageFilter.SHARPEN)
        
        # 4. 增强对比度（可选，有助于文字识别）
        try:
            enhancer = ImageEnhance.Contrast(sharpened)
            sharpened = enhancer.enhance(1.2)  # 轻微增强对比度
        except Exception:
            pass
        
        return sharpened
    
    @classmethod
    def extract_from_image(cls, file_content: bytes, filename: str) -> Dict:
        """
        从图片文件中提取文本
        使用轻量级方案，优先尝试 pytesseract
        
        处理流程：
        1. 截取图片上半部分（发票信息集中区域）
        2. 根据分辨率判断是否放大
        3. 锐化处理提高清晰度
        4. OCR识别
        
        注意：文件仅在内存中处理，不保存到硬盘
        """
        text = ''
        
        try:
            from PIL import Image
            import pytesseract
            
            # 设置 Tesseract 路径
            if TESSERACT_PATH:
                pytesseract.pytesseract.tesseract_cmd = TESSERACT_PATH
            
            # 检查 Tesseract 是否可用
            if not TESSERACT_PATH and not shutil.which('tesseract'):
                return {
                    'titles': [],
                    'tax_numbers': [],
                    'raw_text': '',
                    'is_individual': False,
                    'error': 'Tesseract OCR 未安装或路径未配置。请安装 Tesseract 并设置环境变量 TESSERACT_CMD'
                }
            
            image = Image.open(io.BytesIO(file_content))
            
            # 如果是 RGBA 模式，转换为 RGB
            if image.mode == 'RGBA':
                image = image.convert('RGB')
            
            # 预处理图片（截取上半部分、放大、锐化）
            processed_image = cls._preprocess_image(image)
            
            # 尝试使用中文语言包，如果失败则只用英文
            try:
                text = pytesseract.image_to_string(processed_image, lang='chi_sim+eng')
            except Exception:
                try:
                    text = pytesseract.image_to_string(processed_image, lang='chi_sim')
                except Exception:
                    text = pytesseract.image_to_string(processed_image)
            
            # 如果上半部分识别结果不理想，尝试全图识别
            if not cls._has_valid_invoice_content(text):
                try:
                    # 对全图进行预处理（只放大和锐化，不裁剪）
                    full_processed = cls._preprocess_image_full(image)
                    full_text = pytesseract.image_to_string(full_processed, lang='chi_sim+eng')
                    if cls._has_valid_invoice_content(full_text):
                        text = full_text
                except Exception:
                    pass
                    
        except ImportError:
            return {
                'titles': [],
                'tax_numbers': [],
                'raw_text': '',
                'is_individual': False,
                'error': 'OCR 服务未安装，请安装 pytesseract: pip install pytesseract'
            }
        except Exception as e:
            error_msg = str(e)
            if 'tesseract is not installed' in error_msg.lower():
                return {
                    'titles': [],
                    'tax_numbers': [],
                    'raw_text': '',
                    'is_individual': False,
                    'error': f'Tesseract OCR 未找到。请确保已安装并设置环境变量。当前搜索路径: {TESSERACT_PATH or "未配置"}'
                }
            return {
                'titles': [],
                'tax_numbers': [],
                'raw_text': '',
                'is_individual': False,
                'error': f'图片处理失败: {error_msg}'
            }
        
        return cls.extract_from_text(text)
    
    @classmethod
    def _preprocess_image_full(cls, image) -> 'Image':
        """
        对完整图片进行预处理（不裁剪，只放大和锐化）
        """
        from PIL import Image, ImageFilter, ImageEnhance
        
        width, height = image.size
        
        # 根据分辨率判断是否需要放大
        if width < IMAGE_MIN_WIDTH_THRESHOLD:
            scale_factor = IMAGE_TARGET_WIDTH / width
            new_width = int(width * scale_factor)
            new_height = int(height * scale_factor)
            image = image.resize((new_width, new_height), Image.Resampling.LANCZOS)
        
        # 锐化处理
        try:
            processed = image.filter(ImageFilter.UnsharpMask(radius=2, percent=150, threshold=3))
        except Exception:
            processed = image.filter(ImageFilter.SHARPEN)
        
        # 增强对比度
        try:
            enhancer = ImageEnhance.Contrast(processed)
            processed = enhancer.enhance(1.2)
        except Exception:
            pass
        
        return processed
    
    @classmethod
    def _has_valid_invoice_content(cls, text: str) -> bool:
        """
        检查文本是否包含有效的发票内容
        """
        if not text:
            return False
        
        # 检查是否有符合规则的税号
        has_tax = bool(cls.TAX_NUMBER_PATTERN.search(text)) or \
                  bool(cls.TAX_NUMBER_LOOSE_PATTERN.search(text))
        
        # 检查是否有公司/商户名称相关关键词
        has_name = any(s in text for s in cls.COMPANY_SUFFIXES) or \
                   any(s in text for s in cls.INDIVIDUAL_SUFFIXES) or \
                   '名称' in text or '识别号' in text
        
        return has_tax or has_name
    
    @classmethod
    def extract_from_pdf(cls, file_content: bytes, filename: str) -> Dict:
        """
        从 PDF 文件中提取文本
        支持两种模式：
        1. 文本型 PDF - 直接提取文本
        2. 图片型 PDF - 将页面渲染为图片后 OCR
        
        注意：文件仅在内存中处理，不保存到硬盘
        """
        text = ''
        used_ocr = False
        
        # 方法1：尝试直接提取文本（文本型PDF）
        try:
            try:
                import pdfplumber
                with pdfplumber.open(io.BytesIO(file_content)) as pdf:
                    for page in pdf.pages:
                        page_text = page.extract_text()
                        if page_text:
                            text += page_text + '\n'
            except ImportError:
                try:
                    from PyPDF2 import PdfReader
                    reader = PdfReader(io.BytesIO(file_content))
                    for page in reader.pages:
                        page_text = page.extract_text()
                        if page_text:
                            text += page_text + '\n'
                except ImportError:
                    pass
        except Exception:
            pass
        
        # 检查提取的文本是否有效（是否包含税号或公司名称）
        has_valid_content = cls._has_valid_invoice_content(text)
        
        # 方法2：如果文本提取失败或内容不足，使用 OCR（图片型PDF）
        if not has_valid_content:
            ocr_text = cls._extract_pdf_with_ocr(file_content)
            if ocr_text:
                text = ocr_text
                used_ocr = True
        
        if not text.strip():
            return {
                'titles': [],
                'tax_numbers': [],
                'raw_text': '',
                'error': 'PDF 内容提取失败，请确保 PDF 清晰可读或尝试手动输入'
            }
        
        result = cls.extract_from_text(text)
        if used_ocr:
            result['ocr_mode'] = True
        return result
    
    @classmethod
    def _extract_pdf_with_ocr(cls, file_content: bytes) -> str:
        """
        将 PDF 页面渲染为图片后进行 OCR
        适用于扫描件/图片型 PDF
        
        处理流程：
        1. 渲染PDF页面为图片
        2. 截取上半部分（发票信息集中区域）
        3. 根据分辨率判断是否放大
        4. 锐化处理
        5. OCR识别
        """
        text = ''
        
        # 检查 Tesseract 是否可用
        if not TESSERACT_PATH and not shutil.which('tesseract'):
            print("Tesseract not found, skipping OCR")
            return text
        
        # 方法1：使用 PyMuPDF (fitz) - 推荐
        try:
            import fitz  # PyMuPDF
            from PIL import Image
            import pytesseract
            
            # 设置 Tesseract 路径
            if TESSERACT_PATH:
                pytesseract.pytesseract.tesseract_cmd = TESSERACT_PATH
            
            doc = fitz.open(stream=file_content, filetype="pdf")
            
            for page_num in range(min(doc.page_count, 5)):  # 最多处理5页
                page = doc[page_num]
                # 渲染页面为图片（300 DPI）
                mat = fitz.Matrix(300/72, 300/72)
                pix = page.get_pixmap(matrix=mat)
                
                # 转换为 PIL Image
                img = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)
                
                # 预处理图片（截取上半部分、放大、锐化）
                processed_img = cls._preprocess_image(img)
                
                # OCR 识别（尝试不同语言包）
                try:
                    page_text = pytesseract.image_to_string(processed_img, lang='chi_sim+eng')
                except Exception:
                    try:
                        page_text = pytesseract.image_to_string(processed_img, lang='chi_sim')
                    except Exception:
                        page_text = pytesseract.image_to_string(processed_img)
                
                if page_text:
                    text += page_text + '\n'
                
                # 如果上半部分没有识别到有效内容，尝试全图
                if not cls._has_valid_invoice_content(text):
                    try:
                        full_img = cls._preprocess_image_full(img)
                        full_text = pytesseract.image_to_string(full_img, lang='chi_sim+eng')
                        if full_text:
                            text += full_text + '\n'
                    except Exception:
                        pass
            
            doc.close()
            return text
            
        except ImportError:
            pass
        except Exception as e:
            print(f"PyMuPDF OCR failed: {e}")
        
        # 方法2：使用 pdf2image（需要 poppler）
        try:
            from pdf2image import convert_from_bytes
            from PIL import Image
            import pytesseract
            
            # 设置 Tesseract 路径
            if TESSERACT_PATH:
                pytesseract.pytesseract.tesseract_cmd = TESSERACT_PATH
            
            images = convert_from_bytes(file_content, dpi=300, first_page=1, last_page=5)
            
            for img in images:
                # 预处理图片（截取上半部分、放大、锐化）
                processed_img = cls._preprocess_image(img)
                
                try:
                    page_text = pytesseract.image_to_string(processed_img, lang='chi_sim+eng')
                except Exception:
                    try:
                        page_text = pytesseract.image_to_string(processed_img, lang='chi_sim')
                    except Exception:
                        page_text = pytesseract.image_to_string(processed_img)
                
                if page_text:
                    text += page_text + '\n'
                
                # 如果上半部分没有识别到有效内容，尝试全图
                if not cls._has_valid_invoice_content(text):
                    try:
                        full_img = cls._preprocess_image_full(img)
                        full_text = pytesseract.image_to_string(full_img, lang='chi_sim+eng')
                        if full_text:
                            text += full_text + '\n'
                    except Exception:
                        pass
            
            return text
            
        except ImportError:
            pass
        except Exception as e:
            print(f"pdf2image OCR failed: {e}")
        
        return text


class InvoiceVerifyService:
    """
    发票校验服务
    使用 Hash Map/Set 进行 O(1) 快速匹配
    """
    
    @classmethod
    def _find_best_match(cls, title: str, tax_number: str, title_set: set, tax_set: set, title_to_tax: dict) -> Optional[Dict]:
        """
        查找最匹配的标准库数据
        使用简单的字符串相似度匹配
        
        Returns:
            最匹配的数据 {'title': '...', 'tax_number': '...', 'similarity': 0.8} 或 None
        """
        if not title and not tax_number:
            return None
        
        best_match = None
        best_score = 0
        
        # 根据抬头查找
        if title:
            for lib_title in title_set:
                score = cls._calculate_similarity(title, lib_title)
                if score > best_score and score >= 0.5:  # 至少50%相似度
                    best_score = score
                    best_match = {
                        'title': lib_title,
                        'tax_number': title_to_tax.get(lib_title, ''),
                        'similarity': round(score, 2),
                        'match_type': 'title'
                    }
        
        # 根据税号查找（税号完全匹配优先级更高）
        if tax_number and tax_number in tax_set:
            # 找到对应的抬头
            for lib_title, lib_tax in title_to_tax.items():
                if lib_tax == tax_number:
                    return {
                        'title': lib_title,
                        'tax_number': lib_tax,
                        'similarity': 1.0,
                        'match_type': 'tax_number'
                    }
        
        return best_match
    
    @classmethod
    def _calculate_similarity(cls, s1: str, s2: str) -> float:
        """
        计算两个字符串的相似度（基于公共子序列）
        返回 0-1 之间的值
        """
        if not s1 or not s2:
            return 0.0
        
        # 简单的字符匹配相似度
        len1, len2 = len(s1), len(s2)
        
        # 计算公共字符数
        common = 0
        s2_chars = list(s2)
        for c in s1:
            if c in s2_chars:
                common += 1
                s2_chars.remove(c)
        
        # 归一化
        similarity = (2.0 * common) / (len1 + len2)
        
        # 如果包含关系，给予额外加分
        if s1 in s2 or s2 in s1:
            similarity = min(1.0, similarity + 0.2)
        
        return similarity
    
    @classmethod
    def verify_batch(cls, items: List[Dict], title_set: set, tax_set: set, title_to_tax: dict) -> List[Dict]:
        """
        批量校验发票信息
        时间复杂度: O(N)，其中 N 为待校验项数
        
        Args:
            items: 待校验项列表 [{'title': '公司名', 'tax_number': '税号'}, ...]
            title_set: 标准抬头集合
            tax_set: 标准税号集合
            title_to_tax: 抬头到税号的映射
        
        Returns:
            校验结果列表
        """
        # 个体工商户常见后缀（不以"公司"结尾）
        individual_suffixes = ['店', '部', '行', '馆', '坊', '庄', '铺', '摊', '厂', '社', '站', '所', '中心', '工作室']
        company_suffixes = ['有限公司', '股份有限公司', '集团', '公司', '有限责任公司']
        
        results = []
        
        for item in items:
            title = item.get('title', '').strip()
            tax_number = item.get('tax_number', '').strip().upper()
            
            result = {
                'title': title,
                'tax_number': tax_number,
                'status': 'unknown',  # pass/fail/warning/unknown
                'messages': [],
                'suggestions': [],
                'is_individual': False,  # 是否为个体工商户
                'best_match': None  # 最匹配的标准库数据
            }
            
            # 判断是否为个体工商户
            is_individual = cls._is_individual_business(tax_number)
            result['is_individual'] = is_individual
            
            # 校验税号格式
            if tax_number:
                if not cls._validate_tax_format(tax_number):
                    result['status'] = 'fail'
                    # 提供更详细的错误信息
                    if len(tax_number) != 18:
                        result['messages'].append(f'税号长度应为18位，当前为{len(tax_number)}位')
                    elif tax_number[0] not in ('1', '5', '9'):
                        result['messages'].append('税号应以1、5或9开头')
                    else:
                        result['messages'].append('税号格式不正确（应为数字和大写字母组合）')
                elif tax_number in tax_set:
                    # 税号存在于库中
                    result['status'] = 'pass'
                    result['messages'].append('税号已通过校验')
                    if is_individual:
                        result['messages'].append('（个体工商户）')
                else:
                    result['status'] = 'warning'
                    result['messages'].append('税号不在标准库中')
                    result['is_new'] = True
                    if is_individual:
                        result['messages'].append('（个体工商户）')
            
            # 校验抬头
            if title:
                # 个体工商户抬头校验：不能以"公司"结尾
                if is_individual:
                    if any(title.endswith(suffix) for suffix in company_suffixes):
                        result['status'] = 'fail'
                        result['messages'].append('个体工商户（税号92开头）的抬头不能以"公司"结尾')
                    elif title in title_set:
                        expected_tax = title_to_tax.get(title)
                        if tax_number and expected_tax and tax_number != expected_tax:
                            result['status'] = 'fail'
                            result['messages'].append(f'抬头对应的标准税号为 {expected_tax}，与输入不符')
                            result['suggestions'].append({'tax_number': expected_tax})
                        elif result['status'] != 'fail':
                            result['status'] = 'pass'
                            result['messages'].append('抬头已通过校验')
                    else:
                        if result['status'] not in ['fail']:
                            result['status'] = 'warning'
                        result['messages'].append('抬头不在标准库中')
                        result['is_new'] = True
                else:
                    # 企业抬头校验
                    if title in title_set:
                        expected_tax = title_to_tax.get(title)
                        if tax_number and expected_tax and tax_number != expected_tax:
                            result['status'] = 'fail'
                            result['messages'].append(f'抬头对应的标准税号为 {expected_tax}，与输入不符')
                            result['suggestions'].append({'tax_number': expected_tax})
                        elif result['status'] != 'fail':
                            result['status'] = 'pass'
                            result['messages'].append('抬头已通过校验')
                    else:
                        if result['status'] not in ['fail']:
                            result['status'] = 'warning'
                        result['messages'].append('抬头不在标准库中')
                        result['is_new'] = True
            
            # 没有输入任何信息
            if not title and not tax_number:
                result['status'] = 'fail'
                result['messages'].append('请输入抬头或税号')
            
            # 查找最匹配的标准库数据（仅当不是完全匹配时）
            if result['status'] != 'pass' and (title or tax_number):
                best_match = cls._find_best_match(title, tax_number, title_set, tax_set, title_to_tax)
                if best_match:
                    result['best_match'] = best_match
            
            results.append(result)
        
        return results
    
    @classmethod
    def _validate_tax_format(cls, tax_number: str) -> bool:
        """
        验证税号格式
        规则：
        - 固定18位
        - 只能以1、5、9开头
        - 由数字和大写字母组成
        """
        if not tax_number:
            return False
        
        tax_number = tax_number.upper().strip()
        
        # 必须是18位
        if len(tax_number) != 18:
            return False
        
        # 必须以1、5、9开头
        if tax_number[0] not in ('1', '5', '9'):
            return False
        
        # 必须是数字和大写字母组成
        return bool(re.match(r'^[0-9A-Z]+$', tax_number))
    
    @classmethod
    def _is_individual_business(cls, tax_number: str) -> bool:
        """
        判断是否为个体工商户
        规则：税号以92开头
        """
        if not tax_number or len(tax_number) < 2:
            return False
        return tax_number.startswith('92')


