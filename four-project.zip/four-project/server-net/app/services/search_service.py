# -*- coding: utf-8 -*-
"""
高性能搜索服务 - PostgreSQL pg_trgm 实现
实现类 ElasticSearch 的模糊搜索体验

核心特性：
1. Trigram 模糊匹配（Fuzzy Search）
2. 相似度排序（Similarity Ranking）
3. 混合搜索策略（精确 > 前缀 > 模糊）
4. 多表联合搜索
5. GIN 索引加速（毫秒级响应）
"""
from sqlalchemy import or_, func, text, desc, case, literal
from sqlalchemy.sql.expression import cast
from sqlalchemy.types import Float
from flask import current_app
from app import db
from app.models.website import Website
from app.models.employee import Employee
from app.models.user_file import UserFile
from app.models.search import SearchHistory


class SearchService:
    """
    高性能搜索服务类
    使用 PostgreSQL pg_trgm 扩展实现类 ES 搜索体验
    """
    
    # ==================== 核心搜索方法 ====================
    
    @staticmethod
    def fuzzy_search(keyword, limit=50, search_type='all'):
        """
        超级模糊搜索 - 混合搜索策略
        
        搜索策略：
        1. 精确匹配 (权重 100) - 完全相等
        2. 前缀匹配 (权重 50) - 以关键词开头
        3. 模糊匹配 (权重: similarity * 10) - pg_trgm 相似度
        
        Args:
            keyword: 搜索关键词
            limit: 结果数量限制
            search_type: 搜索类型 'all' | 'websites' | 'employees' | 'files'
        
        Returns:
            按相关性排序的搜索结果
        """
        keyword = keyword.strip().lower()
        
        if not keyword:
            return {'websites': [], 'employees': [], 'files': []}
        
        threshold = current_app.config.get('FUZZY_SEARCH_THRESHOLD', 0.3)
        
        results = {}
        
        if search_type in ('all', 'websites'):
            results['websites'] = SearchService._search_websites(keyword, limit, threshold)
        else:
            results['websites'] = []
            
        if search_type in ('all', 'employees'):
            results['employees'] = SearchService._search_employees(keyword, limit, threshold)
        else:
            results['employees'] = []
            
        if search_type in ('all', 'files'):
            results['files'] = SearchService._search_files(keyword, limit, threshold)
        else:
            results['files'] = []
        
        return results
    
    @staticmethod
    def _search_websites(keyword, limit, threshold):
        """
        网站搜索 - pg_trgm 模糊匹配 + 权重排序
        
        搜索域：name, url, description, pinyin, pinyin_initials
        """
        # 使用 pg_trgm 的 similarity 函数计算相似度
        # 同时支持 % 操作符进行模糊匹配
        
        # 计算各字段的相似度得分
        name_similarity = func.similarity(func.lower(Website.name), keyword)
        pinyin_similarity = func.similarity(func.lower(func.coalesce(Website.pinyin, '')), keyword)
        pinyin_initials_sim = func.similarity(func.lower(func.coalesce(Website.pinyin_initials, '')), keyword)
        desc_similarity = func.similarity(func.lower(func.coalesce(Website.description, '')), keyword)
        url_similarity = func.similarity(func.lower(Website.url), keyword)
        
        # 构建混合权重得分
        # 精确匹配 > 前缀匹配 > 模糊匹配
        relevance_score = case(
            # 精确匹配 - 最高优先级
            (func.lower(Website.name) == keyword, literal(100.0)),
            (func.lower(Website.pinyin_initials) == keyword, literal(95.0)),
            (func.lower(Website.pinyin) == keyword, literal(90.0)),
            # 前缀匹配 - 次高优先级
            (func.lower(Website.name).startswith(keyword), literal(80.0)),
            (func.lower(Website.pinyin_initials).startswith(keyword), literal(75.0)),
            (func.lower(Website.pinyin).startswith(keyword), literal(70.0)),
            # 模糊匹配 - 基于相似度
            else_=(
                name_similarity * 40 + 
                pinyin_initials_sim * 25 +
                pinyin_similarity * 20 + 
                url_similarity * 10 +
                desc_similarity * 5
            )
        )
        
        # 使用 % 操作符进行模糊匹配过滤
        # 这会利用 GIN 索引加速查询
        filter_condition = or_(
            func.lower(Website.name).op('%')(keyword),
            func.lower(func.coalesce(Website.pinyin, '')).op('%')(keyword),
            func.lower(func.coalesce(Website.pinyin_initials, '')).op('%')(keyword),
            func.lower(func.coalesce(Website.description, '')).op('%')(keyword),
            func.lower(Website.url).op('%')(keyword),
            # 也支持传统 LIKE 匹配（用于短关键词）
            func.lower(Website.name).contains(keyword),
            func.lower(func.coalesce(Website.pinyin_initials, '')).contains(keyword)
        )
        
        # 执行查询
        websites = db.session.query(
            Website,
            relevance_score.label('relevance')
        ).filter(
            filter_condition
        ).order_by(
            desc('relevance'),
            desc(Website.click_count),
            Website.sort_order
        ).limit(limit).all()
        
        return [{
            **w.Website.to_dict(),
            'relevance': float(w.relevance) if w.relevance else 0,
            'match_type': 'website'
        } for w in websites]
    
    @staticmethod
    def _search_employees(keyword, limit, threshold):
        """
        员工搜索 - pg_trgm 模糊匹配 + 拼音搜索
        
        搜索域：name, pinyin, pinyin_initials, position, signature, email, phone
        
        支持搜索方式：
        - 中文姓名：张三
        - 拼音全拼：zhangsan
        - 拼音首字母：zs
        - 职位：主任、护士
        """
        # 计算各字段的相似度得分
        name_similarity = func.similarity(func.lower(Employee.name), keyword)
        pinyin_similarity = func.similarity(func.lower(func.coalesce(Employee.pinyin, '')), keyword)
        pinyin_initials_sim = func.similarity(func.lower(func.coalesce(Employee.pinyin_initials, '')), keyword)
        position_similarity = func.similarity(func.lower(func.coalesce(Employee.position, '')), keyword)
        signature_similarity = func.similarity(func.lower(func.coalesce(Employee.signature, '')), keyword)
        
        # 构建混合权重得分（与 Website 搜索保持一致的逻辑）
        # 精确匹配 > 前缀匹配 > 模糊匹配
        relevance_score = case(
            # 精确匹配 - 最高优先级
            (func.lower(Employee.name) == keyword, literal(100.0)),
            (func.lower(func.coalesce(Employee.pinyin_initials, '')) == keyword, literal(95.0)),
            (func.lower(func.coalesce(Employee.pinyin, '')) == keyword, literal(90.0)),
            # 前缀匹配 - 次高优先级
            (func.lower(Employee.name).startswith(keyword), literal(80.0)),
            (func.lower(func.coalesce(Employee.pinyin_initials, '')).startswith(keyword), literal(75.0)),
            (func.lower(func.coalesce(Employee.pinyin, '')).startswith(keyword), literal(70.0)),
            # 职位/签名包含 - 中等优先级
            (func.lower(func.coalesce(Employee.position, '')).contains(keyword), literal(60.0)),
            # 模糊匹配 - 基于相似度加权
            else_=(
                name_similarity * 40 +
                pinyin_initials_sim * 25 +
                pinyin_similarity * 20 +
                position_similarity * 10 +
                signature_similarity * 5
            )
        )
        
        # 使用 % 操作符进行模糊匹配过滤（利用 GIN 索引加速）
        filter_condition = or_(
            # 姓名模糊匹配
            func.lower(Employee.name).op('%')(keyword),
            # 拼音模糊匹配（核心新增）
            func.lower(func.coalesce(Employee.pinyin, '')).op('%')(keyword),
            func.lower(func.coalesce(Employee.pinyin_initials, '')).op('%')(keyword),
            # 职位/签名模糊匹配
            func.lower(func.coalesce(Employee.position, '')).op('%')(keyword),
            func.lower(func.coalesce(Employee.signature, '')).op('%')(keyword),
            func.lower(func.coalesce(Employee.email, '')).op('%')(keyword),
            # 传统 LIKE 匹配（用于短关键词）
            func.lower(Employee.name).contains(keyword),
            func.lower(func.coalesce(Employee.pinyin_initials, '')).contains(keyword),
            func.lower(func.coalesce(Employee.pinyin, '')).contains(keyword),
            func.lower(func.coalesce(Employee.phone, '')).contains(keyword)
        )
        
        employees = db.session.query(
            Employee,
            relevance_score.label('relevance')
        ).filter(
            filter_condition,
            Employee.is_active == True
        ).order_by(
            desc('relevance'),
            Employee.level,
            Employee.sort_order
        ).limit(limit).all()
        
        return [{
            **e.Employee.to_dict(),
            'relevance': float(e.relevance) if e.relevance else 0,
            'match_type': 'employee'
        } for e in employees]
    
    @staticmethod
    def _search_files(keyword, limit, threshold):
        """
        文件搜索 - pg_trgm 模糊匹配
        
        搜索域：filename
        """
        filename_similarity = func.similarity(func.lower(UserFile.filename), keyword)
        
        relevance_score = case(
            (func.lower(UserFile.filename) == keyword, literal(100.0)),
            (func.lower(UserFile.filename).startswith(keyword), literal(80.0)),
            else_=filename_similarity * 60
        )
        
        filter_condition = or_(
            func.lower(UserFile.filename).op('%')(keyword),
            func.lower(UserFile.filename).contains(keyword)
        )
        
        files = db.session.query(
            UserFile,
            relevance_score.label('relevance')
        ).filter(
            filter_condition
        ).order_by(
            desc('relevance'),
            desc(UserFile.is_starred),
            desc(UserFile.updated_at)
        ).limit(limit).all()
        
        return [{
            **f.UserFile.to_dict(),
            'relevance': float(f.relevance) if f.relevance else 0,
            'match_type': 'file'
        } for f in files]
    
    # ==================== 搜索建议（实时联想） ====================
    
    @staticmethod
    def get_suggestions(keyword, limit=10):
        """
        获取搜索建议（用于实时联想）
        使用 pg_trgm 提供高质量建议
        
        Args:
            keyword: 输入关键词
            limit: 建议数量
        
        Returns:
            建议列表（带相似度得分）
        """
        keyword = keyword.strip().lower()
        
        if not keyword:
            return []
        
        # 使用相似度排序的前缀/模糊匹配
        name_similarity = func.similarity(func.lower(Website.name), keyword)
        
        suggestions = db.session.query(
            Website.id,
            Website.name,
            Website.url,
            Website.icon,
            name_similarity.label('similarity')
        ).filter(
            or_(
                func.lower(Website.name).op('%')(keyword),
                func.lower(func.coalesce(Website.pinyin_initials, '')).op('%')(keyword),
                func.lower(func.coalesce(Website.pinyin, '')).op('%')(keyword),
                func.lower(Website.name).startswith(keyword),
                func.lower(func.coalesce(Website.pinyin_initials, '')).startswith(keyword)
            )
        ).order_by(
            desc('similarity'),
            desc(Website.click_count)
        ).limit(limit).all()
        
        return [{
            'id': s.id,
            'name': s.name,
            'url': s.url,
            'icon': s.icon,
            'similarity': float(s.similarity) if s.similarity else 0
        } for s in suggestions]
    
    # ==================== 全局搜索（统一接口） ====================
    
    @staticmethod
    def global_search(keyword, limit=20):
        """
        全局搜索 - 跨表联合搜索
        返回各类型结果的混合列表，按相关性统一排序
        
        Args:
            keyword: 搜索关键词
            limit: 每类结果数量限制
        
        Returns:
            统一格式的搜索结果
        """
        keyword = keyword.strip().lower()
        
        if not keyword:
            return []
        
        threshold = current_app.config.get('FUZZY_SEARCH_THRESHOLD', 0.3)
        
        # 获取各类搜索结果
        websites = SearchService._search_websites(keyword, limit, threshold)
        employees = SearchService._search_employees(keyword, limit // 2, threshold)
        files = SearchService._search_files(keyword, limit // 2, threshold)
        
        # 合并并按相关性排序
        all_results = websites + employees + files
        all_results.sort(key=lambda x: x.get('relevance', 0), reverse=True)
        
        return all_results[:limit * 2]
    
    # ==================== 热门搜索 ====================
    
    @staticmethod
    def get_hot_keywords(limit=10):
        """
        获取热门搜索关键词
        
        Args:
            limit: 数量限制
        
        Returns:
            热门关键词列表
        """
        keywords = SearchHistory.query.order_by(
            SearchHistory.search_count.desc()
        ).limit(limit).all()
        
        return [k.keyword for k in keywords]
    
    @staticmethod
    def get_trending_keywords(limit=10, days=7):
        """
        获取趋势搜索关键词（近期热门）
        
        Args:
            limit: 数量限制
            days: 统计天数
        
        Returns:
            趋势关键词列表
        """
        from datetime import datetime, timedelta
        
        since = datetime.utcnow() - timedelta(days=days)
        
        keywords = SearchHistory.query.filter(
            SearchHistory.last_searched_at >= since
        ).order_by(
            SearchHistory.search_count.desc()
        ).limit(limit).all()
        
        return [{
            'keyword': k.keyword,
            'count': k.search_count,
            'last_searched': k.last_searched_at.isoformat() if k.last_searched_at else None
        } for k in keywords]
    
    # ==================== 搜索历史记录 ====================
    
    @staticmethod
    def record_search(keyword):
        """
        记录搜索历史
        
        Args:
            keyword: 搜索关键词
        """
        keyword = keyword.strip()
        
        if not keyword or len(keyword) > 200:
            return
        
        # 查找现有记录
        history = SearchHistory.query.filter_by(keyword=keyword).first()
        
        if history:
            history.search_count += 1
        else:
            history = SearchHistory(keyword=keyword)
            db.session.add(history)
        
        db.session.commit()
    
    # ==================== 高级搜索功能 ====================
    
    @staticmethod
    def search_with_filters(keyword, filters=None, limit=50):
        """
        带过滤条件的高级搜索
        
        Args:
            keyword: 搜索关键词
            filters: 过滤条件字典
                - category_id: 分类ID
                - section_id: 分区ID
                - is_hot: 是否热门
                - min_clicks: 最小点击数
            limit: 结果数量限制
        
        Returns:
            过滤后的搜索结果
        """
        keyword = keyword.strip().lower()
        filters = filters or {}
        
        if not keyword:
            return []
        
        threshold = current_app.config.get('FUZZY_SEARCH_THRESHOLD', 0.3)
        
        # 基础相似度计算
        name_similarity = func.similarity(func.lower(Website.name), keyword)
        
        relevance_score = case(
            (func.lower(Website.name) == keyword, literal(100.0)),
            (func.lower(Website.name).startswith(keyword), literal(80.0)),
            else_=name_similarity * 60
        )
        
        # 基础过滤条件
        filter_conditions = [
            or_(
                func.lower(Website.name).op('%')(keyword),
                func.lower(func.coalesce(Website.pinyin, '')).op('%')(keyword),
                func.lower(func.coalesce(Website.pinyin_initials, '')).op('%')(keyword),
                func.lower(Website.name).contains(keyword)
            )
        ]
        
        # 应用额外过滤条件
        if filters.get('section_id'):
            filter_conditions.append(Website.section_id == filters['section_id'])
        
        if filters.get('is_hot') is not None:
            filter_conditions.append(Website.is_hot == filters['is_hot'])
        
        if filters.get('min_clicks'):
            filter_conditions.append(Website.click_count >= filters['min_clicks'])
        
        # 执行查询
        websites = db.session.query(
            Website,
            relevance_score.label('relevance')
        ).filter(
            *filter_conditions
        ).order_by(
            desc('relevance'),
            desc(Website.click_count)
        ).limit(limit).all()
        
        return [{
            **w.Website.to_dict(),
            'relevance': float(w.relevance) if w.relevance else 0
        } for w in websites]
    
    @staticmethod
    def autocomplete(prefix, limit=5):
        """
        自动补全（高性能前缀匹配）
        
        Args:
            prefix: 输入前缀
            limit: 建议数量
        
        Returns:
            补全建议列表
        """
        prefix = prefix.strip().lower()
        
        if not prefix or len(prefix) < 1:
            return []
        
        # 使用 GIN 索引加速的前缀匹配
        suggestions = Website.query.filter(
            or_(
                func.lower(Website.name).startswith(prefix),
                func.lower(func.coalesce(Website.pinyin_initials, '')).startswith(prefix),
                func.lower(func.coalesce(Website.pinyin, '')).startswith(prefix)
            )
        ).order_by(
            Website.click_count.desc()
        ).limit(limit).all()
        
        return [{
            'id': s.id,
            'name': s.name,
            'url': s.url,
            'icon': s.icon
        } for s in suggestions]


# ==================== 辅助函数 ====================

def set_pg_trgm_threshold(threshold=0.3):
    """
    设置 pg_trgm 相似度阈值
    
    Args:
        threshold: 阈值 (0.0 - 1.0)，默认 0.3
    
    注意：此函数需要在数据库会话中调用
    """
    db.session.execute(text(f"SET pg_trgm.similarity_threshold = {threshold}"))
