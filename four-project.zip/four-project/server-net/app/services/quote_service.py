# -*- coding: utf-8 -*-
"""
语录服务
"""
from datetime import datetime
import random
import hashlib
from app import db
from app.models.quote import Quote


class QuoteService:
    """语录服务类"""
    
    @staticmethod
    def get_random_quotes(count=1):
        """
        获取随机语录
        
        Args:
            count: 语录数量
        
        Returns:
            语录列表
        """
        # 使用数据库随机排序
        quotes = Quote.query.filter_by(is_active=True).order_by(
            db.func.random()
        ).limit(count).all()
        
        # 更新展示次数
        for quote in quotes:
            quote.display_count += 1
        db.session.commit()
        
        return [q.to_display_dict() for q in quotes]
    
    @staticmethod
    def get_daily_quote():
        """
        获取每日语录
        基于日期的确定性随机，同一天返回同一条语录
        
        Returns:
            语录字典或None
        """
        # 获取活跃语录数量
        total = Quote.query.filter_by(is_active=True).count()
        
        if total == 0:
            return None
        
        # 基于日期生成确定性的索引
        today = datetime.utcnow().strftime('%Y-%m-%d')
        hash_value = int(hashlib.md5(today.encode()).hexdigest(), 16)
        index = hash_value % total
        
        # 获取对应的语录
        quote = Quote.query.filter_by(is_active=True).offset(index).first()
        
        if quote:
            quote.display_count += 1
            db.session.commit()
            return quote.to_display_dict()
        
        return None
    
    @staticmethod
    def init_default_quotes():
        """
        初始化默认语录
        """
        default_quotes = [
            {'content': '千里之行，始于足下。', 'author': '老子', 'category': 'philosophy'},
            {'content': '不积跬步，无以至千里；不积小流，无以成江海。', 'author': '荀子', 'category': 'philosophy'},
            {'content': '学而不思则罔，思而不学则殆。', 'author': '孔子', 'category': 'learning'},
            {'content': '业精于勤，荒于嬉；行成于思，毁于随。', 'author': '韩愈', 'category': 'motivation'},
            {'content': '天行健，君子以自强不息。', 'author': '周易', 'category': 'motivation'},
            {'content': '宝剑锋从磨砺出，梅花香自苦寒来。', 'author': '无名', 'category': 'motivation'},
            {'content': '路漫漫其修远兮，吾将上下而求索。', 'author': '屈原', 'category': 'motivation'},
            {'content': '世上无难事，只怕有心人。', 'author': '谚语', 'category': 'motivation'},
            {'content': '知之为知之，不知为不知，是知也。', 'author': '孔子', 'category': 'learning'},
            {'content': '吾生也有涯，而知也无涯。', 'author': '庄子', 'category': 'philosophy'},
            {'content': 'Stay hungry, stay foolish.', 'author': 'Steve Jobs', 'category': 'motivation'},
            {'content': 'The only way to do great work is to love what you do.', 'author': 'Steve Jobs', 'category': 'motivation'},
            {'content': 'Innovation distinguishes between a leader and a follower.', 'author': 'Steve Jobs', 'category': 'innovation'},
            {'content': 'Talk is cheap. Show me the code.', 'author': 'Linus Torvalds', 'category': 'tech'},
            {'content': 'First, solve the problem. Then, write the code.', 'author': 'John Johnson', 'category': 'tech'},
        ]
        
        for data in default_quotes:
            existing = Quote.query.filter_by(content=data['content']).first()
            if not existing:
                quote = Quote(**data)
                db.session.add(quote)
        
        db.session.commit()
