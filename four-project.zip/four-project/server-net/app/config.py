# -*- coding: utf-8 -*-
"""
应用配置模块
支持多环境配置：开发、测试、生产
PostgreSQL + pg_trgm 高性能搜索配置
"""
import os
from dotenv import load_dotenv

load_dotenv()


class Config:
    """基础配置"""
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'nav-system-secret-key-2024-enterprise'
    
    # PostgreSQL数据库配置
    PG_HOST = os.environ.get('PG_HOST', 'localhost')
    PG_PORT = int(os.environ.get('PG_PORT', 5432))
    PG_USER = os.environ.get('PG_USER', 'postgres')
    PG_PASSWORD = os.environ.get('PG_PASSWORD', 'postgres')
    PG_DATABASE = os.environ.get('PG_DATABASE', 'nav_system')
    
    SQLALCHEMY_DATABASE_URI = (
        f"postgresql+psycopg2://{PG_USER}:{PG_PASSWORD}@"
        f"{PG_HOST}:{PG_PORT}/{PG_DATABASE}"
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_ECHO = False
    
    # CORS配置
    CORS_ORIGINS = os.environ.get('CORS_ORIGINS', 'http://localhost:5173,http://127.0.0.1:5173').split(',')
    
    # 代理链配置 - 信任代理层数
    # 生产环境：根据实际代理层数配置（如 LB + Jump Host = 2）
    PROXY_COUNT = int(os.environ.get('PROXY_COUNT', 1))
    
    # 可信代理IP列表（用于额外验证）
    TRUSTED_PROXIES = os.environ.get('TRUSTED_PROXIES', '').split(',')
    
    # 分页配置
    DEFAULT_PAGE_SIZE = 20
    MAX_PAGE_SIZE = 100
    
    # 搜索配置 - PostgreSQL pg_trgm 优化
    SEARCH_RESULT_LIMIT = 50
    FUZZY_SEARCH_THRESHOLD = 0.3  # pg_trgm 相似度阈值（0.3 是推荐值）
    SEARCH_EXACT_BOOST = 100      # 精确匹配权重加成
    SEARCH_PREFIX_BOOST = 50      # 前缀匹配权重加成
    SEARCH_FUZZY_BOOST = 10       # 模糊匹配权重加成
    
    # 语录配置
    QUOTES_ROTATION_INTERVAL = 10  # 语录轮换间隔（秒）
    
    # Flask-Caching 配置
    CACHE_TYPE = os.environ.get('CACHE_TYPE', 'SimpleCache')  # 可选: 'RedisCache'
    CACHE_DEFAULT_TIMEOUT = 300  # 默认缓存超时（秒）
    CACHE_KEY_PREFIX = 'nav_'


class DevelopmentConfig(Config):
    """开发环境配置"""
    DEBUG = True
    SQLALCHEMY_ECHO = True
    PROXY_COUNT = 0  # 开发环境通常无代理


class TestingConfig(Config):
    """测试环境配置"""
    TESTING = True
    SQLALCHEMY_DATABASE_URI = 'sqlite:///:memory:'


class ProductionConfig(Config):
    """生产环境配置"""
    DEBUG = False
    
    # 生产环境必须设置强密钥
    SECRET_KEY = os.environ.get('SECRET_KEY')
    if not SECRET_KEY:
        raise ValueError('生产环境必须设置 SECRET_KEY 环境变量')
    
    # 生产环境代理配置
    # 典型架构：CDN(1) -> LB(1) -> Jump Host(1) -> App
    PROXY_COUNT = int(os.environ.get('PROXY_COUNT', 2))
    
    # 数据库连接池配置 - PostgreSQL 优化
    SQLALCHEMY_POOL_SIZE = int(os.environ.get('DB_POOL_SIZE', 10))
    SQLALCHEMY_POOL_RECYCLE = 3600
    SQLALCHEMY_POOL_PRE_PING = True
    SQLALCHEMY_MAX_OVERFLOW = 20
    
    # 生产环境使用更高的搜索阈值
    FUZZY_SEARCH_THRESHOLD = 0.4


class StagingConfig(ProductionConfig):
    """预发布环境配置"""
    pass


config = {
    'development': DevelopmentConfig,
    'testing': TestingConfig,
    'production': ProductionConfig,
    'staging': StagingConfig,
    'default': DevelopmentConfig
}
