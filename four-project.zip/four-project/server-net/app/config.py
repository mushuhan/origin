# -*- coding: utf-8 -*-
"""
应用配置模块
支持多环境配置：开发、测试、生产
PostgreSQL + pg_trgm 高性能搜索配置

【混合认证系统配置】
- AUTH_MODE: 认证模式 ('dev' | 'prod')
  - dev: 使用账号密码登录，方便开发调试
  - prod: 强制使用 OAuth2/OIDC (IDaaS) 登录
- ADMIN_EMAILS: 管理员邮箱列表，用户登录时自动判断并赋予 admin 权限
"""
import os
from dotenv import load_dotenv

load_dotenv()


class Config:
    """基础配置"""
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'nav-system-secret-key-2024-enterprise'
    
    # ==================== 数据库配置 ====================
    # PostgreSQL数据库配置
    PG_HOST = os.environ.get('PG_HOST', 'localhost')
    PG_PORT = int(os.environ.get('PG_PORT', 5432))
    PG_USER = os.environ.get('PG_USER', 'postgres')
    PG_PASSWORD = os.environ.get('PG_PASSWORD', '123456')
    PG_DATABASE = os.environ.get('PG_DATABASE', 'nav_system')
    
    SQLALCHEMY_DATABASE_URI = (
        f"postgresql+psycopg2://{PG_USER}:{PG_PASSWORD}@"
        f"{PG_HOST}:{PG_PORT}/{PG_DATABASE}"
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_ECHO = False
    
    # ==================== 认证系统配置 ====================
    # 认证模式：'dev' (账号密码) 或 'prod' (OAuth2/OIDC)
    # 通过 .env 文件中的 AUTH_MODE 环境变量控制
    AUTH_MODE = os.environ.get('AUTH_MODE', 'dev').lower()
    
    # JWT 配置（用于签发登录 Token）
    JWT_SECRET_KEY = os.environ.get('JWT_SECRET_KEY') or SECRET_KEY
    JWT_ACCESS_TOKEN_EXPIRES = int(os.environ.get('JWT_ACCESS_TOKEN_EXPIRES', 86400))  # 默认24小时
    JWT_REFRESH_TOKEN_EXPIRES = int(os.environ.get('JWT_REFRESH_TOKEN_EXPIRES', 604800))  # 默认7天
    
    # ==================== IDaaS OAuth2/OIDC 配置 ====================
    # 这些配置仅在 AUTH_MODE='prod' 时使用
    # 支持标准 OIDC 协议的 IDaaS 提供商
    
    # IDaaS 核心配置（必填项）
    # IDAAS_CLIENT_ID: 消费客户端ID，从 IDaaS 控制台获取
    IDAAS_CLIENT_ID = os.environ.get('IDAAS_CLIENT_ID', '')
    
    # IDAAS_CLIENT_SECRET: 应用消费Secret，从 IDaaS 控制台获取
    IDAAS_CLIENT_SECRET = os.environ.get('IDAAS_CLIENT_SECRET', '')
    
    # IDAAS_TOKEN_URL: 请求token的服务URL，用于用授权码换取access_token
    # 例如: https://your-idaas.com/oauth2/token
    IDAAS_TOKEN_URL = os.environ.get('IDAAS_TOKEN_URL', '')
    
    # IDaaS 其他端点配置
    # IDAAS_AUTHORIZE_URL: 授权端点，用于跳转用户登录
    IDAAS_AUTHORIZE_URL = os.environ.get('IDAAS_AUTHORIZE_URL', '')
    
    # IDAAS_USERINFO_URL: 用户信息端点，用于获取用户详情
    IDAAS_USERINFO_URL = os.environ.get('IDAAS_USERINFO_URL', '')
    
    # OAuth2 回调 URL（前端接收授权码的地址）
    # 这个 URL 需要在 IDaaS 提供商处注册为允许的回调地址
    OAUTH_CALLBACK_URL = os.environ.get('OAUTH_CALLBACK_URL', 'http://localhost:5173/auth/callback')
    
    # OAuth2 请求的权限范围
    OAUTH_SCOPES = os.environ.get('OAUTH_SCOPES', 'openid profile email').split()
    
    # 兼容旧配置名称（向后兼容）
    OAUTH_CLIENT_ID = IDAAS_CLIENT_ID
    OAUTH_CLIENT_SECRET = IDAAS_CLIENT_SECRET
    OAUTH_TOKEN_ENDPOINT = IDAAS_TOKEN_URL
    
    # ==================== 管理员权限配置 ====================
    # 管理员邮箱列表：如果用户登录的邮箱在此列表中，自动赋予 admin 权限
    # 支持逗号分隔的多个邮箱
    # 例如: ADMIN_EMAILS=admin@company.com,superuser@company.com
    ADMIN_EMAILS = [
        email.strip().lower() 
        for email in os.environ.get('ADMIN_EMAILS', '').split(',') 
        if email.strip()
    ]
    
    # ==================== CORS配置 ====================
    CORS_ORIGINS = os.environ.get('CORS_ORIGINS', 'http://localhost:5173,http://127.0.0.1:5173').split(',')
    
    # ==================== 代理链配置 ====================
    # 信任代理层数
    # 生产环境：根据实际代理层数配置（如 LB + Jump Host = 2）
    PROXY_COUNT = int(os.environ.get('PROXY_COUNT', 1))
    
    # 可信代理IP列表（用于额外验证）
    TRUSTED_PROXIES = os.environ.get('TRUSTED_PROXIES', '').split(',')
    
    # ==================== 分页配置 ====================
    DEFAULT_PAGE_SIZE = 20
    MAX_PAGE_SIZE = 100
    
    # ==================== 搜索配置 ====================
    # PostgreSQL pg_trgm 优化
    SEARCH_RESULT_LIMIT = 50
    FUZZY_SEARCH_THRESHOLD = 0.3  # pg_trgm 相似度阈值（0.3 是推荐值）
    SEARCH_EXACT_BOOST = 100      # 精确匹配权重加成
    SEARCH_PREFIX_BOOST = 50      # 前缀匹配权重加成
    SEARCH_FUZZY_BOOST = 10       # 模糊匹配权重加成
    
    # ==================== 语录配置 ====================
    QUOTES_ROTATION_INTERVAL = 10  # 语录轮换间隔（秒）
    
    # ==================== 缓存配置 ====================
    # Flask-Caching 配置
    CACHE_TYPE = os.environ.get('CACHE_TYPE', 'SimpleCache')  # 可选: 'RedisCache'
    CACHE_DEFAULT_TIMEOUT = 300  # 默认缓存超时（秒）
    CACHE_KEY_PREFIX = 'nav_'


class DevelopmentConfig(Config):
    """开发环境配置"""
    DEBUG = True
    SQLALCHEMY_ECHO = True
    PROXY_COUNT = 0  # 开发环境通常无代理
    
    # 开发环境默认使用 dev 认证模式
    AUTH_MODE = os.environ.get('AUTH_MODE', 'dev').lower()


class TestingConfig(Config):
    """测试环境配置"""
    TESTING = True
    SQLALCHEMY_DATABASE_URI = 'sqlite:///:memory:'
    AUTH_MODE = 'dev'  # 测试环境强制使用 dev 模式


class ProductionConfig(Config):
    """生产环境配置"""
    DEBUG = False
    
    # 生产环境必须设置强密钥
    SECRET_KEY = os.environ.get('SECRET_KEY')
    if not SECRET_KEY:
        raise ValueError('生产环境必须设置 SECRET_KEY 环境变量')
    
    JWT_SECRET_KEY = os.environ.get('JWT_SECRET_KEY') or SECRET_KEY
    
    # 生产环境建议使用 prod 认证模式（OAuth2/OIDC）
    # 但也允许通过环境变量覆盖
    AUTH_MODE = os.environ.get('AUTH_MODE', 'prod').lower()
    
    # 生产环境代理配置
    # 典型架构：CDN(1) -> LB(1) -> Jump Host(1) -> App
    PROXY_COUNT = int(os.environ.get('PROXY_COUNT', 2))
    
    # 数据库连接池配置 - PostgreSQL 优化
    SQLALCHEMY_POOL_SIZE = int(os.environ.get('DB_POOL_SIZE', 10))
    SQLALCHEMY_POOL_RECYCLE = 3600
    SQLALCHEMY_POOL_PRE_PING = True
    SQLALCHEMY_MAX_OVERFLOW = 20
    
    # 生产环境使用更高的搜索阈值
    FUZZY_SEARCH_THRESHOLD = 0.4


class StagingConfig(ProductionConfig):
    """预发布环境配置"""
    # 预发布环境可以使用 dev 模式方便测试
    AUTH_MODE = os.environ.get('AUTH_MODE', 'dev').lower()


config = {
    'development': DevelopmentConfig,
    'testing': TestingConfig,
    'production': ProductionConfig,
    'staging': StagingConfig,
    'default': DevelopmentConfig
}
