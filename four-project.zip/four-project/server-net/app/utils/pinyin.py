# -*- coding: utf-8 -*-
"""
拼音工具模块 - 中文转拼音支持
用于实现拼音搜索功能
"""
import re
from pypinyin import pinyin, lazy_pinyin, Style


def generate_pinyin_fields(text):
    """
    生成拼音字段
    
    Args:
        text: 中文文本（如姓名、网站名称）
    
    Returns:
        tuple: (全拼, 首字母)
        
    示例:
        generate_pinyin_fields("张三") -> ("zhangsan", "zs")
        generate_pinyin_fields("北京大学") -> ("beijingdaxue", "bjdx")
        generate_pinyin_fields("AI助手") -> ("aizhushou", "azs")
    """
    if not text:
        return '', ''
    
    # 清理文本，只保留中文、字母、数字
    cleaned_text = re.sub(r'[^\u4e00-\u9fa5a-zA-Z0-9]', '', text)
    
    if not cleaned_text:
        return '', ''
    
    try:
        # 全拼：张三 -> zhangsan
        full_pinyin = ''.join(lazy_pinyin(cleaned_text))
        
        # 首字母：张三 -> zs
        # pinyin 返回列表的列表，每个字一个列表
        initials_list = pinyin(cleaned_text, style=Style.FIRST_LETTER)
        initials = ''.join([p[0] for p in initials_list if p])
        
        return full_pinyin.lower(), initials.lower()
    except Exception as e:
        print(f"拼音转换失败: {text}, 错误: {e}")
        return '', ''


def get_pinyin(text, style='full'):
    """
    获取指定格式的拼音
    
    Args:
        text: 中文文本
        style: 拼音格式
            - 'full': 全拼，无空格 (zhangsan)
            - 'full_space': 全拼，带空格 (zhang san)
            - 'initials': 首字母 (zs)
            - 'first_letter': 每个字的首字母带空格 (z s)
    
    Returns:
        str: 转换后的拼音
    """
    if not text:
        return ''
    
    try:
        if style == 'full':
            return ''.join(lazy_pinyin(text)).lower()
        elif style == 'full_space':
            return ' '.join(lazy_pinyin(text)).lower()
        elif style == 'initials':
            initials_list = pinyin(text, style=Style.FIRST_LETTER)
            return ''.join([p[0] for p in initials_list if p]).lower()
        elif style == 'first_letter':
            initials_list = pinyin(text, style=Style.FIRST_LETTER)
            return ' '.join([p[0] for p in initials_list if p]).lower()
        else:
            return ''.join(lazy_pinyin(text)).lower()
    except Exception:
        return ''


def is_pinyin_match(text, keyword):
    """
    判断关键词是否与文本的拼音匹配
    
    Args:
        text: 中文文本
        keyword: 搜索关键词（可能是拼音）
    
    Returns:
        bool: 是否匹配
    """
    if not text or not keyword:
        return False
    
    keyword = keyword.lower()
    full_pinyin, initials = generate_pinyin_fields(text)
    
    # 完全匹配
    if full_pinyin == keyword or initials == keyword:
        return True
    
    # 前缀匹配
    if full_pinyin.startswith(keyword) or initials.startswith(keyword):
        return True
    
    # 包含匹配
    if keyword in full_pinyin or keyword in initials:
        return True
    
    return False


# ==================== SQLAlchemy 事件监听器 ====================

def setup_pinyin_listeners(db):
    """
    设置 SQLAlchemy 事件监听器，自动生成拼音字段
    
    在 Flask app 初始化时调用此函数
    
    Args:
        db: SQLAlchemy 实例
    """
    from sqlalchemy import event
    from app.models.website import Website
    from app.models.employee import Employee
    
    def auto_generate_pinyin_website(mapper, connection, target):
        """Website 保存前自动生成拼音"""
        if target.name:
            full_pinyin, initials = generate_pinyin_fields(target.name)
            target.pinyin = full_pinyin
            target.pinyin_initials = initials
    
    def auto_generate_pinyin_employee(mapper, connection, target):
        """Employee 保存前自动生成拼音"""
        if target.name:
            full_pinyin, initials = generate_pinyin_fields(target.name)
            target.pinyin = full_pinyin
            target.pinyin_initials = initials
    
    # 注册事件监听器
    event.listen(Website, 'before_insert', auto_generate_pinyin_website)
    event.listen(Website, 'before_update', auto_generate_pinyin_website)
    event.listen(Employee, 'before_insert', auto_generate_pinyin_employee)
    event.listen(Employee, 'before_update', auto_generate_pinyin_employee)


def batch_update_pinyin(db, model_class, batch_size=100):
    """
    批量更新现有数据的拼音字段
    
    Args:
        db: SQLAlchemy 实例
        model_class: 模型类 (Website 或 Employee)
        batch_size: 每批处理数量
    
    Returns:
        int: 更新的记录数
    
    使用方法（在 Flask shell 中）:
        from app.utils.pinyin import batch_update_pinyin
        from app.models.employee import Employee
        from app import db
        batch_update_pinyin(db, Employee)
    """
    updated_count = 0
    
    # 查询所有缺少拼音的记录
    query = model_class.query.filter(
        db.or_(
            model_class.pinyin.is_(None),
            model_class.pinyin == '',
            model_class.pinyin_initials.is_(None),
            model_class.pinyin_initials == ''
        )
    )
    
    total = query.count()
    print(f"找到 {total} 条需要更新拼音的记录")
    
    # 分批处理
    offset = 0
    while True:
        records = query.limit(batch_size).offset(offset).all()
        if not records:
            break
        
        for record in records:
            if hasattr(record, 'name') and record.name:
                full_pinyin, initials = generate_pinyin_fields(record.name)
                record.pinyin = full_pinyin
                record.pinyin_initials = initials
                updated_count += 1
        
        db.session.commit()
        print(f"已更新 {min(offset + batch_size, total)}/{total} 条记录")
        offset += batch_size
    
    print(f"拼音更新完成，共更新 {updated_count} 条记录")
    return updated_count




