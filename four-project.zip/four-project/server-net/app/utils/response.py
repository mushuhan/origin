# -*- coding: utf-8 -*-
"""
统一响应格式工具
"""
from flask import jsonify


def success_response(data=None, message='success', code=200):
    """
    成功响应
    
    Args:
        data: 响应数据
        message: 响应消息
        code: HTTP状态码
    
    Returns:
        Flask Response
    """
    response = {
        'code': code,
        'message': message,
        'data': data
    }
    return jsonify(response), code


def error_response(message='error', code=400, data=None):
    """
    错误响应
    
    Args:
        message: 错误消息
        code: HTTP状态码
        data: 附加数据（如验证错误详情）
    
    Returns:
        Flask Response
    """
    response = {
        'code': code,
        'message': message,
        'data': data
    }
    return jsonify(response), code


def paginate_response(items, total, page, per_page, message='success'):
    """
    分页响应
    
    Args:
        items: 数据列表
        total: 总数
        page: 当前页
        per_page: 每页数量
        message: 响应消息
    
    Returns:
        Flask Response
    """
    response = {
        'code': 200,
        'message': message,
        'data': {
            'items': items,
            'pagination': {
                'total': total,
                'page': page,
                'per_page': per_page,
                'pages': (total + per_page - 1) // per_page if per_page > 0 else 0
            }
        }
    }
    return jsonify(response), 200
