# -*- coding: utf-8 -*-
"""
安全工具
"""
import re
import uuid
from urllib.parse import urlparse


def generate_uuid():
    """生成UUID v4"""
    return str(uuid.uuid4())


def validate_uuid(uuid_string):
    """验证UUID格式"""
    try:
        uuid_obj = uuid.UUID(uuid_string, version=4)
        return str(uuid_obj) == uuid_string.lower()
    except (ValueError, AttributeError):
        return False


def validate_url(url):
    """验证URL格式"""
    try:
        result = urlparse(url)
        return all([result.scheme, result.netloc])
    except (ValueError, AttributeError):
        return False


def sanitize_string(s, max_length=255):
    """
    清理字符串，移除潜在危险字符
    """
    if not s:
        return s
    
    # 移除HTML标签
    s = re.sub(r'<[^>]+>', '', s)
    
    # 移除控制字符
    s = re.sub(r'[\x00-\x1f\x7f-\x9f]', '', s)
    
    # 限制长度
    if len(s) > max_length:
        s = s[:max_length]
    
    return s.strip()


def sanitize_html(html):
    """
    清理HTML，只保留安全标签
    """
    if not html:
        return html
    
    # 允许的标签
    allowed_tags = ['p', 'br', 'strong', 'em', 'u', 's', 'span', 'a']
    
    # 移除所有不允许的标签
    pattern = r'<(?!/?(' + '|'.join(allowed_tags) + r')(\s|>))[^>]+>'
    html = re.sub(pattern, '', html, flags=re.IGNORECASE)
    
    # 移除危险属性
    html = re.sub(r'\s(on\w+|javascript:)[^>]*', '', html, flags=re.IGNORECASE)
    
    return html
