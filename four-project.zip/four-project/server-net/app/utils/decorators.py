# -*- coding: utf-8 -*-
"""
装饰器工具

包含：
- require_user: 普通用户身份验证
- admin_required: 管理员权限验证（解析JWT Token）
- validate_json: JSON请求体验证
- rate_limit: 速率限制
"""
from functools import wraps
from flask import g, request, current_app
import jwt
from datetime import datetime

from app.utils.response import error_response


def require_user(f):
    """
    要求用户身份验证的装饰器
    检查请求头中的 X-User-Token（用于普通前台用户）
    """
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not g.get('user_uuid'):
            return error_response('请先登录或初始化用户', 401)
        return f(*args, **kwargs)
    return decorated_function


def admin_required(f):
    """
    管理员权限验证装饰器
    
    【验证逻辑】
    1. 从请求头 Authorization: Bearer <token> 中提取 JWT Token
    2. 验证 Token 签名和有效期
    3. 解析 Token 中的 user_uuid
    4. 查询数据库获取用户
    5. 验证用户 role 是否为 'admin'
    
    如果验证失败，返回相应的错误：
    - 401: 未提供 Token 或 Token 无效/过期
    - 403: 用户不是管理员
    - 404: 用户不存在
    """
    @wraps(f)
    def decorated_function(*args, **kwargs):
        from app.models.user import User
        
        # 1. 获取 Authorization 头
        auth_header = request.headers.get('Authorization')
        if not auth_header:
            return error_response('未提供认证令牌', 401)
        
        # 2. 解析 Bearer Token
        parts = auth_header.split()
        if len(parts) != 2 or parts[0].lower() != 'bearer':
            return error_response('认证令牌格式错误，应为 Bearer <token>', 401)
        
        token = parts[1]
        
        # 3. 验证并解析 JWT
        try:
            payload = jwt.decode(
                token,
                current_app.config['JWT_SECRET_KEY'],
                algorithms=['HS256']
            )
        except jwt.ExpiredSignatureError:
            return error_response('认证令牌已过期，请重新登录', 401)
        except jwt.InvalidTokenError as e:
            current_app.logger.warning(f'Invalid JWT token: {e}')
            return error_response('认证令牌无效', 401)
        
        # 4. 获取用户
        user_uuid = payload.get('sub')
        if not user_uuid:
            return error_response('认证令牌缺少用户标识', 401)
        
        user = User.query.get(user_uuid)
        if not user:
            return error_response('用户不存在', 404)
        
        if not user.is_active:
            return error_response('账户已被禁用', 403)
        
        # 5. 验证管理员权限
        if not user.is_admin():
            return error_response('需要管理员权限', 403)
        
        # 6. 将用户信息存入 g 对象，供后续使用
        g.admin_user = user
        g.admin_uuid = user_uuid
        
        return f(*args, **kwargs)
    return decorated_function


def login_required(f):
    """
    登录验证装饰器（不要求管理员权限）
    
    与 admin_required 类似，但只验证用户是否登录，不检查角色
    用于需要登录但不需要管理员权限的接口
    """
    @wraps(f)
    def decorated_function(*args, **kwargs):
        from app.models.user import User
        
        # 1. 获取 Authorization 头
        auth_header = request.headers.get('Authorization')
        if not auth_header:
            return error_response('未提供认证令牌', 401)
        
        # 2. 解析 Bearer Token
        parts = auth_header.split()
        if len(parts) != 2 or parts[0].lower() != 'bearer':
            return error_response('认证令牌格式错误', 401)
        
        token = parts[1]
        
        # 3. 验证并解析 JWT
        try:
            payload = jwt.decode(
                token,
                current_app.config['JWT_SECRET_KEY'],
                algorithms=['HS256']
            )
        except jwt.ExpiredSignatureError:
            return error_response('认证令牌已过期', 401)
        except jwt.InvalidTokenError:
            return error_response('认证令牌无效', 401)
        
        # 4. 获取用户
        user_uuid = payload.get('sub')
        if not user_uuid:
            return error_response('认证令牌缺少用户标识', 401)
        
        user = User.query.get(user_uuid)
        if not user:
            return error_response('用户不存在', 404)
        
        if not user.is_active:
            return error_response('账户已被禁用', 403)
        
        # 5. 将用户信息存入 g 对象
        g.current_user = user
        g.current_user_uuid = user_uuid
        
        return f(*args, **kwargs)
    return decorated_function


def validate_json(required_fields=None):
    """
    验证JSON请求体的装饰器
    
    Args:
        required_fields: 必需字段列表
    """
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            data = request.get_json()
            
            if data is None:
                return error_response('请求体必须是JSON格式', 400)
            
            if required_fields:
                missing = [field for field in required_fields if field not in data or data[field] is None]
                if missing:
                    return error_response(f'缺少必填字段: {", ".join(missing)}', 400)
            
            return f(*args, **kwargs)
        return decorated_function
    return decorator


def rate_limit(limit=100, period=60):
    """
    简单的速率限制装饰器（生产环境建议使用Redis）
    
    Args:
        limit: 限制次数
        period: 时间周期（秒）
    """
    from collections import defaultdict
    from time import time
    
    # 存储请求记录
    requests = defaultdict(list)
    
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            # 获取客户端标识
            client_id = g.get('client_ip', request.remote_addr)
            current_time = time()
            
            # 清理过期记录
            requests[client_id] = [
                t for t in requests[client_id] 
                if current_time - t < period
            ]
            
            # 检查是否超限
            if len(requests[client_id]) >= limit:
                return error_response('请求过于频繁，请稍后再试', 429)
            
            # 记录请求
            requests[client_id].append(current_time)
            
            return f(*args, **kwargs)
        return decorated_function
    return decorator
