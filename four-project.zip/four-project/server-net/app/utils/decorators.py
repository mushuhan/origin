# -*- coding: utf-8 -*-
"""
装饰器工具
"""
from functools import wraps
from flask import g, request
from app.utils.response import error_response


def require_user(f):
    """
    要求用户身份验证的装饰器
    检查请求头中的 X-User-Token
    """
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not g.get('user_uuid'):
            return error_response('请先登录或初始化用户', 401)
        return f(*args, **kwargs)
    return decorated_function


def validate_json(required_fields=None):
    """
    验证JSON请求体的装饰器
    
    Args:
        required_fields: 必需字段列表
    """
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            data = request.get_json()
            
            if data is None:
                return error_response('请求体必须是JSON格式', 400)
            
            if required_fields:
                missing = [field for field in required_fields if field not in data or data[field] is None]
                if missing:
                    return error_response(f'缺少必填字段: {", ".join(missing)}', 400)
            
            return f(*args, **kwargs)
        return decorated_function
    return decorator


def rate_limit(limit=100, period=60):
    """
    简单的速率限制装饰器（生产环境建议使用Redis）
    
    Args:
        limit: 限制次数
        period: 时间周期（秒）
    """
    from collections import defaultdict
    from time import time
    
    # 存储请求记录
    requests = defaultdict(list)
    
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            # 获取客户端标识
            client_id = g.get('client_ip', request.remote_addr)
            current_time = time()
            
            # 清理过期记录
            requests[client_id] = [
                t for t in requests[client_id] 
                if current_time - t < period
            ]
            
            # 检查是否超限
            if len(requests[client_id]) >= limit:
                return error_response('请求过于频繁，请稍后再试', 429)
            
            # 记录请求
            requests[client_id].append(current_time)
            
            return f(*args, **kwargs)
        return decorated_function
    return decorator
