"""
科室控制器 - 科室信息的增删改查
"""
from flask import Blueprint, request
from app.models.department import Department
from app.utils.response import success_response, error_response

bp = Blueprint('departments', __name__, url_prefix='/api/departments')


@bp.route('', methods=['GET'])
def get_departments():
    """获取所有科室列表"""
    departments = Department.get_all()
    return success_response([d.to_dict() for d in departments])


@bp.route('/<int:dept_id>', methods=['GET'])
def get_department(dept_id):
    """获取单个科室详情"""
    department = Department.get_by_id(dept_id)
    
    if not department:
        return error_response('科室不存在', 404)
    
    return success_response(department.to_dict())


@bp.route('', methods=['POST'])
def create_department():
    """创建新科室"""
    data = request.get_json()
    
    if not data.get('name'):
        return error_response('科室名称不能为空')
    
    department = Department.create(
        name=data['name'],
        description=data.get('description', ''),
        icon=data.get('icon', 'OfficeBuilding'),
        contact=data.get('contact', ''),
        sort_order=data.get('sort_order', 0)
    )
    
    return success_response(department.to_dict(), '创建成功', 201)


@bp.route('/<int:dept_id>', methods=['PUT'])
def update_department(dept_id):
    """更新科室"""
    department = Department.get_by_id(dept_id)
    
    if not department:
        return error_response('科室不存在', 404)
    
    data = request.get_json()
    department.update(
        name=data.get('name'),
        description=data.get('description'),
        icon=data.get('icon'),
        contact=data.get('contact'),
        sort_order=data.get('sort_order')
    )
    
    return success_response(department.to_dict(), '更新成功')


@bp.route('/<int:dept_id>', methods=['DELETE'])
def delete_department(dept_id):
    """删除科室"""
    department = Department.get_by_id(dept_id)
    
    if not department:
        return error_response('科室不存在', 404)
    
    department.delete()
    return success_response(None, '删除成功')

