# -*- coding: utf-8 -*-
"""
搜索控制器
智能模糊搜索实现
"""
from flask import Blueprint, request, g, current_app
from app import db
from app.models.website import Website
from app.models.search import SearchHistory
from app.services.search_service import SearchService
from app.utils.response import success_response, error_response
from app.utils.decorators import require_user, admin_required

search_bp = Blueprint('search', __name__)


@search_bp.route('', methods=['GET'])
def search():
    """
    智能模糊搜索
    检索域：网站名、域名、描述、拼音
    """
    keyword = request.args.get('keyword', '').strip()
    limit = request.args.get('limit', 50, type=int)
    
    if not keyword:
        return success_response([])
    
    # 限制搜索结果数量
    limit = min(limit, current_app.config.get('SEARCH_RESULT_LIMIT', 50))
    
    # 执行模糊搜索
    results = SearchService.fuzzy_search(keyword, limit)
    
    # 记录搜索历史
    SearchService.record_search(keyword)
    
    return success_response(results)


@search_bp.route('/suggestions', methods=['GET'])
def get_suggestions():
    """获取搜索建议（实时联想）"""
    keyword = request.args.get('keyword', '').strip()
    limit = request.args.get('limit', 10, type=int)
    
    suggestions = []
    hot_keywords = []
    
    if keyword:
        # 模糊匹配网站名称
        suggestions = SearchService.get_suggestions(keyword, limit)
    
    # 获取热门搜索关键词
    hot_keywords = SearchService.get_hot_keywords(10)
    
    return success_response({
        'suggestions': suggestions,
        'hot_keywords': hot_keywords
    })


@search_bp.route('/history', methods=['GET'])
def get_search_history():
    """获取搜索历史"""
    limit = request.args.get('limit', 20, type=int)
    
    history = SearchHistory.query.order_by(
        SearchHistory.last_searched_at.desc()
    ).limit(limit).all()
    
    return success_response([h.to_dict() for h in history])


@search_bp.route('/history', methods=['DELETE'])
@admin_required
def clear_search_history():
    """清空搜索历史（管理员）"""
    SearchHistory.query.delete()
    db.session.commit()
    
    return success_response(None, '搜索历史已清空')

