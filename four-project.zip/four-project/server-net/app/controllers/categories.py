# -*- coding: utf-8 -*-
"""
分类控制器
处理侧边栏分类的CRUD操作
"""
from flask import Blueprint, request, g
from app import db
from app.models.category import SidebarCategory
from app.models.section import Section
from app.utils.response import success_response, error_response
from app.utils.decorators import require_user

categories_bp = Blueprint('categories', __name__)


@categories_bp.route('', methods=['GET'])
def get_categories():
    """获取所有分类"""
    include_sections = request.args.get('include_sections', 'false').lower() == 'true'
    
    categories = SidebarCategory.query.order_by(SidebarCategory.sort_order).all()
    
    if include_sections:
        data = [c.to_dict_with_sections() for c in categories]
    else:
        data = [c.to_dict() for c in categories]
    
    return success_response(data)


@categories_bp.route('/<int:id>', methods=['GET'])
def get_category(id):
    """获取单个分类详情（含分区和网址）"""
    category = SidebarCategory.query.get_or_404(id)
    return success_response(category.to_dict_with_sections())


@categories_bp.route('', methods=['POST'])
def create_category():
    """创建分类"""
    data = request.get_json()
    
    if not data or not data.get('name'):
        return error_response('分类名称不能为空', 400)
    
    # 获取最大排序值
    max_order = db.session.query(db.func.max(SidebarCategory.sort_order)).scalar() or 0
    
    category = SidebarCategory(
        name=data['name'],
        icon=data.get('icon', 'Folder'),
        sort_order=max_order + 1,
        is_system=False
    )
    
    db.session.add(category)
    db.session.commit()
    
    return success_response(category.to_dict(), '创建成功', 201)


@categories_bp.route('/<int:id>', methods=['PUT'])
def update_category(id):
    """更新分类"""
    category = SidebarCategory.query.get_or_404(id)
    data = request.get_json()
    
    if data.get('name'):
        category.name = data['name']
    if data.get('icon'):
        category.icon = data['icon']
    if 'sort_order' in data:
        category.sort_order = data['sort_order']
    
    db.session.commit()
    
    return success_response(category.to_dict(), '更新成功')


@categories_bp.route('/<int:id>', methods=['DELETE'])
def delete_category(id):
    """删除分类"""
    category = SidebarCategory.query.get_or_404(id)
    
    if category.is_system:
        return error_response('系统分类不能删除', 403)
    
    db.session.delete(category)
    db.session.commit()
    
    return success_response(None, '删除成功')


@categories_bp.route('/batch-reorder', methods=['PUT'])
def batch_reorder():
    """批量重排序分类"""
    data = request.get_json()
    items = data.get('items', [])
    
    for item in items:
        category = SidebarCategory.query.get(item['id'])
        if category:
            category.sort_order = item['sort_order']
    
    db.session.commit()
    
    return success_response(None, '排序更新成功')

