# -*- coding: utf-8 -*-
"""
管理员控制器

【功能概述】
- 用户管理：列表、搜索、角色设置、账户状态管理
- 数据导入：Excel 批量导入用户
- 系统统计：Dashboard 数据统计

【权限控制】
所有接口都需要 @admin_required 装饰器
只有 role='admin' 的用户才能访问
"""
import uuid
import io
from datetime import datetime, timedelta
from flask import Blueprint, request, current_app, send_file, g

import pandas as pd

from app import db
from app.models.user import User
from app.utils.response import success_response, error_response, paginate_response
from app.utils.decorators import admin_required


admin_bp = Blueprint('admin', __name__)

# Excel 导入限制
MAX_IMPORT_SIZE_BYTES = 5 * 1024 * 1024  # 5MB
MAX_IMPORT_ROWS = 5000


# ==================== 系统统计 ====================

@admin_bp.route('/stats', methods=['GET'])
@admin_required
def get_dashboard_stats():
    """
    获取 Dashboard 统计数据
    
    Returns:
        {
            "total_users": 1000,
            "active_users": 950,
            "admin_users": 5,
            "new_users_today": 10,
            "new_users_week": 50,
            "new_users_month": 200
        }
    """
    try:
        now = datetime.utcnow()
        today_start = now.replace(hour=0, minute=0, second=0, microsecond=0)
        week_start = today_start - timedelta(days=7)
        month_start = today_start - timedelta(days=30)
        
        stats = {
            # 用户统计
            'total_users': User.query.count(),
            'active_users': User.query.filter_by(is_active=True).count(),
            'admin_users': User.query.filter_by(role='admin').count(),
            
            # 新增用户统计
            'new_users_today': User.query.filter(User.created_at >= today_start).count(),
            'new_users_week': User.query.filter(User.created_at >= week_start).count(),
            'new_users_month': User.query.filter(User.created_at >= month_start).count(),
            
            # 登录统计
            'active_today': User.query.filter(User.last_login_at >= today_start).count(),
            'active_week': User.query.filter(User.last_login_at >= week_start).count(),
            
            # 认证模式
            'auth_mode': current_app.config.get('AUTH_MODE', 'dev'),
            
            # 有密码用户数（DEV模式相关）
            'users_with_password': User.query.filter(User.password_hash != None).count(),
            
            # OAuth 用户数
            'users_with_oauth': User.query.filter(User.oauth_id != None).count(),
        }
        
        return success_response(stats)
        
    except Exception as e:
        current_app.logger.error(f'Get dashboard stats error: {e}')
        return error_response('获取统计数据失败', 500)


@admin_bp.route('/stats/trends', methods=['GET'])
@admin_required
def get_user_trends():
    """
    获取用户增长趋势（最近30天）
    
    Returns:
        {
            "dates": ["2024-01-01", ...],
            "new_users": [10, 15, ...],
            "active_users": [100, 120, ...]
        }
    """
    try:
        days = request.args.get('days', 30, type=int)
        days = min(days, 90)  # 最多90天
        
        now = datetime.utcnow()
        dates = []
        new_users = []
        active_users = []
        
        for i in range(days - 1, -1, -1):
            date = now - timedelta(days=i)
            day_start = date.replace(hour=0, minute=0, second=0, microsecond=0)
            day_end = day_start + timedelta(days=1)
            
            dates.append(day_start.strftime('%Y-%m-%d'))
            new_users.append(
                User.query.filter(
                    User.created_at >= day_start,
                    User.created_at < day_end
                ).count()
            )
            active_users.append(
                User.query.filter(
                    User.last_login_at >= day_start,
                    User.last_login_at < day_end
                ).count()
            )
        
        return success_response({
            'dates': dates,
            'new_users': new_users,
            'active_users': active_users
        })
        
    except Exception as e:
        current_app.logger.error(f'Get user trends error: {e}')
        return error_response('获取趋势数据失败', 500)


# ==================== 用户管理 ====================

@admin_bp.route('/users', methods=['GET'])
@admin_required
def list_users():
    """
    获取用户列表（分页）
    
    Query Params:
        page: 页码（默认1）
        per_page: 每页数量（默认20，最大100）
        search: 搜索关键词（邮箱/名称）
        role: 角色筛选 ('user' | 'admin' | 'all')
        status: 状态筛选 ('active' | 'inactive' | 'all')
        sort: 排序字段 ('created_at' | 'last_login_at' | 'email')
        order: 排序方向 ('asc' | 'desc')
    
    Returns:
        分页用户列表
    """
    try:
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        per_page = min(per_page, 100)  # 最大100
        
        search = request.args.get('search', '').strip()
        role = request.args.get('role', 'all')
        status = request.args.get('status', 'all')
        sort = request.args.get('sort', 'created_at')
        order = request.args.get('order', 'desc')
        
        # 构建查询
        query = User.query
        
        # 搜索
        if search:
            search_pattern = f'%{search}%'
            query = query.filter(
                db.or_(
                    User.email.ilike(search_pattern),
                    User.name.ilike(search_pattern),
                    User.uuid.ilike(search_pattern)
                )
            )
        
        # 角色筛选
        if role != 'all':
            query = query.filter(User.role == role)
        
        # 状态筛选
        if status == 'active':
            query = query.filter(User.is_active == True)
        elif status == 'inactive':
            query = query.filter(User.is_active == False)
        
        # 排序
        sort_column = getattr(User, sort, User.created_at)
        if order == 'desc':
            query = query.order_by(sort_column.desc())
        else:
            query = query.order_by(sort_column.asc())
        
        # 分页
        pagination = query.paginate(page=page, per_page=per_page, error_out=False)
        
        users = [user.to_admin_dict() for user in pagination.items]
        
        return paginate_response(
            items=users,
            total=pagination.total,
            page=page,
            per_page=per_page
        )
        
    except Exception as e:
        current_app.logger.error(f'List users error: {e}')
        return error_response('获取用户列表失败', 500)


@admin_bp.route('/users/<user_uuid>', methods=['GET'])
@admin_required
def get_user(user_uuid):
    """
    获取单个用户详情
    """
    user = User.query.get(user_uuid)
    if not user:
        return error_response('用户不存在', 404)
    
    return success_response(user.to_admin_dict())


@admin_bp.route('/users/<user_uuid>', methods=['PUT'])
@admin_required
def update_user(user_uuid):
    """
    更新用户信息
    
    Request Body:
        {
            "name": "新名称",
            "email": "new@email.com",
            "role": "admin" | "user",
            "is_active": true | false
        }
    """
    user = User.query.get(user_uuid)
    if not user:
        return error_response('用户不存在', 404)
    
    data = request.get_json()
    if not data:
        return error_response('请求体不能为空', 400)
    
    # 更新允许的字段
    if 'name' in data:
        user.name = data['name']
    
    if 'email' in data:
        new_email = data['email'].strip().lower()
        # 检查邮箱是否被其他用户使用
        existing = User.query.filter(
            User.email == new_email,
            User.uuid != user_uuid
        ).first()
        if existing:
            return error_response('该邮箱已被其他用户使用', 400)
        user.email = new_email
    
    if 'role' in data and data['role'] in ['user', 'admin']:
        # 防止管理员取消自己的权限
        admin_user = g.admin_user
        if user.uuid == admin_user.uuid and data['role'] != 'admin':
            return error_response('不能取消自己的管理员权限', 400)
        user.role = data['role']
    
    if 'is_active' in data:
        # 防止管理员禁用自己
        admin_user = g.admin_user
        if user.uuid == admin_user.uuid and not data['is_active']:
            return error_response('不能禁用自己的账户', 400)
        user.is_active = data['is_active']
    
    try:
        db.session.commit()
        return success_response(user.to_admin_dict(), '用户信息已更新')
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f'Update user error: {e}')
        return error_response('更新用户信息失败', 500)


@admin_bp.route('/users/<user_uuid>', methods=['DELETE'])
@admin_required
def delete_user(user_uuid):
    """
    删除用户
    
    注意：这会删除用户的所有关联数据
    """
    user = User.query.get(user_uuid)
    if not user:
        return error_response('用户不存在', 404)
    
    # 防止删除自己
    admin_user = g.admin_user
    if user.uuid == admin_user.uuid:
        return error_response('不能删除自己的账户', 400)
    
    try:
        db.session.delete(user)
        db.session.commit()
        return success_response(None, '用户已删除')
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f'Delete user error: {e}')
        return error_response('删除用户失败', 500)


@admin_bp.route('/users/<user_uuid>/role', methods=['PUT'])
@admin_required
def set_user_role(user_uuid):
    """
    设置用户角色（快捷接口）
    
    Request Body:
        {
            "role": "admin" | "user"
        }
    """
    user = User.query.get(user_uuid)
    if not user:
        return error_response('用户不存在', 404)
    
    data = request.get_json()
    if not data or 'role' not in data:
        return error_response('请提供 role 参数', 400)
    
    role = data['role']
    if role not in ['user', 'admin']:
        return error_response('role 必须是 user 或 admin', 400)
    
    # 防止管理员取消自己的权限
    admin_user = g.admin_user
    if user.uuid == admin_user.uuid and role != 'admin':
        return error_response('不能取消自己的管理员权限', 400)
    
    user.role = role
    db.session.commit()
    
    return success_response(user.to_admin_dict(), f'用户角色已设置为 {role}')


@admin_bp.route('/users/<user_uuid>/toggle-status', methods=['POST'])
@admin_required
def toggle_user_status(user_uuid):
    """
    切换用户账户状态（启用/禁用）
    """
    user = User.query.get(user_uuid)
    if not user:
        return error_response('用户不存在', 404)
    
    # 防止禁用自己
    admin_user = g.admin_user
    if user.uuid == admin_user.uuid:
        return error_response('不能禁用自己的账户', 400)
    
    user.is_active = not user.is_active
    db.session.commit()
    
    status_text = '已启用' if user.is_active else '已禁用'
    return success_response(user.to_admin_dict(), f'用户账户{status_text}')


# ==================== 用户创建 ====================

@admin_bp.route('/users', methods=['POST'])
@admin_required
def create_user():
    """
    创建新用户（管理员手动创建）
    
    Request Body:
        {
            "email": "user@example.com",
            "name": "用户名",
            "password": "password123" (DEV模式可选),
            "role": "user" | "admin"
        }
    """
    data = request.get_json()
    if not data:
        return error_response('请求体不能为空', 400)
    
    email = data.get('email', '').strip().lower()
    name = data.get('name', '').strip()
    password = data.get('password', '')
    role = data.get('role', 'user')
    
    if not email:
        return error_response('邮箱不能为空', 400)
    
    # 检查邮箱是否已存在
    existing = User.query.filter_by(email=email).first()
    if existing:
        return error_response('该邮箱已被使用', 400)
    
    # 创建用户
    new_uuid = str(uuid.uuid4())
    user = User(
        uuid=new_uuid,
        email=email,
        name=name or email.split('@')[0],
        role=role if role in ['user', 'admin'] else 'user',
        is_active=True
    )
    
    # 如果提供了密码，设置密码（DEV模式用）
    if password:
        user.set_password(password)
    
    try:
        db.session.add(user)
        db.session.commit()
        return success_response(user.to_admin_dict(), '用户创建成功', 201)
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f'Create user error: {e}')
        return error_response('创建用户失败', 500)


# ==================== Excel 导入 ====================

@admin_bp.route('/import/template', methods=['GET'])
@admin_required
def download_import_template():
    """
    下载 Excel 导入模板
    
    模板包含以下列：
    - email: 邮箱（必填）
    - name: 姓名
    - role: 角色（user/admin）
    - password: 密码（DEV模式可选）
    """
    try:
        # 创建模板 DataFrame
        template_data = {
            'email': ['user1@example.com', 'user2@example.com'],
            'name': ['用户1', '用户2'],
            'role': ['user', 'admin'],
            'password': ['password123', '']  # 空表示不设置密码
        }
        df = pd.DataFrame(template_data)
        
        # 写入到内存中的 Excel 文件
        output = io.BytesIO()
        with pd.ExcelWriter(output, engine='openpyxl') as writer:
            df.to_excel(writer, index=False, sheet_name='用户导入模板')
            
            # 添加说明 sheet
            instructions = pd.DataFrame({
                '说明': [
                    '1. email 列为必填，其他列可选',
                    '2. role 列只能填 user 或 admin',
                    '3. password 列仅在 DEV 模式下有效',
                    '4. 如果邮箱已存在，将更新对应用户信息',
                    '5. 如果邮箱不存在，将创建新用户'
                ]
            })
            instructions.to_excel(writer, index=False, sheet_name='填写说明')
        
        output.seek(0)
        
        return send_file(
            output,
            mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            as_attachment=True,
            download_name='user_import_template.xlsx'
        )
        
    except Exception as e:
        current_app.logger.error(f'Download template error: {e}')
        return error_response('下载模板失败', 500)


@admin_bp.route('/import/excel', methods=['POST'])
@admin_required
def import_users_from_excel():
    """
    从 Excel 导入用户
    
    【业务逻辑】
    1. 读取 Excel 文件
    2. 遍历每一行
    3. 根据邮箱判断用户是否存在：
       - 存在：更新用户信息
       - 不存在：创建新用户（生成新 UUID）
    4. 返回导入结果统计
    
    【关键点】
    - UUID 是系统自动生成的，不从 Excel 导入
    - 这样保证了 UUID 的唯一性和系统控制权
    
    Request:
        multipart/form-data
        file: Excel 文件
    
    Returns:
        {
            "total": 100,
            "created": 80,
            "updated": 15,
            "failed": 5,
            "errors": [
                {"row": 3, "email": "bad@", "reason": "邮箱格式错误"}
            ]
        }
    """
    if 'file' not in request.files:
        return error_response('请上传 Excel 文件', 400)
    
    file = request.files['file']
    if not file.filename:
        return error_response('文件名不能为空', 400)

    # 尺寸限制，防止压缩炸弹/超大文件
    file.stream.seek(0, io.SEEK_END)
    file_size = file.stream.tell()
    file.stream.seek(0)
    if file_size and file_size > MAX_IMPORT_SIZE_BYTES:
        return error_response(f'文件过大，限制 {MAX_IMPORT_SIZE_BYTES // (1024 * 1024)}MB', 413)
    
    # 检查文件扩展名
    allowed_extensions = {'.xlsx', '.xls'}
    ext = '.' + file.filename.rsplit('.', 1)[-1].lower() if '.' in file.filename else ''
    if ext not in allowed_extensions:
        return error_response('只支持 .xlsx 和 .xls 格式', 400)
    
    try:
        # 读取 Excel
        df = pd.read_excel(file, engine='openpyxl' if ext == '.xlsx' else 'xlrd')
        
        # 验证必需列
        if 'email' not in df.columns:
            return error_response('Excel 必须包含 email 列', 400)

        if len(df) > MAX_IMPORT_ROWS:
            return error_response(f'行数超出限制，最多支持 {MAX_IMPORT_ROWS} 行', 400)
        
        # 统计结果
        result = {
            'total': len(df),
            'created': 0,
            'updated': 0,
            'failed': 0,
            'errors': []
        }
        
        # 获取管理员邮箱列表
        admin_emails = [e.lower() for e in current_app.config.get('ADMIN_EMAILS', [])]
        
        # 遍历每一行
        for index, row in df.iterrows():
            row_num = index + 2  # Excel 行号（从2开始，因为第1行是表头）
            
            try:
                email = str(row.get('email', '')).strip().lower()
                
                # 验证邮箱
                if not email or '@' not in email:
                    result['failed'] += 1
                    result['errors'].append({
                        'row': row_num,
                        'email': email,
                        'reason': '邮箱格式错误'
                    })
                    continue
                
                name = str(row.get('name', '')).strip() if pd.notna(row.get('name')) else ''
                role = str(row.get('role', 'user')).strip().lower() if pd.notna(row.get('role')) else 'user'
                password = str(row.get('password', '')).strip() if pd.notna(row.get('password')) else ''
                
                # 验证角色
                if role not in ['user', 'admin']:
                    role = 'user'
                
                # 检查是否应该是管理员（根据 ADMIN_EMAILS 配置）
                if email in admin_emails:
                    role = 'admin'
                
                # 查找或创建用户
                user = User.query.filter_by(email=email).first()
                
                if user:
                    # 用户存在，更新信息
                    if name:
                        user.name = name
                    user.role = role
                    if password:
                        user.set_password(password)
                    result['updated'] += 1
                else:
                    # 用户不存在，创建新用户
                    # 关键：系统自动生成 UUID
                    new_uuid = str(uuid.uuid4())
                    user = User(
                        uuid=new_uuid,
                        email=email,
                        name=name or email.split('@')[0],
                        role=role,
                        is_active=True
                    )
                    if password:
                        user.set_password(password)
                    db.session.add(user)
                    result['created'] += 1
                
            except Exception as e:
                result['failed'] += 1
                result['errors'].append({
                    'row': row_num,
                    'email': str(row.get('email', '')),
                    'reason': str(e)
                })
        
        # 提交事务
        db.session.commit()
        
        return success_response(result, f'导入完成：新增 {result["created"]} 人，更新 {result["updated"]} 人')
        
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f'Import users error: {e}')
        return error_response(f'导入失败: {str(e)}', 500)


# ==================== 批量操作 ====================

@admin_bp.route('/users/batch-delete', methods=['POST'])
@admin_required
def batch_delete_users():
    """
    批量删除用户
    
    Request Body:
        {
            "user_uuids": ["uuid1", "uuid2", ...]
        }
    """
    data = request.get_json()
    if not data or not data.get('user_uuids'):
        return error_response('请提供要删除的用户 UUID 列表', 400)
    
    user_uuids = data['user_uuids']
    admin_user = g.admin_user
    
    # 过滤掉管理员自己
    user_uuids = [u for u in user_uuids if u != admin_user.uuid]
    
    if not user_uuids:
        return error_response('没有可删除的用户', 400)
    
    try:
        deleted_count = User.query.filter(User.uuid.in_(user_uuids)).delete(synchronize_session='fetch')
        db.session.commit()
        return success_response({'deleted': deleted_count}, f'已删除 {deleted_count} 个用户')
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f'Batch delete users error: {e}')
        return error_response('批量删除失败', 500)


@admin_bp.route('/users/batch-set-role', methods=['POST'])
@admin_required
def batch_set_role():
    """
    批量设置用户角色
    
    Request Body:
        {
            "user_uuids": ["uuid1", "uuid2", ...],
            "role": "user" | "admin"
        }
    """
    data = request.get_json()
    if not data or not data.get('user_uuids') or not data.get('role'):
        return error_response('请提供用户列表和角色', 400)
    
    user_uuids = data['user_uuids']
    role = data['role']
    
    if role not in ['user', 'admin']:
        return error_response('role 必须是 user 或 admin', 400)
    
    admin_user = g.admin_user
    
    # 如果是降级为普通用户，过滤掉管理员自己
    if role == 'user':
        user_uuids = [u for u in user_uuids if u != admin_user.uuid]
    
    if not user_uuids:
        return error_response('没有可操作的用户', 400)
    
    try:
        updated_count = User.query.filter(User.uuid.in_(user_uuids)).update(
            {'role': role},
            synchronize_session='fetch'
        )
        db.session.commit()
        return success_response({'updated': updated_count}, f'已更新 {updated_count} 个用户的角色')
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f'Batch set role error: {e}')
        return error_response('批量设置角色失败', 500)

