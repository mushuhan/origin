# -*- coding: utf-8 -*-
"""
用户控制器
处理用户注册、设置等操作
"""
from flask import Blueprint, request, g
from app import db
from app.models.user import User
from app.services.user_service import UserService
from app.utils.response import success_response, error_response
from app.utils.decorators import require_user

users_bp = Blueprint('users', __name__)


@users_bp.route('/register', methods=['POST'])
def register():
    """
    用户注册/初始化
    前端首次访问时调用，传入UUID
    """
    data = request.get_json()
    uuid = data.get('uuid')
    
    if not uuid:
        return error_response('UUID不能为空', 400)
    
    # 获取或创建用户
    user = UserService.get_or_create_user(uuid)
    
    return success_response(user.to_dict())


@users_bp.route('/me', methods=['GET'])
@require_user
def get_current_user():
    """获取当前用户信息"""
    user = g.user
    
    if not user:
        return error_response('用户不存在', 404)
    
    return success_response(user.to_dict())


@users_bp.route('/me/settings', methods=['GET'])
@require_user
def get_user_settings():
    """获取用户设置"""
    user = g.user
    
    if not user:
        return error_response('用户不存在', 404)
    
    return success_response(user.settings or {})


@users_bp.route('/me/settings', methods=['PUT'])
@require_user
def update_user_settings():
    """更新用户设置"""
    user = g.user
    
    if not user:
        return error_response('用户不存在', 404)
    
    data = request.get_json()
    
    # 合并设置
    current_settings = user.settings or {}
    current_settings.update(data)
    user.settings = current_settings
    
    db.session.commit()
    
    return success_response(user.settings, '设置已更新')


@users_bp.route('/me/stats', methods=['GET'])
@require_user
def get_user_stats():
    """获取用户统计信息"""
    user_uuid = g.user_uuid
    
    stats = UserService.get_user_stats(user_uuid)
    
    return success_response(stats)

