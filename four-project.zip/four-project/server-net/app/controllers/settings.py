# -*- coding: utf-8 -*-
"""
系统设置控制器
"""
from flask import Blueprint, request
from app import db
from app.models.setting import SystemSetting
from app.utils.response import success_response, error_response

settings_bp = Blueprint('settings', __name__)


@settings_bp.route('', methods=['GET'])
def get_settings():
    """获取所有系统设置"""
    settings = SystemSetting.query.all()
    
    # 转换为键值对
    result = {}
    for setting in settings:
        result[setting.setting_key] = setting.setting_value
    
    return success_response(result)


@settings_bp.route('/<key>', methods=['GET'])
def get_setting(key):
    """获取单个设置项"""
    setting = SystemSetting.query.filter_by(setting_key=key).first()
    
    if not setting:
        return error_response('设置项不存在', 404)
    
    return success_response({
        'key': setting.setting_key,
        'value': setting.setting_value,
        'description': setting.description
    })


@settings_bp.route('/<key>', methods=['PUT'])
def update_setting(key):
    """更新设置项"""
    data = request.get_json()
    value = data.get('value')
    
    setting = SystemSetting.query.filter_by(setting_key=key).first()
    
    if setting:
        setting.setting_value = value
    else:
        # 创建新设置项
        setting = SystemSetting(
            setting_key=key,
            setting_value=value,
            description=data.get('description')
        )
        db.session.add(setting)
    
    db.session.commit()
    
    return success_response({
        'key': setting.setting_key,
        'value': setting.setting_value
    }, '设置已更新')


@settings_bp.route('/<key>', methods=['DELETE'])
def delete_setting(key):
    """删除设置项"""
    setting = SystemSetting.query.filter_by(setting_key=key).first()
    
    if not setting:
        return error_response('设置项不存在', 404)
    
    db.session.delete(setting)
    db.session.commit()
    
    return success_response(None, '设置已删除')


@settings_bp.route('/batch', methods=['PUT'])
def batch_update_settings():
    """批量更新设置"""
    data = request.get_json()
    
    if not data or not isinstance(data, dict):
        return error_response('无效的请求数据', 400)
    
    for key, value in data.items():
        setting = SystemSetting.query.filter_by(setting_key=key).first()
        
        if setting:
            setting.setting_value = str(value) if value is not None else None
        else:
            setting = SystemSetting(
                setting_key=key,
                setting_value=str(value) if value is not None else None
            )
            db.session.add(setting)
    
    db.session.commit()
    
    return success_response(None, '设置已批量更新')

