"""
员工控制器 - 员工信息的增删改查
"""
from flask import Blueprint, request
from app.models.employee import Employee
from app.models.department import Department
from app.utils.response import success_response, error_response

bp = Blueprint('employees', __name__, url_prefix='/api/employees')


@bp.route('', methods=['GET'])
def get_employees():
    """获取员工列表"""
    department_id = request.args.get('department_id', type=int)
    
    if department_id:
        employees = Employee.get_by_department(department_id)
    else:
        employees = Employee.query.filter_by(is_active=True).order_by(Employee.department_id, Employee.sort_order).all()
    
    return success_response([e.to_dict() for e in employees])


@bp.route('/org-tree/<int:department_id>', methods=['GET'])
def get_org_tree(department_id):
    """获取科室组织架构树"""
    department = Department.get_by_id(department_id)
    
    if not department:
        return error_response('科室不存在', 404)
    
    tree = Employee.get_org_tree(department_id)
    return success_response(tree)


@bp.route('/<int:emp_id>', methods=['GET'])
def get_employee(emp_id):
    """获取单个员工详情"""
    employee = Employee.get_by_id(emp_id)
    
    if not employee:
        return error_response('员工不存在', 404)
    
    return success_response(employee.to_dict())


@bp.route('', methods=['POST'])
def create_employee():
    """创建新员工"""
    data = request.get_json()
    
    if not data.get('name'):
        return error_response('员工姓名不能为空')
    
    if not data.get('department_id'):
        return error_response('必须指定所属科室')
    
    # 验证科室存在
    department = Department.get_by_id(data['department_id'])
    if not department:
        return error_response('科室不存在', 404)
    
    # 验证上级存在（如果指定）
    if data.get('parent_id'):
        parent = Employee.get_by_id(data['parent_id'])
        if not parent:
            return error_response('上级员工不存在', 404)
    
    employee = Employee.create(
        department_id=data['department_id'],
        name=data['name'],
        position=data.get('position', ''),
        avatar=data.get('avatar', ''),
        signature=data.get('signature', ''),
        phone=data.get('phone', ''),
        email=data.get('email', ''),
        parent_id=data.get('parent_id'),
        level=data.get('level', 0),
        sort_order=data.get('sort_order', 0)
    )
    
    return success_response(employee.to_dict(), '创建成功', 201)


@bp.route('/<int:emp_id>', methods=['PUT'])
def update_employee(emp_id):
    """更新员工"""
    employee = Employee.get_by_id(emp_id)
    
    if not employee:
        return error_response('员工不存在', 404)
    
    data = request.get_json()
    employee.update(
        name=data.get('name'),
        position=data.get('position'),
        avatar=data.get('avatar'),
        signature=data.get('signature'),
        phone=data.get('phone'),
        email=data.get('email'),
        parent_id=data.get('parent_id'),
        level=data.get('level'),
        sort_order=data.get('sort_order')
    )
    
    return success_response(employee.to_dict(), '更新成功')


@bp.route('/<int:emp_id>', methods=['DELETE'])
def delete_employee(emp_id):
    """删除员工"""
    employee = Employee.get_by_id(emp_id)
    
    if not employee:
        return error_response('员工不存在', 404)
    
    employee.delete()
    return success_response(None, '删除成功')


@bp.route('/batch', methods=['POST'])
def batch_create_employees():
    """批量创建员工"""
    data = request.get_json()
    
    if not data.get('employees') or not isinstance(data['employees'], list):
        return error_response('请提供员工列表')
    
    created = []
    for emp_data in data['employees']:
        if not emp_data.get('name') or not emp_data.get('department_id'):
            continue
        
        employee = Employee.create(
            department_id=emp_data['department_id'],
            name=emp_data['name'],
            position=emp_data.get('position', ''),
            avatar=emp_data.get('avatar', ''),
            signature=emp_data.get('signature', ''),
            phone=emp_data.get('phone', ''),
            email=emp_data.get('email', ''),
            parent_id=emp_data.get('parent_id'),
            level=emp_data.get('level', 0),
            sort_order=emp_data.get('sort_order', 0)
        )
        created.append(employee.to_dict())
    
    return success_response(created, f'成功创建{len(created)}名员工', 201)

