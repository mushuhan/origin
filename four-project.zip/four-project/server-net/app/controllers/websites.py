# -*- coding: utf-8 -*-
"""
网址控制器
处理公共网址库的CRUD操作
"""
from flask import Blueprint, request, g, current_app
from app import db
from app.models.website import Website
from app.models.section import Section
from app.utils.response import success_response, error_response

websites_bp = Blueprint('websites', __name__)


@websites_bp.route('', methods=['GET'])
def get_websites():
    """获取网址列表"""
    section_id = request.args.get('section_id', type=int)
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 20, type=int)
    
    # 限制每页最大数量
    per_page = min(per_page, current_app.config.get('MAX_PAGE_SIZE', 100))
    
    query = Website.query
    
    if section_id:
        query = query.filter_by(section_id=section_id)
    
    # 分页
    pagination = query.order_by(Website.sort_order).paginate(
        page=page, per_page=per_page, error_out=False
    )
    
    return success_response({
        'items': [w.to_dict() for w in pagination.items],
        'total': pagination.total,
        'page': page,
        'per_page': per_page,
        'pages': pagination.pages
    })


@websites_bp.route('/hot', methods=['GET'])
def get_hot_websites():
    """获取热门网址"""
    limit = request.args.get('limit', 20, type=int)
    limit = min(limit, 100)
    
    # 按点击量排序
    websites = Website.query.filter_by(is_hot=True).order_by(
        Website.click_count.desc()
    ).limit(limit).all()
    
    # 如果热门标记的网址不足，补充点击量高的
    if len(websites) < limit:
        existing_ids = [w.id for w in websites]
        additional = Website.query.filter(
            ~Website.id.in_(existing_ids) if existing_ids else True
        ).order_by(Website.click_count.desc()).limit(limit - len(websites)).all()
        websites.extend(additional)
    
    return success_response([w.to_dict() for w in websites])


@websites_bp.route('/<int:id>', methods=['GET'])
def get_website(id):
    """获取单个网址详情"""
    website = Website.query.get_or_404(id)
    return success_response(website.to_dict())


@websites_bp.route('', methods=['POST'])
def create_website():
    """创建网址"""
    data = request.get_json()
    
    if not data or not data.get('name'):
        return error_response('网站名称不能为空', 400)
    
    if not data.get('url'):
        return error_response('网址URL不能为空', 400)
    
    if not data.get('section_id'):
        return error_response('必须指定所属分区', 400)
    
    # 验证分区存在
    section = Section.query.get(data['section_id'])
    if not section:
        return error_response('分区不存在', 404)
    
    # 获取该分区下最大排序值
    max_order = db.session.query(db.func.max(Website.sort_order)).filter(
        Website.section_id == data['section_id']
    ).scalar() or 0
    
    website = Website(
        section_id=data['section_id'],
        name=data['name'],
        url=data['url'],
        icon=data.get('icon'),
        description=data.get('description'),
        pinyin=data.get('pinyin'),  # 拼音
        pinyin_initials=data.get('pinyin_initials'),  # 拼音首字母
        sort_order=max_order + 1,
        is_hot=data.get('is_hot', False)
    )
    
    db.session.add(website)
    db.session.commit()
    
    return success_response(website.to_dict(), '创建成功', 201)


@websites_bp.route('/<int:id>', methods=['PUT'])
def update_website(id):
    """更新网址"""
    website = Website.query.get_or_404(id)
    data = request.get_json()
    
    if data.get('name'):
        website.name = data['name']
    if 'url' in data:
        website.url = data['url']
    if 'icon' in data:
        website.icon = data['icon']
    if 'description' in data:
        website.description = data['description']
    if 'pinyin' in data:
        website.pinyin = data['pinyin']
    if 'pinyin_initials' in data:
        website.pinyin_initials = data['pinyin_initials']
    if 'section_id' in data:
        section = Section.query.get(data['section_id'])
        if not section:
            return error_response('分区不存在', 404)
        website.section_id = data['section_id']
    if 'sort_order' in data:
        website.sort_order = data['sort_order']
    if 'is_hot' in data:
        website.is_hot = data['is_hot']
    
    db.session.commit()
    
    return success_response(website.to_dict(), '更新成功')


@websites_bp.route('/<int:id>', methods=['DELETE'])
def delete_website(id):
    """删除网址"""
    website = Website.query.get_or_404(id)
    
    db.session.delete(website)
    db.session.commit()
    
    return success_response(None, '删除成功')


@websites_bp.route('/<int:id>/click', methods=['POST'])
def click_website(id):
    """记录网址点击"""
    website = Website.query.get_or_404(id)
    website.click_count += 1
    db.session.commit()
    
    return success_response({'click_count': website.click_count})


@websites_bp.route('/batch-reorder', methods=['PUT'])
def batch_reorder():
    """批量重排序网址"""
    data = request.get_json()
    items = data.get('items', [])
    
    for item in items:
        website = Website.query.get(item['id'])
        if website:
            website.sort_order = item['sort_order']
            if 'section_id' in item:
                website.section_id = item['section_id']
    
    db.session.commit()
    
    return success_response(None, '排序更新成功')

