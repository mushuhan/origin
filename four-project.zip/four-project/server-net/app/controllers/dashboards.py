"""
看板控制器 - 数据看板的增删改查

优化版本：
1. 支持列表/详情分离查询（减少数据传输）
2. 支持按需加载单个工作表数据
3. 支持图表下钻查询 API
4. 支持数据缓存统计
"""
from flask import Blueprint, request, jsonify, g
from app.models.dashboard import Dashboard
from app.utils.response import success_response, error_response
from app.utils.decorators import require_user

bp = Blueprint('dashboards', __name__, url_prefix='/api/dashboards')


@bp.route('', methods=['GET'])
@require_user
def get_dashboards():
    """
    获取当前用户的看板列表
    
    Query params:
    - include_public: 是否包含公开看板 (default: true)
    - include_data: 是否包含完整数据 (default: false，列表模式不加载数据)
    """
    user_uuid = g.user_uuid
    include_public = request.args.get('include_public', 'true').lower() == 'true'
    include_data = request.args.get('include_data', 'false').lower() == 'true'
    
    dashboards = Dashboard.get_user_dashboards(user_uuid, include_public)
    
    if include_data:
        return success_response([d.to_dict() for d in dashboards])
    else:
        # 列表模式：只返回基本信息，不加载大数据
        return success_response([d.to_list_dict() for d in dashboards])


@bp.route('/<int:dashboard_id>', methods=['GET'])
@require_user
def get_dashboard(dashboard_id):
    """
    获取单个看板详情
    
    Query params:
    - include_data: 是否包含完整数据 (default: true)
    """
    dashboard = Dashboard.get_by_id(dashboard_id)
    
    if not dashboard:
        return error_response('看板不存在', 404)
    
    # 检查权限
    if dashboard.visibility == 'private' and dashboard.user_uuid != g.user_uuid:
        return error_response('无权访问', 403)
    
    include_data = request.args.get('include_data', 'true').lower() == 'true'
    return success_response(dashboard.to_dict(include_data=include_data))


@bp.route('/<int:dashboard_id>/sheet/<sheet_name>', methods=['GET'])
@require_user
def get_dashboard_sheet(dashboard_id, sheet_name):
    """
    按需获取单个工作表数据
    优化：只加载需要的工作表，减少内存和网络开销
    """
    dashboard = Dashboard.get_by_id(dashboard_id)
    
    if not dashboard:
        return error_response('看板不存在', 404)
    
    if dashboard.visibility == 'private' and dashboard.user_uuid != g.user_uuid:
        return error_response('无权访问', 403)
    
    sheet_data = dashboard.get_sheet_data(sheet_name)
    return success_response(sheet_data)


@bp.route('', methods=['POST'])
@require_user
def create_dashboard():
    """创建新看板"""
    data = request.get_json()
    
    if not data.get('name'):
        return error_response('看板名称不能为空')
    
    dashboard = Dashboard.create(
        user_uuid=g.user_uuid,
        name=data['name'],
        config=data,
        visibility=data.get('visibility', 'private')
    )
    
    return success_response(dashboard.to_dict(), '创建成功', 201)


@bp.route('/<int:dashboard_id>', methods=['PUT'])
@require_user
def update_dashboard(dashboard_id):
    """更新看板"""
    dashboard = Dashboard.get_by_id(dashboard_id)
    
    if not dashboard:
        return error_response('看板不存在', 404)
    
    if dashboard.user_uuid != g.user_uuid:
        return error_response('无权修改', 403)
    
    data = request.get_json()
    dashboard.update(
        name=data.get('name'),
        config=data,
        visibility=data.get('visibility')
    )
    
    return success_response(dashboard.to_dict(), '更新成功')


@bp.route('/<int:dashboard_id>', methods=['DELETE'])
@require_user
def delete_dashboard(dashboard_id):
    """删除看板"""
    dashboard = Dashboard.get_by_id(dashboard_id)
    
    if not dashboard:
        return error_response('看板不存在', 404)
    
    if dashboard.user_uuid != g.user_uuid:
        return error_response('无权删除', 403)
    
    dashboard.delete()
    return success_response(None, '删除成功')


@bp.route('/calculate', methods=['POST'])
@require_user
def calculate_chart():
    """
    计算图表数据（预览或实时）
    
    支持扩展配置：
    - sort: {field: 'x'/'y'/字段名, order: 'asc'/'desc'}
    - limit: {type: 'top'/'bottom', count: 10}
    - groupField: 分组字段（用于堆叠图）
    """
    try:
        data = request.get_json()
        sheet_data = data.get('sheetData', [])
        chart_config = data.get('chartConfig', {})
        
        from app.services.chart_service import ChartService
        result = ChartService.process_chart_data(sheet_data, chart_config)
        
        return success_response(result)
    except Exception as e:
        import traceback
        traceback.print_exc()
        return error_response(str(e))


@bp.route('/drill-down', methods=['POST'])
@require_user
def drill_down():
    """
    图表下钻查询 API
    
    请求体：
    {
        "sheetData": [...],  // 或使用 dashboardId + sheetName
        "dashboardId": 1,
        "sheetName": "Sheet1",
        "chartConfig": {...},
        "drillParams": {
            "xValue": "一班",  // 点击的 X 轴值
            "seriesName": "及格人数",  // 点击的系列名（可选）
            "groupValue": "产品A",  // 分组值（可选，用于堆叠图）
            "page": 1,
            "pageSize": 20
        }
    }
    
    返回：
    {
        "headers": ["姓名", "班级", "分数", ...],
        "rows": [...],
        "total": 100,
        "page": 1,
        "pageSize": 20
    }
    """
    try:
        data = request.get_json()
        chart_config = data.get('chartConfig', {})
        drill_params = data.get('drillParams', {})
        
        # 获取数据源
        sheet_data = data.get('sheetData')
        
        if not sheet_data:
            # 从看板加载数据
            dashboard_id = data.get('dashboardId')
            sheet_name = data.get('sheetName')
            
            if dashboard_id and sheet_name:
                dashboard = Dashboard.get_by_id(dashboard_id)
                if not dashboard:
                    return error_response('看板不存在', 404)
                
                if dashboard.visibility == 'private' and dashboard.user_uuid != g.user_uuid:
                    return error_response('无权访问', 403)
                
                sheet_data_dict = dashboard.get_sheet_data(sheet_name)
                sheet_data = sheet_data_dict.get('rows', [])
        
        if not sheet_data:
            return error_response('数据源为空')
        
        from app.services.chart_service import ChartService
        result = ChartService.get_drill_down_data(sheet_data, chart_config, drill_params)
        
        return success_response(result)
    except Exception as e:
        import traceback
        traceback.print_exc()
        return error_response(str(e))


@bp.route('/field-values', methods=['POST'])
@require_user
def get_field_values():
    """
    获取字段的唯一值（用于筛选器下拉选项）
    
    请求体：
    {
        "sheetData": [...],  // 或使用 dashboardId + sheetName
        "dashboardId": 1,
        "sheetName": "Sheet1",
        "field": "班级"
    }
    """
    try:
        data = request.get_json()
        field = data.get('field')
        
        if not field:
            return error_response('字段名不能为空')
        
        sheet_data = data.get('sheetData')
        
        if not sheet_data:
            dashboard_id = data.get('dashboardId')
            sheet_name = data.get('sheetName')
            
            if dashboard_id and sheet_name:
                dashboard = Dashboard.get_by_id(dashboard_id)
                if dashboard:
                    sheet_data_dict = dashboard.get_sheet_data(sheet_name)
                    sheet_data = sheet_data_dict.get('rows', [])
        
        from app.services.chart_service import ChartService
        values = ChartService.get_field_unique_values(sheet_data, field)
        
        return success_response(values)
    except Exception as e:
        return error_response(str(e))


@bp.route('/cache-stats', methods=['GET'])
@require_user
def get_cache_stats():
    """获取数据缓存统计（调试用）"""
    from app.services.data_storage_service import DataStorageService
    stats = DataStorageService.get_cache_stats()
    return success_response(stats)


@bp.route('/stat-card', methods=['POST'])
@require_user
def calculate_stat_card():
    """
    计算单个统计卡片数据（含趋势和增长率）
    
    请求体：
    {
        "sheetData": [...],  // 或使用 dashboardId + sheetName
        "dashboardId": 1,
        "sheetName": "Sheet1",
        "field": "销售额",
        "aggregation": "sum",  // sum/count/avg/max/min
        "timeField": "日期",   // 可选，用于计算趋势
        "trendPeriods": 7,     // 趋势周期数
        "filters": [...]       // 可选筛选条件
    }
    
    返回：
    {
        "value": 12345.67,
        "trend": 5.2,
        "sparklineData": [100, 120, 115, 130, 125, 140, 150],
        "periodLabel": "较昨日"
    }
    """
    try:
        data = request.get_json()
        field = data.get('field')
        aggregation = data.get('aggregation', 'sum')
        time_field = data.get('timeField')
        trend_periods = data.get('trendPeriods', 7)
        filters = data.get('filters', [])
        
        if not field:
            return error_response('统计字段不能为空')
        
        # 获取数据源
        sheet_data = data.get('sheetData')
        
        if not sheet_data:
            dashboard_id = data.get('dashboardId')
            sheet_name = data.get('sheetName')
            
            if dashboard_id and sheet_name:
                dashboard = Dashboard.get_by_id(dashboard_id)
                if not dashboard:
                    return error_response('看板不存在', 404)
                
                if dashboard.visibility == 'private' and dashboard.user_uuid != g.user_uuid:
                    return error_response('无权访问', 403)
                
                sheet_data_dict = dashboard.get_sheet_data(sheet_name)
                sheet_data = sheet_data_dict.get('rows', [])
        
        if not sheet_data:
            return error_response('数据源为空')
        
        from app.services.analytics_service import StatCardService
        result = StatCardService.get_summary_stats(
            data=sheet_data,
            field=field,
            aggregation=aggregation,
            time_field=time_field,
            trend_periods=trend_periods,
            filters=filters
        )
        
        return success_response(result)
    except Exception as e:
        import traceback
        traceback.print_exc()
        return error_response(str(e))


@bp.route('/stat-cards', methods=['POST'])
@require_user
def calculate_stat_cards():
    """
    批量计算多个统计卡片数据
    
    请求体：
    {
        "sheetData": [...],  // 或使用 dashboardId + sheetName
        "dashboardId": 1,
        "sheetName": "Sheet1",
        "configs": [
            {
                "field": "销售额",
                "aggregation": "sum",
                "title": "总销售额",
                "prefix": "¥",
                "timeField": "日期"
            },
            {
                "field": "订单数",
                "aggregation": "count",
                "title": "订单总数"
            }
        ]
    }
    """
    try:
        data = request.get_json()
        configs = data.get('configs', [])
        
        if not configs:
            return error_response('统计配置不能为空')
        
        # 获取数据源
        sheet_data = data.get('sheetData')
        
        if not sheet_data:
            dashboard_id = data.get('dashboardId')
            sheet_name = data.get('sheetName')
            
            if dashboard_id and sheet_name:
                dashboard = Dashboard.get_by_id(dashboard_id)
                if not dashboard:
                    return error_response('看板不存在', 404)
                
                if dashboard.visibility == 'private' and dashboard.user_uuid != g.user_uuid:
                    return error_response('无权访问', 403)
                
                sheet_data_dict = dashboard.get_sheet_data(sheet_name)
                sheet_data = sheet_data_dict.get('rows', [])
        
        if not sheet_data:
            return error_response('数据源为空')
        
        from app.services.analytics_service import StatCardService
        results = StatCardService.calculate_multi_stats(sheet_data, configs)
        
        return success_response(results)
    except Exception as e:
        import traceback
        traceback.print_exc()
        return error_response(str(e))


@bp.route('/preview-join', methods=['POST'])
@require_user
def preview_join():
    """
    预览多表关联结果
    
    请求体：
    {
        "sheetData1": [...],  // 表1数据（或使用 dashboardId + sheetName1）
        "sheetData2": [...],  // 表2数据
        "dashboardId": 1,     // 可选，从看板加载数据
        "sheetName1": "Sheet1",
        "sheetName2": "Sheet2",
        "joinKey1": "user_id",  // 表1关联字段
        "joinKey2": "uid",      // 表2关联字段
        "joinType": "inner"     // inner/left/right/outer
    }
    
    返回：
    {
        "columns": ["col1", "col2", ...],
        "rows": [{...}, {...}],
        "totalRows": 100,
        "joinStats": {
            "leftRows": 50,
            "rightRows": 60,
            "matchedRows": 45
        }
    }
    """
    try:
        data = request.get_json()
        
        join_key1 = data.get('joinKey1')
        join_key2 = data.get('joinKey2')
        join_type = data.get('joinType', 'inner')
        
        if not join_key1 or not join_key2:
            return error_response('关联字段不能为空')
        
        # 获取数据源1
        sheet_data1 = data.get('sheetData1')
        sheet_data2 = data.get('sheetData2')
        
        dashboard_id = data.get('dashboardId')
        
        if not sheet_data1 or not sheet_data2:
            # 从看板加载数据
            if dashboard_id:
                dashboard = Dashboard.get_by_id(dashboard_id)
                if not dashboard:
                    return error_response('看板不存在', 404)
                
                if dashboard.visibility == 'private' and dashboard.user_uuid != g.user_uuid:
                    return error_response('无权访问', 403)
                
                sheet_name1 = data.get('sheetName1')
                sheet_name2 = data.get('sheetName2')
                
                if sheet_name1 and not sheet_data1:
                    sheet_data_dict1 = dashboard.get_sheet_data(sheet_name1)
                    sheet_data1 = sheet_data_dict1.get('rows', [])
                
                if sheet_name2 and not sheet_data2:
                    sheet_data_dict2 = dashboard.get_sheet_data(sheet_name2)
                    sheet_data2 = sheet_data_dict2.get('rows', [])
        
        if not sheet_data1 or not sheet_data2:
            return error_response('数据源为空，请确保两个表都有数据')
        
        from app.services.analytics_service import DataJoinService
        result = DataJoinService.preview_join(
            data1=sheet_data1,
            data2=sheet_data2,
            join_key1=join_key1,
            join_key2=join_key2,
            join_type=join_type,
            preview_limit=100  # 预览返回最多100行
        )
        
        return success_response(result)
    except ValueError as ve:
        return error_response(str(ve))
    except Exception as e:
        import traceback
        traceback.print_exc()
        return error_response(f'合并失败: {str(e)}')


@bp.route('/execute-join', methods=['POST'])
@require_user
def execute_join():
    """
    执行完整的多表关联
    
    请求体：
    {
        "sheetData1": [...],  // 表1数据（或使用 dashboardId + sheetName1）
        "sheetData2": [...],  // 表2数据
        "dashboardId": 1,     // 可选，从看板加载数据
        "sheetName1": "Sheet1",
        "sheetName2": "Sheet2",
        "joinKey1": "user_id",
        "joinKey2": "uid",
        "joinType": "inner",
        "resultName": "merged_data"
    }
    
    返回完整的合并数据
    """
    try:
        data = request.get_json()
        
        join_key1 = data.get('joinKey1')
        join_key2 = data.get('joinKey2')
        join_type = data.get('joinType', 'inner')
        result_name = data.get('resultName', 'joined_data')
        
        if not join_key1 or not join_key2:
            return error_response('关联字段不能为空')
        
        # 获取数据源
        sheet_data1 = data.get('sheetData1')
        sheet_data2 = data.get('sheetData2')
        
        dashboard_id = data.get('dashboardId')
        
        if not sheet_data1 or not sheet_data2:
            # 从看板加载数据
            if dashboard_id:
                dashboard = Dashboard.get_by_id(dashboard_id)
                if not dashboard:
                    return error_response('看板不存在', 404)
                
                if dashboard.visibility == 'private' and dashboard.user_uuid != g.user_uuid:
                    return error_response('无权访问', 403)
                
                sheet_name1 = data.get('sheetName1')
                sheet_name2 = data.get('sheetName2')
                
                if sheet_name1 and not sheet_data1:
                    sheet_data_dict1 = dashboard.get_sheet_data(sheet_name1)
                    sheet_data1 = sheet_data_dict1.get('rows', [])
                
                if sheet_name2 and not sheet_data2:
                    sheet_data_dict2 = dashboard.get_sheet_data(sheet_name2)
                    sheet_data2 = sheet_data_dict2.get('rows', [])
        
        if not sheet_data1 or not sheet_data2:
            return error_response('数据源为空，请确保两个表都有数据')
        
        from app.services.analytics_service import DataJoinService
        result = DataJoinService.execute_join(
            data1=sheet_data1,
            data2=sheet_data2,
            join_key1=join_key1,
            join_key2=join_key2,
            join_type=join_type
        )
        
        # 返回结果
        return success_response({
            'name': result_name,
            'headers': result['headers'],
            'rows': result['rows'],
            'totalRows': len(result['rows'])
        })
    except ValueError as ve:
        return error_response(str(ve))
    except Exception as e:
        import traceback
        traceback.print_exc()
        return error_response(f'执行失败: {str(e)}')