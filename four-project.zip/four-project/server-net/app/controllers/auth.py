# -*- coding: utf-8 -*-
"""
认证控制器

【混合认证系统】
支持两种认证模式，通过 AUTH_MODE 配置切换：

1. DEV 模式 (AUTH_MODE='dev')
   - 使用账号（邮箱）+ 密码登录
   - 方便开发调试，无需配置 IDaaS

2. PROD 模式 (AUTH_MODE='prod')
   - 使用 OAuth2/OIDC 跳转登录
   - 前端跳转到 IDaaS 授权页
   - 后端接收授权码，换取用户信息
   - 根据 sub 字段映射到系统用户

【用户映射逻辑】（关键）
- PROD 模式下，IDaaS 返回的 sub 字段存储在 User.oauth_id
- 如果找到匹配的 oauth_id -> 登录成功
- 如果没找到 -> 自动创建新用户（生成新 UUID）
- UUID 是系统主键，oauth_id 只是外部身份映射

【管理员自动判断】
- 如果用户邮箱在 ADMIN_EMAILS 配置列表中
- 登录时自动将 role 设置为 'admin'
"""
import uuid
import jwt
import requests
from datetime import datetime, timedelta
from urllib.parse import urlencode

from flask import Blueprint, request, current_app, redirect
from app import db
from app.models.user import User
from app.utils.response import success_response, error_response
from app.utils.decorators import admin_required, login_required

auth_bp = Blueprint('auth', __name__)


def generate_jwt_token(user, expires_in=None):
    """
    生成 JWT Token
    
    Args:
        user: User 模型实例
        expires_in: 过期时间（秒），默认使用配置值
    
    Returns:
        str: JWT Token
    """
    if expires_in is None:
        expires_in = current_app.config.get('JWT_ACCESS_TOKEN_EXPIRES', 86400)
    
    payload = {
        'sub': user.uuid,  # 主题：用户UUID
        'email': user.email,
        'role': user.role,
        'iat': datetime.utcnow(),  # 签发时间
        'exp': datetime.utcnow() + timedelta(seconds=expires_in)  # 过期时间
    }
    
    token = jwt.encode(
        payload,
        current_app.config['JWT_SECRET_KEY'],
        algorithm='HS256'
    )
    
    return token


def check_and_set_admin_role(user, email):
    """
    检查邮箱是否在管理员列表中，如果是则自动提升为管理员
    
    Args:
        user: User 模型实例
        email: 用户邮箱
    
    Returns:
        bool: 是否为管理员
    """
    admin_emails = current_app.config.get('ADMIN_EMAILS', [])
    if email and email.lower() in [e.lower() for e in admin_emails]:
        if user.role != 'admin':
            user.role = 'admin'
            current_app.logger.info(f'User {user.uuid} promoted to admin via email match')
        return True
    return False


# ==================== 认证模式查询 ====================

@auth_bp.route('/mode', methods=['GET'])
def get_auth_mode():
    """
    获取当前认证模式
    前端根据此接口决定显示哪种登录方式
    
    Returns:
        {
            "mode": "dev" | "prod",
            "oauth_url": "..." (仅 prod 模式)
        }
    """
    auth_mode = current_app.config.get('AUTH_MODE', 'dev')
    
    response_data = {
        'mode': auth_mode
    }
    
    # 如果是 prod 模式，返回 OAuth 授权 URL
    if auth_mode == 'prod':
        oauth_url = build_oauth_authorize_url()
        response_data['oauth_url'] = oauth_url
    
    return success_response(response_data)


def build_oauth_authorize_url(state=None):
    """
    构建 OAuth 授权 URL
    
    Args:
        state: CSRF 防护状态值（可选，建议使用）
    
    Returns:
        str: 完整的 OAuth 授权 URL
    """
    # 获取授权端点（优先使用新配置名称）
    auth_endpoint = current_app.config.get('IDAAS_AUTHORIZE_URL', '')
    
    # 兼容旧配置
    if not auth_endpoint:
        auth_endpoint = current_app.config.get('OAUTH_AUTHORIZATION_ENDPOINT', '')
    
    if not auth_endpoint:
        current_app.logger.warning('未配置 IDAAS_AUTHORIZE_URL')
        return None
    
    # 获取客户端ID（优先使用新配置名称）
    client_id = current_app.config.get('IDAAS_CLIENT_ID', '') or current_app.config.get('OAUTH_CLIENT_ID', '')
    
    params = {
        'client_id': client_id,
        'response_type': 'code',
        'redirect_uri': current_app.config.get('OAUTH_CALLBACK_URL', ''),
        'scope': ' '.join(current_app.config.get('OAUTH_SCOPES', ['openid', 'profile', 'email'])),
    }
    
    if state:
        params['state'] = state
    
    return f"{auth_endpoint}?{urlencode(params)}"


# ==================== DEV 模式：账号密码登录 ====================

@auth_bp.route('/login', methods=['POST'])
def login():
    """
    账号密码登录（仅 DEV 模式可用）
    
    Request Body:
        {
            "email": "user@example.com",
            "password": "password123"
        }
    
    Returns:
        {
            "token": "jwt_token...",
            "user": { ... }
        }
    """
    auth_mode = current_app.config.get('AUTH_MODE', 'dev')
    
    # PROD 模式下禁止密码登录
    if auth_mode == 'prod':
        return error_response(
            '生产环境请使用 OAuth 登录，请跳转到 /auth/mode 获取授权地址',
            400
        )
    
    data = request.get_json()
    if not data:
        return error_response('请求体不能为空', 400)
    
    email = data.get('email', '').strip().lower()
    password = data.get('password', '')
    
    if not email or not password:
        return error_response('邮箱和密码不能为空', 400)
    
    # 查找用户
    user = User.query.filter_by(email=email).first()
    
    if not user:
        return error_response('用户不存在', 404)
    
    if not user.is_active:
        return error_response('账户已被禁用', 403)
    
    # 验证密码
    if not user.check_password(password):
        return error_response('密码错误', 401)
    
    # 检查是否应该是管理员
    check_and_set_admin_role(user, email)
    
    # 更新最后登录时间
    user.last_login_at = datetime.utcnow()
    db.session.commit()
    
    # 生成 JWT Token
    token = generate_jwt_token(user)
    
    return success_response({
        'token': token,
        'user': user.to_dict()
    }, '登录成功')


# ==================== DEV 模式：注册账号 ====================

@auth_bp.route('/register', methods=['POST'])
def register():
    """
    注册账号（仅 DEV 模式可用）
    
    Request Body:
        {
            "email": "user@example.com",
            "password": "password123",
            "name": "用户名"
        }
    
    Returns:
        {
            "token": "jwt_token...",
            "user": { ... }
        }
    """
    auth_mode = current_app.config.get('AUTH_MODE', 'dev')
    
    if auth_mode == 'prod':
        return error_response('生产环境请使用 OAuth 登录', 400)
    
    data = request.get_json()
    if not data:
        return error_response('请求体不能为空', 400)
    
    email = data.get('email', '').strip().lower()
    password = data.get('password', '')
    name = data.get('name', '').strip()
    
    if not email or not password:
        return error_response('邮箱和密码不能为空', 400)
    
    # 检查邮箱是否已存在
    existing_user = User.query.filter_by(email=email).first()
    if existing_user:
        return error_response('该邮箱已被注册', 400)
    
    # 创建新用户
    new_uuid = str(uuid.uuid4())
    user = User(
        uuid=new_uuid,
        email=email,
        name=name or email.split('@')[0],  # 默认使用邮箱前缀作为名称
        role='user',
        is_active=True
    )
    user.set_password(password)
    
    # 检查是否应该是管理员
    check_and_set_admin_role(user, email)
    
    db.session.add(user)
    db.session.commit()
    
    # 生成 JWT Token
    token = generate_jwt_token(user)
    
    return success_response({
        'token': token,
        'user': user.to_dict()
    }, '注册成功', 201)


# ==================== PROD 模式：OAuth 回调 ====================

@auth_bp.route('/callback', methods=['POST'])
def oauth_callback():
    """
    OAuth 回调接口
    前端接收到授权码后，将 code 发送到此接口完成登录
    
    【处理流程】
    1. 接收前端传来的授权码 (code)
    2. 使用 code 向 IDaaS 换取 access_token
    3. 使用 access_token 获取用户信息
    4. 根据 sub 字段查找/创建用户
    5. 生成系统 JWT Token 返回给前端
    
    Request Body:
        {
            "code": "authorization_code",
            "state": "csrf_state" (可选)
        }
    
    Returns:
        {
            "token": "jwt_token...",
            "user": { ... },
            "is_new_user": true/false
        }
    """
    data = request.get_json()
    if not data or not data.get('code'):
        return error_response('缺少授权码', 400)
    
    code = data.get('code')
    
    try:
        # 1. 换取 access_token
        token_data = exchange_code_for_token(code)
        if not token_data:
            return error_response('获取访问令牌失败', 400)
        
        access_token = token_data.get('access_token')
        id_token = token_data.get('id_token')
        
        # 2. 获取用户信息
        # 优先从 id_token 解析，否则调用 userinfo 端点
        user_info = None
        if id_token:
            user_info = decode_id_token(id_token)
        
        if not user_info and access_token:
            user_info = fetch_userinfo(access_token)
        
        if not user_info:
            return error_response('获取用户信息失败', 400)
        
        # 3. 提取关键信息
        # sub 是 OIDC 标准的唯一用户标识
        oauth_id = user_info.get('sub')
        email = user_info.get('email', '').lower()
        name = user_info.get('name') or user_info.get('preferred_username') or email.split('@')[0]
        avatar = user_info.get('picture')
        
        if not oauth_id:
            return error_response('IDaaS 返回的用户信息缺少 sub 字段', 400)
        
        # 4. 查找或创建用户
        # 关键逻辑：根据 oauth_id 查找用户
        user = User.query.filter_by(oauth_id=oauth_id).first()
        is_new_user = False
        
        if user:
            # 用户已存在，更新信息
            user.email = email or user.email
            user.name = name or user.name
            user.avatar = avatar or user.avatar
            user.last_login_at = datetime.utcnow()
            current_app.logger.info(f'OAuth login: existing user {user.uuid}')
        else:
            # 用户不存在，创建新用户
            # 关键：生成新的 UUID 作为系统主键
            new_uuid = str(uuid.uuid4())
            user = User(
                uuid=new_uuid,
                oauth_id=oauth_id,  # 存储 IDaaS 的 sub 标识
                email=email,
                name=name,
                avatar=avatar,
                role='user',
                is_active=True,
                last_login_at=datetime.utcnow()
            )
            db.session.add(user)
            is_new_user = True
            current_app.logger.info(f'OAuth login: new user created {new_uuid}')
        
        # 5. 检查是否应该是管理员
        check_and_set_admin_role(user, email)
        
        db.session.commit()
        
        # 6. 生成系统 JWT Token
        token = generate_jwt_token(user)
        
        return success_response({
            'token': token,
            'user': user.to_dict(),
            'is_new_user': is_new_user
        }, '登录成功')
        
    except Exception as e:
        current_app.logger.error(f'OAuth callback error: {e}')
        return error_response(f'OAuth 回调处理失败: {str(e)}', 500)


def exchange_code_for_token(code):
    """
    使用授权码换取 access_token
    
    【关键逻辑】
    使用 POST 请求向 IDAAS_TOKEN_URL 发送以下参数：
    - client_id: 消费客户端ID (IDAAS_CLIENT_ID)
    - client_secret: 应用消费Secret (IDAAS_CLIENT_SECRET)
    - code: 前端传来的授权码
    - grant_type: authorization_code
    - redirect_uri: 回调地址
    
    Args:
        code: 授权码
    
    Returns:
        dict: 包含 access_token, id_token 等的响应
    """
    # 获取 IDaaS Token URL（优先使用新配置名称）
    token_url = current_app.config.get('IDAAS_TOKEN_URL', '')
    
    # 兼容旧配置
    if not token_url:
        token_url = current_app.config.get('OAUTH_TOKEN_ENDPOINT', '')
    
    if not token_url:
        raise ValueError('未配置 IDAAS_TOKEN_URL，请在 .env 中设置')
    
    # 获取客户端凭证（优先使用新配置名称）
    client_id = current_app.config.get('IDAAS_CLIENT_ID', '') or current_app.config.get('OAUTH_CLIENT_ID', '')
    client_secret = current_app.config.get('IDAAS_CLIENT_SECRET', '') or current_app.config.get('OAUTH_CLIENT_SECRET', '')
    redirect_uri = current_app.config.get('OAUTH_CALLBACK_URL', '')
    
    if not client_id or not client_secret:
        raise ValueError('未配置 IDAAS_CLIENT_ID 或 IDAAS_CLIENT_SECRET')
    
    # 构建 POST 请求数据
    # 按照 OAuth2 规范，使用 application/x-www-form-urlencoded 格式
    post_data = {
        'grant_type': 'authorization_code',
        'code': code,
        'client_id': client_id,
        'client_secret': client_secret,
        'redirect_uri': redirect_uri
    }
    
    current_app.logger.info(f'Exchanging code for token at: {token_url}')
    current_app.logger.debug(f'Request data: client_id={client_id}, redirect_uri={redirect_uri}')
    
    # 发送 POST 请求到 IDaaS Token URL
    try:
        response = requests.post(
            token_url,
            data=post_data,  # 使用 data= 发送表单数据
            headers={'Content-Type': 'application/x-www-form-urlencoded'},
            timeout=10
        )
        
        if response.status_code != 200:
            current_app.logger.error(f'Token exchange failed: status={response.status_code}, response={response.text}')
            return None
        
        token_data = response.json()
        current_app.logger.info('Token exchange successful')
        return token_data
        
    except requests.RequestException as e:
        current_app.logger.error(f'Token exchange request error: {e}')
        raise


def decode_id_token(id_token):
    """
    解析 ID Token（简化版，不验证签名）
    生产环境应该使用 JWKS 验证签名
    
    Args:
        id_token: OIDC ID Token
    
    Returns:
        dict: 解析后的 payload
    """
    try:
        # 简化处理：不验证签名，只解析 payload
        # 生产环境应使用 JWKS 验证
        payload = jwt.decode(id_token, options={"verify_signature": False})
        return payload
    except Exception as e:
        current_app.logger.warning(f'ID token decode failed: {e}')
        return None


def fetch_userinfo(access_token):
    """
    从 userinfo 端点获取用户信息
    
    Args:
        access_token: OAuth access_token
    
    Returns:
        dict: 用户信息
    """
    # 获取用户信息端点（优先使用新配置名称）
    userinfo_endpoint = current_app.config.get('IDAAS_USERINFO_URL', '')
    
    # 兼容旧配置
    if not userinfo_endpoint:
        userinfo_endpoint = current_app.config.get('OAUTH_USERINFO_ENDPOINT', '')
    
    if not userinfo_endpoint:
        current_app.logger.warning('未配置 IDAAS_USERINFO_URL')
        return None
    
    headers = {'Authorization': f'Bearer {access_token}'}
    
    try:
        response = requests.get(userinfo_endpoint, headers=headers, timeout=10)
        
        if response.status_code != 200:
            current_app.logger.error(f'Userinfo fetch failed: status={response.status_code}, response={response.text}')
            return None
        
        return response.json()
        
    except requests.RequestException as e:
        current_app.logger.error(f'Userinfo fetch request error: {e}')
        return None


# ==================== 通用：获取当前用户 ====================

@auth_bp.route('/me', methods=['GET'])
@login_required
def get_current_user():
    """
    获取当前登录用户信息
    需要携带有效的 JWT Token
    
    Returns:
        用户信息对象
    """
    from flask import g
    user = g.current_user
    return success_response(user.to_dict())


@auth_bp.route('/refresh', methods=['POST'])
@login_required
def refresh_token():
    """
    刷新 JWT Token
    用于在 Token 即将过期时获取新的 Token
    
    Returns:
        {
            "token": "new_jwt_token..."
        }
    """
    from flask import g
    user = g.current_user
    
    # 生成新的 Token
    token = generate_jwt_token(user)
    
    return success_response({
        'token': token
    }, 'Token 已刷新')


@auth_bp.route('/logout', methods=['POST'])
def logout():
    """
    登出（客户端处理）
    
    JWT 是无状态的，服务端不需要处理登出
    客户端只需清除本地存储的 Token 即可
    
    如果需要服务端登出，可以实现 Token 黑名单机制
    """
    return success_response(None, '登出成功')


# ==================== 管理员：重置用户密码 ====================

@auth_bp.route('/reset-password/<user_uuid>', methods=['POST'])
@admin_required
def reset_user_password(user_uuid):
    """
    重置用户密码（仅管理员可用，仅 DEV 模式有效）
    
    Path Params:
        user_uuid: 要重置密码的用户 UUID
    
    Request Body:
        {
            "new_password": "newpassword123"
        }
    
    Returns:
        成功/失败消息
    """
    auth_mode = current_app.config.get('AUTH_MODE', 'dev')
    
    if auth_mode == 'prod':
        return error_response('生产环境使用 OAuth，无法重置密码', 400)
    
    data = request.get_json()
    if not data or not data.get('new_password'):
        return error_response('请提供新密码', 400)
    
    user = User.query.get(user_uuid)
    if not user:
        return error_response('用户不存在', 404)
    
    new_password = data.get('new_password')
    if len(new_password) < 6:
        return error_response('密码长度不能少于6位', 400)
    
    user.set_password(new_password)
    db.session.commit()
    
    return success_response(None, '密码已重置')

