# -*- coding: utf-8 -*-
"""
文件管理控制器
处理用户数据文件的上传、预览、下载、删除等操作
"""
import os
import uuid
from datetime import datetime
from flask import Blueprint, request, g, send_file
from werkzeug.utils import secure_filename
import pandas as pd

from app import db
from app.models.user_file import UserFile
from app.models.folder import Folder
from app.utils.response import success_response, error_response
from app.utils.decorators import require_user
from app.services.data_storage_service import DATA_STORAGE_ROOT

files_bp = Blueprint('files', __name__)

# 允许的文件扩展名
ALLOWED_EXTENSIONS = {'csv', 'xlsx', 'xls', 'parquet'}

# 用户文件存储目录
USER_FILES_ROOT = os.path.join(DATA_STORAGE_ROOT, 'user_files')
os.makedirs(USER_FILES_ROOT, exist_ok=True)


def allowed_file(filename):
    """检查文件扩展名是否允许"""
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


def get_file_extension(filename):
    """获取文件扩展名"""
    return filename.rsplit('.', 1)[1].lower() if '.' in filename else ''


@files_bp.route('', methods=['GET'])
@require_user
def get_files():
    """获取用户文件列表"""
    user_uuid = g.user_uuid
    folder_id = request.args.get('folder_id', type=int)
    
    query = UserFile.query.filter_by(user_uuid=user_uuid)
    
    if folder_id:
        query = query.filter_by(folder_id=folder_id)
    elif folder_id is None and 'folder_id' in request.args:
        # 明确传了 folder_id=null，获取根目录文件
        query = query.filter_by(folder_id=None)
    
    files = query.order_by(UserFile.sort_order, UserFile.created_at.desc()).all()
    
    return success_response([f.to_dict() for f in files])


@files_bp.route('/all', methods=['GET'])
@require_user
def get_all_files():
    """获取用户所有文件（含文件夹结构）"""
    user_uuid = g.user_uuid
    
    # 获取所有文件夹（树形结构）
    root_folders = Folder.query.filter_by(
        user_uuid=user_uuid,
        parent_id=None
    ).order_by(Folder.sort_order).all()
    
    folders_data = []
    for folder in root_folders:
        folder_dict = folder.to_dict(include_children=True)
        folder_dict['files'] = [f.to_dict() for f in UserFile.query.filter_by(
            user_uuid=user_uuid, folder_id=folder.id
        ).order_by(UserFile.sort_order).all()]
        folders_data.append(folder_dict)
    
    # 获取根目录的文件
    root_files = UserFile.query.filter_by(
        user_uuid=user_uuid,
        folder_id=None
    ).order_by(UserFile.sort_order, UserFile.created_at.desc()).all()
    
    return success_response({
        'folders': folders_data,
        'files': [f.to_dict() for f in root_files]
    })


@files_bp.route('/upload', methods=['POST'])
@require_user
def upload_file():
    """上传文件"""
    user_uuid = g.user_uuid
    
    if 'file' not in request.files:
        return error_response('未找到文件', 400)
    
    file = request.files['file']
    
    if file.filename == '':
        return error_response('未选择文件', 400)
    
    if not allowed_file(file.filename):
        return error_response(f'不支持的文件类型，仅支持: {", ".join(ALLOWED_EXTENSIONS)}', 400)
    
    folder_id = request.form.get('folder_id', type=int)
    
    # 验证文件夹
    if folder_id:
        folder = Folder.query.filter_by(id=folder_id, user_uuid=user_uuid).first()
        if not folder:
            return error_response('文件夹不存在', 404)
    
    try:
        # 生成安全的文件名
        original_filename = file.filename
        extension = get_file_extension(original_filename)
        safe_filename = f"{user_uuid}_{uuid.uuid4().hex}_{datetime.now().strftime('%Y%m%d%H%M%S')}.{extension}"
        
        # 创建用户目录
        user_dir = os.path.join(USER_FILES_ROOT, user_uuid)
        os.makedirs(user_dir, exist_ok=True)
        
        # 保存文件
        file_path = os.path.join(user_dir, safe_filename)
        file.save(file_path)
        
        # 获取文件大小
        file_size = os.path.getsize(file_path)
        
        # 读取数据获取元信息
        row_count = 0
        column_count = 0
        columns_info = []
        
        try:
            if extension == 'parquet':
                df = pd.read_parquet(file_path)
            elif extension in ('xlsx', 'xls'):
                df = pd.read_excel(file_path)
            else:  # csv
                df = pd.read_csv(file_path, encoding='utf-8-sig')
            
            row_count = len(df)
            column_count = len(df.columns)
            columns_info = [
                {'name': col, 'dtype': str(df[col].dtype)}
                for col in df.columns
            ]
        except Exception as e:
            print(f"读取文件元信息失败: {e}")
        
        # 获取最大排序值
        max_order = db.session.query(db.func.max(UserFile.sort_order)).filter(
            UserFile.user_uuid == user_uuid,
            UserFile.folder_id == folder_id
        ).scalar() or 0
        
        # 创建文件记录
        user_file = UserFile(
            user_uuid=user_uuid,
            folder_id=folder_id,
            filename=original_filename,
            storage_path=file_path,
            file_type=extension,
            file_size=file_size,
            row_count=row_count,
            column_count=column_count,
            columns_info=columns_info,
            sort_order=max_order + 1
        )
        
        db.session.add(user_file)
        db.session.commit()
        
        return success_response(user_file.to_dict(), '上传成功', 201)
        
    except Exception as e:
        db.session.rollback()
        return error_response(f'上传失败: {str(e)}', 500)


@files_bp.route('/preview/<int:file_id>', methods=['GET'])
@require_user
def preview_file(file_id):
    """
    预览文件内容
    返回文件摘要信息和前N行数据
    """
    user_uuid = g.user_uuid
    limit = request.args.get('limit', 20, type=int)
    limit = min(limit, 100)  # 最多100行
    
    user_file = UserFile.query.filter_by(id=file_id, user_uuid=user_uuid).first()
    if not user_file:
        return error_response('文件不存在', 404)
    
    if not os.path.exists(user_file.storage_path):
        return error_response('文件已丢失', 404)
    
    try:
        # 根据文件类型读取数据
        extension = user_file.file_type
        
        if extension == 'parquet':
            df = pd.read_parquet(user_file.storage_path)
        elif extension in ('xlsx', 'xls'):
            df = pd.read_excel(user_file.storage_path)
        else:  # csv
            df = pd.read_csv(user_file.storage_path, encoding='utf-8-sig')
        
        # 获取前N行
        preview_df = df.head(limit)
        
        # 转换为前端友好的格式
        headers = df.columns.tolist()
        rows = preview_df.fillna('').to_dict('records')
        
        # 统计信息
        stats = {
            'total_rows': len(df),
            'total_columns': len(df.columns),
            'preview_rows': len(preview_df),
            'column_types': {col: str(df[col].dtype) for col in df.columns}
        }
        
        return success_response({
            'file': user_file.to_dict(),
            'preview': {
                'headers': headers,
                'rows': rows
            },
            'stats': stats
        })
        
    except Exception as e:
        return error_response(f'预览失败: {str(e)}', 500)


@files_bp.route('/download/<int:file_id>', methods=['GET'])
@require_user
def download_file(file_id):
    """下载文件"""
    user_uuid = g.user_uuid
    
    user_file = UserFile.query.filter_by(id=file_id, user_uuid=user_uuid).first()
    if not user_file:
        return error_response('文件不存在', 404)
    
    if not os.path.exists(user_file.storage_path):
        return error_response('文件已丢失', 404)
    
    return send_file(
        user_file.storage_path,
        download_name=user_file.filename,
        as_attachment=True
    )


@files_bp.route('/<int:file_id>', methods=['PUT'])
@require_user
def update_file(file_id):
    """更新文件信息（重命名、移动等）"""
    user_uuid = g.user_uuid
    
    user_file = UserFile.query.filter_by(id=file_id, user_uuid=user_uuid).first()
    if not user_file:
        return error_response('文件不存在', 404)
    
    data = request.get_json()
    
    if 'filename' in data:
        # 保留原扩展名
        new_name = data['filename']
        if '.' not in new_name:
            new_name = f"{new_name}.{user_file.file_type}"
        user_file.filename = new_name
    
    if 'folder_id' in data:
        folder_id = data['folder_id']
        if folder_id:
            folder = Folder.query.filter_by(id=folder_id, user_uuid=user_uuid).first()
            if not folder:
                return error_response('目标文件夹不存在', 404)
        user_file.folder_id = folder_id
    
    if 'is_starred' in data:
        user_file.is_starred = data['is_starred']
    
    if 'sort_order' in data:
        user_file.sort_order = data['sort_order']
    
    db.session.commit()
    
    return success_response(user_file.to_dict(), '更新成功')


@files_bp.route('/<int:file_id>', methods=['DELETE'])
@require_user
def delete_file(file_id):
    """删除文件"""
    user_uuid = g.user_uuid
    
    user_file = UserFile.query.filter_by(id=file_id, user_uuid=user_uuid).first()
    if not user_file:
        return error_response('文件不存在', 404)
    
    # 删除物理文件
    if os.path.exists(user_file.storage_path):
        try:
            os.remove(user_file.storage_path)
        except Exception as e:
            print(f"删除物理文件失败: {e}")
    
    # 删除数据库记录
    db.session.delete(user_file)
    db.session.commit()
    
    return success_response(None, '删除成功')


@files_bp.route('/reorder', methods=['PUT'])
@require_user
def reorder_files():
    """重新排序文件"""
    user_uuid = g.user_uuid
    data = request.get_json()
    items = data.get('items', [])
    
    for item_data in items:
        user_file = UserFile.query.filter_by(
            id=item_data['id'],
            user_uuid=user_uuid
        ).first()
        if user_file:
            user_file.sort_order = item_data.get('sort_order', 0)
            if 'folder_id' in item_data:
                user_file.folder_id = item_data['folder_id']
    
    db.session.commit()
    
    return success_response(None, '排序更新成功')

