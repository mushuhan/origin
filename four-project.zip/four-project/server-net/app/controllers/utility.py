# -*- coding: utf-8 -*-
"""
便捷工具控制器 - 发票校验、邮件分发生成器、PDF转换
"""
from flask import Blueprint, request, g, send_file
from app import db
from app.models.invoice_header import InvoiceHeader
from app.models.email_preset import EmailPreset
from app.models.employee import Employee
from app.models.department import Department
from app.utils.response import success_response, error_response
from app.utils.decorators import require_user
from app.services.invoice_service import InvoiceOCRService, InvoiceVerifyService
import io
import fitz  # PyMuPDF

utility_bp = Blueprint('utility', __name__, url_prefix='/api/utility')


# ==================== 发票校验相关 ====================

@utility_bp.route('/invoice/verify', methods=['POST'])
@require_user
def verify_invoice():
    """
    发票校验接口
    
    支持两种输入方式：
    1. 文本输入：直接传入 title 和 tax_number
    2. 文件上传：上传图片/PDF，进行 OCR 提取后校验
    
    请求体（JSON）：
    {
        "items": [
            {"title": "公司名称", "tax_number": "税号"},
            ...
        ]
    }
    
    或 multipart/form-data 上传文件
    """
    # 获取标准库数据（使用 Set 进行 O(1) 匹配）
    title_set, tax_set, title_to_tax = InvoiceHeader.get_all_as_set()
    
    # 检查是否为文件上传
    if request.files:
        files = request.files.getlist('files')
        all_results = []
        
        for file in files:
            if not file or not file.filename:
                continue
            
            # 读取文件内容到内存（不保存到硬盘）
            file_content = file.read()
            filename = file.filename.lower()
            
            # 根据文件类型选择处理方式
            if filename.endswith('.pdf'):
                extracted = InvoiceOCRService.extract_from_pdf(file_content, filename)
            elif filename.endswith(('.jpg', '.jpeg', '.png', '.gif', '.bmp')):
                extracted = InvoiceOCRService.extract_from_image(file_content, filename)
            else:
                all_results.append({
                    'filename': file.filename,
                    'status': 'fail',
                    'messages': ['不支持的文件格式'],
                    'extracted': {}
                })
                continue
            
            # 检查提取错误
            if extracted.get('error'):
                all_results.append({
                    'filename': file.filename,
                    'status': 'fail',
                    'messages': [extracted['error']],
                    'extracted': extracted
                })
                continue
            
            # 构建待校验项
            items = []
            titles = extracted.get('titles', [])
            tax_numbers = extracted.get('tax_numbers', [])
            
            # 尝试配对抬头和税号
            max_count = max(len(titles), len(tax_numbers), 1)
            for i in range(max_count):
                items.append({
                    'title': titles[i] if i < len(titles) else '',
                    'tax_number': tax_numbers[i] if i < len(tax_numbers) else ''
                })
            
            # 校验
            verify_results = InvoiceVerifyService.verify_batch(items, title_set, tax_set, title_to_tax)
            
            all_results.append({
                'filename': file.filename,
                'extracted': extracted,
                'results': verify_results
            })
        
        return success_response(all_results)
    
    # JSON 输入方式
    data = request.get_json()
    if not data:
        return error_response('请提供校验数据')
    
    items = data.get('items', [])
    
    # 支持单项输入
    if not items and (data.get('title') or data.get('tax_number')):
        items = [{
            'title': data.get('title', ''),
            'tax_number': data.get('tax_number', '')
        }]
    
    if not items:
        return error_response('请提供待校验的发票信息')
    
    # 校验
    results = InvoiceVerifyService.verify_batch(items, title_set, tax_set, title_to_tax)
    
    return success_response(results)


@utility_bp.route('/invoice/save', methods=['POST'])
@require_user
def save_invoice_header():
    """
    保存新的发票抬头到库
    
    请求体：
    {
        "title": "公司名称",
        "tax_number": "税号",
        "address": "地址（可选）",
        "phone": "电话（可选）",
        "bank_name": "开户银行（可选）",
        "bank_account": "银行账号（可选）"
    }
    """
    data = request.get_json()
    
    title = data.get('title', '').strip()
    tax_number = data.get('tax_number', '').strip()
    
    if not title:
        return error_response('抬头名称不能为空')
    if not tax_number:
        return error_response('税号不能为空')
    
    # 创建
    header, err = InvoiceHeader.create(
        title=title,
        tax_number=tax_number,
        address=data.get('address', ''),
        phone=data.get('phone', ''),
        bank_name=data.get('bank_name', ''),
        bank_account=data.get('bank_account', ''),
        created_by=g.user_uuid
    )
    
    if err:
        return error_response(err)
    
    return success_response(header.to_dict(), '保存成功', 201)


@utility_bp.route('/invoice/headers', methods=['GET'])
@require_user
def get_invoice_headers():
    """获取发票抬头库列表"""
    keyword = request.args.get('keyword', '')
    limit = request.args.get('limit', 50, type=int)
    
    headers = InvoiceHeader.search(keyword, limit)
    return success_response([h.to_dict() for h in headers])


# ==================== 邮件分发生成器相关 ====================

@utility_bp.route('/email/search', methods=['POST'])
@require_user
def search_employees():
    """
    搜索员工（支持复杂筛选）
    
    请求体：
    {
        "keyword": "模糊搜索关键字（可选）",
        "department_ids": [1, 2, 3],  // 科室ID列表
        "roles": ["主管", "检验员"],  // 职位/角色筛选
        "employee_type": "dispatch" | "regular" | "all",  // 派遣/正式/全部
        "page": 1,
        "page_size": 50
    }
    """
    data = request.get_json() or {}
    
    keyword = data.get('keyword', '').strip()
    department_ids = data.get('department_ids', [])
    roles = data.get('roles', [])
    employee_type = data.get('employee_type', 'all')
    page = data.get('page', 1)
    page_size = min(data.get('page_size', 50), 200)  # 最大200条
    
    # 构建查询
    query = Employee.query.filter_by(is_active=True)
    
    # 科室筛选
    if department_ids:
        query = query.filter(Employee.department_id.in_(department_ids))
    
    # 职位/角色筛选
    if roles:
        from sqlalchemy import or_
        role_filters = [Employee.position.ilike(f'%{role}%') for role in roles]
        query = query.filter(or_(*role_filters))
    
    # 员工类型筛选（根据工号特征）
    if employee_type == 'dispatch':
        # 派遣员工：工号以 '8' 开头
        query = query.filter(Employee.id.cast(db.String).like('8%'))
    elif employee_type == 'regular':
        # 正式员工：工号以 '00' 开头
        query = query.filter(Employee.id.cast(db.String).like('00%'))
    
    # 关键字搜索
    if keyword:
        from sqlalchemy import or_
        query = query.filter(or_(
            Employee.name.ilike(f'%{keyword}%'),
            Employee.pinyin.ilike(f'%{keyword}%'),
            Employee.pinyin_initials.ilike(f'%{keyword}%'),
            Employee.email.ilike(f'%{keyword}%'),
            Employee.position.ilike(f'%{keyword}%')
        ))
    
    # 分页
    total = query.count()
    employees = query.order_by(Employee.department_id, Employee.sort_order)\
                    .offset((page - 1) * page_size)\
                    .limit(page_size)\
                    .all()
    
    # 获取科室信息
    dept_map = {d.id: d.name for d in Department.get_all()}
    
    result = []
    for emp in employees:
        emp_dict = emp.to_dict()
        emp_dict['department_name'] = dept_map.get(emp.department_id, '')
        result.append(emp_dict)
    
    return success_response({
        'items': result,
        'total': total,
        'page': page,
        'page_size': page_size
    })


@utility_bp.route('/email/export', methods=['POST'])
@require_user
def export_employees():
    """
    导出员工列表为 Excel
    
    请求体：
    {
        "employee_ids": [1, 2, 3, ...],  // 选中的员工ID列表
        "format": "excel" | "string",    // 输出格式
        "string_type": "email" | "id"    // string格式时输出邮箱还是工号
    }
    """
    data = request.get_json() or {}
    
    employee_ids = data.get('employee_ids', [])
    output_format = data.get('format', 'excel')
    string_type = data.get('string_type', 'email')
    
    if not employee_ids:
        return error_response('请选择要导出的员工')
    
    # 查询员工
    employees = Employee.query.filter(
        Employee.id.in_(employee_ids),
        Employee.is_active == True
    ).all()
    
    if not employees:
        return error_response('未找到选中的员工')
    
    # 获取科室信息
    dept_map = {d.id: d.name for d in Department.get_all()}
    
    if output_format == 'string':
        # 生成字符串格式
        if string_type == 'email':
            items = [emp.email for emp in employees if emp.email]
            result_string = ';'.join(items)
        else:
            items = [str(emp.id) for emp in employees]
            result_string = ';'.join(items)
        
        return success_response({
            'string': result_string,
            'count': len(items)
        })
    
    # 生成 Excel
    try:
        import openpyxl
        from openpyxl.styles import Font, Alignment, PatternFill
        
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = '员工列表'
        
        # 表头样式
        header_font = Font(bold=True, color='FFFFFF')
        header_fill = PatternFill(start_color='4472C4', end_color='4472C4', fill_type='solid')
        
        # 表头（脱敏：仅保留姓名、邮箱、工号、科室）
        headers = ['工号', '姓名', '科室', '邮箱']
        for col, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col, value=header)
            cell.font = header_font
            cell.fill = header_fill
            cell.alignment = Alignment(horizontal='center')
        
        # 数据
        for row, emp in enumerate(employees, 2):
            ws.cell(row=row, column=1, value=emp.id)
            ws.cell(row=row, column=2, value=emp.name)
            ws.cell(row=row, column=3, value=dept_map.get(emp.department_id, ''))
            ws.cell(row=row, column=4, value=emp.email or '')
        
        # 调整列宽
        ws.column_dimensions['A'].width = 12
        ws.column_dimensions['B'].width = 15
        ws.column_dimensions['C'].width = 20
        ws.column_dimensions['D'].width = 30
        
        # 保存到内存
        output = io.BytesIO()
        wb.save(output)
        output.seek(0)
        
        return send_file(
            output,
            mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            as_attachment=True,
            download_name='employees.xlsx'
        )
    except ImportError:
        return error_response('Excel 导出功能需要安装 openpyxl 库')
    except Exception as e:
        return error_response(f'导出失败: {str(e)}')


@utility_bp.route('/email/preset', methods=['GET'])
@require_user
def get_presets():
    """获取当前用户的预设列表"""
    presets = EmailPreset.get_user_presets(g.user_uuid)
    return success_response([p.to_dict() for p in presets])


@utility_bp.route('/email/preset', methods=['POST'])
@require_user
def save_preset():
    """
    保存筛选预设
    
    请求体：
    {
        "name": "预设名称",
        "description": "描述（可选）",
        "filters": {
            "department_ids": [1, 2],
            "roles": ["主管"],
            "employee_type": "regular"
        }
    }
    """
    data = request.get_json() or {}
    
    name = data.get('name', '').strip()
    if not name:
        return error_response('预设名称不能为空')
    
    filters = data.get('filters', {})
    description = data.get('description', '')
    
    preset = EmailPreset.create(
        user_uuid=g.user_uuid,
        name=name,
        filters=filters,
        description=description
    )
    
    return success_response(preset.to_dict(), '保存成功', 201)


@utility_bp.route('/email/preset/<int:preset_id>', methods=['PUT'])
@require_user
def update_preset(preset_id):
    """更新预设"""
    preset = EmailPreset.get_by_id(preset_id)
    
    if not preset:
        return error_response('预设不存在', 404)
    
    if preset.user_uuid != g.user_uuid:
        return error_response('无权修改', 403)
    
    data = request.get_json() or {}
    preset.update(
        name=data.get('name'),
        filters=data.get('filters'),
        description=data.get('description')
    )
    
    return success_response(preset.to_dict(), '更新成功')


@utility_bp.route('/email/preset/<int:preset_id>', methods=['DELETE'])
@require_user
def delete_preset(preset_id):
    """删除预设"""
    preset = EmailPreset.get_by_id(preset_id)
    
    if not preset:
        return error_response('预设不存在', 404)
    
    if preset.user_uuid != g.user_uuid:
        return error_response('无权删除', 403)
    
    preset.delete()
    return success_response(None, '删除成功')


@utility_bp.route('/email/departments', methods=['GET'])
@require_user
def get_departments_for_filter():
    """获取科室列表（用于筛选器下拉）"""
    departments = Department.get_all()
    return success_response([{
        'id': d.id,
        'name': d.name
    } for d in departments])


@utility_bp.route('/email/roles', methods=['GET'])
@require_user
def get_roles():
    """获取所有职位/角色（用于筛选器下拉）"""
    # 从员工表中提取所有不重复的职位
    from sqlalchemy import distinct
    positions = Employee.query.with_entities(
        distinct(Employee.position)
    ).filter(
        Employee.is_active == True,
        Employee.position != None,
        Employee.position != ''
    ).all()
    
    roles = [p[0] for p in positions if p[0]]
    return success_response(roles)


# ==================== PDF转换相关 ====================

@utility_bp.route('/pdf/convert', methods=['POST'])
@require_user
def convert_pdf():
    """
    PDF转Excel/Word接口
    
    请求方式：multipart/form-data
    参数：
    - file: PDF文件
    - target_format: 目标格式 'excel' 或 'word'
    
    返回：转换后的文件流
    """
    if 'file' not in request.files:
        return error_response('请上传PDF文件')
    
    file = request.files['file']
    target_format = request.form.get('target_format', 'excel')
    
    if not file or not file.filename:
        return error_response('请选择有效的PDF文件')
    
    if not file.filename.lower().endswith('.pdf'):
        return error_response('仅支持PDF文件')
    
    # 限制文件大小 20MB
    file.stream.seek(0, 2)
    file_size = file.stream.tell()
    file.stream.seek(0)
    
    if file_size > 20 * 1024 * 1024:
        return error_response('文件过大，最大支持20MB')
    
    try:
        pdf_content = file.read()
        pdf_doc = fitz.open(stream=pdf_content, filetype="pdf")
        
        if target_format == 'word':
            return _convert_pdf_to_word(pdf_doc, file.filename)
        else:
            return _convert_pdf_to_excel(pdf_doc, file.filename)
            
    except Exception as e:
        return error_response(f'转换失败: {str(e)}')


def _convert_pdf_to_excel(pdf_doc, original_filename):
    """将PDF转换为Excel"""
    import openpyxl
    from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
    
    wb = openpyxl.Workbook()
    wb.remove(wb.active)
    
    # 表头样式
    header_font = Font(bold=True, color='FFFFFF', size=11)
    header_fill = PatternFill(start_color='4472C4', end_color='4472C4', fill_type='solid')
    thin_border = Border(
        left=Side(style='thin'),
        right=Side(style='thin'),
        top=Side(style='thin'),
        bottom=Side(style='thin')
    )
    
    for page_num in range(len(pdf_doc)):
        page = pdf_doc[page_num]
        
        # 提取表格数据 - find_tables()返回TableFinder对象，需要用.tables获取列表
        table_finder = page.find_tables()
        tables = table_finder.tables if table_finder else []
        
        if tables and len(tables) > 0:
            # 有表格，提取表格数据
            for table_idx, table in enumerate(tables):
                sheet_name = f"页{page_num + 1}" if table_idx == 0 else f"页{page_num + 1}_表{table_idx + 1}"
                sheet_name = sheet_name[:31]  # Excel工作表名最多31字符
                ws = wb.create_sheet(title=sheet_name)
                
                table_data = table.extract()
                
                for row_idx, row in enumerate(table_data):
                    for col_idx, cell_value in enumerate(row):
                        cell = ws.cell(row=row_idx + 1, column=col_idx + 1, value=cell_value or '')
                        cell.border = thin_border
                        cell.alignment = Alignment(wrap_text=True, vertical='center')
                        
                        # 首行作为表头
                        if row_idx == 0:
                            cell.font = header_font
                            cell.fill = header_fill
                
                # 自动调整列宽
                for col in ws.columns:
                    max_length = 0
                    column = col[0].column_letter
                    for cell in col:
                        try:
                            if cell.value:
                                cell_len = len(str(cell.value))
                                if cell_len > max_length:
                                    max_length = cell_len
                        except:
                            pass
                    adjusted_width = min(max_length + 2, 50)
                    ws.column_dimensions[column].width = adjusted_width
        else:
            # 无表格，提取纯文本
            text = page.get_text()
            if text.strip():
                sheet_name = f"页{page_num + 1}"[:31]
                ws = wb.create_sheet(title=sheet_name)
                
                lines = text.split('\n')
                for row_idx, line in enumerate(lines):
                    if line.strip():
                        ws.cell(row=row_idx + 1, column=1, value=line)
                
                ws.column_dimensions['A'].width = 100
    
    # 如果没有创建任何工作表，创建一个空的
    if len(wb.sheetnames) == 0:
        ws = wb.create_sheet(title="Sheet1")
        ws.cell(row=1, column=1, value="PDF中未检测到可提取的内容")
    
    # 保存到内存
    output = io.BytesIO()
    wb.save(output)
    output.seek(0)
    
    download_name = original_filename.rsplit('.', 1)[0] + '.xlsx'
    
    return send_file(
        output,
        mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        as_attachment=True,
        download_name=download_name
    )


def _convert_pdf_to_word(pdf_doc, original_filename):
    """将PDF转换为Word"""
    from docx import Document
    from docx.shared import Inches, Pt, RGBColor
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.enum.table import WD_TABLE_ALIGNMENT
    
    doc = Document()
    
    # 设置默认字体
    style = doc.styles['Normal']
    style.font.name = '微软雅黑'
    style.font.size = Pt(11)
    
    for page_num in range(len(pdf_doc)):
        page = pdf_doc[page_num]
        
        # 添加页码分隔
        if page_num > 0:
            doc.add_page_break()
        
        # 尝试提取表格 - find_tables()返回TableFinder对象
        table_finder = page.find_tables()
        tables = table_finder.tables if table_finder else []
        
        if tables and len(tables) > 0:
            for table_idx, table in enumerate(tables):
                table_data = table.extract()
                
                if table_data and len(table_data) > 0:
                    # 创建Word表格
                    num_rows = len(table_data)
                    num_cols = max(len(row) for row in table_data) if table_data else 1
                    
                    word_table = doc.add_table(rows=num_rows, cols=num_cols)
                    word_table.style = 'Table Grid'
                    word_table.alignment = WD_TABLE_ALIGNMENT.CENTER
                    
                    for row_idx, row in enumerate(table_data):
                        for col_idx, cell_value in enumerate(row):
                            if col_idx < num_cols:
                                cell = word_table.rows[row_idx].cells[col_idx]
                                cell.text = str(cell_value or '')
                                
                                # 首行加粗
                                if row_idx == 0:
                                    for paragraph in cell.paragraphs:
                                        for run in paragraph.runs:
                                            run.bold = True
                    
                    doc.add_paragraph()  # 表格后空行
        
        # 提取文本（排除已提取的表格区域）
        text_blocks = page.get_text("blocks")
        
        for block in text_blocks:
            if block[6] == 0:  # 文本块（非图片）
                text = block[4].strip()
                if text:
                    para = doc.add_paragraph(text)
                    para.alignment = WD_ALIGN_PARAGRAPH.LEFT
    
    # 保存到内存
    output = io.BytesIO()
    doc.save(output)
    output.seek(0)
    
    download_name = original_filename.rsplit('.', 1)[0] + '.docx'
    
    return send_file(
        output,
        mimetype='application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        as_attachment=True,
        download_name=download_name
    )

