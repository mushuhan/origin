# -*- coding: utf-8 -*-
"""
励志语录控制器
"""
from flask import Blueprint, request
from app import db
from app.models.quote import Quote
from app.services.quote_service import QuoteService
from app.utils.response import success_response, error_response

quotes_bp = Blueprint('quotes', __name__)


@quotes_bp.route('', methods=['GET'])
def get_quotes():
    """获取语录列表"""
    category = request.args.get('category')
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 20, type=int)
    
    query = Quote.query.filter_by(is_active=True)
    
    if category:
        query = query.filter_by(category=category)
    
    pagination = query.order_by(Quote.id).paginate(
        page=page, per_page=per_page, error_out=False
    )
    
    return success_response({
        'items': [q.to_dict() for q in pagination.items],
        'total': pagination.total,
        'page': page,
        'per_page': per_page
    })


@quotes_bp.route('/random', methods=['GET'])
def get_random_quote():
    """获取随机语录"""
    count = request.args.get('count', 1, type=int)
    count = min(count, 10)
    
    quotes = QuoteService.get_random_quotes(count)
    
    if count == 1 and quotes:
        return success_response(quotes[0])
    
    return success_response(quotes)


@quotes_bp.route('/daily', methods=['GET'])
def get_daily_quote():
    """获取每日语录（基于日期确定性随机）"""
    quote = QuoteService.get_daily_quote()
    
    if not quote:
        return success_response(None)
    
    return success_response(quote)


@quotes_bp.route('/<int:id>', methods=['GET'])
def get_quote(id):
    """获取单条语录"""
    quote = Quote.query.get_or_404(id)
    return success_response(quote.to_dict())


@quotes_bp.route('', methods=['POST'])
def create_quote():
    """创建语录"""
    data = request.get_json()
    
    if not data or not data.get('content'):
        return error_response('语录内容不能为空', 400)
    
    quote = Quote(
        content=data['content'],
        author=data.get('author'),
        source=data.get('source'),
        category=data.get('category', 'general'),
        is_active=data.get('is_active', True)
    )
    
    db.session.add(quote)
    db.session.commit()
    
    return success_response(quote.to_dict(), '创建成功', 201)


@quotes_bp.route('/<int:id>', methods=['PUT'])
def update_quote(id):
    """更新语录"""
    quote = Quote.query.get_or_404(id)
    data = request.get_json()
    
    if 'content' in data:
        quote.content = data['content']
    if 'author' in data:
        quote.author = data['author']
    if 'source' in data:
        quote.source = data['source']
    if 'category' in data:
        quote.category = data['category']
    if 'is_active' in data:
        quote.is_active = data['is_active']
    
    db.session.commit()
    
    return success_response(quote.to_dict(), '更新成功')


@quotes_bp.route('/<int:id>', methods=['DELETE'])
def delete_quote(id):
    """删除语录"""
    quote = Quote.query.get_or_404(id)
    
    db.session.delete(quote)
    db.session.commit()
    
    return success_response(None, '删除成功')


@quotes_bp.route('/categories', methods=['GET'])
def get_categories():
    """获取语录分类列表"""
    categories = db.session.query(Quote.category).distinct().all()
    return success_response([c[0] for c in categories if c[0]])

