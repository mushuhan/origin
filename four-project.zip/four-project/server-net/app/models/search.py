# -*- coding: utf-8 -*-
"""
搜索历史模型
PostgreSQL pg_trgm 高性能搜索优化
"""
from datetime import datetime
from app import db


class SearchHistory(db.Model):
    """搜索历史模型 - 支持 pg_trgm 模糊搜索"""
    __tablename__ = 'search_history'
    
    # PostgreSQL GIN 索引配置
    __table_args__ = (
        # GIN 索引：keyword 支持模糊搜索
        db.Index(
            'idx_search_keyword_gin',
            'keyword',
            postgresql_using='gin',
            postgresql_ops={'keyword': 'gin_trgm_ops'}
        ),
        # 常规索引
        db.Index('idx_search_count', 'search_count', postgresql_using='btree'),
        {'comment': '搜索历史表 - pg_trgm 高性能搜索'}
    )
    
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    keyword = db.Column(db.String(200), nullable=False, comment='搜索关键词')
    search_count = db.Column(db.Integer, default=1, comment='搜索次数')
    last_searched_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'keyword': self.keyword,
            'search_count': self.search_count,
            'last_searched_at': self.last_searched_at.isoformat() if self.last_searched_at else None,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }
    
    def __repr__(self):
        return f'<SearchHistory {self.keyword}>'
