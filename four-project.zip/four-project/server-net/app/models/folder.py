# -*- coding: utf-8 -*-
"""
文件夹模型
支持工作台分组和多级嵌套
"""
from datetime import datetime
from app import db


class Folder(db.Model):
    """
    文件夹表
    支持用户工作台的分组管理，可选多级嵌套
    category 字段用于区分文件夹类型：sites（网址）、files（数据文件）
    """
    __tablename__ = 'folders'
    
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    user_uuid = db.Column(db.String(36), db.ForeignKey('users.uuid', ondelete='CASCADE'), nullable=False, comment='关联用户UUID')
    name = db.Column(db.String(100), nullable=False, comment='文件夹名称')
    parent_id = db.Column(db.Integer, db.ForeignKey('folders.id', ondelete='CASCADE'), nullable=True, comment='父文件夹ID（支持嵌套）')
    category = db.Column(db.String(20), default='sites', nullable=False, comment='文件夹分类: sites(网址), files(数据文件)')
    icon = db.Column(db.String(50), default='Folder', comment='文件夹图标')
    color = db.Column(db.String(20), default='#6b7280', comment='文件夹颜色')
    sort_order = db.Column(db.Integer, default=0, comment='排序顺序')
    is_collapsed = db.Column(db.Boolean, default=False, comment='是否折叠')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # 自引用关系 - 子文件夹
    children = db.relationship(
        'Folder',
        backref=db.backref('parent', remote_side=[id]),
        lazy='dynamic',
        cascade='all, delete-orphan'
    )
    
    # 关联的网址
    user_sites = db.relationship('UserSite', backref='folder', lazy='dynamic')
    
    def to_dict(self, include_children=False, include_sites=False):
        data = {
            'id': self.id,
            'user_uuid': self.user_uuid,
            'name': self.name,
            'parent_id': self.parent_id,
            'category': self.category,
            'icon': self.icon,
            'color': self.color,
            'sort_order': self.sort_order,
            'is_collapsed': self.is_collapsed,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }
        
        if include_children:
            data['children'] = [
                child.to_dict(include_children=True, include_sites=include_sites)
                for child in self.children.order_by(Folder.sort_order).all()
            ]
        
        if include_sites:
            data['sites'] = [
                site.to_dict() for site in self.user_sites.order_by(db.text('sort_order')).all()
            ]
            data['sites_count'] = self.user_sites.count()
        
        return data
    
    def to_tree_dict(self):
        """生成树形结构数据"""
        return self.to_dict(include_children=True, include_sites=True)
    
    def __repr__(self):
        return f'<Folder {self.name}>'

