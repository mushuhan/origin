# -*- coding: utf-8 -*-
"""
用户模型
实现无状态访客标识（Stateless Visitor Identity）
"""
from datetime import datetime
from app import db


class User(db.Model):
    """
    用户表
    存储前端生成的UUID标识，实现用户数据隔离
    """
    __tablename__ = 'users'
    
    uuid = db.Column(db.String(36), primary_key=True, comment='用户UUID（前端生成）')
    created_at = db.Column(db.DateTime, default=datetime.utcnow, comment='首次访问时间')
    last_active_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, comment='最后活跃时间')
    settings = db.Column(db.JSON, default=dict, comment='用户个人设置（JSON）')
    
    # 关联
    folders = db.relationship('Folder', backref='user', lazy='dynamic', cascade='all, delete-orphan')
    user_sites = db.relationship('UserSite', backref='user', lazy='dynamic', cascade='all, delete-orphan')
    
    def to_dict(self):
        return {
            'uuid': self.uuid,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'last_active_at': self.last_active_at.isoformat() if self.last_active_at else None,
            'settings': self.settings or {}
        }
    
    def __repr__(self):
        return f'<User {self.uuid[:8]}...>'

