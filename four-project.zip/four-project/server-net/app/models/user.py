# -*- coding: utf-8 -*-
"""
用户模型
支持混合认证：DEV模式(账号密码) / PROD模式(OAuth2/OIDC IDaaS)

【核心设计原则】
- uuid 字段是系统的基石，所有文件、数据关联都依赖它，绝对不能修改
- oauth_id 是 IDaaS 返回的 sub 标识，用于 PROD 模式下的用户映射
- 两种认证模式最终都会映射到同一个 uuid 用户
"""
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash
from app import db


class User(db.Model):
    """
    用户表
    
    字段设计说明：
    - uuid: 系统内部主键，前端生成或系统自动生成，是所有业务数据关联的基础
    - oauth_id: IDaaS 返回的 sub 唯一标识，仅用于 PROD 模式下的用户查找
    - email: 用户邮箱，用于管理员判断和用户识别
    - name: 用户显示名称
    - role: 用户角色 ('user' | 'admin')，决定访问权限
    - password_hash: 密码哈希，仅用于 DEV 模式
    """
    __tablename__ = 'users'
    
    # ==================== 核心主键（不可修改） ====================
    uuid = db.Column(db.String(36), primary_key=True, comment='用户UUID（系统主键，关联所有业务数据）')
    
    # ==================== 认证相关字段 ====================
    # OAuth2/OIDC 集成：存储 IDaaS 返回的 sub 标识
    # 为什么用 oauth_id 而不是替换 uuid？
    # 答：uuid 已经被文件系统、数据存储等模块引用，更改会导致数据孤立
    oauth_id = db.Column(db.String(255), unique=True, nullable=True, index=True,
                         comment='IDaaS唯一标识(sub)，用于PROD模式用户映射')
    
    # DEV 模式密码认证
    # nullable=True 因为 PROD 模式用户不需要密码
    password_hash = db.Column(db.String(256), nullable=True, 
                              comment='密码哈希，仅DEV模式使用')
    
    # ==================== 用户信息字段 ====================
    email = db.Column(db.String(255), unique=True, nullable=True, index=True,
                      comment='用户邮箱')
    name = db.Column(db.String(100), nullable=True, comment='用户显示名称')
    avatar = db.Column(db.String(500), nullable=True, comment='用户头像URL')
    
    # ==================== 权限控制字段 ====================
    # role 字段决定用户的访问级别
    # 'user': 普通用户，只能访问前台功能
    # 'admin': 管理员，可以访问后台管理功能
    role = db.Column(db.String(20), default='user', nullable=False,
                     comment='用户角色: user(普通用户) / admin(管理员)')
    
    # 账户状态
    is_active = db.Column(db.Boolean, default=True, nullable=False,
                          comment='账户是否激活')
    
    # ==================== 时间戳字段 ====================
    created_at = db.Column(db.DateTime, default=datetime.utcnow, comment='创建时间')
    last_active_at = db.Column(db.DateTime, default=datetime.utcnow, 
                               onupdate=datetime.utcnow, comment='最后活跃时间')
    last_login_at = db.Column(db.DateTime, nullable=True, comment='最后登录时间')
    
    # ==================== 用户设置 ====================
    settings = db.Column(db.JSON, default=dict, comment='用户个人设置（JSON）')
    
    # ==================== 关联关系 ====================
    folders = db.relationship('Folder', backref='user', lazy='dynamic', cascade='all, delete-orphan')
    user_sites = db.relationship('UserSite', backref='user', lazy='dynamic', cascade='all, delete-orphan')
    
    # ==================== 密码处理方法 ====================
    def set_password(self, password):
        """
        设置密码（仅用于 DEV 模式）
        使用 Werkzeug 的安全哈希函数
        """
        if password:
            self.password_hash = generate_password_hash(password, method='pbkdf2:sha256')
    
    def check_password(self, password):
        """
        验证密码
        返回 True 如果密码正确，否则返回 False
        """
        if not self.password_hash:
            return False
        return check_password_hash(self.password_hash, password)
    
    # ==================== 权限检查方法 ====================
    def is_admin(self):
        """检查用户是否为管理员"""
        return self.role == 'admin'
    
    def promote_to_admin(self):
        """提升为管理员"""
        self.role = 'admin'
    
    def demote_to_user(self):
        """降级为普通用户"""
        self.role = 'user'
    
    # ==================== 序列化方法 ====================
    def to_dict(self, include_sensitive=False):
        """
        转换为字典（用于 API 响应）
        
        Args:
            include_sensitive: 是否包含敏感信息（如 oauth_id）
        """
        data = {
            'uuid': self.uuid,
            'email': self.email,
            'name': self.name,
            'avatar': self.avatar,
            'role': self.role,
            'is_active': self.is_active,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'last_active_at': self.last_active_at.isoformat() if self.last_active_at else None,
            'last_login_at': self.last_login_at.isoformat() if self.last_login_at else None,
            'settings': self.settings or {}
        }
        
        if include_sensitive:
            data['oauth_id'] = self.oauth_id
            data['has_password'] = bool(self.password_hash)
        
        return data
    
    def to_admin_dict(self):
        """
        转换为管理员视图字典（包含更多信息）
        用于后台管理界面
        """
        return {
            'uuid': self.uuid,
            'email': self.email,
            'name': self.name,
            'avatar': self.avatar,
            'role': self.role,
            'is_active': self.is_active,
            'oauth_id': self.oauth_id,
            'has_password': bool(self.password_hash),
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'last_active_at': self.last_active_at.isoformat() if self.last_active_at else None,
            'last_login_at': self.last_login_at.isoformat() if self.last_login_at else None,
        }
    
    def __repr__(self):
        return f'<User {self.uuid[:8]}... role={self.role}>'
