"""
看板模型 - 数据看板存储
优化版本：使用文件存储代替数据库存储大数据
"""
import json
from datetime import datetime
from sqlalchemy.dialects.mysql import LONGTEXT
from app import db


class Dashboard(db.Model):
    __tablename__ = 'dashboards'
    
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    user_uuid = db.Column(db.String(36), db.ForeignKey('users.uuid'), nullable=False)
    name = db.Column(db.String(100), nullable=False)
    
    # 图表和统计卡片配置（较小，保留在数据库）
    charts_config = db.Column(db.Text, nullable=True, comment='图表配置JSON')
    stat_cards_config = db.Column(db.Text, nullable=True, comment='统计卡片配置JSON')
    
    # 数据文件路径映射（替代直接存储数据）
    # 格式: {"sheet_name": "file_path", ...}
    data_file_paths = db.Column(db.Text, nullable=True, comment='数据文件路径映射JSON')
    
    # 工作表名称列表
    sheet_names = db.Column(db.String(500), nullable=True, comment='工作表名称JSON数组')
    
    # 文件存储ID（用于定位文件）
    file_id = db.Column(db.String(100), nullable=True, comment='文件存储ID')
    
    visibility = db.Column(db.String(20), default='private', comment='可见性: private/public')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # 兼容旧数据：保留 config 字段用于迁移
    config = db.Column(db.Text().with_variant(LONGTEXT, 'mysql'), nullable=True, comment='[废弃]旧版看板配置JSON')
    
    def to_dict(self, include_data: bool = True):
        """
        转换为字典
        
        :param include_data: 是否包含完整数据（加载列表时设为 False 提升性能）
        """
        result = {
            'id': self.id,
            'user_uuid': self.user_uuid,
            'name': self.name,
            'visibility': self.visibility,
            'fileId': self.file_id,
            'createdAt': self.created_at.isoformat() if self.created_at else None,
            'updatedAt': self.updated_at.isoformat() if self.updated_at else None
        }
        
        # 解析图表配置
        result['charts'] = self._parse_json(self.charts_config, [])
        result['statCards'] = self._parse_json(self.stat_cards_config, [])
        result['sheetNames'] = self._parse_json(self.sheet_names, [])
        
        # 尝试加载或恢复文件路径
        file_paths = self._parse_json(self.data_file_paths, {})
        
        # 自动修复：如果路径为空但有 file_id，尝试扫描文件（应对元数据丢失的情况）
        if not file_paths and self.file_id:
            try:
                from app.services.data_storage_service import DataStorageService
                found_paths = DataStorageService.find_dashboard_files(self.file_id)
                if found_paths:
                    file_paths = found_paths
                    # 如果 sheetNames 也丢失了，一并修复
                    if not result['sheetNames']:
                        result['sheetNames'] = list(file_paths.keys())
            except Exception as e:
                print(f"[Dashboard {self.id}] File recovery failed: {e}")
        
        if include_data:
            # 加载完整数据
            if file_paths:
                from app.services.data_storage_service import DataStorageService
                import os
                
                # 检查文件是否存在（调试用）
                # for sheet_name, path in file_paths.items():
                #     exists = os.path.exists(path)
                #     print(f"  - {sheet_name}: {path} (exists: {exists})")
                
                result['sheetData'] = DataStorageService.load_dashboard_data(file_paths)
            else:
                # 兼容旧数据：从 config 字段读取
                result['sheetData'] = self._load_legacy_data()
        else:
            result['sheetData'] = {}
            
        # 返回文件路径映射（供前端按需加载）
        result['dataFilePaths'] = file_paths
        
        return result
    
    def to_list_dict(self):
        """列表展示用的简化字典（不加载数据）"""
        return self.to_dict(include_data=False)
    
    def _parse_json(self, json_str, default):
        """
        安全解析 JSON
        兼容 PostgreSQL/psycopg2 自动解析 JSON 的情况
        """
        if not json_str:
            return default
        
        # 如果已经是 dict 或 list（PostgreSQL 驱动自动解析了），直接返回
        if isinstance(json_str, (dict, list)):
            return json_str
        
        try:
            return json.loads(json_str)
        except:
            return default
    
    def _load_legacy_data(self):
        """加载旧版数据（兼容迁移）"""
        if not self.config:
            return {}
        try:
            # 兼容 PostgreSQL 自动解析 JSON 的情况
            if isinstance(self.config, dict):
                config_data = self.config
            else:
                config_data = json.loads(self.config)
            return config_data.get('sheetData', {})
        except:
            return {}
    
    @classmethod
    def get_by_id(cls, dashboard_id):
        return cls.query.get(dashboard_id)
    
    @classmethod
    def get_user_dashboards(cls, user_uuid, include_public=True):
        """获取用户看板列表"""
        if include_public:
            return cls.query.filter(
                db.or_(
                    cls.user_uuid == user_uuid,
                    cls.visibility == 'public'
                )
            ).order_by(cls.updated_at.desc()).all()
        else:
            return cls.query.filter_by(user_uuid=user_uuid).order_by(cls.updated_at.desc()).all()
    
    @classmethod
    def create(cls, user_uuid, name, config, visibility='private'):
        """
        创建看板
        
        :param config: 包含 charts, statCards, sheetData, sheetNames
        """
        from app.services.data_storage_service import DataStorageService
        
        # 先创建记录获取 ID
        dashboard = cls(
            user_uuid=user_uuid,
            name=name,
            visibility=visibility
        )
        db.session.add(dashboard)
        db.session.flush()  # 获取自增 ID
        
        # 生成文件 ID
        file_id = DataStorageService.generate_file_id(user_uuid, dashboard.id)
        dashboard.file_id = file_id
        
        # 保存数据文件
        sheet_data = config.get('sheetData', {})
        if sheet_data:
            file_paths = DataStorageService.save_dashboard_data(file_id, sheet_data)
            dashboard.data_file_paths = json.dumps(file_paths, ensure_ascii=False)
        
        # 保存配置
        dashboard.charts_config = json.dumps(config.get('charts', []), ensure_ascii=False)
        dashboard.stat_cards_config = json.dumps(config.get('statCards', []), ensure_ascii=False)
        dashboard.sheet_names = json.dumps(config.get('sheetNames', []), ensure_ascii=False)
        
        db.session.commit()
        return dashboard
    
    def update(self, name=None, config=None, visibility=None):
        """更新看板"""
        from app.services.data_storage_service import DataStorageService
        
        if name:
            self.name = name
        if visibility:
            self.visibility = visibility
        
        if config:
            # 更新图表配置
            if 'charts' in config:
                self.charts_config = json.dumps(config['charts'], ensure_ascii=False)
            if 'statCards' in config:
                self.stat_cards_config = json.dumps(config['statCards'], ensure_ascii=False)
            if 'sheetNames' in config:
                self.sheet_names = json.dumps(config['sheetNames'], ensure_ascii=False)
            
            # 更新数据文件
            sheet_data = config.get('sheetData')
            if sheet_data:
                # 删除旧文件
                old_paths = self._parse_json(self.data_file_paths, {})
                if old_paths:
                    DataStorageService.delete_dashboard_files(old_paths)
                
                # 保存新文件
                if not self.file_id:
                    self.file_id = DataStorageService.generate_file_id(self.user_uuid, self.id)
                
                file_paths = DataStorageService.save_dashboard_data(self.file_id, sheet_data)
                self.data_file_paths = json.dumps(file_paths, ensure_ascii=False)
        
        db.session.commit()
        return self
    
    def delete(self):
        """删除看板（包括数据文件）"""
        from app.services.data_storage_service import DataStorageService
        
        # 删除数据文件
        file_paths = self._parse_json(self.data_file_paths, {})
        if file_paths:
            DataStorageService.delete_dashboard_files(file_paths)
        
        db.session.delete(self)
        db.session.commit()
    
    def get_sheet_data(self, sheet_name: str) -> dict:
        """
        按需获取单个工作表数据（用于图表计算）
        """
        file_paths = self._parse_json(self.data_file_paths, {})
        
        if sheet_name in file_paths:
            from app.services.data_storage_service import DataStorageService
            return DataStorageService.load_sheet_data_as_dict(file_paths[sheet_name])
        
        # 兼容旧数据
        legacy_data = self._load_legacy_data()
        return legacy_data.get(sheet_name, {'headers': [], 'rows': []})
    
    def get_sheet_dataframe(self, sheet_name: str):
        """
        获取工作表的 DataFrame（用于高性能计算）
        """
        file_paths = self._parse_json(self.data_file_paths, {})
        
        if sheet_name in file_paths:
            from app.services.data_storage_service import DataStorageService
            return DataStorageService.load_sheet_data(file_paths[sheet_name])
        
        # 兼容旧数据
        import pandas as pd
        legacy_data = self._load_legacy_data()
        sheet_data = legacy_data.get(sheet_name, {})
        rows = sheet_data.get('rows', [])
        return pd.DataFrame(rows) if rows else pd.DataFrame()
