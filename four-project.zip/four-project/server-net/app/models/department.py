"""
科室模型 - 科室信息存储
"""
from datetime import datetime
from app import db


class Department(db.Model):
    __tablename__ = 'departments'
    
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    name = db.Column(db.String(100), nullable=False, comment='科室名称')
    description = db.Column(db.Text, nullable=True, comment='科室描述')
    icon = db.Column(db.String(50), default='OfficeBuilding', comment='图标名称')
    contact = db.Column(db.String(100), nullable=True, comment='联系方式')
    sort_order = db.Column(db.Integer, default=0, comment='排序顺序')
    is_active = db.Column(db.Boolean, default=True, comment='是否启用')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'icon': self.icon,
            'contact': self.contact,
            'sort_order': self.sort_order,
            'is_active': self.is_active,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }
    
    @classmethod
    def get_by_id(cls, dept_id):
        return cls.query.get(dept_id)
    
    @classmethod
    def get_all(cls, active_only=True):
        """获取所有科室"""
        query = cls.query
        if active_only:
            query = query.filter_by(is_active=True)
        return query.order_by(cls.sort_order.asc()).all()
    
    @classmethod
    def create(cls, name, description='', icon='OfficeBuilding', contact='', sort_order=0):
        """创建科室"""
        department = cls(
            name=name,
            description=description,
            icon=icon,
            contact=contact,
            sort_order=sort_order
        )
        db.session.add(department)
        db.session.commit()
        return department
    
    def update(self, name=None, description=None, icon=None, contact=None, sort_order=None):
        """更新科室"""
        if name is not None:
            self.name = name
        if description is not None:
            self.description = description
        if icon is not None:
            self.icon = icon
        if contact is not None:
            self.contact = contact
        if sort_order is not None:
            self.sort_order = sort_order
        db.session.commit()
        return self
    
    def delete(self):
        """删除科室（软删除）"""
        self.is_active = False
        db.session.commit()

