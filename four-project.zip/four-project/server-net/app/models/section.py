# -*- coding: utf-8 -*-
"""
网址分区模型
"""
from datetime import datetime
from app import db


class Section(db.Model):
    """网址分区模型"""
    __tablename__ = 'sections'
    
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    category_id = db.Column(db.Integer, db.ForeignKey('sidebar_categories.id'), nullable=False, comment='所属分类ID')
    name = db.Column(db.String(100), nullable=False, comment='分区名称')
    description = db.Column(db.String(255), comment='分区描述')
    sort_order = db.Column(db.Integer, default=0, comment='排序顺序')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # 关联网址
    websites = db.relationship('Website', backref='section', lazy='dynamic', cascade='all, delete-orphan')
    
    def to_dict(self):
        return {
            'id': self.id,
            'category_id': self.category_id,
            'name': self.name,
            'description': self.description,
            'sort_order': self.sort_order,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }
    
    def to_dict_with_websites(self):
        from app.models.website import Website
        data = self.to_dict()
        data['websites'] = [
            website.to_dict() 
            for website in self.websites.order_by(Website.sort_order).all()
        ]
        return data
    
    def __repr__(self):
        return f'<Section {self.name}>'
