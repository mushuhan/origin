# -*- coding: utf-8 -*-
"""
励志语录模型
"""
from datetime import datetime
from app import db


class Quote(db.Model):
    """
    励志语录表
    用于首页语录轮播展示
    """
    __tablename__ = 'quotes'
    
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    content = db.Column(db.Text, nullable=False, comment='语录内容')
    author = db.Column(db.String(100), comment='作者')
    source = db.Column(db.String(200), comment='出处')
    category = db.Column(db.String(50), default='general', comment='分类（励志、哲理、文学等）')
    is_active = db.Column(db.Boolean, default=True, comment='是否启用')
    display_count = db.Column(db.Integer, default=0, comment='展示次数')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'content': self.content,
            'author': self.author,
            'source': self.source,
            'category': self.category,
            'is_active': self.is_active,
            'display_count': self.display_count,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }
    
    def to_display_dict(self):
        """用于前端展示的精简数据"""
        return {
            'id': self.id,
            'content': self.content,
            'author': self.author,
            'source': self.source
        }
    
    def __repr__(self):
        return f'<Quote {self.content[:20]}...>'

