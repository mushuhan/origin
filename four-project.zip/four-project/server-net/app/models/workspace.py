# -*- coding: utf-8 -*-
"""
用户网址模型
用户私有工作台网址（带用户隔离）
"""
from datetime import datetime
from app import db


class UserSite(db.Model):
    """
    用户私有网址表
    支持从公共库添加或完全自定义
    """
    __tablename__ = 'user_sites'
    
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    user_uuid = db.Column(db.String(36), db.ForeignKey('users.uuid', ondelete='CASCADE'), nullable=False, comment='关联用户UUID')
    website_id = db.Column(db.Integer, db.ForeignKey('websites.id', ondelete='SET NULL'), nullable=True, comment='关联公共网址ID')
    folder_id = db.Column(db.Integer, db.ForeignKey('folders.id', ondelete='SET NULL'), nullable=True, comment='所属文件夹ID')
    custom_name = db.Column(db.String(100), comment='自定义名称')
    custom_url = db.Column(db.String(500), comment='自定义URL')
    custom_icon = db.Column(db.String(500), comment='自定义图标')
    custom_description = db.Column(db.String(255), comment='自定义描述')
    sort_order = db.Column(db.Integer, default=0, comment='排序顺序')
    click_count = db.Column(db.Integer, default=0, comment='用户点击次数')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # 关联公共网址
    website = db.relationship('Website', backref='user_sites')
    
    def to_dict(self):
        """
        转换为字典
        优先使用自定义信息，否则使用关联的公共网址信息
        """
        if self.website_id and self.website:
            return {
                'id': self.id,
                'user_uuid': self.user_uuid,
                'website_id': self.website_id,
                'folder_id': self.folder_id,
                'name': self.custom_name or self.website.name,
                'url': self.custom_url or self.website.url,
                'icon': self.custom_icon or self.website.icon,
                'description': self.custom_description or self.website.description,
                'sort_order': self.sort_order,
                'click_count': self.click_count,
                'is_custom': False,
                'created_at': self.created_at.isoformat() if self.created_at else None,
                'updated_at': self.updated_at.isoformat() if self.updated_at else None
            }
        else:
            return {
                'id': self.id,
                'user_uuid': self.user_uuid,
                'website_id': None,
                'folder_id': self.folder_id,
                'name': self.custom_name,
                'url': self.custom_url,
                'icon': self.custom_icon,
                'description': self.custom_description,
                'sort_order': self.sort_order,
                'click_count': self.click_count,
                'is_custom': True,
                'created_at': self.created_at.isoformat() if self.created_at else None,
                'updated_at': self.updated_at.isoformat() if self.updated_at else None
            }
    
    def __repr__(self):
        name = self.custom_name or (self.website.name if self.website else 'Unknown')
        return f'<UserSite {name}>'
