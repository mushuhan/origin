# -*- coding: utf-8 -*-
"""
侧边栏分类模型
"""
from datetime import datetime
from app import db


class SidebarCategory(db.Model):
    """侧边栏分类模型"""
    __tablename__ = 'sidebar_categories'
    
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    name = db.Column(db.String(50), nullable=False, comment='分类名称')
    icon = db.Column(db.String(100), comment='分类图标')
    sort_order = db.Column(db.Integer, default=0, comment='排序顺序')
    is_system = db.Column(db.Boolean, default=False, comment='是否系统分类')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # 关联分区
    sections = db.relationship('Section', backref='category', lazy='dynamic', cascade='all, delete-orphan')
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'icon': self.icon,
            'sort_order': self.sort_order,
            'is_system': self.is_system,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }
    
    def to_dict_with_sections(self):
        from app.models.section import Section
        data = self.to_dict()
        data['sections'] = [
            section.to_dict_with_websites() 
            for section in self.sections.order_by(Section.sort_order).all()
        ]
        return data
    
    def __repr__(self):
        return f'<Category {self.name}>'

