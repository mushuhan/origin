# -*- coding: utf-8 -*-
"""
用户文件模型
管理用户上传的数据文件（CSV/Excel/Parquet）
PostgreSQL pg_trgm 高性能搜索优化
"""
from datetime import datetime
from app import db


class UserFile(db.Model):
    """
    用户文件表
    存储用户上传的数据文件元信息 - 支持 pg_trgm 模糊搜索
    """
    __tablename__ = 'user_files'
    
    # PostgreSQL GIN 索引配置
    __table_args__ = (
        # GIN 索引：filename 支持模糊搜索
        db.Index(
            'idx_user_files_filename_gin',
            'filename',
            postgresql_using='gin',
            postgresql_ops={'filename': 'gin_trgm_ops'}
        ),
        # 常规索引
        db.Index('idx_user_files_user', 'user_uuid'),
        db.Index('idx_user_files_folder', 'folder_id'),
        db.Index('idx_user_files_type', 'file_type'),
        db.Index('idx_user_files_starred', 'is_starred'),
        {'comment': '用户文件表 - pg_trgm 高性能搜索'}
    )
    
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    user_uuid = db.Column(db.String(36), db.ForeignKey('users.uuid', ondelete='CASCADE'), nullable=False, comment='关联用户UUID')
    folder_id = db.Column(db.Integer, db.ForeignKey('folders.id', ondelete='SET NULL'), nullable=True, comment='所属文件夹ID')
    
    # 文件基本信息
    filename = db.Column(db.String(255), nullable=False, comment='原始文件名')
    storage_path = db.Column(db.String(500), nullable=False, comment='存储路径')
    file_type = db.Column(db.String(20), nullable=False, comment='文件类型: csv, xlsx, parquet')
    file_size = db.Column(db.BigInteger, default=0, comment='文件大小（字节）')
    
    # 数据元信息
    row_count = db.Column(db.Integer, default=0, comment='数据行数')
    column_count = db.Column(db.Integer, default=0, comment='数据列数')
    columns_info = db.Column(db.JSON, default=list, comment='列信息 [{name, dtype}]')
    
    # 排序和状态
    sort_order = db.Column(db.Integer, default=0, comment='排序顺序')
    is_starred = db.Column(db.Boolean, default=False, comment='是否收藏')
    
    # 时间戳
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # 关联
    folder = db.relationship('Folder', backref=db.backref('files', lazy='dynamic'))
    
    def to_dict(self):
        """转换为字典"""
        return {
            'id': self.id,
            'user_uuid': self.user_uuid,
            'folder_id': self.folder_id,
            'filename': self.filename,
            'storage_path': self.storage_path,
            'file_type': self.file_type,
            'file_size': self.file_size,
            'file_size_formatted': self._format_size(self.file_size),
            'row_count': self.row_count,
            'column_count': self.column_count,
            'columns_info': self.columns_info or [],
            'sort_order': self.sort_order,
            'is_starred': self.is_starred,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }
    
    @staticmethod
    def _format_size(size):
        """格式化文件大小"""
        if size < 1024:
            return f"{size} B"
        elif size < 1024 * 1024:
            return f"{size / 1024:.1f} KB"
        elif size < 1024 * 1024 * 1024:
            return f"{size / (1024 * 1024):.1f} MB"
        else:
            return f"{size / (1024 * 1024 * 1024):.2f} GB"
    
    def __repr__(self):
        return f'<UserFile {self.filename}>'
