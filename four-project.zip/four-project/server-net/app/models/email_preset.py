# -*- coding: utf-8 -*-
"""
邮件预设模型 - 存储用户的邮件筛选预设
"""
from datetime import datetime
from app import db
import json


class EmailPreset(db.Model):
    """邮件筛选预设 - 用户可保存常用筛选组合"""
    __tablename__ = 'email_presets'
    
    __table_args__ = (
        db.Index('idx_email_presets_user', 'user_uuid'),
        {'comment': '邮件筛选预设'}
    )
    
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    user_uuid = db.Column(db.String(50), nullable=False, comment='用户UUID')
    name = db.Column(db.String(100), nullable=False, comment='预设名称')
    description = db.Column(db.String(255), nullable=True, comment='预设描述')
    filters = db.Column(db.Text, nullable=False, comment='筛选条件JSON')
    is_active = db.Column(db.Boolean, default=True, comment='是否启用')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'user_uuid': self.user_uuid,
            'name': self.name,
            'description': self.description,
            'filters': json.loads(self.filters) if self.filters else {},
            'is_active': self.is_active,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }
    
    @classmethod
    def get_by_id(cls, preset_id):
        return cls.query.filter_by(id=preset_id, is_active=True).first()
    
    @classmethod
    def get_user_presets(cls, user_uuid):
        """获取用户的所有预设"""
        return cls.query.filter_by(
            user_uuid=user_uuid, 
            is_active=True
        ).order_by(cls.created_at.desc()).all()
    
    @classmethod
    def create(cls, user_uuid, name, filters, description=''):
        """创建预设"""
        preset = cls(
            user_uuid=user_uuid,
            name=name,
            description=description,
            filters=json.dumps(filters, ensure_ascii=False)
        )
        db.session.add(preset)
        db.session.commit()
        return preset
    
    def update(self, name=None, filters=None, description=None):
        """更新预设"""
        if name is not None:
            self.name = name
        if filters is not None:
            self.filters = json.dumps(filters, ensure_ascii=False)
        if description is not None:
            self.description = description
        db.session.commit()
        return self
    
    def delete(self):
        """删除预设（软删除）"""
        self.is_active = False
        db.session.commit()

