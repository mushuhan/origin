# -*- coding: utf-8 -*-
"""
网址模型
公共网址库 - PostgreSQL pg_trgm 高性能搜索优化
"""
from datetime import datetime
from app import db


class Website(db.Model):
    """公共网址模型 - 支持 pg_trgm 模糊搜索"""
    __tablename__ = 'websites'
    
    # PostgreSQL GIN 索引配置 - 让搜索快如 Redis
    __table_args__ = (
        # 复合 GIN 索引：name + description + pinyin，使用 gin_trgm_ops
        db.Index(
            'idx_websites_search_gin',
            'name', 'description', 'pinyin', 'pinyin_initials',
            postgresql_using='gin',
            postgresql_ops={
                'name': 'gin_trgm_ops',
                'description': 'gin_trgm_ops',
                'pinyin': 'gin_trgm_ops',
                'pinyin_initials': 'gin_trgm_ops'
            }
        ),
        # 单字段 GIN 索引（用于特定字段搜索）
        db.Index('idx_websites_name_gin', 'name', postgresql_using='gin', postgresql_ops={'name': 'gin_trgm_ops'}),
        db.Index('idx_websites_url_gin', 'url', postgresql_using='gin', postgresql_ops={'url': 'gin_trgm_ops'}),
        # 常规 B-tree 索引
        db.Index('idx_websites_section', 'section_id'),
        db.Index('idx_websites_click', 'click_count', postgresql_using='btree'),
        db.Index('idx_websites_hot', 'is_hot'),
        {'comment': '公共网址表 - pg_trgm 高性能搜索'}
    )
    
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    section_id = db.Column(db.Integer, db.ForeignKey('sections.id'), nullable=False, comment='所属分区ID')
    name = db.Column(db.String(100), nullable=False, comment='网站名称')
    url = db.Column(db.String(500), nullable=False, comment='网站URL')
    icon = db.Column(db.String(500), comment='网站图标URL')
    description = db.Column(db.String(255), comment='网站描述')
    pinyin = db.Column(db.String(200), comment='网站名称拼音（用于搜索）')
    pinyin_initials = db.Column(db.String(50), comment='拼音首字母（用于搜索）')
    sort_order = db.Column(db.Integer, default=0, comment='排序顺序')
    click_count = db.Column(db.Integer, default=0, comment='点击次数')
    is_hot = db.Column(db.Boolean, default=False, comment='是否热门')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'section_id': self.section_id,
            'name': self.name,
            'url': self.url,
            'icon': self.icon,
            'description': self.description,
            'pinyin': self.pinyin,
            'pinyin_initials': self.pinyin_initials,
            'sort_order': self.sort_order,
            'click_count': self.click_count,
            'is_hot': self.is_hot,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }
    
    def __repr__(self):
        return f'<Website {self.name}>'
