# -*- coding: utf-8 -*-
"""
发票抬头模型 - 存储标准发票抬头库
全员共享，用于发票校验
"""
from datetime import datetime
from app import db


class InvoiceHeader(db.Model):
    """发票抬头库 - 用于发票信息校验"""
    __tablename__ = 'invoice_headers'
    
    __table_args__ = (
        # 税号唯一索引
        db.Index('idx_invoice_headers_tax_no', 'tax_number', unique=True),
        # 抬头名称索引（用于模糊搜索）
        db.Index('idx_invoice_headers_title', 'title'),
        {'comment': '发票抬头库 - 全员共享'}
    )
    
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    title = db.Column(db.String(255), nullable=False, comment='发票抬头（公司名称）')
    tax_number = db.Column(db.String(50), nullable=False, unique=True, comment='纳税人识别号')
    address = db.Column(db.String(500), nullable=True, comment='公司地址')
    phone = db.Column(db.String(50), nullable=True, comment='联系电话')
    bank_name = db.Column(db.String(200), nullable=True, comment='开户银行')
    bank_account = db.Column(db.String(100), nullable=True, comment='银行账号')
    created_by = db.Column(db.String(50), nullable=True, comment='创建者UUID')
    is_active = db.Column(db.Boolean, default=True, comment='是否启用')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'title': self.title,
            'tax_number': self.tax_number,
            'address': self.address,
            'phone': self.phone,
            'bank_name': self.bank_name,
            'bank_account': self.bank_account,
            'created_by': self.created_by,
            'is_active': self.is_active,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }
    
    @classmethod
    def get_by_id(cls, header_id):
        return cls.query.filter_by(id=header_id, is_active=True).first()
    
    @classmethod
    def get_by_tax_number(cls, tax_number):
        """根据税号查找"""
        return cls.query.filter_by(tax_number=tax_number, is_active=True).first()
    
    @classmethod
    def get_by_title(cls, title):
        """根据抬头名称查找（精确匹配）"""
        return cls.query.filter_by(title=title, is_active=True).first()
    
    @classmethod
    def search(cls, keyword, limit=20):
        """搜索抬头库"""
        query = cls.query.filter_by(is_active=True)
        if keyword:
            query = query.filter(
                db.or_(
                    cls.title.ilike(f'%{keyword}%'),
                    cls.tax_number.ilike(f'%{keyword}%')
                )
            )
        return query.order_by(cls.created_at.desc()).limit(limit).all()
    
    @classmethod
    def get_all_as_set(cls):
        """
        获取所有抬头和税号作为 Set，用于 O(1) 快速匹配
        返回: (title_set, tax_number_set, title_to_tax_map)
        """
        headers = cls.query.filter_by(is_active=True).all()
        title_set = set()
        tax_number_set = set()
        title_to_tax_map = {}
        
        for h in headers:
            title_set.add(h.title)
            tax_number_set.add(h.tax_number)
            title_to_tax_map[h.title] = h.tax_number
        
        return title_set, tax_number_set, title_to_tax_map
    
    @classmethod
    def create(cls, title, tax_number, address='', phone='', bank_name='', bank_account='', created_by=None):
        """创建新抬头"""
        # 检查税号是否已存在
        existing = cls.get_by_tax_number(tax_number)
        if existing:
            return None, '该税号已存在'
        
        header = cls(
            title=title,
            tax_number=tax_number,
            address=address,
            phone=phone,
            bank_name=bank_name,
            bank_account=bank_account,
            created_by=created_by
        )
        db.session.add(header)
        db.session.commit()
        return header, None
    
    def update(self, **kwargs):
        """更新抬头信息"""
        for key, value in kwargs.items():
            if hasattr(self, key) and value is not None:
                setattr(self, key, value)
        db.session.commit()
        return self
    
    def delete(self):
        """删除抬头（软删除）"""
        self.is_active = False
        db.session.commit()

