"""
员工模型 - 员工信息存储
PostgreSQL pg_trgm 高性能搜索优化
支持拼音搜索
"""
from datetime import datetime
from app import db


class Employee(db.Model):
    """员工模型 - 支持 pg_trgm 模糊搜索 + 拼音搜索"""
    __tablename__ = 'employees'
    
    # PostgreSQL GIN 索引配置
    __table_args__ = (
        # 复合 GIN 索引：name + position + signature + pinyin
        db.Index(
            'idx_employees_search_gin',
            'name', 'position', 'signature', 'pinyin', 'pinyin_initials',
            postgresql_using='gin',
            postgresql_ops={
                'name': 'gin_trgm_ops',
                'position': 'gin_trgm_ops',
                'signature': 'gin_trgm_ops',
                'pinyin': 'gin_trgm_ops',
                'pinyin_initials': 'gin_trgm_ops'
            }
        ),
        # 单字段 GIN 索引
        db.Index('idx_employees_name_gin', 'name', postgresql_using='gin', postgresql_ops={'name': 'gin_trgm_ops'}),
        db.Index('idx_employees_email_gin', 'email', postgresql_using='gin', postgresql_ops={'email': 'gin_trgm_ops'}),
        # 拼音 GIN 索引（高性能拼音搜索）
        db.Index('idx_employees_pinyin_gin', 'pinyin', postgresql_using='gin', postgresql_ops={'pinyin': 'gin_trgm_ops'}),
        db.Index('idx_employees_pinyin_initials_gin', 'pinyin_initials', postgresql_using='gin', postgresql_ops={'pinyin_initials': 'gin_trgm_ops'}),
        # 常规索引
        db.Index('idx_employees_dept', 'department_id'),
        db.Index('idx_employees_parent', 'parent_id'),
        db.Index('idx_employees_active', 'is_active'),
        db.Index('idx_employees_level', 'level'),
        {'comment': '员工信息表 - pg_trgm 高性能搜索 + 拼音支持'}
    )
    
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    department_id = db.Column(db.Integer, db.ForeignKey('departments.id'), nullable=False, comment='所属科室ID')
    name = db.Column(db.String(50), nullable=False, comment='员工姓名')
    pinyin = db.Column(db.String(200), comment='姓名拼音全拼（如：zhangsan）')
    pinyin_initials = db.Column(db.String(50), comment='姓名拼音首字母（如：zs）')
    position = db.Column(db.String(100), nullable=True, comment='职位')
    avatar = db.Column(db.String(500), nullable=True, comment='头像URL')
    signature = db.Column(db.String(255), nullable=True, comment='个性签名')
    phone = db.Column(db.String(20), nullable=True, comment='联系电话')
    email = db.Column(db.String(100), nullable=True, comment='邮箱')
    parent_id = db.Column(db.Integer, db.ForeignKey('employees.id'), nullable=True, comment='上级ID(用于架构图)')
    level = db.Column(db.Integer, default=0, comment='层级(0为最高层)')
    sort_order = db.Column(db.Integer, default=0, comment='同级排序')
    is_active = db.Column(db.Boolean, default=True, comment='是否启用')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # 关系
    department = db.relationship('Department', backref=db.backref('employees', lazy='dynamic'))
    children = db.relationship('Employee', backref=db.backref('parent', remote_side=[id]), lazy='dynamic')
    
    def to_dict(self, include_children=False):
        data = {
            'id': self.id,
            'department_id': self.department_id,
            'name': self.name,
            'pinyin': self.pinyin,
            'pinyin_initials': self.pinyin_initials,
            'position': self.position,
            'avatar': self.avatar,
            'signature': self.signature,
            'phone': self.phone,
            'email': self.email,
            'parent_id': self.parent_id,
            'level': self.level,
            'sort_order': self.sort_order,
            'is_active': self.is_active,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }
        
        if include_children:
            data['children'] = [child.to_dict(include_children=True) for child in self.children.filter_by(is_active=True).order_by(Employee.sort_order.asc())]
        
        return data
    
    @classmethod
    def get_by_id(cls, emp_id):
        return cls.query.get(emp_id)
    
    @classmethod
    def get_by_department(cls, department_id, active_only=True):
        """获取科室所有员工"""
        query = cls.query.filter_by(department_id=department_id)
        if active_only:
            query = query.filter_by(is_active=True)
        return query.order_by(cls.level.asc(), cls.sort_order.asc()).all()
    
    @classmethod
    def get_org_tree(cls, department_id):
        """获取科室组织架构树"""
        # 获取该科室的根节点员工(level=0或parent_id为空)
        roots = cls.query.filter_by(
            department_id=department_id,
            parent_id=None,
            is_active=True
        ).order_by(cls.sort_order.asc()).all()
        
        return [emp.to_dict(include_children=True) for emp in roots]
    
    @classmethod
    def create(cls, department_id, name, position='', avatar='', signature='', phone='', email='', parent_id=None, level=0, sort_order=0):
        """创建员工（自动生成拼音）"""
        from app.utils.pinyin import generate_pinyin_fields
        
        # 自动生成拼音
        pinyin_full, pinyin_initials = generate_pinyin_fields(name)
        
        employee = cls(
            department_id=department_id,
            name=name,
            pinyin=pinyin_full,
            pinyin_initials=pinyin_initials,
            position=position,
            avatar=avatar,
            signature=signature,
            phone=phone,
            email=email,
            parent_id=parent_id,
            level=level,
            sort_order=sort_order
        )
        db.session.add(employee)
        db.session.commit()
        return employee
    
    def update(self, **kwargs):
        """更新员工（姓名变更时自动更新拼音）"""
        from app.utils.pinyin import generate_pinyin_fields
        
        # 如果更新了姓名，自动更新拼音
        if 'name' in kwargs and kwargs['name']:
            pinyin_full, pinyin_initials = generate_pinyin_fields(kwargs['name'])
            kwargs['pinyin'] = pinyin_full
            kwargs['pinyin_initials'] = pinyin_initials
        
        for key, value in kwargs.items():
            if hasattr(self, key) and value is not None:
                setattr(self, key, value)
        db.session.commit()
        return self
    
    def delete(self):
        """删除员工（软删除）"""
        self.is_active = False
        db.session.commit()
