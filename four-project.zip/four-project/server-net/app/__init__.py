# -*- coding: utf-8 -*-
"""
企业级网址导航系统 - Flask应用工厂
支持负载均衡、跳板机代理链信任配置
"""
import secrets
from flask import Flask
from flask_cors import CORS
from flask_sqlalchemy import SQLAlchemy

# 初始化扩展（延迟绑定）
db = SQLAlchemy()

def create_app(config_name='default'):
    """应用工厂函数"""
    from app.config import config
    
    app = Flask(__name__)
    app.config.from_object(config[config_name])

    # 关键安全配置兜底：避免使用弱默认值
    if not app.config.get('SECRET_KEY') or app.config['SECRET_KEY'] == 'nav-system-secret-key-2024-enterprise':
        app.logger.warning('检测到未配置安全的 SECRET_KEY，已生成临时密钥，请尽快在环境变量中显式设置。')
        app.config['SECRET_KEY'] = secrets.token_hex(32)
    if not app.config.get('JWT_SECRET_KEY') or app.config['JWT_SECRET_KEY'] == 'nav-system-secret-key-2024-enterprise':
        app.logger.warning('检测到未配置安全的 JWT_SECRET_KEY，已回退为 SECRET_KEY，请尽快在环境变量中设置。')
        app.config['JWT_SECRET_KEY'] = app.config['SECRET_KEY']
    if app.config.get('PG_PASSWORD') == '123456':
        app.logger.warning('正在使用默认的 PG_PASSWORD，建议通过环境变量覆盖。')
    
    # 初始化扩展
    db.init_app(app)
    
    # 配置CORS - 支持凭证和自定义头部
    CORS(
        app,
        origins=app.config.get('CORS_ORIGINS', ['*']),
        supports_credentials=True,
        allow_headers=['Content-Type', 'X-User-Token', 'X-Requested-With'],
        expose_headers=['X-User-Token']
    )
    
    # 配置代理链信任 - 生产环境关键配置
    configure_proxy_fix(app)
    
    # 注册蓝图
    register_blueprints(app)
    
    # 注册错误处理
    register_error_handlers(app)
    
    # 注册请求钩子
    register_request_hooks(app)
    
    # 设置拼音自动生成监听器（用于中文搜索支持）
    setup_pinyin_listeners(app)
    
    return app


def setup_pinyin_listeners(app):
    """设置拼音自动生成监听器"""
    from sqlalchemy import event
    from app.utils.pinyin import generate_pinyin_fields
    
    with app.app_context():
        from app.models.website import Website
        from app.models.employee import Employee
        
        def auto_generate_pinyin_website(mapper, connection, target):
            """Website 保存前自动生成拼音"""
            if target.name and (not target.pinyin or not target.pinyin_initials):
                full_pinyin, initials = generate_pinyin_fields(target.name)
                target.pinyin = full_pinyin
                target.pinyin_initials = initials
        
        def auto_generate_pinyin_employee(mapper, connection, target):
            """Employee 保存前自动生成拼音"""
            if target.name and (not target.pinyin or not target.pinyin_initials):
                full_pinyin, initials = generate_pinyin_fields(target.name)
                target.pinyin = full_pinyin
                target.pinyin_initials = initials
        
        # 注册事件监听器（避免重复注册）
        if not event.contains(Website, 'before_insert', auto_generate_pinyin_website):
            event.listen(Website, 'before_insert', auto_generate_pinyin_website)
        if not event.contains(Website, 'before_update', auto_generate_pinyin_website):
            event.listen(Website, 'before_update', auto_generate_pinyin_website)
        if not event.contains(Employee, 'before_insert', auto_generate_pinyin_employee):
            event.listen(Employee, 'before_insert', auto_generate_pinyin_employee)
        if not event.contains(Employee, 'before_update', auto_generate_pinyin_employee):
            event.listen(Employee, 'before_update', auto_generate_pinyin_employee)
        
        app.logger.info('拼音自动生成监听器已设置')


def configure_proxy_fix(app):
    """
    配置代理链信任
    当请求经过负载均衡（LB）和跳板机（Jump Host）时：
    - 信任 X-Forwarded-For 头部获取真实客户端IP
    - 信任 X-Forwarded-Proto 头部判断HTTPS
    - 信任 X-Forwarded-Host 头部获取原始Host
    """
    from werkzeug.middleware.proxy_fix import ProxyFix
    
    # 参数说明：
    # x_for: 信任几层代理的 X-Forwarded-For（客户端IP）
    # x_proto: 信任几层代理的 X-Forwarded-Proto（HTTPS卸载）
    # x_host: 信任几层代理的 X-Forwarded-Host
    # x_port: 信任几层代理的 X-Forwarded-Port
    # x_prefix: 信任几层代理的 X-Forwarded-Prefix
    
    proxy_count = app.config.get('PROXY_COUNT', 1)
    
    app.wsgi_app = ProxyFix(
        app.wsgi_app,
        x_for=proxy_count,
        x_proto=proxy_count,
        x_host=proxy_count,
        x_port=proxy_count,
        x_prefix=proxy_count
    )
    
    app.logger.info(f'ProxyFix configured with proxy_count={proxy_count}')


def register_blueprints(app):
    """注册所有蓝图（路由模块）"""
    from app.controllers.categories import categories_bp
    from app.controllers.sections import sections_bp
    from app.controllers.websites import websites_bp
    from app.controllers.workspace import workspace_bp
    from app.controllers.folders import folders_bp
    from app.controllers.search import search_bp
    from app.controllers.quotes import quotes_bp
    from app.controllers.users import users_bp
    from app.controllers.home import home_bp
    from app.controllers.settings import settings_bp
    from app.controllers.analytics import analytics_bp
    from app.controllers.dashboards import bp as dashboards_bp
    from app.controllers.departments import bp as departments_bp
    from app.controllers.employees import bp as employees_bp
    from app.controllers.files import files_bp
    # 认证和管理员模块
    from app.controllers.auth import auth_bp
    from app.controllers.admin import admin_bp
    
    # API路由前缀
    api_prefix = '/api'
    
    app.register_blueprint(categories_bp, url_prefix=f'{api_prefix}/categories')
    app.register_blueprint(sections_bp, url_prefix=f'{api_prefix}/sections')
    app.register_blueprint(websites_bp, url_prefix=f'{api_prefix}/websites')
    app.register_blueprint(workspace_bp, url_prefix=f'{api_prefix}/workspace')
    app.register_blueprint(folders_bp, url_prefix=f'{api_prefix}/folders')
    app.register_blueprint(search_bp, url_prefix=f'{api_prefix}/search')
    app.register_blueprint(quotes_bp, url_prefix=f'{api_prefix}/quotes')
    app.register_blueprint(users_bp, url_prefix=f'{api_prefix}/users')
    app.register_blueprint(home_bp, url_prefix=f'{api_prefix}/home')
    app.register_blueprint(settings_bp, url_prefix=f'{api_prefix}/settings')
    app.register_blueprint(analytics_bp, url_prefix=f'{api_prefix}/analytics')
    app.register_blueprint(dashboards_bp)
    app.register_blueprint(departments_bp)
    app.register_blueprint(employees_bp)
    app.register_blueprint(files_bp, url_prefix=f'{api_prefix}/files')
    # 认证和管理员路由
    app.register_blueprint(auth_bp, url_prefix=f'{api_prefix}/auth')
    app.register_blueprint(admin_bp, url_prefix=f'{api_prefix}/admin')


def register_error_handlers(app):
    """注册全局错误处理器"""
    from app.utils.response import error_response
    
    @app.errorhandler(400)
    def bad_request(error):
        return error_response('请求参数错误', 400)
    
    @app.errorhandler(401)
    def unauthorized(error):
        return error_response('未授权访问', 401)
    
    @app.errorhandler(403)
    def forbidden(error):
        return error_response('禁止访问', 403)
    
    @app.errorhandler(404)
    def not_found(error):
        return error_response('资源未找到', 404)
    
    @app.errorhandler(500)
    def internal_error(error):
        db.session.rollback()
        app.logger.error(f'Internal Server Error: {error}')
        return error_response('服务器内部错误', 500)


def register_request_hooks(app):
    """注册请求钩子"""
    from flask import g, request
    from app.services.user_service import UserService
    
    @app.before_request
    def before_request():
        """请求前处理 - 用户身份识别"""
        # 获取用户Token
        user_token = request.headers.get('X-User-Token')
        
        if user_token:
            # 获取或创建用户
            user = UserService.get_or_create_user(user_token)
            g.user = user
            g.user_uuid = user_token
        else:
            g.user = None
            g.user_uuid = None
        
        # 记录真实客户端IP（经过ProxyFix处理）
        g.client_ip = request.remote_addr
        
        # 记录协议类型（用于判断HTTPS卸载）
        g.is_secure = request.is_secure or request.headers.get('X-Forwarded-Proto') == 'https'
    
    @app.after_request
    def after_request(response):
        """请求后处理 - 添加安全头部"""
        # 安全相关头部
        response.headers['X-Content-Type-Options'] = 'nosniff'
        response.headers['X-Frame-Options'] = 'SAMEORIGIN'
        response.headers['X-XSS-Protection'] = '1; mode=block'
        
        # 如果是HTTPS，添加HSTS头部
        if g.get('is_secure'):
            response.headers['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains'
        
        return response

