# 企业级网址导航系统 - 后端服务

基于 Flask 的 RESTful API 后端服务，支持负载均衡、跳板机代理链信任配置。

## 功能特性

- **RESTful API**: 完整的 CRUD 接口，遵循 REST 规范
- **用户隔离**: 基于 UUID 的无状态访客标识，数据完全隔离
- **模糊搜索**: 支持拼音首字母检索，实时联想建议
- **文件夹系统**: 多级嵌套的工作台分组管理
- **数据分析**: 热门排行榜、点击统计
- **代理支持**: 支持负载均衡和跳板机的 IP 透传

## 技术栈

- Python 3.10+
- Flask 3.0
- Flask-SQLAlchemy
- Flask-CORS
- PyMySQL
- Werkzeug (ProxyFix)

## 快速开始

### 1. 安装依赖

```bash
cd server-net
pip install -r requirements.txt
```

### 2. 配置环境变量

```bash
cp .env.example .env
# 编辑 .env 文件，配置数据库等信息
```

### 3. 初始化数据库

```bash
# 方式1：使用 SQL 脚本
mysql -u root -p < database.sql

# 方式2：使用 ORM 创建表
INIT_DB=true python run.py
```

### 4. 启动服务

```bash
# 开发环境
python run.py

# 生产环境
FLASK_ENV=production gunicorn -w 4 -b 0.0.0.0:5000 "run:app"
```

## API 接口

### 首页数据
- `GET /api/home` - 获取首页聚合数据

### 分类管理
- `GET /api/categories` - 获取分类列表
- `GET /api/categories/:id` - 获取分类详情
- `POST /api/categories` - 创建分类
- `PUT /api/categories/:id` - 更新分类
- `DELETE /api/categories/:id` - 删除分类

### 网址管理
- `GET /api/websites` - 获取网址列表
- `GET /api/websites/hot` - 获取热门网址
- `POST /api/websites/:id/click` - 记录点击

### 工作台
- `GET /api/workspace` - 获取工作台项目
- `GET /api/workspace/all` - 获取全部（含文件夹）
- `POST /api/workspace` - 添加到工作台
- `DELETE /api/workspace/:id` - 移除项目

### 文件夹
- `GET /api/folders` - 获取文件夹列表
- `POST /api/folders` - 创建文件夹
- `PUT /api/folders/:id` - 更新文件夹
- `DELETE /api/folders/:id` - 删除文件夹

### 搜索
- `GET /api/search?keyword=xxx` - 模糊搜索
- `GET /api/search/suggestions?keyword=xxx` - 搜索建议

### 语录
- `GET /api/quotes/random` - 随机语录
- `GET /api/quotes/daily` - 每日语录

### 数据分析
- `GET /api/analytics/hot-ranking` - 热门排行
- `GET /api/analytics/overview` - 数据概览

## 生产环境部署

### 代理链配置

当请求经过负载均衡和跳板机时，需要配置 `PROXY_COUNT`:

```env
# 典型架构：CDN -> LB -> Jump Host -> App
PROXY_COUNT=3
```

### Nginx 配置示例

```nginx
location /api {
    proxy_pass http://127.0.0.1:5000;
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
}
```

## 目录结构

```
server-net/
├── app/
│   ├── __init__.py          # 应用工厂
│   ├── config.py             # 配置管理
│   ├── controllers/          # 路由控制器
│   ├── models/               # 数据模型
│   ├── services/             # 业务逻辑
│   └── utils/                # 工具函数
├── database.sql              # 数据库初始化脚本
├── requirements.txt          # Python 依赖
├── run.py                    # 启动入口
└── .env.example              # 环境配置示例
```

## License

MIT
