-- ============================================================
-- 企业级网址导航系统数据库初始化脚本
-- PostgreSQL 15+ / pg_trgm 高性能模糊搜索
-- 支持用户隔离、文件夹系统、语录模块
-- ============================================================

-- 创建数据库（需要超级用户权限执行，通常由 DBA 单独创建）
-- CREATE DATABASE nav_system WITH ENCODING 'UTF8' LC_COLLATE 'zh_CN.UTF-8' LC_CTYPE 'zh_CN.UTF-8';

-- 连接到数据库后执行以下内容
-- \c nav_system

-- ============================================================
-- 启用 pg_trgm 扩展（核心：模糊搜索加速）
-- ============================================================
CREATE EXTENSION IF NOT EXISTS pg_trgm;

-- 设置默认相似度阈值（可选，影响 % 操作符行为）
-- 较低阈值 = 更宽松的匹配，较高阈值 = 更精确的匹配
-- SET pg_trgm.similarity_threshold = 0.3;

-- ============================================================
-- 用户表 (用户隔离核心)
-- ============================================================
DROP TABLE IF EXISTS dashboards CASCADE;
DROP TABLE IF EXISTS user_files CASCADE;
DROP TABLE IF EXISTS user_sites CASCADE;
DROP TABLE IF EXISTS folders CASCADE;
DROP TABLE IF EXISTS employees CASCADE;
DROP TABLE IF EXISTS departments CASCADE;
DROP TABLE IF EXISTS websites CASCADE;
DROP TABLE IF EXISTS sections CASCADE;
DROP TABLE IF EXISTS sidebar_categories CASCADE;
DROP TABLE IF EXISTS search_history CASCADE;
DROP TABLE IF EXISTS quotes CASCADE;
DROP TABLE IF EXISTS system_settings CASCADE;
DROP TABLE IF EXISTS users CASCADE;

CREATE TABLE users (
    uuid VARCHAR(36) PRIMARY KEY,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_active_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    settings JSONB DEFAULT NULL
);

COMMENT ON TABLE users IS '用户表';
COMMENT ON COLUMN users.uuid IS '用户UUID（前端生成）';
COMMENT ON COLUMN users.created_at IS '首次访问时间';
COMMENT ON COLUMN users.last_active_at IS '最后活跃时间';
COMMENT ON COLUMN users.settings IS '用户个人设置（JSONB）';

-- ============================================================
-- 侧边栏分类表
-- ============================================================
CREATE TABLE sidebar_categories (
    id SERIAL PRIMARY KEY,
    name VARCHAR(50) NOT NULL,
    icon VARCHAR(100) DEFAULT NULL,
    sort_order INT DEFAULT 0,
    is_system BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

COMMENT ON TABLE sidebar_categories IS '侧边栏分类表';
COMMENT ON COLUMN sidebar_categories.name IS '分类名称';
COMMENT ON COLUMN sidebar_categories.icon IS '分类图标';
COMMENT ON COLUMN sidebar_categories.sort_order IS '排序顺序';
COMMENT ON COLUMN sidebar_categories.is_system IS '是否系统分类';

-- ============================================================
-- 网址分区表
-- ============================================================
CREATE TABLE sections (
    id SERIAL PRIMARY KEY,
    category_id INT NOT NULL REFERENCES sidebar_categories(id) ON DELETE CASCADE,
    name VARCHAR(100) NOT NULL,
    description VARCHAR(255) DEFAULT NULL,
    sort_order INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

COMMENT ON TABLE sections IS '网址分区表';
COMMENT ON COLUMN sections.category_id IS '所属分类ID';
COMMENT ON COLUMN sections.name IS '分区名称';
COMMENT ON COLUMN sections.description IS '分区描述';
COMMENT ON COLUMN sections.sort_order IS '排序顺序';

-- ============================================================
-- 公共网址表 - pg_trgm 高性能搜索优化
-- ============================================================
CREATE TABLE websites (
    id SERIAL PRIMARY KEY,
    section_id INT NOT NULL REFERENCES sections(id) ON DELETE CASCADE,
    name VARCHAR(100) NOT NULL,
    url VARCHAR(500) NOT NULL,
    icon VARCHAR(500) DEFAULT NULL,
    description VARCHAR(255) DEFAULT NULL,
    pinyin VARCHAR(200) DEFAULT NULL,
    pinyin_initials VARCHAR(50) DEFAULT NULL,
    sort_order INT DEFAULT 0,
    click_count INT DEFAULT 0,
    is_hot BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

COMMENT ON TABLE websites IS '公共网址表 - pg_trgm 高性能搜索';
COMMENT ON COLUMN websites.section_id IS '所属分区ID';
COMMENT ON COLUMN websites.name IS '网站名称';
COMMENT ON COLUMN websites.url IS '网站URL';
COMMENT ON COLUMN websites.icon IS '网站图标URL';
COMMENT ON COLUMN websites.description IS '网站描述';
COMMENT ON COLUMN websites.pinyin IS '拼音（用于搜索）';
COMMENT ON COLUMN websites.pinyin_initials IS '拼音首字母（用于搜索）';
COMMENT ON COLUMN websites.sort_order IS '排序顺序';
COMMENT ON COLUMN websites.click_count IS '点击次数';
COMMENT ON COLUMN websites.is_hot IS '是否热门';

-- ============================================================
-- 用户文件夹表 (工作台分组)
-- ============================================================
CREATE TABLE folders (
    id SERIAL PRIMARY KEY,
    user_uuid VARCHAR(36) NOT NULL REFERENCES users(uuid) ON DELETE CASCADE,
    name VARCHAR(100) NOT NULL,
    parent_id INT DEFAULT NULL REFERENCES folders(id) ON DELETE CASCADE,
    category VARCHAR(20) DEFAULT 'sites' NOT NULL,
    icon VARCHAR(50) DEFAULT 'Folder',
    color VARCHAR(20) DEFAULT '#6b7280',
    sort_order INT DEFAULT 0,
    is_collapsed BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

COMMENT ON TABLE folders IS '用户文件夹表';
COMMENT ON COLUMN folders.user_uuid IS '关联用户UUID';
COMMENT ON COLUMN folders.name IS '文件夹名称';
COMMENT ON COLUMN folders.parent_id IS '父文件夹ID（支持嵌套）';
COMMENT ON COLUMN folders.category IS '文件夹分类: sites(网址), files(数据文件)';
COMMENT ON COLUMN folders.icon IS '文件夹图标';
COMMENT ON COLUMN folders.color IS '文件夹颜色';
COMMENT ON COLUMN folders.sort_order IS '排序顺序';
COMMENT ON COLUMN folders.is_collapsed IS '是否折叠';

-- ============================================================
-- 用户私有网址表
-- ============================================================
CREATE TABLE user_sites (
    id SERIAL PRIMARY KEY,
    user_uuid VARCHAR(36) NOT NULL REFERENCES users(uuid) ON DELETE CASCADE,
    website_id INT DEFAULT NULL REFERENCES websites(id) ON DELETE SET NULL,
    folder_id INT DEFAULT NULL REFERENCES folders(id) ON DELETE SET NULL,
    custom_name VARCHAR(100) DEFAULT NULL,
    custom_url VARCHAR(500) DEFAULT NULL,
    custom_icon VARCHAR(500) DEFAULT NULL,
    custom_description VARCHAR(255) DEFAULT NULL,
    sort_order INT DEFAULT 0,
    click_count INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

COMMENT ON TABLE user_sites IS '用户私有网址表';
COMMENT ON COLUMN user_sites.user_uuid IS '关联用户UUID';
COMMENT ON COLUMN user_sites.website_id IS '关联公共网址ID';
COMMENT ON COLUMN user_sites.folder_id IS '所属文件夹ID';
COMMENT ON COLUMN user_sites.custom_name IS '自定义名称';
COMMENT ON COLUMN user_sites.custom_url IS '自定义URL';
COMMENT ON COLUMN user_sites.custom_icon IS '自定义图标';
COMMENT ON COLUMN user_sites.custom_description IS '自定义描述';
COMMENT ON COLUMN user_sites.sort_order IS '排序顺序';
COMMENT ON COLUMN user_sites.click_count IS '用户点击次数';

-- ============================================================
-- 搜索历史表 - pg_trgm 支持
-- ============================================================
CREATE TABLE search_history (
    id SERIAL PRIMARY KEY,
    keyword VARCHAR(200) NOT NULL,
    search_count INT DEFAULT 1,
    last_searched_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

COMMENT ON TABLE search_history IS '搜索历史表 - pg_trgm 高性能搜索';
COMMENT ON COLUMN search_history.keyword IS '搜索关键词';
COMMENT ON COLUMN search_history.search_count IS '搜索次数';

-- ============================================================
-- 励志语录表
-- ============================================================
CREATE TABLE quotes (
    id SERIAL PRIMARY KEY,
    content TEXT NOT NULL,
    author VARCHAR(100) DEFAULT NULL,
    source VARCHAR(200) DEFAULT NULL,
    category VARCHAR(50) DEFAULT 'general',
    is_active BOOLEAN DEFAULT TRUE,
    display_count INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

COMMENT ON TABLE quotes IS '励志语录表';
COMMENT ON COLUMN quotes.content IS '语录内容';
COMMENT ON COLUMN quotes.author IS '作者';
COMMENT ON COLUMN quotes.source IS '出处';
COMMENT ON COLUMN quotes.category IS '分类';
COMMENT ON COLUMN quotes.is_active IS '是否启用';
COMMENT ON COLUMN quotes.display_count IS '展示次数';

-- ============================================================
-- 系统设置表
-- ============================================================
CREATE TABLE system_settings (
    id SERIAL PRIMARY KEY,
    setting_key VARCHAR(50) NOT NULL UNIQUE,
    setting_value TEXT,
    description VARCHAR(255) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

COMMENT ON TABLE system_settings IS '系统设置表';
COMMENT ON COLUMN system_settings.setting_key IS '设置键';
COMMENT ON COLUMN system_settings.setting_value IS '设置值';
COMMENT ON COLUMN system_settings.description IS '设置描述';

-- ============================================================
-- 用户文件表 - pg_trgm 支持
-- ============================================================
CREATE TABLE user_files (
    id SERIAL PRIMARY KEY,
    user_uuid VARCHAR(36) NOT NULL REFERENCES users(uuid) ON DELETE CASCADE,
    folder_id INT DEFAULT NULL REFERENCES folders(id) ON DELETE SET NULL,
    filename VARCHAR(255) NOT NULL,
    storage_path VARCHAR(500) NOT NULL,
    file_type VARCHAR(20) NOT NULL,
    file_size BIGINT DEFAULT 0,
    row_count INT DEFAULT 0,
    column_count INT DEFAULT 0,
    columns_info JSONB DEFAULT '[]'::jsonb,
    sort_order INT DEFAULT 0,
    is_starred BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

COMMENT ON TABLE user_files IS '用户文件表 - pg_trgm 高性能搜索';
COMMENT ON COLUMN user_files.user_uuid IS '关联用户UUID';
COMMENT ON COLUMN user_files.folder_id IS '所属文件夹ID';
COMMENT ON COLUMN user_files.filename IS '原始文件名';
COMMENT ON COLUMN user_files.storage_path IS '存储路径';
COMMENT ON COLUMN user_files.file_type IS '文件类型: csv, xlsx, parquet';
COMMENT ON COLUMN user_files.file_size IS '文件大小（字节）';
COMMENT ON COLUMN user_files.row_count IS '数据行数';
COMMENT ON COLUMN user_files.column_count IS '数据列数';
COMMENT ON COLUMN user_files.columns_info IS '列信息 [{name, dtype}]';
COMMENT ON COLUMN user_files.sort_order IS '排序顺序';
COMMENT ON COLUMN user_files.is_starred IS '是否收藏';

-- ============================================================
-- 数据看板表
-- ============================================================
CREATE TABLE dashboards (
    id SERIAL PRIMARY KEY,
    user_uuid VARCHAR(36) NOT NULL REFERENCES users(uuid) ON DELETE CASCADE,
    name VARCHAR(100) NOT NULL,
    config TEXT DEFAULT NULL,
    visibility VARCHAR(20) DEFAULT 'private',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

COMMENT ON TABLE dashboards IS '数据看板表';
COMMENT ON COLUMN dashboards.user_uuid IS '关联用户UUID';
COMMENT ON COLUMN dashboards.name IS '看板名称';
COMMENT ON COLUMN dashboards.config IS '看板配置（JSON）';
COMMENT ON COLUMN dashboards.visibility IS '可见性: private/public';

-- ============================================================
-- 科室信息表
-- ============================================================
CREATE TABLE departments (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT DEFAULT NULL,
    icon VARCHAR(50) DEFAULT 'OfficeBuilding',
    contact VARCHAR(100) DEFAULT NULL,
    sort_order INT DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

COMMENT ON TABLE departments IS '科室信息表';
COMMENT ON COLUMN departments.name IS '科室名称';
COMMENT ON COLUMN departments.description IS '科室描述';
COMMENT ON COLUMN departments.icon IS '图标名称';
COMMENT ON COLUMN departments.contact IS '联系方式';
COMMENT ON COLUMN departments.sort_order IS '排序顺序';
COMMENT ON COLUMN departments.is_active IS '是否启用';

-- ============================================================
-- 员工信息表 - pg_trgm 支持
-- ============================================================
CREATE TABLE employees (
    id SERIAL PRIMARY KEY,
    department_id INT NOT NULL REFERENCES departments(id) ON DELETE CASCADE,
    name VARCHAR(50) NOT NULL,
    position VARCHAR(100) DEFAULT NULL,
    avatar VARCHAR(500) DEFAULT NULL,
    signature VARCHAR(255) DEFAULT NULL,
    phone VARCHAR(20) DEFAULT NULL,
    email VARCHAR(100) DEFAULT NULL,
    parent_id INT DEFAULT NULL REFERENCES employees(id) ON DELETE SET NULL,
    level INT DEFAULT 0,
    sort_order INT DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

COMMENT ON TABLE employees IS '员工信息表 - pg_trgm 高性能搜索';
COMMENT ON COLUMN employees.department_id IS '所属科室ID';
COMMENT ON COLUMN employees.name IS '员工姓名';
COMMENT ON COLUMN employees.position IS '职位';
COMMENT ON COLUMN employees.avatar IS '头像URL';
COMMENT ON COLUMN employees.signature IS '个性签名';
COMMENT ON COLUMN employees.phone IS '联系电话';
COMMENT ON COLUMN employees.email IS '邮箱';
COMMENT ON COLUMN employees.parent_id IS '上级ID(用于架构图)';
COMMENT ON COLUMN employees.level IS '层级(0为最高层)';
COMMENT ON COLUMN employees.sort_order IS '同级排序';
COMMENT ON COLUMN employees.is_active IS '是否启用';

-- ============================================================
-- 索引优化 - 核心：GIN + pg_trgm 索引
-- ============================================================

-- ====== websites 表索引（搜索核心）======
-- GIN 索引：name 字段模糊搜索（使用 gin_trgm_ops）
CREATE INDEX idx_websites_name_gin ON websites USING gin (name gin_trgm_ops);
-- GIN 索引：description 字段模糊搜索
CREATE INDEX idx_websites_desc_gin ON websites USING gin (description gin_trgm_ops);
-- GIN 索引：pinyin 字段模糊搜索
CREATE INDEX idx_websites_pinyin_gin ON websites USING gin (pinyin gin_trgm_ops);
-- GIN 索引：pinyin_initials 字段模糊搜索
CREATE INDEX idx_websites_pinyin_init_gin ON websites USING gin (pinyin_initials gin_trgm_ops);
-- GIN 索引：url 字段模糊搜索
CREATE INDEX idx_websites_url_gin ON websites USING gin (url gin_trgm_ops);
-- B-tree 索引：常规查询优化
CREATE INDEX idx_websites_section ON websites(section_id);
CREATE INDEX idx_websites_click ON websites(click_count DESC);
CREATE INDEX idx_websites_hot ON websites(is_hot);

-- ====== employees 表索引 ======
-- GIN 索引：name 字段模糊搜索
CREATE INDEX idx_employees_name_gin ON employees USING gin (name gin_trgm_ops);
-- GIN 索引：position 字段模糊搜索
CREATE INDEX idx_employees_pos_gin ON employees USING gin (position gin_trgm_ops);
-- GIN 索引：signature 字段模糊搜索
CREATE INDEX idx_employees_sig_gin ON employees USING gin (signature gin_trgm_ops);
-- GIN 索引：email 字段模糊搜索
CREATE INDEX idx_employees_email_gin ON employees USING gin (email gin_trgm_ops);
-- B-tree 索引
CREATE INDEX idx_employees_dept ON employees(department_id);
CREATE INDEX idx_employees_parent ON employees(parent_id);
CREATE INDEX idx_employees_active ON employees(is_active);
CREATE INDEX idx_employees_level ON employees(level);

-- ====== user_files 表索引 ======
-- GIN 索引：filename 字段模糊搜索
CREATE INDEX idx_user_files_filename_gin ON user_files USING gin (filename gin_trgm_ops);
-- B-tree 索引
CREATE INDEX idx_user_files_user ON user_files(user_uuid);
CREATE INDEX idx_user_files_folder ON user_files(folder_id);
CREATE INDEX idx_user_files_type ON user_files(file_type);
CREATE INDEX idx_user_files_starred ON user_files(is_starred);

-- ====== search_history 表索引 ======
-- GIN 索引：keyword 字段模糊搜索
CREATE INDEX idx_search_keyword_gin ON search_history USING gin (keyword gin_trgm_ops);
-- B-tree 索引
CREATE INDEX idx_search_count ON search_history(search_count DESC);

-- ====== 其他表常规索引 ======
CREATE INDEX idx_sections_category ON sections(category_id);
CREATE INDEX idx_folders_user ON folders(user_uuid);
CREATE INDEX idx_folders_parent ON folders(parent_id);
CREATE INDEX idx_folders_category ON folders(category);
CREATE INDEX idx_user_sites_user ON user_sites(user_uuid);
CREATE INDEX idx_user_sites_folder ON user_sites(folder_id);
CREATE INDEX idx_quotes_category ON quotes(category);
CREATE INDEX idx_quotes_active ON quotes(is_active);
CREATE INDEX idx_dashboards_user ON dashboards(user_uuid);
CREATE INDEX idx_dashboards_visibility ON dashboards(visibility);
CREATE INDEX idx_departments_active ON departments(is_active);
CREATE INDEX idx_departments_sort ON departments(sort_order);

-- ============================================================
-- 创建更新时间触发器函数
-- ============================================================
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

-- 为需要自动更新时间的表添加触发器
CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_sidebar_categories_updated_at BEFORE UPDATE ON sidebar_categories
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_sections_updated_at BEFORE UPDATE ON sections
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_websites_updated_at BEFORE UPDATE ON websites
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_folders_updated_at BEFORE UPDATE ON folders
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_user_sites_updated_at BEFORE UPDATE ON user_sites
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_quotes_updated_at BEFORE UPDATE ON quotes
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_system_settings_updated_at BEFORE UPDATE ON system_settings
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_user_files_updated_at BEFORE UPDATE ON user_files
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_dashboards_updated_at BEFORE UPDATE ON dashboards
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_departments_updated_at BEFORE UPDATE ON departments
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_employees_updated_at BEFORE UPDATE ON employees
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- ============================================================
-- 初始化数据
-- ============================================================

-- 侧边栏分类
INSERT INTO sidebar_categories (name, icon, sort_order, is_system) VALUES
('自定义工作台', 'Briefcase', 0, TRUE),
('常用工具', 'Tools', 1, FALSE),
('技术开发', 'Code', 2, FALSE),
('设计资源', 'Palette', 3, FALSE),
('学习教育', 'BookOpen', 4, FALSE),
('影音娱乐', 'Film', 5, FALSE),
('社交媒体', 'Users', 6, FALSE),
('新闻资讯', 'Newspaper', 7, FALSE),
('购物电商', 'ShoppingCart', 8, FALSE);

-- 常用工具分区
INSERT INTO sections (category_id, name, description, sort_order) VALUES
(2, '搜索引擎', '各大搜索引擎入口', 0),
(2, '在线翻译', '多语言翻译工具', 1),
(2, '文档办公', '在线文档和办公工具', 2),
(2, 'AI工具', '人工智能相关工具', 3);

-- 技术开发分区
INSERT INTO sections (category_id, name, description, sort_order) VALUES
(3, '代码托管', 'Git代码托管平台', 0),
(3, '技术社区', '程序员社区和论坛', 1),
(3, '开发文档', '各类技术文档', 2),
(3, '在线工具', '开发者在线工具', 3);

-- 设计资源分区
INSERT INTO sections (category_id, name, description, sort_order) VALUES
(4, '设计工具', '在线设计工具', 0),
(4, '图标素材', '图标和素材资源', 1),
(4, '配色方案', '配色工具和灵感', 2);

-- 学习教育分区
INSERT INTO sections (category_id, name, description, sort_order) VALUES
(5, '在线课程', '在线学习平台', 0),
(5, '编程学习', '编程教学资源', 1),
(5, '知识百科', '百科和知识库', 2);

-- 影音娱乐分区
INSERT INTO sections (category_id, name, description, sort_order) VALUES
(6, '视频平台', '主流视频网站', 0),
(6, '音乐平台', '音乐播放平台', 1),
(6, '直播平台', '直播网站', 2);

-- 社交媒体分区
INSERT INTO sections (category_id, name, description, sort_order) VALUES
(7, '社交网络', '社交媒体平台', 0),
(7, '即时通讯', '在线聊天工具', 1);

-- 新闻资讯分区
INSERT INTO sections (category_id, name, description, sort_order) VALUES
(8, '综合新闻', '新闻门户网站', 0),
(8, '科技资讯', '科技新闻网站', 1);

-- 购物电商分区
INSERT INTO sections (category_id, name, description, sort_order) VALUES
(9, '综合电商', '综合购物平台', 0),
(9, '数码科技', '数码产品商城', 1);

-- 搜索引擎网址
INSERT INTO websites (section_id, name, url, icon, description, pinyin, pinyin_initials, sort_order, is_hot) VALUES
(1, '百度', 'https://www.baidu.com', 'https://www.baidu.com/favicon.ico', '全球最大的中文搜索引擎', 'baidu', 'bd', 0, TRUE),
(1, 'Google', 'https://www.google.com', 'https://www.google.com/favicon.ico', '全球最大的搜索引擎', 'google', 'gl', 1, TRUE),
(1, 'Bing', 'https://www.bing.com', 'https://www.bing.com/favicon.ico', '微软搜索引擎', 'bing', 'bg', 2, FALSE),
(1, '搜狗', 'https://www.sogou.com', 'https://www.sogou.com/favicon.ico', '搜狗搜索引擎', 'sougou', 'sg', 3, FALSE);

-- 在线翻译网址
INSERT INTO websites (section_id, name, url, icon, description, pinyin, pinyin_initials, sort_order, is_hot) VALUES
(2, '百度翻译', 'https://fanyi.baidu.com', 'https://fanyi.baidu.com/favicon.ico', '百度在线翻译', 'baidufanyi', 'bdfy', 0, TRUE),
(2, 'Google翻译', 'https://translate.google.com', 'https://translate.google.com/favicon.ico', '谷歌在线翻译', 'googlefanyi', 'glfy', 1, TRUE),
(2, 'DeepL', 'https://www.deepl.com/translator', 'https://www.deepl.com/favicon.ico', 'AI翻译工具', 'deepl', 'dl', 2, TRUE);

-- 文档办公网址
INSERT INTO websites (section_id, name, url, icon, description, pinyin, pinyin_initials, sort_order, is_hot) VALUES
(3, '腾讯文档', 'https://docs.qq.com', 'https://docs.qq.com/favicon.ico', '腾讯在线文档协作', 'tengxunwendang', 'txwd', 0, TRUE),
(3, '石墨文档', 'https://shimo.im', 'https://shimo.im/favicon.ico', '云端Office办公', 'shimowendang', 'smwd', 1, FALSE),
(3, '语雀', 'https://www.yuque.com', 'https://www.yuque.com/favicon.ico', '阿里知识库', 'yuque', 'yq', 2, TRUE),
(3, 'Notion', 'https://www.notion.so', 'https://www.notion.so/favicon.ico', '全能工作空间', 'notion', 'nt', 3, TRUE);

-- AI工具网址
INSERT INTO websites (section_id, name, url, icon, description, pinyin, pinyin_initials, sort_order, is_hot) VALUES
(4, 'ChatGPT', 'https://chat.openai.com', 'https://chat.openai.com/favicon.ico', 'OpenAI对话AI', 'chatgpt', 'cgpt', 0, TRUE),
(4, '文心一言', 'https://yiyan.baidu.com', 'https://yiyan.baidu.com/favicon.ico', '百度AI助手', 'wenxinyiyan', 'wxyy', 1, TRUE),
(4, '通义千问', 'https://tongyi.aliyun.com', 'https://tongyi.aliyun.com/favicon.ico', '阿里AI助手', 'tongyiqianwen', 'tyqw', 2, TRUE),
(4, 'Claude', 'https://claude.ai', 'https://claude.ai/favicon.ico', 'Anthropic AI助手', 'claude', 'cd', 3, TRUE);

-- 代码托管网址
INSERT INTO websites (section_id, name, url, icon, description, pinyin, pinyin_initials, sort_order, is_hot) VALUES
(5, 'GitHub', 'https://github.com', 'https://github.com/favicon.ico', '全球最大代码托管平台', 'github', 'gh', 0, TRUE),
(5, 'Gitee', 'https://gitee.com', 'https://gitee.com/favicon.ico', '国内代码托管平台', 'gitee', 'ge', 1, TRUE),
(5, 'GitLab', 'https://gitlab.com', 'https://gitlab.com/favicon.ico', '开源代码托管平台', 'gitlab', 'gl', 2, FALSE);

-- 技术社区网址
INSERT INTO websites (section_id, name, url, icon, description, pinyin, pinyin_initials, sort_order, is_hot) VALUES
(6, '掘金', 'https://juejin.cn', 'https://juejin.cn/favicon.ico', '开发者社区', 'juejin', 'jj', 0, TRUE),
(6, 'CSDN', 'https://www.csdn.net', 'https://www.csdn.net/favicon.ico', '中文IT社区', 'csdn', 'csdn', 1, TRUE),
(6, 'Stack Overflow', 'https://stackoverflow.com', 'https://stackoverflow.com/favicon.ico', '程序员问答社区', 'stackoverflow', 'so', 2, TRUE),
(6, '博客园', 'https://www.cnblogs.com', 'https://www.cnblogs.com/favicon.ico', '开发者博客平台', 'bokeyuan', 'bky', 3, FALSE);

-- 开发文档网址
INSERT INTO websites (section_id, name, url, icon, description, pinyin, pinyin_initials, sort_order, is_hot) VALUES
(7, 'MDN Web Docs', 'https://developer.mozilla.org', 'https://developer.mozilla.org/favicon.ico', 'Web开发文档', 'mdn', 'mdn', 0, TRUE),
(7, 'Vue.js', 'https://vuejs.org', 'https://vuejs.org/favicon.ico', 'Vue框架官方文档', 'vuejs', 'vj', 1, TRUE),
(7, 'React', 'https://react.dev', 'https://react.dev/favicon.ico', 'React框架官方文档', 'react', 'rt', 2, TRUE);

-- 在线工具网址
INSERT INTO websites (section_id, name, url, icon, description, pinyin, pinyin_initials, sort_order, is_hot) VALUES
(8, 'CodePen', 'https://codepen.io', 'https://codepen.io/favicon.ico', '在线代码编辑器', 'codepen', 'cp', 0, TRUE),
(8, 'JSFiddle', 'https://jsfiddle.net', 'https://jsfiddle.net/favicon.ico', '在线代码测试', 'jsfiddle', 'jsf', 1, FALSE);

-- 设计工具网址
INSERT INTO websites (section_id, name, url, icon, description, pinyin, pinyin_initials, sort_order, is_hot) VALUES
(9, 'Figma', 'https://www.figma.com', 'https://www.figma.com/favicon.ico', '在线UI设计工具', 'figma', 'fg', 0, TRUE),
(9, 'Canva', 'https://www.canva.com', 'https://www.canva.com/favicon.ico', '在线设计平台', 'canva', 'cv', 1, TRUE),
(9, '即时设计', 'https://js.design', 'https://js.design/favicon.ico', '国产在线设计工具', 'jishisheji', 'jssj', 2, TRUE);

-- 图标素材网址
INSERT INTO websites (section_id, name, url, icon, description, pinyin, pinyin_initials, sort_order, is_hot) VALUES
(10, 'iconfont', 'https://www.iconfont.cn', 'https://www.iconfont.cn/favicon.ico', '阿里图标库', 'iconfont', 'if', 0, TRUE),
(10, 'Unsplash', 'https://unsplash.com', 'https://unsplash.com/favicon.ico', '免费高清图片', 'unsplash', 'us', 1, TRUE);

-- 配色方案网址
INSERT INTO websites (section_id, name, url, icon, description, pinyin, pinyin_initials, sort_order, is_hot) VALUES
(11, 'Coolors', 'https://coolors.co', 'https://coolors.co/favicon.ico', '配色生成器', 'coolors', 'cl', 0, TRUE);

-- 在线课程网址
INSERT INTO websites (section_id, name, url, icon, description, pinyin, pinyin_initials, sort_order, is_hot) VALUES
(12, '慕课网', 'https://www.imooc.com', 'https://www.imooc.com/favicon.ico', 'IT技能学习平台', 'mukewang', 'mkw', 0, TRUE),
(12, 'Coursera', 'https://www.coursera.org', 'https://www.coursera.org/favicon.ico', '全球在线学习平台', 'coursera', 'csr', 1, TRUE);

-- 编程学习网址
INSERT INTO websites (section_id, name, url, icon, description, pinyin, pinyin_initials, sort_order, is_hot) VALUES
(13, 'LeetCode', 'https://leetcode.cn', 'https://leetcode.cn/favicon.ico', '算法刷题平台', 'leetcode', 'lc', 0, TRUE),
(13, '菜鸟教程', 'https://www.runoob.com', 'https://www.runoob.com/favicon.ico', '编程入门教程', 'cainiaojiaocheng', 'cnjc', 1, TRUE);

-- 知识百科网址
INSERT INTO websites (section_id, name, url, icon, description, pinyin, pinyin_initials, sort_order, is_hot) VALUES
(14, '维基百科', 'https://zh.wikipedia.org', 'https://zh.wikipedia.org/favicon.ico', '自由的百科全书', 'weijibaike', 'wjbk', 0, TRUE),
(14, '知乎', 'https://www.zhihu.com', 'https://www.zhihu.com/favicon.ico', '知识问答社区', 'zhihu', 'zh', 1, TRUE);

-- 视频平台网址
INSERT INTO websites (section_id, name, url, icon, description, pinyin, pinyin_initials, sort_order, is_hot) VALUES
(15, 'Bilibili', 'https://www.bilibili.com', 'https://www.bilibili.com/favicon.ico', 'B站视频平台', 'bilibili', 'blbl', 0, TRUE),
(15, 'YouTube', 'https://www.youtube.com', 'https://www.youtube.com/favicon.ico', '全球视频平台', 'youtube', 'ytb', 1, TRUE);

-- 音乐平台网址
INSERT INTO websites (section_id, name, url, icon, description, pinyin, pinyin_initials, sort_order, is_hot) VALUES
(16, '网易云音乐', 'https://music.163.com', 'https://music.163.com/favicon.ico', '网易云音乐', 'wangyiyunyinyue', 'wyyyy', 0, TRUE),
(16, 'QQ音乐', 'https://y.qq.com', 'https://y.qq.com/favicon.ico', 'QQ音乐', 'qqyinyue', 'qqyy', 1, TRUE);

-- 直播平台网址
INSERT INTO websites (section_id, name, url, icon, description, pinyin, pinyin_initials, sort_order, is_hot) VALUES
(17, '斗鱼', 'https://www.douyu.com', 'https://www.douyu.com/favicon.ico', '斗鱼直播', 'douyu', 'dy', 0, TRUE),
(17, '虎牙', 'https://www.huya.com', 'https://www.huya.com/favicon.ico', '虎牙直播', 'huya', 'hy', 1, TRUE);

-- 社交网络网址
INSERT INTO websites (section_id, name, url, icon, description, pinyin, pinyin_initials, sort_order, is_hot) VALUES
(18, '微博', 'https://weibo.com', 'https://weibo.com/favicon.ico', '新浪微博', 'weibo', 'wb', 0, TRUE),
(18, 'Twitter/X', 'https://twitter.com', 'https://twitter.com/favicon.ico', '推特社交平台', 'twitter', 'tt', 1, TRUE);

-- 即时通讯网址
INSERT INTO websites (section_id, name, url, icon, description, pinyin, pinyin_initials, sort_order, is_hot) VALUES
(19, 'QQ邮箱', 'https://mail.qq.com', 'https://mail.qq.com/favicon.ico', 'QQ邮箱', 'qqyouxiang', 'qqyx', 0, TRUE),
(19, 'Gmail', 'https://mail.google.com', 'https://mail.google.com/favicon.ico', '谷歌邮箱', 'gmail', 'gm', 1, TRUE);

-- 综合新闻网址
INSERT INTO websites (section_id, name, url, icon, description, pinyin, pinyin_initials, sort_order, is_hot) VALUES
(20, '今日头条', 'https://www.toutiao.com', 'https://www.toutiao.com/favicon.ico', '今日头条新闻', 'jinritoutiao', 'jrtt', 0, TRUE);

-- 科技资讯网址
INSERT INTO websites (section_id, name, url, icon, description, pinyin, pinyin_initials, sort_order, is_hot) VALUES
(21, '36氪', 'https://36kr.com', 'https://36kr.com/favicon.ico', '创业科技媒体', '36ke', '36k', 0, TRUE),
(21, '虎嗅', 'https://www.huxiu.com', 'https://www.huxiu.com/favicon.ico', '科技商业媒体', 'huxiu', 'hx', 1, TRUE);

-- 综合电商网址
INSERT INTO websites (section_id, name, url, icon, description, pinyin, pinyin_initials, sort_order, is_hot) VALUES
(22, '淘宝', 'https://www.taobao.com', 'https://www.taobao.com/favicon.ico', '淘宝购物', 'taobao', 'tb', 0, TRUE),
(22, '京东', 'https://www.jd.com', 'https://www.jd.com/favicon.ico', '京东商城', 'jingdong', 'jd', 1, TRUE);

-- 数码科技网址
INSERT INTO websites (section_id, name, url, icon, description, pinyin, pinyin_initials, sort_order, is_hot) VALUES
(23, '苹果官网', 'https://www.apple.com.cn', 'https://www.apple.com.cn/favicon.ico', 'Apple中国', 'pingguoguanwang', 'pggw', 0, TRUE),
(23, '小米商城', 'https://www.mi.com', 'https://www.mi.com/favicon.ico', '小米官方商城', 'xiaomishangcheng', 'xmsc', 1, TRUE);

-- 系统设置初始数据
INSERT INTO system_settings (setting_key, setting_value, description) VALUES
('site_name', 'NavHub', '网站名称'),
('site_logo', '/logo.svg', '网站Logo'),
('default_search_engine', 'baidu', '默认搜索引擎'),
('footer_copyright', '© 2024 NavHub. All rights reserved.', '页脚版权信息'),
('footer_contact', 'contact@navhub.com', '联系邮箱'),
('theme_mode', 'system', '主题模式（light/dark/system）');

-- 励志语录初始数据
INSERT INTO quotes (content, author, source, category, is_active) VALUES
('千里之行，始于足下。', '老子', '道德经', 'philosophy', TRUE),
('不积跬步，无以至千里；不积小流，无以成江海。', '荀子', '劝学', 'philosophy', TRUE),
('学而不思则罔，思而不学则殆。', '孔子', '论语', 'learning', TRUE),
('业精于勤，荒于嬉；行成于思，毁于随。', '韩愈', '进学解', 'motivation', TRUE),
('天行健，君子以自强不息。', '', '周易', 'motivation', TRUE),
('宝剑锋从磨砺出，梅花香自苦寒来。', '', '警世贤文', 'motivation', TRUE),
('路漫漫其修远兮，吾将上下而求索。', '屈原', '离骚', 'motivation', TRUE),
('世上无难事，只怕有心人。', '', '谚语', 'motivation', TRUE),
('知之为知之，不知为不知，是知也。', '孔子', '论语', 'learning', TRUE),
('吾生也有涯，而知也无涯。', '庄子', '养生主', 'philosophy', TRUE),
('Stay hungry, stay foolish.', 'Steve Jobs', 'Stanford Commencement Speech', 'motivation', TRUE),
('The only way to do great work is to love what you do.', 'Steve Jobs', '', 'motivation', TRUE),
('Innovation distinguishes between a leader and a follower.', 'Steve Jobs', '', 'innovation', TRUE),
('Talk is cheap. Show me the code.', 'Linus Torvalds', '', 'tech', TRUE),
('First, solve the problem. Then, write the code.', 'John Johnson', '', 'tech', TRUE),
('Any fool can write code that a computer can understand. Good programmers write code that humans can understand.', 'Martin Fowler', 'Refactoring', 'tech', TRUE),
('Simplicity is the soul of efficiency.', 'Austin Freeman', '', 'tech', TRUE),
('Code is like humor. When you have to explain it, it''s bad.', 'Cory House', '', 'tech', TRUE);

-- 科室初始数据
INSERT INTO departments (name, description, icon, contact, sort_order, is_active) VALUES
('信息技术部', '负责公司信息系统建设与维护，提供技术支持与解决方案，推动数字化转型进程。包括系统开发、网络安全、数据管理等职能。', 'Monitor', '分机 8001', 1, TRUE),
('人力资源部', '负责人才招聘、培训发展、薪酬福利及员工关系管理，构建优秀团队。致力于打造良好的企业文化和员工发展环境。', 'User', '分机 8002', 2, TRUE),
('财务管理部', '负责财务规划、成本控制、资金管理及财务报表编制，保障企业财务健康。提供准确及时的财务信息支持决策。', 'Wallet', '分机 8003', 3, TRUE),
('市场营销部', '负责市场调研、品牌推广、营销策划及客户关系维护，提升市场竞争力。制定并执行营销战略，扩大市场份额。', 'TrendCharts', '分机 8004', 4, TRUE),
('行政综合部', '负责行政管理、后勤保障、会议组织及办公环境维护，提供优质服务支持。确保公司日常运营顺畅高效。', 'OfficeBuilding', '分机 8005', 5, TRUE);

-- 员工初始数据
INSERT INTO employees (department_id, name, position, avatar, signature, phone, email, parent_id, level, sort_order, is_active) VALUES
-- 信息技术部 (ID: 1)
(1, '张明远', '技术总监', '', '代码改变世界', '13800001001', 'zhangmy@company.com', NULL, 0, 0, TRUE),
(1, '李晓峰', '开发组长', '', '持续学习，追求卓越', '13800001002', 'lixf@company.com', 1, 1, 0, TRUE),
(1, '王思琪', '前端工程师', '', '用户体验至上', '13800001003', 'wangsq@company.com', 2, 2, 0, TRUE),
(1, '陈浩然', '后端工程师', '', '稳定可靠是我的追求', '13800001004', 'chenhr@company.com', 2, 2, 1, TRUE),
(1, '刘雅婷', '运维组长', '', '保障系统稳定运行', '13800001005', 'liuyt@company.com', 1, 1, 1, TRUE),
(1, '周文博', '运维工程师', '', '7x24小时守护', '13800001006', 'zhouwb@company.com', 5, 2, 0, TRUE),
-- 人力资源部 (ID: 2)
(2, '赵雪梅', '人力总监', '', '人才是企业最宝贵的财富', '13800002001', 'zhaoxm@company.com', NULL, 0, 0, TRUE),
(2, '孙建国', '招聘主管', '', '发现优秀人才', '13800002002', 'sunjg@company.com', 7, 1, 0, TRUE),
(2, '吴芳华', '培训专员', '', '助力员工成长', '13800002003', 'wufh@company.com', 7, 1, 1, TRUE),
-- 财务管理部 (ID: 3)
(3, '郑伟强', '财务总监', '', '精准核算，合规经营', '13800003001', 'zhengwq@company.com', NULL, 0, 0, TRUE),
(3, '钱丽娟', '会计主管', '', '严谨细致是我的原则', '13800003002', 'qianlj@company.com', 10, 1, 0, TRUE),
(3, '许志明', '出纳', '', '安全高效处理资金', '13800003003', 'xuzm@company.com', 10, 1, 1, TRUE),
-- 市场营销部 (ID: 4)
(4, '冯晓燕', '市场总监', '', '创意驱动增长', '13800004001', 'fengxy@company.com', NULL, 0, 0, TRUE),
(4, '卫国栋', '品牌主管', '', '打造卓越品牌', '13800004002', 'weigd@company.com', 13, 1, 0, TRUE),
(4, '沈美玲', '市场专员', '', '洞察市场趋势', '13800004003', 'shenml@company.com', 13, 1, 1, TRUE),
-- 行政综合部 (ID: 5)
(5, '何建华', '行政总监', '', '服务至上，高效运转', '13800005001', 'hejh@company.com', NULL, 0, 0, TRUE),
(5, '彭小芳', '行政主管', '', '细节决定品质', '13800005002', 'pengxf@company.com', 16, 1, 0, TRUE),
(5, '曹志远', '后勤专员', '', '保障日常运营', '13800005003', 'caozy@company.com', 16, 1, 1, TRUE);

-- ============================================================
-- 分析统计信息
-- ============================================================
ANALYZE websites;
ANALYZE employees;
ANALYZE user_files;
ANALYZE search_history;

-- ============================================================
-- 完成提示
-- ============================================================
DO $$
BEGIN
    RAISE NOTICE '========================================';
    RAISE NOTICE 'PostgreSQL 数据库初始化完成！';
    RAISE NOTICE '';
    RAISE NOTICE '已启用的扩展：';
    RAISE NOTICE '  - pg_trgm (模糊搜索加速)';
    RAISE NOTICE '';
    RAISE NOTICE '已创建的 GIN 索引：';
    RAISE NOTICE '  - websites: name, description, pinyin, url';
    RAISE NOTICE '  - employees: name, position, signature, email';
    RAISE NOTICE '  - user_files: filename';
    RAISE NOTICE '  - search_history: keyword';
    RAISE NOTICE '';
    RAISE NOTICE '搜索性能提示：';
    RAISE NOTICE '  - 使用 % 操作符进行模糊匹配';
    RAISE NOTICE '  - 使用 similarity() 函数获取相似度';
    RAISE NOTICE '  - 调整 pg_trgm.similarity_threshold 控制阈值';
    RAISE NOTICE '========================================';
END $$;
