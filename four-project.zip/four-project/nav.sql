--
-- PostgreSQL database dump
--

\restrict xBOAhEY8d2qxskruMdYeKSqex2zgHn0jRV5PXfWW3S52DuouJDdGMVnmGLnA9h1

-- Dumped from database version 17.7
-- Dumped by pg_dump version 17.7

-- Started on 2025-12-17 20:33:19

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 2 (class 3079 OID 16636)
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- TOC entry 5159 (class 0 OID 0)
-- Dependencies: 2
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- TOC entry 275 (class 1255 OID 17012)
-- Name: update_last_active_at_column(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_last_active_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.last_active_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_last_active_at_column() OWNER TO postgres;

--
-- TOC entry 276 (class 1255 OID 17014)
-- Name: update_last_searched_at_column(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_last_searched_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.last_searched_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_last_searched_at_column() OWNER TO postgres;

--
-- TOC entry 274 (class 1255 OID 16717)
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 232 (class 1259 OID 16848)
-- Name: dashboards; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dashboards (
    id integer NOT NULL,
    user_uuid character varying(36) NOT NULL,
    name character varying(100) NOT NULL,
    config jsonb,
    visibility character varying(20) DEFAULT 'private'::character varying,
    charts_config jsonb,
    stat_cards_config jsonb,
    data_file_paths jsonb,
    sheet_names jsonb,
    file_id character varying(100) DEFAULT NULL::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.dashboards OWNER TO postgres;

--
-- TOC entry 231 (class 1259 OID 16847)
-- Name: dashboards_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.dashboards_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.dashboards_id_seq OWNER TO postgres;

--
-- TOC entry 5160 (class 0 OID 0)
-- Dependencies: 231
-- Name: dashboards_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.dashboards_id_seq OWNED BY public.dashboards.id;


--
-- TOC entry 226 (class 1259 OID 16780)
-- Name: departments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.departments (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    icon character varying(50) DEFAULT 'OfficeBuilding'::character varying,
    contact character varying(100) DEFAULT NULL::character varying,
    sort_order integer DEFAULT 0,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.departments OWNER TO postgres;

--
-- TOC entry 225 (class 1259 OID 16779)
-- Name: departments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.departments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.departments_id_seq OWNER TO postgres;

--
-- TOC entry 5161 (class 0 OID 0)
-- Dependencies: 225
-- Name: departments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.departments_id_seq OWNED BY public.departments.id;


--
-- TOC entry 228 (class 1259 OID 16795)
-- Name: employees; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employees (
    id integer NOT NULL,
    department_id integer NOT NULL,
    name character varying(50) NOT NULL,
    "position" character varying(100) DEFAULT NULL::character varying,
    avatar character varying(500) DEFAULT NULL::character varying,
    signature character varying(255) DEFAULT NULL::character varying,
    phone character varying(20) DEFAULT NULL::character varying,
    email character varying(100) DEFAULT NULL::character varying,
    parent_id integer,
    level integer DEFAULT 0,
    sort_order integer DEFAULT 0,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    pinyin character varying(200),
    pinyin_initials character varying(50)
);


ALTER TABLE public.employees OWNER TO postgres;

--
-- TOC entry 227 (class 1259 OID 16794)
-- Name: employees_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.employees_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.employees_id_seq OWNER TO postgres;

--
-- TOC entry 5162 (class 0 OID 0)
-- Dependencies: 227
-- Name: employees_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.employees_id_seq OWNED BY public.employees.id;


--
-- TOC entry 230 (class 1259 OID 16824)
-- Name: folders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.folders (
    id integer NOT NULL,
    user_uuid character varying(36) NOT NULL,
    name character varying(100) NOT NULL,
    parent_id integer,
    category character varying(20) DEFAULT 'sites'::character varying,
    icon character varying(50) DEFAULT 'Folder'::character varying,
    color character varying(20) DEFAULT '#6b7280'::character varying,
    sort_order integer DEFAULT 0,
    is_collapsed boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.folders OWNER TO postgres;

--
-- TOC entry 229 (class 1259 OID 16823)
-- Name: folders_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.folders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.folders_id_seq OWNER TO postgres;

--
-- TOC entry 5163 (class 0 OID 0)
-- Dependencies: 229
-- Name: folders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.folders_id_seq OWNED BY public.folders.id;


--
-- TOC entry 238 (class 1259 OID 16925)
-- Name: quotes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quotes (
    id integer NOT NULL,
    content text NOT NULL,
    author character varying(100) DEFAULT NULL::character varying,
    source character varying(200) DEFAULT NULL::character varying,
    category character varying(50) DEFAULT 'general'::character varying,
    is_active boolean DEFAULT true,
    display_count integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.quotes OWNER TO postgres;

--
-- TOC entry 237 (class 1259 OID 16924)
-- Name: quotes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.quotes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.quotes_id_seq OWNER TO postgres;

--
-- TOC entry 5164 (class 0 OID 0)
-- Dependencies: 237
-- Name: quotes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.quotes_id_seq OWNED BY public.quotes.id;


--
-- TOC entry 240 (class 1259 OID 16941)
-- Name: search_history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.search_history (
    id integer NOT NULL,
    keyword character varying(200) NOT NULL,
    search_count integer DEFAULT 1,
    last_searched_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.search_history OWNER TO postgres;

--
-- TOC entry 239 (class 1259 OID 16940)
-- Name: search_history_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.search_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.search_history_id_seq OWNER TO postgres;

--
-- TOC entry 5165 (class 0 OID 0)
-- Dependencies: 239
-- Name: search_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.search_history_id_seq OWNED BY public.search_history.id;


--
-- TOC entry 222 (class 1259 OID 16741)
-- Name: sections; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sections (
    id integer NOT NULL,
    category_id integer NOT NULL,
    name character varying(100) NOT NULL,
    description character varying(255) DEFAULT NULL::character varying,
    sort_order integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.sections OWNER TO postgres;

--
-- TOC entry 221 (class 1259 OID 16740)
-- Name: sections_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sections_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sections_id_seq OWNER TO postgres;

--
-- TOC entry 5166 (class 0 OID 0)
-- Dependencies: 221
-- Name: sections_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sections_id_seq OWNED BY public.sections.id;


--
-- TOC entry 220 (class 1259 OID 16729)
-- Name: sidebar_categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sidebar_categories (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    icon character varying(100) DEFAULT NULL::character varying,
    sort_order integer DEFAULT 0,
    is_system boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.sidebar_categories OWNER TO postgres;

--
-- TOC entry 219 (class 1259 OID 16728)
-- Name: sidebar_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sidebar_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sidebar_categories_id_seq OWNER TO postgres;

--
-- TOC entry 5167 (class 0 OID 0)
-- Dependencies: 219
-- Name: sidebar_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sidebar_categories_id_seq OWNED BY public.sidebar_categories.id;


--
-- TOC entry 242 (class 1259 OID 16951)
-- Name: system_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.system_settings (
    id integer NOT NULL,
    setting_key character varying(50) NOT NULL,
    setting_value text,
    description character varying(255) DEFAULT NULL::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.system_settings OWNER TO postgres;

--
-- TOC entry 241 (class 1259 OID 16950)
-- Name: system_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.system_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.system_settings_id_seq OWNER TO postgres;

--
-- TOC entry 5168 (class 0 OID 0)
-- Dependencies: 241
-- Name: system_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.system_settings_id_seq OWNED BY public.system_settings.id;


--
-- TOC entry 234 (class 1259 OID 16866)
-- Name: user_files; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_files (
    id integer NOT NULL,
    user_uuid character varying(36) NOT NULL,
    folder_id integer,
    filename character varying(255) NOT NULL,
    storage_path character varying(500) NOT NULL,
    file_type character varying(20) NOT NULL,
    file_size bigint DEFAULT 0,
    row_count integer DEFAULT 0,
    column_count integer DEFAULT 0,
    columns_info jsonb DEFAULT '[]'::jsonb,
    sort_order integer DEFAULT 0,
    is_starred boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.user_files OWNER TO postgres;

--
-- TOC entry 233 (class 1259 OID 16865)
-- Name: user_files_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_files_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_files_id_seq OWNER TO postgres;

--
-- TOC entry 5169 (class 0 OID 0)
-- Dependencies: 233
-- Name: user_files_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_files_id_seq OWNED BY public.user_files.id;


--
-- TOC entry 236 (class 1259 OID 16893)
-- Name: user_sites; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_sites (
    id integer NOT NULL,
    user_uuid character varying(36) NOT NULL,
    website_id integer,
    folder_id integer,
    custom_name character varying(100) DEFAULT NULL::character varying,
    custom_url character varying(500) DEFAULT NULL::character varying,
    custom_icon character varying(500) DEFAULT NULL::character varying,
    custom_description character varying(255) DEFAULT NULL::character varying,
    sort_order integer DEFAULT 0,
    click_count integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.user_sites OWNER TO postgres;

--
-- TOC entry 235 (class 1259 OID 16892)
-- Name: user_sites_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_sites_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_sites_id_seq OWNER TO postgres;

--
-- TOC entry 5170 (class 0 OID 0)
-- Dependencies: 235
-- Name: user_sites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_sites_id_seq OWNED BY public.user_sites.id;


--
-- TOC entry 218 (class 1259 OID 16718)
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    uuid character varying(36) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    last_active_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    settings jsonb DEFAULT '{}'::jsonb
);


ALTER TABLE public.users OWNER TO postgres;

--
-- TOC entry 224 (class 1259 OID 16757)
-- Name: websites; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.websites (
    id integer NOT NULL,
    section_id integer NOT NULL,
    name character varying(100) NOT NULL,
    url character varying(500) NOT NULL,
    icon character varying(500) DEFAULT NULL::character varying,
    description character varying(255) DEFAULT NULL::character varying,
    pinyin character varying(200) DEFAULT NULL::character varying,
    pinyin_initials character varying(50) DEFAULT NULL::character varying,
    sort_order integer DEFAULT 0,
    click_count integer DEFAULT 0,
    is_hot boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.websites OWNER TO postgres;

--
-- TOC entry 223 (class 1259 OID 16756)
-- Name: websites_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.websites_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.websites_id_seq OWNER TO postgres;

--
-- TOC entry 5171 (class 0 OID 0)
-- Dependencies: 223
-- Name: websites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.websites_id_seq OWNED BY public.websites.id;


--
-- TOC entry 4855 (class 2604 OID 16851)
-- Name: dashboards id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dashboards ALTER COLUMN id SET DEFAULT nextval('public.dashboards_id_seq'::regclass);


--
-- TOC entry 4829 (class 2604 OID 16783)
-- Name: departments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.departments ALTER COLUMN id SET DEFAULT nextval('public.departments_id_seq'::regclass);


--
-- TOC entry 4836 (class 2604 OID 16798)
-- Name: employees id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employees ALTER COLUMN id SET DEFAULT nextval('public.employees_id_seq'::regclass);


--
-- TOC entry 4847 (class 2604 OID 16827)
-- Name: folders id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.folders ALTER COLUMN id SET DEFAULT nextval('public.folders_id_seq'::regclass);


--
-- TOC entry 4878 (class 2604 OID 16928)
-- Name: quotes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quotes ALTER COLUMN id SET DEFAULT nextval('public.quotes_id_seq'::regclass);


--
-- TOC entry 4886 (class 2604 OID 16944)
-- Name: search_history id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.search_history ALTER COLUMN id SET DEFAULT nextval('public.search_history_id_seq'::regclass);


--
-- TOC entry 4814 (class 2604 OID 16744)
-- Name: sections id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sections ALTER COLUMN id SET DEFAULT nextval('public.sections_id_seq'::regclass);


--
-- TOC entry 4808 (class 2604 OID 16732)
-- Name: sidebar_categories id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sidebar_categories ALTER COLUMN id SET DEFAULT nextval('public.sidebar_categories_id_seq'::regclass);


--
-- TOC entry 4890 (class 2604 OID 16954)
-- Name: system_settings id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_settings ALTER COLUMN id SET DEFAULT nextval('public.system_settings_id_seq'::regclass);


--
-- TOC entry 4860 (class 2604 OID 16869)
-- Name: user_files id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_files ALTER COLUMN id SET DEFAULT nextval('public.user_files_id_seq'::regclass);


--
-- TOC entry 4869 (class 2604 OID 16896)
-- Name: user_sites id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_sites ALTER COLUMN id SET DEFAULT nextval('public.user_sites_id_seq'::regclass);


--
-- TOC entry 4819 (class 2604 OID 16760)
-- Name: websites id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.websites ALTER COLUMN id SET DEFAULT nextval('public.websites_id_seq'::regclass);


--
-- TOC entry 5143 (class 0 OID 16848)
-- Dependencies: 232
-- Data for Name: dashboards; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dashboards (id, user_uuid, name, config, visibility, charts_config, stat_cards_config, data_file_paths, sheet_names, file_id, created_at, updated_at) FROM stdin;
8	ae42c436-7415-465f-8a49-b5f182e6c005	test	\N	public	[{"id": "1765963869015", "type": "bar", "sheet": "sheet_Sheet1_joined", "title": "大数据专业MySQL成绩柱状图", "width": 12, "colors": ["#374151", "#6B7280", "#9CA3AF", "#D1D5DB", "#1f2937", "#4B5563"], "height": 360, "xField": "姓名", "filters": [{"field": "数据预处理技术，专业基础课，必修，学分3，学时60，2022-2023-2", "value": "", "operator": "notEmpty"}, {"field": "", "value": "", "operator": "eq"}], "yFields": ["MySQL数据库应用基础，专业基础课，必修，学分3，学时48，2022-2023-2"], "isGrouped": true, "limitType": "", "showLabel": false, "sortField": "y", "sortOrder": "asc", "groupField": "班级", "limitCount": 10, "showLegend": true, "aggregation": "none", "yAxisConfig": {}, "computedFields": [], "enableDrillDown": true}, {"id": "1765964222245", "type": "bar", "sheet": "sheet_Sheet1_joined", "title": "院内各班级户口堆叠分布图", "width": 12, "colors": ["#374151", "#6B7280", "#9CA3AF", "#D1D5DB", "#1f2937", "#4B5563"], "height": 360, "xField": "班级", "filters": [{"field": "入学前户口性质", "value": "", "operator": "notEmpty"}, {"field": "入学前户口性质", "value": "农业家庭", "operator": "contains"}], "yFields": ["入学前户口性质"], "isGrouped": true, "limitType": "", "showLabel": true, "sortField": "", "sortOrder": "", "groupField": "入学前户口性质", "limitCount": 10, "showLegend": true, "aggregation": "count", "yAxisConfig": {"入学前户口性质": 0}, "computedFields": [], "enableDrillDown": true}, {"id": "1765964945751", "type": "pie", "sheet": "sheet_Sheet1_joined", "title": "性别占比图", "width": 6, "colors": ["#374151", "#6B7280", "#9CA3AF", "#D1D5DB", "#1f2937", "#4B5563"], "height": 360, "xField": "性别", "filters": [{"field": "性别", "value": "", "operator": "notEmpty"}], "yFields": ["姓名"], "limitType": "", "showLabel": true, "sortField": "", "sortOrder": "", "groupField": "性别", "limitCount": 10, "showLegend": true, "aggregation": "count", "yAxisConfig": {}, "computedFields": [], "enableDrillDown": true}, {"id": "1765965087748", "type": "pie", "sheet": "sheet_Sheet1_joined", "title": "各专业人数饼状占比图", "width": 6, "colors": ["#374151", "#6B7280", "#9CA3AF", "#D1D5DB", "#1f2937", "#4B5563"], "height": 360, "xField": "专业", "filters": [{"field": "专业", "value": "", "operator": "notEmpty"}], "yFields": ["姓名"], "limitType": "", "showLabel": true, "sortField": "", "sortOrder": "", "groupField": "", "limitCount": 10, "showLegend": true, "aggregation": "count", "yAxisConfig": {}, "computedFields": [], "enableDrillDown": true}, {"id": "1765970162781", "type": "line", "sheet": "sheet_Sheet1_joined", "title": "院内出生年份各性别人数分布图", "width": 6, "colors": ["#3b82f6", "#10b981", "#f59e0b", "#ef4444", "#8b5cf6", "#ec4899", "#06b6d4", "#84cc16"], "height": 360, "xField": "年份", "filters": [{"field": "班级", "value": "23", "operator": "notContains"}, {"field": "班级", "value": "24", "operator": "notContains"}, {"field": "出生日期", "value": "", "operator": "notEmpty"}], "yFields": ["人数"], "isGrouped": true, "limitType": "", "showLabel": false, "sortField": "", "sortOrder": "", "groupField": "性别", "limitCount": 10, "showLegend": true, "aggregation": "count", "yAxisConfig": {}, "computedFields": [{"name": "人数", "type": "legacy", "unit": "days", "cases": [], "source": "学号", "default": "0", "end_date": "", "operator": ">", "threshold": "0", "expression": "", "start_date": ""}, {"name": "年份", "type": "extraction", "unit": "days", "cases": [], "method": "substr", "params": {"start": 0, "length": 4}, "source": "出生日期", "default": "", "end_date": "", "operator": ">=", "threshold": "60", "expression": "", "start_date": ""}], "enableDrillDown": true}, {"id": "1765974255879", "type": "pie", "sheet": "sheet", "title": "各省份出生人数占比图", "width": 6, "colors": ["#3b82f6", "#10b981", "#f59e0b", "#ef4444", "#8b5cf6", "#ec4899", "#06b6d4", "#84cc16"], "height": 360, "xField": "出生省份", "filters": [{"field": "出生地", "value": "", "operator": "notEmpty"}], "yFields": ["姓名"], "limitType": "", "showLabel": true, "sortField": "", "sortOrder": "", "groupField": "出生省份", "limitCount": 10, "showLegend": true, "aggregation": "count", "yAxisConfig": {}, "computedFields": [{"name": "出生省份", "type": "extraction", "unit": "days", "cases": [], "method": "substr", "params": {"start": 0, "length": 2}, "source": "出生地", "default": "", "end_date": "", "operator": ">=", "threshold": "60", "expression": "", "start_date": ""}], "enableDrillDown": true}]	[]	{"sheet": "C:\\\\Users\\\\1\\\\Desktop\\\\second-project\\\\server-net\\\\data_storage\\\\ae42c436-7415-465f-8a49-b5f182e6c005_8_20251217180217_sheet.parquet", "Sheet1": "C:\\\\Users\\\\1\\\\Desktop\\\\second-project\\\\server-net\\\\data_storage\\\\ae42c436-7415-465f-8a49-b5f182e6c005_8_20251217180217_Sheet1.parquet", "sheet_Sheet1_joined": "C:\\\\Users\\\\1\\\\Desktop\\\\second-project\\\\server-net\\\\data_storage\\\\ae42c436-7415-465f-8a49-b5f182e6c005_8_20251217180217_sheet_Sheet1_joined.parquet"}	["sheet", "Sheet1", "sheet_Sheet1_joined"]	ae42c436-7415-465f-8a49-b5f182e6c005_8_20251217180217	2025-12-17 10:02:17.285825	2025-12-17 20:28:08.534415
\.


--
-- TOC entry 5137 (class 0 OID 16780)
-- Dependencies: 226
-- Data for Name: departments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.departments (id, name, description, icon, contact, sort_order, is_active, created_at, updated_at) FROM stdin;
1	信息技术部	负责公司信息系统建设与维护，提供技术支持与解决方案，推动数字化转型进程。包括系统开发、网络安全、数据管理等职能。	Monitor	分机 8001	1	t	2025-12-16 12:28:02	2025-12-16 12:28:02
2	人力资源部	负责人才招聘、培训发展、薪酬福利及员工关系管理，构建优秀团队。致力于打造良好的企业文化和员工发展环境。	User	分机 8002	2	t	2025-12-16 12:28:02	2025-12-16 12:28:02
3	财务管理部	负责财务规划、成本控制、资金管理及财务报表编制，保障企业财务健康。提供准确及时的财务信息支持决策。	Wallet	分机 8003	3	t	2025-12-16 12:28:02	2025-12-16 12:28:02
4	市场营销部	负责市场调研、品牌推广、营销策划及客户关系维护，提升市场竞争力。制定并执行营销战略，扩大市场份额。	TrendCharts	分机 8004	4	t	2025-12-16 12:28:02	2025-12-16 12:28:02
5	行政综合部	负责行政管理、后勤保障、会议组织及办公环境维护，提供优质服务支持。确保公司日常运营顺畅高效。	OfficeBuilding	分机 8005	5	t	2025-12-16 12:28:02	2025-12-16 12:28:02
\.


--
-- TOC entry 5139 (class 0 OID 16795)
-- Dependencies: 228
-- Data for Name: employees; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employees (id, department_id, name, "position", avatar, signature, phone, email, parent_id, level, sort_order, is_active, created_at, updated_at, pinyin, pinyin_initials) FROM stdin;
1	1	张明远	技术总监		代码改变世界	13800001001	zhangmy@company.com	\N	0	0	t	2025-12-16 12:28:02	2025-12-17 16:00:08.888673	zhangmingyuan	zmy
2	1	李晓峰	开发组长		持续学习，追求卓越	13800001002	lixf@company.com	1	1	0	t	2025-12-16 12:28:02	2025-12-17 16:00:08.888673	lixiaofeng	lxf
3	1	王思琪	前端工程师		用户体验至上	13800001003	wangsq@company.com	2	2	0	t	2025-12-16 12:28:02	2025-12-17 16:00:08.888673	wangsiqi	wsq
4	1	陈浩然	后端工程师		稳定可靠是我的追求	13800001004	chenhr@company.com	2	2	1	t	2025-12-16 12:28:02	2025-12-17 16:00:08.888673	chenhaoran	chr
5	1	刘雅婷	运维组长		保障系统稳定运行	13800001005	liuyt@company.com	1	1	1	t	2025-12-16 12:28:02	2025-12-17 16:00:08.888673	liuyating	lyt
6	1	周文博	运维工程师		7x24小时守护	13800001006	zhouwb@company.com	5	2	0	t	2025-12-16 12:28:02	2025-12-17 16:00:08.888673	zhouwenbo	zwb
7	2	赵雪梅	人力总监		人才是企业最宝贵的财富	13800002001	zhaoxm@company.com	\N	0	0	t	2025-12-16 12:28:02	2025-12-17 16:00:08.888673	zhaoxuemei	zxm
8	2	孙建国	招聘主管		发现优秀人才	13800002002	sunjg@company.com	7	1	0	t	2025-12-16 12:28:02	2025-12-17 16:00:08.888673	sunjianguo	sjg
9	2	吴芳华	培训专员		助力员工成长	13800002003	wufh@company.com	7	1	1	t	2025-12-16 12:28:02	2025-12-17 16:00:08.888673	wufanghua	wfh
10	3	郑伟强	财务总监		精准核算，合规经营	13800003001	zhengwq@company.com	\N	0	0	t	2025-12-16 12:28:02	2025-12-17 16:00:08.888673	zhengweiqiang	zwq
11	3	钱丽娟	会计主管		严谨细致是我的原则	13800003002	qianlj@company.com	10	1	0	t	2025-12-16 12:28:02	2025-12-17 16:00:08.888673	qianlijuan	qlj
12	3	许志明	出纳		安全高效处理资金	13800003003	xuzm@company.com	10	1	1	t	2025-12-16 12:28:02	2025-12-17 16:00:08.888673	xuzhiming	xzm
13	4	冯晓燕	市场总监		创意驱动增长	13800004001	fengxy@company.com	\N	0	0	t	2025-12-16 12:28:02	2025-12-17 16:00:08.888673	fengxiaoyan	fxy
14	4	卫国栋	品牌主管		打造卓越品牌	13800004002	weigd@company.com	13	1	0	t	2025-12-16 12:28:02	2025-12-17 16:00:08.888673	weiguodong	wgd
15	4	沈美玲	市场专员		洞察市场趋势	13800004003	shenml@company.com	13	1	1	t	2025-12-16 12:28:02	2025-12-17 16:00:08.888673	shenmeiling	sml
16	5	何建华	行政总监		服务至上，高效运转	13800005001	hejh@company.com	\N	0	0	t	2025-12-16 12:28:02	2025-12-17 16:00:08.888673	hejianhua	hjh
17	5	彭小芳	行政主管		细节决定品质	13800005002	pengxf@company.com	16	1	0	t	2025-12-16 12:28:02	2025-12-17 16:00:08.888673	pengxiaofang	pxf
18	5	曹志远	后勤专员		保障日常运营	13800005003	caozy@company.com	16	1	1	t	2025-12-16 12:28:02	2025-12-17 16:00:08.888673	caozhiyuan	czy
\.


--
-- TOC entry 5141 (class 0 OID 16824)
-- Dependencies: 230
-- Data for Name: folders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.folders (id, user_uuid, name, parent_id, category, icon, color, sort_order, is_collapsed, created_at, updated_at) FROM stdin;
6	11079a45-5b58-42bc-9bd7-cd4630dfeaec	cx	\N	sites	Folder	#6b7280	1	f	2025-12-16 12:54:52	2025-12-16 12:54:52
7	11079a45-5b58-42bc-9bd7-cd4630dfeaec	cxc	\N	files	Folder	#6b7280	1	f	2025-12-16 12:55:08	2025-12-16 12:55:08
8	ae42c436-7415-465f-8a49-b5f182e6c005	cv	\N	sites	Folder	#6b7280	1	f	2025-12-17 08:14:43.08412	2025-12-17 08:14:43.08412
9	ae42c436-7415-465f-8a49-b5f182e6c005	vcv	8	sites	Folder	#6b7280	1	f	2025-12-17 08:14:55.271582	2025-12-17 08:14:55.271582
10	ae42c436-7415-465f-8a49-b5f182e6c005	vcvv	\N	sites	Folder	#6b7280	2	f	2025-12-17 08:52:54.611025	2025-12-17 08:52:54.611025
\.


--
-- TOC entry 5149 (class 0 OID 16925)
-- Dependencies: 238
-- Data for Name: quotes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quotes (id, content, author, source, category, is_active, display_count, created_at, updated_at) FROM stdin;
18	Code is like humor. When you have to explain it, it's bad.	Cory House		tech	t	53	2025-12-16 12:28:02	2025-12-17 20:20:02.671602
1	千里之行，始于足下。	老子	道德经	philosophy	t	49	2025-12-16 12:28:02	2025-12-17 20:23:49.189485
2	不积跬步，无以至千里；不积小流，无以成江海。	荀子	劝学	philosophy	t	51	2025-12-16 12:28:02	2025-12-17 18:16:30.402099
3	学而不思则罔，思而不学则殆。	孔子	论语	learning	t	45	2025-12-16 12:28:02	2025-12-17 19:53:31.932481
4	业精于勤，荒于嬉；行成于思，毁于随。	韩愈	进学解	motivation	t	58	2025-12-16 12:28:02	2025-12-17 20:23:49.189485
6	宝剑锋从磨砺出，梅花香自苦寒来。		警世贤文	motivation	t	47	2025-12-16 12:28:02	2025-12-17 20:23:49.189485
8	世上无难事，只怕有心人。		谚语	motivation	t	53	2025-12-16 12:28:02	2025-12-17 20:23:49.189485
10	吾生也有涯，而知也无涯。	庄子	养生主	philosophy	t	53	2025-12-16 12:28:02	2025-12-17 20:23:49.189485
12	The only way to do great work is to love what you do.	Steve Jobs		motivation	t	56	2025-12-16 12:28:02	2025-12-17 20:23:49.189485
13	Innovation distinguishes between a leader and a follower.	Steve Jobs		innovation	t	47	2025-12-16 12:28:02	2025-12-17 20:23:49.189485
14	Talk is cheap. Show me the code.	Linus Torvalds		tech	t	57	2025-12-16 12:28:02	2025-12-17 20:23:49.189485
15	First, solve the problem. Then, write the code.	John Johnson		tech	t	57	2025-12-16 12:28:02	2025-12-17 20:23:49.189485
17	Simplicity is the soul of efficiency.	Austin Freeman		tech	t	55	2025-12-16 12:28:02	2025-12-17 20:23:49.189485
7	路漫漫其修远兮，吾将上下而求索。	屈原	离骚	motivation	t	50	2025-12-16 12:28:02	2025-12-17 20:17:38.817826
16	Any fool can write code that a computer can understand. Good programmers write code that humans can understand.	Martin Fowler	Refactoring	tech	t	48	2025-12-16 12:28:02	2025-12-17 20:17:38.817826
5	天行健，君子以自强不息。		周易	motivation	t	52	2025-12-16 12:28:02	2025-12-17 20:20:02.671602
9	知之为知之，不知为不知，是知也。	孔子	论语	learning	t	55	2025-12-16 12:28:02	2025-12-17 20:20:02.671602
11	Stay hungry, stay foolish.	Steve Jobs	Stanford Commencement Speech	motivation	t	43	2025-12-16 12:28:02	2025-12-17 20:20:02.671602
\.


--
-- TOC entry 5151 (class 0 OID 16941)
-- Dependencies: 240
-- Data for Name: search_history; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.search_history (id, keyword, search_count, last_searched_at, created_at) FROM stdin;
1	xz	1	2025-12-16 11:23:03	2025-12-16 11:23:03
2	x	1	2025-12-16 11:23:04	2025-12-16 11:23:04
3	王	2	2025-12-16 11:30:53	2025-12-16 11:30:27
4	b	1	2025-12-16 11:30:32	2025-12-16 11:30:32
7	claude	2	2025-12-16 11:47:35	2025-12-16 11:43:04
8	clau	1	2025-12-16 11:47:35	2025-12-16 11:47:35
9	bd	2	2025-12-16 11:57:12	2025-12-16 11:53:29
10	fd	1	2025-12-16 12:12:16	2025-12-16 12:12:16
11	f	1	2025-12-16 12:12:18	2025-12-16 12:12:18
12	baud	1	2025-12-17 07:28:18.363823	2025-12-17 07:28:18.363823
13	baidu	1	2025-12-17 07:35:39.035833	2025-12-17 07:35:39.035833
15	baisa	1	2025-12-17 07:35:41.147077	2025-12-17 07:35:41.147077
16	baas	1	2025-12-17 07:35:42.44414	2025-12-17 07:35:42.44414
17	baa	1	2025-12-17 07:35:43.79186	2025-12-17 07:35:43.79186
18	ba	1	2025-12-17 07:35:44.793799	2025-12-17 07:35:44.793799
19	bao	1	2025-12-17 07:35:45.064518	2025-12-17 07:35:45.064518
14	bai	2	2025-12-17 15:35:45.925632	2025-12-17 07:35:40.217537
20	bin x	1	2025-12-17 07:35:49.269262	2025-12-17 07:35:49.269262
21	mus	1	2025-12-17 07:35:51.759194	2025-12-17 07:35:51.759194
22	huan	1	2025-12-17 07:35:54.614335	2025-12-17 07:35:54.614335
23	hu	1	2025-12-17 07:35:55.688578	2025-12-17 07:35:55.688578
26	ioj	1	2025-12-17 07:36:09.589979	2025-12-17 07:36:09.589979
27	mushu	1	2025-12-17 07:36:12.184376	2025-12-17 07:36:12.184376
28	mush	1	2025-12-17 07:36:13.124535	2025-12-17 07:36:13.124535
29	ioc	1	2025-12-17 07:36:15.030161	2025-12-17 07:36:15.030161
30	io	1	2025-12-17 07:36:15.814245	2025-12-17 07:36:15.815261
31	xo	1	2025-12-17 07:36:24.211496	2025-12-17 07:36:24.211496
32	con	1	2025-12-17 07:36:25.976345	2025-12-17 07:36:25.976345
33	穆	1	2025-12-17 07:36:41.94925	2025-12-17 07:36:41.94925
34	六	1	2025-12-17 07:36:46.046534	2025-12-17 07:36:46.046534
35	刘	1	2025-12-17 07:36:48.219146	2025-12-17 07:36:48.219146
37	com	1	2025-12-17 07:36:58.75616	2025-12-17 07:36:58.75616
38	sam	1	2025-12-17 07:37:00.76534	2025-12-17 07:37:00.76534
39	sa	1	2025-12-17 07:37:01.54898	2025-12-17 07:37:01.54898
40	s	2	2025-12-17 15:37:05.546999	2025-12-17 07:37:02.420671
42	zhan	1	2025-12-17 07:52:34.707908	2025-12-17 07:52:34.707908
44	zhaa	1	2025-12-17 07:52:37.327725	2025-12-17 07:52:37.327725
45	zhi	1	2025-12-17 07:52:39.515029	2025-12-17 07:52:39.515029
46	cin	1	2025-12-17 07:52:42.927823	2025-12-17 07:52:42.927823
47	kanban	2	2025-12-17 15:52:46.787859	2025-12-17 07:52:46.753982
48	kan	1	2025-12-17 07:52:48.016665	2025-12-17 07:52:48.016665
49	ka	1	2025-12-17 07:52:48.935181	2025-12-17 07:52:48.935181
50	k	1	2025-12-17 07:52:49.601309	2025-12-17 07:52:49.601309
25	shu	4	2025-12-17 15:54:59.393534	2025-12-17 07:36:06.411145
43	zha	2	2025-12-17 15:55:07.130033	2025-12-17 07:52:35.18444
52	dmi	1	2025-12-17 07:55:08.441729	2025-12-17 07:55:08.441729
53	wna	1	2025-12-17 07:58:04.61662	2025-12-17 07:58:04.61662
55	wwang	1	2025-12-17 07:58:06.459051	2025-12-17 07:58:06.459051
57	hsua	1	2025-12-17 08:01:08.33383	2025-12-17 08:01:08.33383
58	h	1	2025-12-17 08:01:09.381895	2025-12-17 08:01:09.381895
60	hao	1	2025-12-17 08:01:21.965147	2025-12-17 08:01:21.965147
61	婷	1	2025-12-17 08:01:34.690606	2025-12-17 08:01:34.690606
62	han	2	2025-12-17 16:08:33.171477	2025-12-17 08:08:31.584652
63	zahng	1	2025-12-17 08:08:43.924201	2025-12-17 08:08:43.924201
66	zhuxn	1	2025-12-17 08:08:51.351821	2025-12-17 08:08:51.351821
65	zhu	2	2025-12-17 16:08:52.510366	2025-12-17 08:08:49.793362
67	zhua	1	2025-12-17 08:08:53.42602	2025-12-17 08:08:53.42602
59	ha	2	2025-12-17 16:08:56.254603	2025-12-17 08:01:09.718683
51	zhao	2	2025-12-17 16:08:59.543647	2025-12-17 07:55:06.493644
68	xu	1	2025-12-17 08:09:02.610579	2025-12-17 08:09:02.610579
41	zhang	5	2025-12-17 16:13:21.013047	2025-12-17 07:52:34.0241
69	zgabf	1	2025-12-17 08:13:25.258357	2025-12-17 08:13:25.258357
70	zg	1	2025-12-17 08:13:26.610558	2025-12-17 08:13:26.610558
64	z	2	2025-12-17 16:13:27.325923	2025-12-17 08:08:45.201947
71	ren	1	2025-12-17 08:13:30.019632	2025-12-17 08:13:30.019632
72	renyuan	1	2025-12-17 08:13:30.500306	2025-12-17 08:13:30.500306
73	renyua	1	2025-12-17 08:13:31.198247	2025-12-17 08:13:31.198247
74	zhuren	2	2025-12-17 16:13:33.603515	2025-12-17 08:13:33.023113
75	zhure	1	2025-12-17 08:13:33.94018	2025-12-17 08:13:33.94018
76	ming	1	2025-12-17 08:13:35.388388	2025-12-17 08:13:35.388388
77	min	1	2025-12-17 08:13:36.940943	2025-12-17 08:13:36.940943
24	mu	7	2025-12-17 16:13:38.212626	2025-12-17 07:36:04.209312
54	wnag	2	2025-12-17 16:13:48.522137	2025-12-17 07:58:04.797413
78	wn	1	2025-12-17 08:13:49.573412	2025-12-17 08:13:49.573412
81	wangy	1	2025-12-17 08:13:54.866945	2025-12-17 08:13:54.866945
83	wa	1	2025-12-17 08:13:57.253058	2025-12-17 08:13:57.253058
5	w	4	2025-12-17 16:13:57.8181	2025-12-16 11:30:40
84	wanh	1	2025-12-17 08:14:04.029158	2025-12-17 08:14:04.029158
85	wanhg	1	2025-12-17 08:14:04.540527	2025-12-17 08:14:04.540527
86	wanhgyi	1	2025-12-17 08:14:04.884445	2025-12-17 08:14:04.884445
87	liuh	1	2025-12-17 08:14:11.940232	2025-12-17 08:14:11.940232
88	liuha	1	2025-12-17 08:14:12.174174	2025-12-17 08:14:12.174174
36	liu	8	2025-12-17 16:14:12.978174	2025-12-17 07:36:54.027421
89	liuc	1	2025-12-17 08:14:13.772708	2025-12-17 08:14:13.772708
90	liucc	1	2025-12-17 08:14:13.990406	2025-12-17 08:14:13.990406
56	li	4	2025-12-17 16:14:14.852636	2025-12-17 08:01:04.090933
91	mei	1	2025-12-17 08:14:17.342343	2025-12-17 08:14:17.342343
92	m	1	2025-12-17 08:14:18.597923	2025-12-17 08:14:18.597923
93	jiu	1	2025-12-17 08:14:20.144048	2025-12-17 08:14:20.144048
94	cx	1	2025-12-17 08:15:05.825385	2025-12-17 08:15:05.825385
96	wnagyiyun	1	2025-12-17 08:15:10.608376	2025-12-17 08:15:10.608376
82	wan	3	2025-12-17 16:15:17.911998	2025-12-17 08:13:56.214708
97	网易云	1	2025-12-17 08:15:20.607267	2025-12-17 08:15:20.607267
98	cxc	1	2025-12-17 08:15:31.350269	2025-12-17 08:15:31.350269
99	mushuhan	1	2025-12-17 08:15:36.288038	2025-12-17 08:15:36.288038
100	mushuha	1	2025-12-17 08:15:37.394509	2025-12-17 08:15:37.394509
101	wangyi	1	2025-12-17 08:15:44.581107	2025-12-17 08:15:44.581107
79	wangyiyu	4	2025-12-17 16:15:44.879648	2025-12-17 08:13:52.96679
80	wangyiyun	4	2025-12-17 16:15:45.075747	2025-12-17 08:13:53.184338
102	hzang	1	2025-12-17 08:21:11.44948	2025-12-17 08:21:11.44948
6	wang	11	2025-12-17 16:21:16.549902	2025-12-16 11:30:45
95	wnagyi	2	2025-12-17 16:21:18.963983	2025-12-17 08:15:09.006406
103	wnagy	1	2025-12-17 08:21:19.646144	2025-12-17 08:21:19.646144
104	wyy	2	2025-12-17 16:21:31.823378	2025-12-17 08:21:21.755598
105	zhuye	1	2025-12-17 08:21:38.518376	2025-12-17 08:21:38.518376
106	QQ	2	2025-12-17 16:21:53.111763	2025-12-17 08:21:41.762937
\.


--
-- TOC entry 5133 (class 0 OID 16741)
-- Dependencies: 222
-- Data for Name: sections; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sections (id, category_id, name, description, sort_order, created_at, updated_at) FROM stdin;
1	2	搜索引擎	各大搜索引擎入口	0	2025-12-16 12:28:02	2025-12-16 12:28:02
2	2	在线翻译	多语言翻译工具	1	2025-12-16 12:28:02	2025-12-16 12:28:02
3	2	文档办公	在线文档和办公工具	2	2025-12-16 12:28:02	2025-12-16 12:28:02
4	2	AI工具	人工智能相关工具	3	2025-12-16 12:28:02	2025-12-16 12:28:02
5	3	代码托管	Git代码托管平台	0	2025-12-16 12:28:02	2025-12-16 12:28:02
6	3	技术社区	程序员社区和论坛	1	2025-12-16 12:28:02	2025-12-16 12:28:02
7	3	开发文档	各类技术文档	2	2025-12-16 12:28:02	2025-12-16 12:28:02
8	3	在线工具	开发者在线工具	3	2025-12-16 12:28:02	2025-12-16 12:28:02
9	4	设计工具	在线设计工具	0	2025-12-16 12:28:02	2025-12-16 12:28:02
10	4	图标素材	图标和素材资源	1	2025-12-16 12:28:02	2025-12-16 12:28:02
11	4	配色方案	配色工具和灵感	2	2025-12-16 12:28:02	2025-12-16 12:28:02
12	5	在线课程	在线学习平台	0	2025-12-16 12:28:02	2025-12-16 12:28:02
13	5	编程学习	编程教学资源	1	2025-12-16 12:28:02	2025-12-16 12:28:02
14	5	知识百科	百科和知识库	2	2025-12-16 12:28:02	2025-12-16 12:28:02
15	6	视频平台	主流视频网站	0	2025-12-16 12:28:02	2025-12-16 12:28:02
16	6	音乐平台	音乐播放平台	1	2025-12-16 12:28:02	2025-12-16 12:28:02
17	6	直播平台	直播网站	2	2025-12-16 12:28:02	2025-12-16 12:28:02
18	7	社交网络	社交媒体平台	0	2025-12-16 12:28:02	2025-12-16 12:28:02
19	7	即时通讯	在线聊天工具	1	2025-12-16 12:28:02	2025-12-16 12:28:02
20	8	综合新闻	新闻门户网站	0	2025-12-16 12:28:02	2025-12-16 12:28:02
21	8	科技资讯	科技新闻网站	1	2025-12-16 12:28:02	2025-12-16 12:28:02
22	9	综合电商	综合购物平台	0	2025-12-16 12:28:02	2025-12-16 12:28:02
23	9	数码科技	数码产品商城	1	2025-12-16 12:28:02	2025-12-16 12:28:02
\.


--
-- TOC entry 5131 (class 0 OID 16729)
-- Dependencies: 220
-- Data for Name: sidebar_categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sidebar_categories (id, name, icon, sort_order, is_system, created_at, updated_at) FROM stdin;
1	自定义工作台	Briefcase	0	t	2025-12-16 12:28:02	2025-12-16 12:28:02
2	常用工具	Tools	1	f	2025-12-16 12:28:02	2025-12-16 12:28:02
3	技术开发	Code	2	f	2025-12-16 12:28:02	2025-12-16 12:28:02
4	设计资源	Palette	3	f	2025-12-16 12:28:02	2025-12-16 12:28:02
5	学习教育	BookOpen	4	f	2025-12-16 12:28:02	2025-12-16 12:28:02
6	影音娱乐	Film	5	f	2025-12-16 12:28:02	2025-12-16 12:28:02
7	社交媒体	Users	6	f	2025-12-16 12:28:02	2025-12-16 12:28:02
8	新闻资讯	Newspaper	7	f	2025-12-16 12:28:02	2025-12-16 12:28:02
9	购物电商	ShoppingCart	8	f	2025-12-16 12:28:02	2025-12-16 12:28:02
\.


--
-- TOC entry 5153 (class 0 OID 16951)
-- Dependencies: 242
-- Data for Name: system_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.system_settings (id, setting_key, setting_value, description, created_at, updated_at) FROM stdin;
1	site_name	NavHub	网站名称	2025-12-16 12:28:02	2025-12-16 12:28:02
2	site_logo	/logo.svg	网站Logo	2025-12-16 12:28:02	2025-12-16 12:28:02
3	default_search_engine	baidu	默认搜索引擎	2025-12-16 12:28:02	2025-12-16 12:28:02
4	footer_copyright	© 2024 NavHub. All rights reserved.	页脚版权信息	2025-12-16 12:28:02	2025-12-16 12:28:02
5	footer_contact	contact@navhub.com	联系邮箱	2025-12-16 12:28:02	2025-12-16 12:28:02
6	theme_mode	system	主题模式（light/dark/system）	2025-12-16 12:28:02	2025-12-16 12:28:02
\.


--
-- TOC entry 5145 (class 0 OID 16866)
-- Dependencies: 234
-- Data for Name: user_files; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_files (id, user_uuid, folder_id, filename, storage_path, file_type, file_size, row_count, column_count, columns_info, sort_order, is_starred, created_at, updated_at) FROM stdin;
1	11079a45-5b58-42bc-9bd7-cd4630dfeaec	\N	成绩信息cc.xlsx	C:\\\\Users\\\\1\\\\Desktop\\\\second-project\\\\server-net\\\\data_storage\\\\user_files\\\\11079a45-5b58-42bc-9bd7-cd4630dfeaec\\\\11079a45-5b58-42bc-9bd7-cd4630dfeaec_202ad0e7f6be472ca0f54516c17f6eb4_20251216202352.xlsx	xlsx	22691	104	20	[{"name": "学号", "dtype": "int64"}, {"name": "姓名", "dtype": "object"}, {"name": "课程门数", "dtype": "int64"}, {"name": "MySQL数据库应用基础，专业基础课，必修，学分3，学时48，2022-2023-2", "dtype": "float64"}, {"name": "数据预处理技术，专业基础课，必修，学分3，学时60，2022-2023-2", "dtype": "float64"}, {"name": "Python编程基础，专业基础课，必修，学分4，学时60，2022-2023-2", "dtype": "float64"}, {"name": "Java程序设计，专业基础课，必修，学分3，学时60，2022-2023-2", "dtype": "float64"}, {"name": "数据采集技术，专业课，必修，学分6，学时96，2023-2024-1", "dtype": "int64"}, {"name": "Java Web程序设计，专业选修课，必修，学分3，学时60，2023-2024-1", "dtype": "int64"}, {"name": "Hadoop开发技术，专业课，必修，学分6，学时96，2023-2024-1", "dtype": "int64"}, {"name": "Linux服务器管理与维护，专业选修课，必修，学分3，学时60，2023-2024-1", "dtype": "int64"}, {"name": "Python高级编程，专业课，必修，学分3，学时60，2023-2024-1", "dtype": "int64"}, {"name": "Spark大数据处理与分析3，专业课，必修，学分9，学时60，2023-2024-1", "dtype": "int64"}, {"name": "不及格门数", "dtype": "int64"}, {"name": "平均分", "dtype": "float64"}, {"name": "总分", "dtype": "int64"}, {"name": "所得学分", "dtype": "int64"}, {"name": "平均学分绩", "dtype": "float64"}, {"name": "平均学分绩点", "dtype": "int64"}, {"name": "排名", "dtype": "float64"}]	1	f	2025-12-16 12:23:53	2025-12-16 12:55:19
\.


--
-- TOC entry 5147 (class 0 OID 16893)
-- Dependencies: 236
-- Data for Name: user_sites; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_sites (id, user_uuid, website_id, folder_id, custom_name, custom_url, custom_icon, custom_description, sort_order, click_count, created_at, updated_at) FROM stdin;
2	11079a45-5b58-42bc-9bd7-cd4630dfeaec	5	\N	\N	\N	\N	\N	1	0	2025-12-16 12:12:19	2025-12-16 12:41:18
3	ae42c436-7415-465f-8a49-b5f182e6c005	2	\N	\N	\N	\N	\N	1	0	2025-12-17 08:14:35.770663	2025-12-17 08:14:35.770663
4	ae42c436-7415-465f-8a49-b5f182e6c005	42	\N	\N	\N	\N	\N	2	0	2025-12-17 08:21:24.120584	2025-12-17 08:21:24.120584
5	ae42c436-7415-465f-8a49-b5f182e6c005	48	\N	\N	\N	\N	\N	3	0	2025-12-17 08:21:44.145925	2025-12-17 08:21:44.145925
6	ae42c436-7415-465f-8a49-b5f182e6c005	43	\N	\N	\N	\N	\N	4	0	2025-12-17 08:21:55.925699	2025-12-17 08:21:55.925699
\.


--
-- TOC entry 5129 (class 0 OID 16718)
-- Dependencies: 218
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (uuid, created_at, last_active_at, settings) FROM stdin;
ae42c436-7415-465f-8a49-b5f182e6c005	2025-12-16 04:29:03	2025-12-17 20:29:34.827921	{}
11079a45-5b58-42bc-9bd7-cd4630dfeaec	2025-12-16 04:31:15	2025-12-17 20:23:52.071494	{}
\.


--
-- TOC entry 5135 (class 0 OID 16757)
-- Dependencies: 224
-- Data for Name: websites; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.websites (id, section_id, name, url, icon, description, pinyin, pinyin_initials, sort_order, click_count, is_hot, created_at, updated_at) FROM stdin;
2	1	Google	https://www.google.com	https://www.google.com/favicon.ico	全球最大的搜索引擎	google	gl	1	2	t	2025-12-16 12:28:02	2025-12-16 12:12:21
3	1	Bing	https://www.bing.com	https://www.bing.com/favicon.ico	微软搜索引擎	bing	bg	2	1	f	2025-12-16 12:28:02	2025-12-16 12:00:12
4	1	搜狗	https://www.sogou.com	https://www.sogou.com/favicon.ico	搜狗搜索引擎	sougou	sg	3	0	f	2025-12-16 12:28:02	2025-12-16 12:28:02
5	2	百度翻译	https://fanyi.baidu.com	https://fanyi.baidu.com/favicon.ico	百度在线翻译	baidufanyi	bdfy	0	1	t	2025-12-16 12:28:02	2025-12-16 11:26:32
6	2	Google翻译	https://translate.google.com	https://translate.google.com/favicon.ico	谷歌在线翻译	googlefanyi	glfy	1	1	t	2025-12-16 12:28:02	2025-12-16 11:28:16
7	2	DeepL	https://www.deepl.com/translator	https://www.deepl.com/favicon.ico	AI翻译工具	deepl	dl	2	1	t	2025-12-16 12:28:02	2025-12-16 11:57:32
8	3	腾讯文档	https://docs.qq.com	https://docs.qq.com/favicon.ico	腾讯在线文档协作	tengxunwendang	txwd	0	0	t	2025-12-16 12:28:02	2025-12-16 12:28:02
9	3	石墨文档	https://shimo.im	https://shimo.im/favicon.ico	云端Office办公	shimowendang	smwd	1	1	f	2025-12-16 12:28:02	2025-12-16 11:57:37
10	3	语雀	https://www.yuque.com	https://www.yuque.com/favicon.ico	阿里知识库	yuque	yq	2	0	t	2025-12-16 12:28:02	2025-12-16 12:28:02
11	3	Notion	https://www.notion.so	https://www.notion.so/favicon.ico	全能工作空间	notion	nt	3	0	t	2025-12-16 12:28:02	2025-12-16 12:28:02
12	4	ChatGPT	https://chat.openai.com	https://chat.openai.com/favicon.ico	OpenAI对话AI	chatgpt	cgpt	0	0	t	2025-12-16 12:28:02	2025-12-16 12:28:02
13	4	文心一言	https://yiyan.baidu.com	https://yiyan.baidu.com/favicon.ico	百度AI助手	wenxinyiyan	wxyy	1	0	t	2025-12-16 12:28:02	2025-12-16 12:28:02
14	4	通义千问	https://tongyi.aliyun.com	https://tongyi.aliyun.com/favicon.ico	阿里AI助手	tongyiqianwen	tyqw	2	0	t	2025-12-16 12:28:02	2025-12-16 12:28:02
16	5	GitHub	https://github.com	https://github.com/favicon.ico	全球最大代码托管平台	github	gh	0	0	t	2025-12-16 12:28:02	2025-12-16 12:28:02
17	5	Gitee	https://gitee.com	https://gitee.com/favicon.ico	国内代码托管平台	gitee	ge	1	0	t	2025-12-16 12:28:02	2025-12-16 12:28:02
18	5	GitLab	https://gitlab.com	https://gitlab.com/favicon.ico	开源代码托管平台	gitlab	gl	2	0	f	2025-12-16 12:28:02	2025-12-16 12:28:02
19	6	掘金	https://juejin.cn	https://juejin.cn/favicon.ico	开发者社区	juejin	jj	0	0	t	2025-12-16 12:28:02	2025-12-16 12:28:02
20	6	CSDN	https://www.csdn.net	https://www.csdn.net/favicon.ico	中文IT社区	csdn	csdn	1	0	t	2025-12-16 12:28:02	2025-12-16 12:28:02
21	6	Stack Overflow	https://stackoverflow.com	https://stackoverflow.com/favicon.ico	程序员问答社区	stackoverflow	so	2	0	t	2025-12-16 12:28:02	2025-12-16 12:28:02
22	6	博客园	https://www.cnblogs.com	https://www.cnblogs.com/favicon.ico	开发者博客平台	bokeyuan	bky	3	0	f	2025-12-16 12:28:02	2025-12-16 12:28:02
23	7	MDN Web Docs	https://developer.mozilla.org	https://developer.mozilla.org/favicon.ico	Web开发文档	mdn	mdn	0	0	t	2025-12-16 12:28:02	2025-12-16 12:28:02
24	7	Vue.js	https://vuejs.org	https://vuejs.org/favicon.ico	Vue框架官方文档	vuejs	vj	1	0	t	2025-12-16 12:28:02	2025-12-16 12:28:02
25	7	React	https://react.dev	https://react.dev/favicon.ico	React框架官方文档	react	rt	2	0	t	2025-12-16 12:28:02	2025-12-16 12:28:02
26	8	CodePen	https://codepen.io	https://codepen.io/favicon.ico	在线代码编辑器	codepen	cp	0	0	t	2025-12-16 12:28:02	2025-12-16 12:28:02
27	8	JSFiddle	https://jsfiddle.net	https://jsfiddle.net/favicon.ico	在线代码测试	jsfiddle	jsf	1	0	f	2025-12-16 12:28:02	2025-12-16 12:28:02
28	9	Figma	https://www.figma.com	https://www.figma.com/favicon.ico	在线UI设计工具	figma	fg	0	0	t	2025-12-16 12:28:02	2025-12-16 12:28:02
29	9	Canva	https://www.canva.com	https://www.canva.com/favicon.ico	在线设计平台	canva	cv	1	0	t	2025-12-16 12:28:02	2025-12-16 12:28:02
30	9	即时设计	https://js.design	https://js.design/favicon.ico	国产在线设计工具	jishisheji	jssj	2	0	t	2025-12-16 12:28:02	2025-12-16 12:28:02
31	10	iconfont	https://www.iconfont.cn	https://www.iconfont.cn/favicon.ico	阿里图标库	iconfont	if	0	0	t	2025-12-16 12:28:02	2025-12-16 12:28:02
32	10	Unsplash	https://unsplash.com	https://unsplash.com/favicon.ico	免费高清图片	unsplash	us	1	0	t	2025-12-16 12:28:02	2025-12-16 12:28:02
33	11	Coolors	https://coolors.co	https://coolors.co/favicon.ico	配色生成器	coolors	cl	0	0	t	2025-12-16 12:28:02	2025-12-16 12:28:02
34	12	慕课网	https://www.imooc.com	https://www.imooc.com/favicon.ico	IT技能学习平台	mukewang	mkw	0	0	t	2025-12-16 12:28:02	2025-12-16 12:28:02
35	12	Coursera	https://www.coursera.org	https://www.coursera.org/favicon.ico	全球在线学习平台	coursera	csr	1	0	t	2025-12-16 12:28:02	2025-12-16 12:28:02
36	13	LeetCode	https://leetcode.cn	https://leetcode.cn/favicon.ico	算法刷题平台	leetcode	lc	0	0	t	2025-12-16 12:28:02	2025-12-16 12:28:02
37	13	菜鸟教程	https://www.runoob.com	https://www.runoob.com/favicon.ico	编程入门教程	cainiaojiaocheng	cnjc	1	0	t	2025-12-16 12:28:02	2025-12-16 12:28:02
38	14	维基百科	https://zh.wikipedia.org	https://zh.wikipedia.org/favicon.ico	自由的百科全书	weijibaike	wjbk	0	0	t	2025-12-16 12:28:02	2025-12-16 12:28:02
39	14	知乎	https://www.zhihu.com	https://www.zhihu.com/favicon.ico	知识问答社区	zhihu	zh	1	0	t	2025-12-16 12:28:02	2025-12-16 12:28:02
40	15	Bilibili	https://www.bilibili.com	https://www.bilibili.com/favicon.ico	B站视频平台	bilibili	blbl	0	0	t	2025-12-16 12:28:02	2025-12-16 12:28:02
41	15	YouTube	https://www.youtube.com	https://www.youtube.com/favicon.ico	全球视频平台	youtube	ytb	1	0	t	2025-12-16 12:28:02	2025-12-16 12:28:02
43	16	QQ音乐	https://y.qq.com	https://y.qq.com/favicon.ico	QQ音乐	qqyinyue	qqyy	1	0	t	2025-12-16 12:28:02	2025-12-16 12:28:02
44	17	斗鱼	https://www.douyu.com	https://www.douyu.com/favicon.ico	斗鱼直播	douyu	dy	0	0	t	2025-12-16 12:28:02	2025-12-16 12:28:02
45	17	虎牙	https://www.huya.com	https://www.huya.com/favicon.ico	虎牙直播	huya	hy	1	0	t	2025-12-16 12:28:02	2025-12-16 12:28:02
46	18	微博	https://weibo.com	https://weibo.com/favicon.ico	新浪微博	weibo	wb	0	0	t	2025-12-16 12:28:02	2025-12-16 12:28:02
47	18	Twitter/X	https://twitter.com	https://twitter.com/favicon.ico	推特社交平台	twitter	tt	1	0	t	2025-12-16 12:28:02	2025-12-16 12:28:02
48	19	QQ邮箱	https://mail.qq.com	https://mail.qq.com/favicon.ico	QQ邮箱	qqyouxiang	qqyx	0	0	t	2025-12-16 12:28:02	2025-12-16 12:28:02
49	19	Gmail	https://mail.google.com	https://mail.google.com/favicon.ico	谷歌邮箱	gmail	gm	1	0	t	2025-12-16 12:28:02	2025-12-16 12:28:02
15	4	Claude	https://claude.ai	https://claude.ai/favicon.ico	Anthropic AI助手	claude	cd	3	8	t	2025-12-16 12:28:02	2025-12-17 16:22:58.447959
1	1	百度	https://www.baidu.com	https://www.baidu.com/favicon.ico	全球最大的中文搜索引擎	baidu	bd	0	6	t	2025-12-16 12:28:02	2025-12-17 16:23:14.516108
50	20	今日头条	https://www.toutiao.com	https://www.toutiao.com/favicon.ico	今日头条新闻	jinritoutiao	jrtt	0	0	t	2025-12-16 12:28:02	2025-12-16 12:28:02
51	21	36氪	https://36kr.com	https://36kr.com/favicon.ico	创业科技媒体	36ke	36k	0	0	t	2025-12-16 12:28:02	2025-12-16 12:28:02
52	21	虎嗅	https://www.huxiu.com	https://www.huxiu.com/favicon.ico	科技商业媒体	huxiu	hx	1	0	t	2025-12-16 12:28:02	2025-12-16 12:28:02
53	22	淘宝	https://www.taobao.com	https://www.taobao.com/favicon.ico	淘宝购物	taobao	tb	0	0	t	2025-12-16 12:28:02	2025-12-16 12:28:02
54	22	京东	https://www.jd.com	https://www.jd.com/favicon.ico	京东商城	jingdong	jd	1	0	t	2025-12-16 12:28:02	2025-12-16 12:28:02
55	23	苹果官网	https://www.apple.com.cn	https://www.apple.com.cn/favicon.ico	Apple中国	pingguoguanwang	pggw	0	0	t	2025-12-16 12:28:02	2025-12-16 12:28:02
56	23	小米商城	https://www.mi.com	https://www.mi.com/favicon.ico	小米官方商城	xiaomishangcheng	xmsc	1	0	t	2025-12-16 12:28:02	2025-12-16 12:28:02
42	16	网易云音乐	https://music.163.com	https://music.163.com/favicon.ico	网易云音乐	wangyiyunyinyue	wyyyy	0	2	t	2025-12-16 12:28:02	2025-12-17 16:22:31.718191
\.


--
-- TOC entry 5172 (class 0 OID 0)
-- Dependencies: 231
-- Name: dashboards_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.dashboards_id_seq', 8, true);


--
-- TOC entry 5173 (class 0 OID 0)
-- Dependencies: 225
-- Name: departments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.departments_id_seq', 5, true);


--
-- TOC entry 5174 (class 0 OID 0)
-- Dependencies: 227
-- Name: employees_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.employees_id_seq', 18, true);


--
-- TOC entry 5175 (class 0 OID 0)
-- Dependencies: 229
-- Name: folders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.folders_id_seq', 10, true);


--
-- TOC entry 5176 (class 0 OID 0)
-- Dependencies: 237
-- Name: quotes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.quotes_id_seq', 18, true);


--
-- TOC entry 5177 (class 0 OID 0)
-- Dependencies: 239
-- Name: search_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.search_history_id_seq', 106, true);


--
-- TOC entry 5178 (class 0 OID 0)
-- Dependencies: 221
-- Name: sections_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sections_id_seq', 23, true);


--
-- TOC entry 5179 (class 0 OID 0)
-- Dependencies: 219
-- Name: sidebar_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sidebar_categories_id_seq', 9, true);


--
-- TOC entry 5180 (class 0 OID 0)
-- Dependencies: 241
-- Name: system_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.system_settings_id_seq', 6, true);


--
-- TOC entry 5181 (class 0 OID 0)
-- Dependencies: 233
-- Name: user_files_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_files_id_seq', 1, true);


--
-- TOC entry 5182 (class 0 OID 0)
-- Dependencies: 235
-- Name: user_sites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_sites_id_seq', 6, true);


--
-- TOC entry 5183 (class 0 OID 0)
-- Dependencies: 223
-- Name: websites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.websites_id_seq', 56, true);


--
-- TOC entry 4933 (class 2606 OID 16859)
-- Name: dashboards dashboards_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dashboards
    ADD CONSTRAINT dashboards_pkey PRIMARY KEY (id);


--
-- TOC entry 4912 (class 2606 OID 16793)
-- Name: departments departments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_pkey PRIMARY KEY (id);


--
-- TOC entry 4916 (class 2606 OID 16812)
-- Name: employees employees_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_pkey PRIMARY KEY (id);


--
-- TOC entry 4928 (class 2606 OID 16836)
-- Name: folders folders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.folders
    ADD CONSTRAINT folders_pkey PRIMARY KEY (id);


--
-- TOC entry 4950 (class 2606 OID 16939)
-- Name: quotes quotes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quotes
    ADD CONSTRAINT quotes_pkey PRIMARY KEY (id);


--
-- TOC entry 4954 (class 2606 OID 16949)
-- Name: search_history search_history_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.search_history
    ADD CONSTRAINT search_history_pkey PRIMARY KEY (id);


--
-- TOC entry 4900 (class 2606 OID 16750)
-- Name: sections sections_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sections
    ADD CONSTRAINT sections_pkey PRIMARY KEY (id);


--
-- TOC entry 4897 (class 2606 OID 16739)
-- Name: sidebar_categories sidebar_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sidebar_categories
    ADD CONSTRAINT sidebar_categories_pkey PRIMARY KEY (id);


--
-- TOC entry 4956 (class 2606 OID 16961)
-- Name: system_settings system_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_pkey PRIMARY KEY (id);


--
-- TOC entry 4958 (class 2606 OID 16963)
-- Name: system_settings system_settings_setting_key_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_setting_key_key UNIQUE (setting_key);


--
-- TOC entry 4942 (class 2606 OID 16881)
-- Name: user_files user_files_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_files
    ADD CONSTRAINT user_files_pkey PRIMARY KEY (id);


--
-- TOC entry 4946 (class 2606 OID 16908)
-- Name: user_sites user_sites_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_sites
    ADD CONSTRAINT user_sites_pkey PRIMARY KEY (id);


--
-- TOC entry 4895 (class 2606 OID 16727)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (uuid);


--
-- TOC entry 4910 (class 2606 OID 16773)
-- Name: websites websites_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.websites
    ADD CONSTRAINT websites_pkey PRIMARY KEY (id);


--
-- TOC entry 4934 (class 1259 OID 16995)
-- Name: idx_dashboards_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_dashboards_user ON public.dashboards USING btree (user_uuid);


--
-- TOC entry 4935 (class 1259 OID 16996)
-- Name: idx_dashboards_visibility; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_dashboards_visibility ON public.dashboards USING btree (visibility);


--
-- TOC entry 4913 (class 1259 OID 16997)
-- Name: idx_departments_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_departments_active ON public.departments USING btree (is_active);


--
-- TOC entry 4914 (class 1259 OID 16998)
-- Name: idx_departments_sort; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_departments_sort ON public.departments USING btree (sort_order);


--
-- TOC entry 4917 (class 1259 OID 16978)
-- Name: idx_employees_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_employees_active ON public.employees USING btree (is_active);


--
-- TOC entry 4918 (class 1259 OID 16976)
-- Name: idx_employees_dept; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_employees_dept ON public.employees USING btree (department_id);


--
-- TOC entry 4919 (class 1259 OID 16975)
-- Name: idx_employees_email_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_employees_email_gin ON public.employees USING gin (email public.gin_trgm_ops);


--
-- TOC entry 4920 (class 1259 OID 16979)
-- Name: idx_employees_level; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_employees_level ON public.employees USING btree (level);


--
-- TOC entry 4921 (class 1259 OID 16972)
-- Name: idx_employees_name_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_employees_name_gin ON public.employees USING gin (name public.gin_trgm_ops);


--
-- TOC entry 4922 (class 1259 OID 16977)
-- Name: idx_employees_parent; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_employees_parent ON public.employees USING btree (parent_id);


--
-- TOC entry 4923 (class 1259 OID 17016)
-- Name: idx_employees_pinyin_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_employees_pinyin_gin ON public.employees USING gin (pinyin public.gin_trgm_ops);


--
-- TOC entry 4924 (class 1259 OID 17017)
-- Name: idx_employees_pinyin_initials_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_employees_pinyin_initials_gin ON public.employees USING gin (pinyin_initials public.gin_trgm_ops);


--
-- TOC entry 4925 (class 1259 OID 16973)
-- Name: idx_employees_pos_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_employees_pos_gin ON public.employees USING gin ("position" public.gin_trgm_ops);


--
-- TOC entry 4926 (class 1259 OID 16974)
-- Name: idx_employees_sig_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_employees_sig_gin ON public.employees USING gin (signature public.gin_trgm_ops);


--
-- TOC entry 4929 (class 1259 OID 16990)
-- Name: idx_folders_category; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_folders_category ON public.folders USING btree (category);


--
-- TOC entry 4930 (class 1259 OID 16989)
-- Name: idx_folders_parent; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_folders_parent ON public.folders USING btree (parent_id);


--
-- TOC entry 4931 (class 1259 OID 16988)
-- Name: idx_folders_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_folders_user ON public.folders USING btree (user_uuid);


--
-- TOC entry 4947 (class 1259 OID 16994)
-- Name: idx_quotes_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_quotes_active ON public.quotes USING btree (is_active);


--
-- TOC entry 4948 (class 1259 OID 16993)
-- Name: idx_quotes_category; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_quotes_category ON public.quotes USING btree (category);


--
-- TOC entry 4951 (class 1259 OID 16986)
-- Name: idx_search_count; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_search_count ON public.search_history USING btree (search_count DESC);


--
-- TOC entry 4952 (class 1259 OID 16985)
-- Name: idx_search_keyword_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_search_keyword_gin ON public.search_history USING gin (keyword public.gin_trgm_ops);


--
-- TOC entry 4898 (class 1259 OID 16987)
-- Name: idx_sections_category; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sections_category ON public.sections USING btree (category_id);


--
-- TOC entry 4936 (class 1259 OID 16980)
-- Name: idx_user_files_filename_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_files_filename_gin ON public.user_files USING gin (filename public.gin_trgm_ops);


--
-- TOC entry 4937 (class 1259 OID 16982)
-- Name: idx_user_files_folder; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_files_folder ON public.user_files USING btree (folder_id);


--
-- TOC entry 4938 (class 1259 OID 16984)
-- Name: idx_user_files_starred; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_files_starred ON public.user_files USING btree (is_starred);


--
-- TOC entry 4939 (class 1259 OID 16983)
-- Name: idx_user_files_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_files_type ON public.user_files USING btree (file_type);


--
-- TOC entry 4940 (class 1259 OID 16981)
-- Name: idx_user_files_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_files_user ON public.user_files USING btree (user_uuid);


--
-- TOC entry 4943 (class 1259 OID 16992)
-- Name: idx_user_sites_folder; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_sites_folder ON public.user_sites USING btree (folder_id);


--
-- TOC entry 4944 (class 1259 OID 16991)
-- Name: idx_user_sites_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_sites_user ON public.user_sites USING btree (user_uuid);


--
-- TOC entry 4901 (class 1259 OID 16970)
-- Name: idx_websites_click; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_websites_click ON public.websites USING btree (click_count DESC);


--
-- TOC entry 4902 (class 1259 OID 16965)
-- Name: idx_websites_desc_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_websites_desc_gin ON public.websites USING gin (description public.gin_trgm_ops);


--
-- TOC entry 4903 (class 1259 OID 16971)
-- Name: idx_websites_hot; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_websites_hot ON public.websites USING btree (is_hot);


--
-- TOC entry 4904 (class 1259 OID 16964)
-- Name: idx_websites_name_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_websites_name_gin ON public.websites USING gin (name public.gin_trgm_ops);


--
-- TOC entry 4905 (class 1259 OID 16966)
-- Name: idx_websites_pinyin_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_websites_pinyin_gin ON public.websites USING gin (pinyin public.gin_trgm_ops);


--
-- TOC entry 4906 (class 1259 OID 16967)
-- Name: idx_websites_pinyin_init_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_websites_pinyin_init_gin ON public.websites USING gin (pinyin_initials public.gin_trgm_ops);


--
-- TOC entry 4907 (class 1259 OID 16969)
-- Name: idx_websites_section; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_websites_section ON public.websites USING btree (section_id);


--
-- TOC entry 4908 (class 1259 OID 16968)
-- Name: idx_websites_url_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_websites_url_gin ON public.websites USING gin (url public.gin_trgm_ops);


--
-- TOC entry 4978 (class 2620 OID 17008)
-- Name: dashboards update_dashboards_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_dashboards_updated_at BEFORE UPDATE ON public.dashboards FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4975 (class 2620 OID 17009)
-- Name: departments update_departments_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_departments_updated_at BEFORE UPDATE ON public.departments FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4976 (class 2620 OID 17010)
-- Name: employees update_employees_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_employees_updated_at BEFORE UPDATE ON public.employees FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4977 (class 2620 OID 17003)
-- Name: folders update_folders_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_folders_updated_at BEFORE UPDATE ON public.folders FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4981 (class 2620 OID 17005)
-- Name: quotes update_quotes_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_quotes_updated_at BEFORE UPDATE ON public.quotes FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4982 (class 2620 OID 17015)
-- Name: search_history update_search_history_timestamp; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_search_history_timestamp BEFORE UPDATE ON public.search_history FOR EACH ROW EXECUTE FUNCTION public.update_last_searched_at_column();


--
-- TOC entry 4973 (class 2620 OID 17001)
-- Name: sections update_sections_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_sections_updated_at BEFORE UPDATE ON public.sections FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4972 (class 2620 OID 17000)
-- Name: sidebar_categories update_sidebar_categories_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_sidebar_categories_updated_at BEFORE UPDATE ON public.sidebar_categories FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4983 (class 2620 OID 17006)
-- Name: system_settings update_system_settings_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_system_settings_updated_at BEFORE UPDATE ON public.system_settings FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4979 (class 2620 OID 17007)
-- Name: user_files update_user_files_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_user_files_updated_at BEFORE UPDATE ON public.user_files FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4980 (class 2620 OID 17004)
-- Name: user_sites update_user_sites_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_user_sites_updated_at BEFORE UPDATE ON public.user_sites FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4971 (class 2620 OID 17013)
-- Name: users update_users_last_active_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_users_last_active_at BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.update_last_active_at_column();


--
-- TOC entry 4974 (class 2620 OID 17002)
-- Name: websites update_websites_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_websites_updated_at BEFORE UPDATE ON public.websites FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4965 (class 2606 OID 16860)
-- Name: dashboards dashboards_user_uuid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dashboards
    ADD CONSTRAINT dashboards_user_uuid_fkey FOREIGN KEY (user_uuid) REFERENCES public.users(uuid) ON DELETE CASCADE;


--
-- TOC entry 4961 (class 2606 OID 16813)
-- Name: employees employees_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_department_id_fkey FOREIGN KEY (department_id) REFERENCES public.departments(id) ON DELETE CASCADE;


--
-- TOC entry 4962 (class 2606 OID 16818)
-- Name: employees employees_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.employees(id) ON DELETE SET NULL;


--
-- TOC entry 4963 (class 2606 OID 16842)
-- Name: folders folders_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.folders
    ADD CONSTRAINT folders_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.folders(id) ON DELETE CASCADE;


--
-- TOC entry 4964 (class 2606 OID 16837)
-- Name: folders folders_user_uuid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.folders
    ADD CONSTRAINT folders_user_uuid_fkey FOREIGN KEY (user_uuid) REFERENCES public.users(uuid) ON DELETE CASCADE;


--
-- TOC entry 4959 (class 2606 OID 16751)
-- Name: sections sections_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sections
    ADD CONSTRAINT sections_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.sidebar_categories(id) ON DELETE CASCADE;


--
-- TOC entry 4966 (class 2606 OID 16887)
-- Name: user_files user_files_folder_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_files
    ADD CONSTRAINT user_files_folder_id_fkey FOREIGN KEY (folder_id) REFERENCES public.folders(id) ON DELETE SET NULL;


--
-- TOC entry 4967 (class 2606 OID 16882)
-- Name: user_files user_files_user_uuid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_files
    ADD CONSTRAINT user_files_user_uuid_fkey FOREIGN KEY (user_uuid) REFERENCES public.users(uuid) ON DELETE CASCADE;


--
-- TOC entry 4968 (class 2606 OID 16919)
-- Name: user_sites user_sites_folder_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_sites
    ADD CONSTRAINT user_sites_folder_id_fkey FOREIGN KEY (folder_id) REFERENCES public.folders(id) ON DELETE SET NULL;


--
-- TOC entry 4969 (class 2606 OID 16909)
-- Name: user_sites user_sites_user_uuid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_sites
    ADD CONSTRAINT user_sites_user_uuid_fkey FOREIGN KEY (user_uuid) REFERENCES public.users(uuid) ON DELETE CASCADE;


--
-- TOC entry 4970 (class 2606 OID 16914)
-- Name: user_sites user_sites_website_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_sites
    ADD CONSTRAINT user_sites_website_id_fkey FOREIGN KEY (website_id) REFERENCES public.websites(id) ON DELETE SET NULL;


--
-- TOC entry 4960 (class 2606 OID 16774)
-- Name: websites websites_section_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.websites
    ADD CONSTRAINT websites_section_id_fkey FOREIGN KEY (section_id) REFERENCES public.sections(id) ON DELETE CASCADE;


-- Completed on 2025-12-17 20:33:19

--
-- PostgreSQL database dump complete
--

\unrestrict xBOAhEY8d2qxskruMdYeKSqex2zgHn0jRV5PXfWW3S52DuouJDdGMVnmGLnA9h1

