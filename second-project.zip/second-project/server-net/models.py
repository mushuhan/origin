from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

db = SQLAlchemy()

class SidebarCategory(db.Model):
    """侧边栏分类模型"""
    __tablename__ = 'sidebar_categories'
    
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    name = db.Column(db.String(50), nullable=False, comment='分类名称')
    icon = db.Column(db.String(100), comment='分类图标')
    sort_order = db.Column(db.Integer, default=0, comment='排序顺序')
    is_system = db.Column(db.Boolean, default=False, comment='是否系统分类')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # 关联分区
    sections = db.relationship('Section', backref='category', lazy='dynamic', cascade='all, delete-orphan')
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'icon': self.icon,
            'sort_order': self.sort_order,
            'is_system': self.is_system,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }
    
    def to_dict_with_sections(self):
        data = self.to_dict()
        data['sections'] = [section.to_dict_with_websites() for section in self.sections.order_by(Section.sort_order).all()]
        return data


class Section(db.Model):
    """网址分区模型"""
    __tablename__ = 'sections'
    
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    category_id = db.Column(db.Integer, db.ForeignKey('sidebar_categories.id'), nullable=False, comment='所属分类ID')
    name = db.Column(db.String(100), nullable=False, comment='分区名称')
    description = db.Column(db.String(255), comment='分区描述')
    sort_order = db.Column(db.Integer, default=0, comment='排序顺序')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # 关联网址
    websites = db.relationship('Website', backref='section', lazy='dynamic', cascade='all, delete-orphan')
    
    def to_dict(self):
        return {
            'id': self.id,
            'category_id': self.category_id,
            'name': self.name,
            'description': self.description,
            'sort_order': self.sort_order,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }
    
    def to_dict_with_websites(self):
        data = self.to_dict()
        data['websites'] = [website.to_dict() for website in self.websites.order_by(Website.sort_order).all()]
        return data


class Website(db.Model):
    """网址模型"""
    __tablename__ = 'websites'
    
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    section_id = db.Column(db.Integer, db.ForeignKey('sections.id'), nullable=False, comment='所属分区ID')
    name = db.Column(db.String(100), nullable=False, comment='网站名称')
    url = db.Column(db.String(500), nullable=False, comment='网站URL')
    icon = db.Column(db.String(500), comment='网站图标URL')
    description = db.Column(db.String(255), comment='网站描述')
    sort_order = db.Column(db.Integer, default=0, comment='排序顺序')
    click_count = db.Column(db.Integer, default=0, comment='点击次数')
    is_hot = db.Column(db.Boolean, default=False, comment='是否热门')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'section_id': self.section_id,
            'name': self.name,
            'url': self.url,
            'icon': self.icon,
            'description': self.description,
            'sort_order': self.sort_order,
            'click_count': self.click_count,
            'is_hot': self.is_hot,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }


class WorkspaceItem(db.Model):
    """用户工作台项目模型"""
    __tablename__ = 'workspace_items'
    
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    website_id = db.Column(db.Integer, db.ForeignKey('websites.id', ondelete='SET NULL'), comment='关联的网址ID')
    custom_name = db.Column(db.String(100), comment='自定义名称')
    custom_url = db.Column(db.String(500), comment='自定义URL')
    custom_icon = db.Column(db.String(500), comment='自定义图标')
    custom_description = db.Column(db.String(255), comment='自定义描述')
    sort_order = db.Column(db.Integer, default=0, comment='排序顺序')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # 关联网址
    website = db.relationship('Website', backref='workspace_items')
    
    def to_dict(self):
        # 如果关联了网址，使用网址信息，否则使用自定义信息
        if self.website_id and self.website:
            return {
                'id': self.id,
                'website_id': self.website_id,
                'name': self.custom_name or self.website.name,
                'url': self.custom_url or self.website.url,
                'icon': self.custom_icon or self.website.icon,
                'description': self.custom_description or self.website.description,
                'sort_order': self.sort_order,
                'is_custom': False,
                'created_at': self.created_at.isoformat() if self.created_at else None,
                'updated_at': self.updated_at.isoformat() if self.updated_at else None
            }
        else:
            return {
                'id': self.id,
                'website_id': None,
                'name': self.custom_name,
                'url': self.custom_url,
                'icon': self.custom_icon,
                'description': self.custom_description,
                'sort_order': self.sort_order,
                'is_custom': True,
                'created_at': self.created_at.isoformat() if self.created_at else None,
                'updated_at': self.updated_at.isoformat() if self.updated_at else None
            }


class SearchHistory(db.Model):
    """搜索历史模型"""
    __tablename__ = 'search_history'
    
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    keyword = db.Column(db.String(200), nullable=False, comment='搜索关键词')
    search_count = db.Column(db.Integer, default=1, comment='搜索次数')
    last_searched_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'keyword': self.keyword,
            'search_count': self.search_count,
            'last_searched_at': self.last_searched_at.isoformat() if self.last_searched_at else None,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }


class SystemSetting(db.Model):
    """系统设置模型"""
    __tablename__ = 'system_settings'
    
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    setting_key = db.Column(db.String(50), unique=True, nullable=False, comment='设置键')
    setting_value = db.Column(db.Text, comment='设置值')
    description = db.Column(db.String(255), comment='设置描述')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'key': self.setting_key,
            'value': self.setting_value,
            'description': self.description
        }

