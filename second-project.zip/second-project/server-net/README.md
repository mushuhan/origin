# NavHub 后端

基于 Flask 的一站式网址导航系统后端 API 服务。

## 技术栈

- **框架**: Flask 3.0
- **数据库**: MySQL 8.0+
- **ORM**: SQLAlchemy
- **跨域**: Flask-CORS

## 功能特性

- RESTful API 设计
- 完整的 CRUD 操作
- 搜索功能支持
- 点击统计
- XSS 防护
- CORS 支持

## 项目结构

```
server-net/
├── app.py              # 主应用和路由
├── config.py           # 配置文件
├── models.py           # 数据库模型
├── run.py              # 启动脚本
├── database.sql        # 数据库初始化脚本
├── requirements.txt    # Python 依赖
└── README.md           # 说明文档
```

## 快速开始

### 1. 创建虚拟环境

```bash
python -m venv venv

# Windows
venv\Scripts\activate

# Linux/Mac
source venv/bin/activate
```

### 2. 安装依赖

```bash
pip install -r requirements.txt
```

### 3. 配置数据库

编辑 `config.py` 或创建 `.env` 文件配置数据库连接：

```
MYSQL_HOST=localhost
MYSQL_PORT=3306
MYSQL_USER=root
MYSQL_PASSWORD=your_password
MYSQL_DATABASE=nav_system
```

### 4. 初始化数据库

在 MySQL 中执行 `database.sql` 脚本：

```bash
mysql -u root -p < database.sql
```

或使用 MySQL 客户端工具导入。

### 5. 启动服务

```bash
python run.py
```

服务将在 http://localhost:5000 启动。

## API 文档

### 分类相关

| 方法 | 路径 | 描述 |
|------|------|------|
| GET | `/api/categories` | 获取所有分类 |
| GET | `/api/categories/:id` | 获取分类详情 |
| POST | `/api/categories` | 创建分类 |
| PUT | `/api/categories/:id` | 更新分类 |
| DELETE | `/api/categories/:id` | 删除分类 |

### 分区相关

| 方法 | 路径 | 描述 |
|------|------|------|
| GET | `/api/sections` | 获取分区列表 |
| GET | `/api/sections/:id` | 获取分区详情 |
| POST | `/api/sections` | 创建分区 |
| PUT | `/api/sections/:id` | 更新分区 |
| DELETE | `/api/sections/:id` | 删除分区 |

### 网址相关

| 方法 | 路径 | 描述 |
|------|------|------|
| GET | `/api/websites` | 获取网址列表 |
| GET | `/api/websites/hot` | 获取热门网址 |
| GET | `/api/websites/:id` | 获取网址详情 |
| POST | `/api/websites` | 创建网址 |
| PUT | `/api/websites/:id` | 更新网址 |
| DELETE | `/api/websites/:id` | 删除网址 |
| POST | `/api/websites/:id/click` | 记录点击 |

### 工作台相关

| 方法 | 路径 | 描述 |
|------|------|------|
| GET | `/api/workspace` | 获取工作台 |
| POST | `/api/workspace` | 添加到工作台 |
| PUT | `/api/workspace/:id` | 更新工作台项 |
| DELETE | `/api/workspace/:id` | 移除工作台项 |
| PUT | `/api/workspace/reorder` | 重新排序 |

### 搜索相关

| 方法 | 路径 | 描述 |
|------|------|------|
| GET | `/api/search?keyword=xxx` | 搜索网址 |
| GET | `/api/search/suggestions?keyword=xxx` | 获取搜索建议 |

### 其他

| 方法 | 路径 | 描述 |
|------|------|------|
| GET | `/api/home` | 获取首页数据 |
| GET | `/api/settings` | 获取系统设置 |
| PUT | `/api/settings/:key` | 更新系统设置 |

## 响应格式

所有 API 响应格式统一为：

```json
{
  "code": 200,
  "message": "操作成功",
  "data": { ... }
}
```

错误响应：

```json
{
  "code": 400,
  "message": "错误信息",
  "data": null
}
```

## 数据库表结构

- `sidebar_categories` - 侧边栏分类
- `sections` - 网址分区
- `websites` - 网址信息
- `workspace_items` - 工作台项目
- `search_history` - 搜索历史
- `system_settings` - 系统设置

详细表结构请参考 `database.sql` 文件。

## 注意事项

1. 生产环境请关闭 DEBUG 模式
2. 生产环境请使用环境变量配置敏感信息
3. 建议使用 Gunicorn 等 WSGI 服务器部署
4. 确保 MySQL 服务已启动并配置正确

