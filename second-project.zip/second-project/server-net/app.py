from flask import Flask, jsonify, request
from flask_cors import CORS
from config import Config
from models import db, SidebarCategory, Section, Website, WorkspaceItem, SearchHistory, SystemSetting
from html import escape

app = Flask(__name__)
app.config.from_object(Config)

# 配置CORS
CORS(app, origins=Config.CORS_ORIGINS, supports_credentials=True)

# 初始化数据库
db.init_app(app)

# ==================== 工具函数 ====================

def sanitize_input(text):
    """防止XSS攻击，转义HTML字符"""
    if text is None:
        return None
    return escape(str(text))

def success_response(data=None, message="操作成功"):
    """成功响应"""
    return jsonify({
        'code': 200,
        'message': message,
        'data': data
    })

def error_response(message="操作失败", code=400):
    """错误响应"""
    return jsonify({
        'code': code,
        'message': message,
        'data': None
    }), code

# ==================== 分类相关API ====================

@app.route('/api/categories', methods=['GET'])
def get_categories():
    """获取所有分类"""
    categories = SidebarCategory.query.order_by(SidebarCategory.sort_order).all()
    return success_response([cat.to_dict() for cat in categories])

@app.route('/api/categories/<int:category_id>', methods=['GET'])
def get_category(category_id):
    """获取单个分类及其内容"""
    category = SidebarCategory.query.get_or_404(category_id)
    return success_response(category.to_dict_with_sections())

@app.route('/api/categories', methods=['POST'])
def create_category():
    """创建分类"""
    data = request.get_json()
    if not data or not data.get('name'):
        return error_response('分类名称不能为空')
    
    category = SidebarCategory(
        name=sanitize_input(data.get('name')),
        icon=sanitize_input(data.get('icon')),
        sort_order=data.get('sort_order', 0)
    )
    db.session.add(category)
    db.session.commit()
    return success_response(category.to_dict(), '创建成功')

@app.route('/api/categories/<int:category_id>', methods=['PUT'])
def update_category(category_id):
    """更新分类"""
    category = SidebarCategory.query.get_or_404(category_id)
    data = request.get_json()
    
    if data.get('name'):
        category.name = sanitize_input(data['name'])
    if 'icon' in data:
        category.icon = sanitize_input(data['icon'])
    if 'sort_order' in data:
        category.sort_order = data['sort_order']
    
    db.session.commit()
    return success_response(category.to_dict(), '更新成功')

@app.route('/api/categories/<int:category_id>', methods=['DELETE'])
def delete_category(category_id):
    """删除分类"""
    category = SidebarCategory.query.get_or_404(category_id)
    if category.is_system:
        return error_response('系统分类不能删除')
    
    db.session.delete(category)
    db.session.commit()
    return success_response(message='删除成功')

# ==================== 分区相关API ====================

@app.route('/api/sections', methods=['GET'])
def get_sections():
    """获取分区列表"""
    category_id = request.args.get('category_id', type=int)
    query = Section.query
    if category_id:
        query = query.filter_by(category_id=category_id)
    sections = query.order_by(Section.sort_order).all()
    return success_response([section.to_dict_with_websites() for section in sections])

@app.route('/api/sections/<int:section_id>', methods=['GET'])
def get_section(section_id):
    """获取单个分区"""
    section = Section.query.get_or_404(section_id)
    return success_response(section.to_dict_with_websites())

@app.route('/api/sections', methods=['POST'])
def create_section():
    """创建分区"""
    data = request.get_json()
    if not data or not data.get('name') or not data.get('category_id'):
        return error_response('分区名称和分类ID不能为空')
    
    section = Section(
        category_id=data['category_id'],
        name=sanitize_input(data['name']),
        description=sanitize_input(data.get('description')),
        sort_order=data.get('sort_order', 0)
    )
    db.session.add(section)
    db.session.commit()
    return success_response(section.to_dict(), '创建成功')

@app.route('/api/sections/<int:section_id>', methods=['PUT'])
def update_section(section_id):
    """更新分区"""
    section = Section.query.get_or_404(section_id)
    data = request.get_json()
    
    if data.get('name'):
        section.name = sanitize_input(data['name'])
    if 'description' in data:
        section.description = sanitize_input(data['description'])
    if 'sort_order' in data:
        section.sort_order = data['sort_order']
    if 'category_id' in data:
        section.category_id = data['category_id']
    
    db.session.commit()
    return success_response(section.to_dict(), '更新成功')

@app.route('/api/sections/<int:section_id>', methods=['DELETE'])
def delete_section(section_id):
    """删除分区"""
    section = Section.query.get_or_404(section_id)
    db.session.delete(section)
    db.session.commit()
    return success_response(message='删除成功')

# ==================== 网址相关API ====================

@app.route('/api/websites', methods=['GET'])
def get_websites():
    """获取网址列表"""
    section_id = request.args.get('section_id', type=int)
    is_hot = request.args.get('is_hot', type=int)
    
    query = Website.query
    if section_id:
        query = query.filter_by(section_id=section_id)
    if is_hot is not None:
        query = query.filter_by(is_hot=bool(is_hot))
    
    websites = query.order_by(Website.sort_order).all()
    return success_response([website.to_dict() for website in websites])

@app.route('/api/websites/hot', methods=['GET'])
def get_hot_websites():
    """获取热门网址"""
    limit = request.args.get('limit', 20, type=int)
    websites = Website.query.filter_by(is_hot=True).order_by(Website.click_count.desc()).limit(limit).all()
    return success_response([website.to_dict() for website in websites])

@app.route('/api/websites/<int:website_id>', methods=['GET'])
def get_website(website_id):
    """获取单个网址"""
    website = Website.query.get_or_404(website_id)
    return success_response(website.to_dict())

@app.route('/api/websites', methods=['POST'])
def create_website():
    """创建网址"""
    data = request.get_json()
    if not data or not data.get('name') or not data.get('url') or not data.get('section_id'):
        return error_response('网址名称、URL和分区ID不能为空')
    
    website = Website(
        section_id=data['section_id'],
        name=sanitize_input(data['name']),
        url=sanitize_input(data['url']),
        icon=sanitize_input(data.get('icon')),
        description=sanitize_input(data.get('description')),
        sort_order=data.get('sort_order', 0),
        is_hot=data.get('is_hot', False)
    )
    db.session.add(website)
    db.session.commit()
    return success_response(website.to_dict(), '创建成功')

@app.route('/api/websites/<int:website_id>', methods=['PUT'])
def update_website(website_id):
    """更新网址"""
    website = Website.query.get_or_404(website_id)
    data = request.get_json()
    
    if data.get('name'):
        website.name = sanitize_input(data['name'])
    if data.get('url'):
        website.url = sanitize_input(data['url'])
    if 'icon' in data:
        website.icon = sanitize_input(data['icon'])
    if 'description' in data:
        website.description = sanitize_input(data['description'])
    if 'sort_order' in data:
        website.sort_order = data['sort_order']
    if 'is_hot' in data:
        website.is_hot = data['is_hot']
    if 'section_id' in data:
        website.section_id = data['section_id']
    
    db.session.commit()
    return success_response(website.to_dict(), '更新成功')

@app.route('/api/websites/<int:website_id>', methods=['DELETE'])
def delete_website(website_id):
    """删除网址"""
    website = Website.query.get_or_404(website_id)
    db.session.delete(website)
    db.session.commit()
    return success_response(message='删除成功')

@app.route('/api/websites/<int:website_id>/click', methods=['POST'])
def click_website(website_id):
    """增加网址点击次数"""
    website = Website.query.get_or_404(website_id)
    website.click_count += 1
    db.session.commit()
    return success_response({'click_count': website.click_count})

# ==================== 工作台相关API ====================

@app.route('/api/workspace', methods=['GET'])
def get_workspace():
    """获取工作台内容"""
    items = WorkspaceItem.query.order_by(WorkspaceItem.sort_order).all()
    return success_response([item.to_dict() for item in items])

@app.route('/api/workspace', methods=['POST'])
def add_to_workspace():
    """添加到工作台"""
    data = request.get_json()
    
    # 从库存添加
    if data.get('website_id'):
        website = Website.query.get_or_404(data['website_id'])
        # 检查是否已存在
        existing = WorkspaceItem.query.filter_by(website_id=website.id).first()
        if existing:
            return error_response('该网址已在工作台中')
        
        item = WorkspaceItem(
            website_id=website.id,
            sort_order=data.get('sort_order', 0)
        )
    # 自定义添加
    else:
        if not data.get('custom_name') or not data.get('custom_url'):
            return error_response('自定义网址名称和URL不能为空')
        
        item = WorkspaceItem(
            custom_name=sanitize_input(data['custom_name']),
            custom_url=sanitize_input(data['custom_url']),
            custom_icon=sanitize_input(data.get('custom_icon')),
            custom_description=sanitize_input(data.get('custom_description')),
            sort_order=data.get('sort_order', 0)
        )
    
    db.session.add(item)
    db.session.commit()
    return success_response(item.to_dict(), '添加成功')

@app.route('/api/workspace/<int:item_id>', methods=['PUT'])
def update_workspace_item(item_id):
    """更新工作台项目"""
    item = WorkspaceItem.query.get_or_404(item_id)
    data = request.get_json()
    
    if 'custom_name' in data:
        item.custom_name = sanitize_input(data['custom_name'])
    if 'custom_url' in data:
        item.custom_url = sanitize_input(data['custom_url'])
    if 'custom_icon' in data:
        item.custom_icon = sanitize_input(data['custom_icon'])
    if 'custom_description' in data:
        item.custom_description = sanitize_input(data['custom_description'])
    if 'sort_order' in data:
        item.sort_order = data['sort_order']
    
    db.session.commit()
    return success_response(item.to_dict(), '更新成功')

@app.route('/api/workspace/<int:item_id>', methods=['DELETE'])
def remove_from_workspace(item_id):
    """从工作台移除"""
    item = WorkspaceItem.query.get_or_404(item_id)
    db.session.delete(item)
    db.session.commit()
    return success_response(message='删除成功')

@app.route('/api/workspace/reorder', methods=['PUT'])
def reorder_workspace():
    """重新排序工作台项目"""
    data = request.get_json()
    if not data or not data.get('items'):
        return error_response('排序数据不能为空')
    
    for item_data in data['items']:
        item = WorkspaceItem.query.get(item_data['id'])
        if item:
            item.sort_order = item_data['sort_order']
    
    db.session.commit()
    return success_response(message='排序更新成功')

# ==================== 搜索相关API ====================

@app.route('/api/search', methods=['GET'])
def search():
    """搜索网址"""
    keyword = request.args.get('keyword', '').strip()
    if not keyword:
        return error_response('搜索关键词不能为空')
    
    # 记录搜索历史
    history = SearchHistory.query.filter_by(keyword=keyword).first()
    if history:
        history.search_count += 1
    else:
        history = SearchHistory(keyword=sanitize_input(keyword))
        db.session.add(history)
    db.session.commit()
    
    # 搜索网址
    websites = Website.query.filter(
        db.or_(
            Website.name.ilike(f'%{keyword}%'),
            Website.description.ilike(f'%{keyword}%'),
            Website.url.ilike(f'%{keyword}%')
        )
    ).order_by(Website.click_count.desc()).limit(50).all()
    
    return success_response([website.to_dict() for website in websites])

@app.route('/api/search/suggestions', methods=['GET'])
def get_search_suggestions():
    """获取搜索建议"""
    keyword = request.args.get('keyword', '').strip()
    
    suggestions = []
    
    if keyword:
        # 从网址中匹配
        websites = Website.query.filter(
            db.or_(
                Website.name.ilike(f'%{keyword}%'),
                Website.description.ilike(f'%{keyword}%')
            )
        ).order_by(Website.click_count.desc()).limit(5).all()
        suggestions.extend([{'type': 'website', 'name': w.name, 'url': w.url, 'id': w.id} for w in websites])
    
    # 获取热门搜索
    hot_searches = SearchHistory.query.order_by(SearchHistory.search_count.desc()).limit(10).all()
    hot_keywords = [{'type': 'keyword', 'keyword': h.keyword, 'count': h.search_count} for h in hot_searches]
    
    return success_response({
        'suggestions': suggestions,
        'hot_keywords': hot_keywords
    })

# ==================== 系统设置相关API ====================

@app.route('/api/settings', methods=['GET'])
def get_settings():
    """获取系统设置"""
    settings = SystemSetting.query.all()
    return success_response({s.setting_key: s.setting_value for s in settings})

@app.route('/api/settings/<key>', methods=['PUT'])
def update_setting(key):
    """更新系统设置"""
    setting = SystemSetting.query.filter_by(setting_key=key).first()
    if not setting:
        return error_response('设置项不存在', 404)
    
    data = request.get_json()
    if 'value' in data:
        setting.setting_value = sanitize_input(data['value'])
    
    db.session.commit()
    return success_response(setting.to_dict(), '更新成功')

# ==================== 首页数据API ====================

@app.route('/api/home', methods=['GET'])
def get_home_data():
    """获取首页数据"""
    # 获取所有分类及其内容
    categories = SidebarCategory.query.order_by(SidebarCategory.sort_order).all()
    
    # 获取热门网址
    hot_websites = Website.query.filter_by(is_hot=True).order_by(Website.click_count.desc()).limit(20).all()
    
    # 获取系统设置
    settings = SystemSetting.query.all()
    settings_dict = {s.setting_key: s.setting_value for s in settings}
    
    return success_response({
        'categories': [cat.to_dict_with_sections() for cat in categories],
        'hot_websites': [w.to_dict() for w in hot_websites],
        'settings': settings_dict
    })

# ==================== 批量操作API ====================

@app.route('/api/websites/batch-reorder', methods=['PUT'])
def batch_reorder_websites():
    """批量重排序网址"""
    data = request.get_json()
    if not data or not data.get('items'):
        return error_response('排序数据不能为空')
    
    for item_data in data['items']:
        website = Website.query.get(item_data['id'])
        if website:
            website.sort_order = item_data['sort_order']
            if 'section_id' in item_data:
                website.section_id = item_data['section_id']
    
    db.session.commit()
    return success_response(message='排序更新成功')

@app.route('/api/sections/batch-reorder', methods=['PUT'])
def batch_reorder_sections():
    """批量重排序分区"""
    data = request.get_json()
    if not data or not data.get('items'):
        return error_response('排序数据不能为空')
    
    for item_data in data['items']:
        section = Section.query.get(item_data['id'])
        if section:
            section.sort_order = item_data['sort_order']
    
    db.session.commit()
    return success_response(message='排序更新成功')

@app.route('/api/categories/batch-reorder', methods=['PUT'])
def batch_reorder_categories():
    """批量重排序分类"""
    data = request.get_json()
    if not data or not data.get('items'):
        return error_response('排序数据不能为空')
    
    for item_data in data['items']:
        category = SidebarCategory.query.get(item_data['id'])
        if category:
            category.sort_order = item_data['sort_order']
    
    db.session.commit()
    return success_response(message='排序更新成功')

# ==================== 错误处理 ====================

@app.errorhandler(404)
def not_found(error):
    return error_response('资源未找到', 404)

@app.errorhandler(500)
def internal_error(error):
    db.session.rollback()
    return error_response('服务器内部错误', 500)

# ==================== 启动应用 ====================

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True, host='0.0.0.0', port=5000)

