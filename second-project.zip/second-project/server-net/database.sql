-- 企业级网址导航系统数据库初始化脚本
-- MySQL 8.0+ / MariaDB 10.5+
-- 支持用户隔离、文件夹系统、语录模块

-- 创建数据库
CREATE DATABASE IF NOT EXISTS nav_system 
CHARACTER SET utf8mb4 
COLLATE utf8mb4_unicode_ci;

USE nav_system;

-- ========================================
-- 用户表 (新增 - 用户隔离核心)
-- ========================================
DROP TABLE IF EXISTS users;
CREATE TABLE users (
    uuid VARCHAR(36) PRIMARY KEY COMMENT '用户UUID（前端生成）',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '首次访问时间',
    last_active_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后活跃时间',
    settings JSON DEFAULT NULL COMMENT '用户个人设置（JSON）'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户表';

-- ========================================
-- 侧边栏分类表
-- ========================================
DROP TABLE IF EXISTS sidebar_categories;
CREATE TABLE sidebar_categories (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(50) NOT NULL COMMENT '分类名称',
    icon VARCHAR(100) DEFAULT NULL COMMENT '分类图标',
    sort_order INT DEFAULT 0 COMMENT '排序顺序',
    is_system TINYINT(1) DEFAULT 0 COMMENT '是否系统分类',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='侧边栏分类表';

-- ========================================
-- 网址分区表
-- ========================================
DROP TABLE IF EXISTS sections;
CREATE TABLE sections (
    id INT PRIMARY KEY AUTO_INCREMENT,
    category_id INT NOT NULL COMMENT '所属分类ID',
    name VARCHAR(100) NOT NULL COMMENT '分区名称',
    description VARCHAR(255) DEFAULT NULL COMMENT '分区描述',
    sort_order INT DEFAULT 0 COMMENT '排序顺序',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES sidebar_categories(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='网址分区表';

-- ========================================
-- 公共网址表
-- ========================================
DROP TABLE IF EXISTS websites;
CREATE TABLE websites (
    id INT PRIMARY KEY AUTO_INCREMENT,
    section_id INT NOT NULL COMMENT '所属分区ID',
    name VARCHAR(100) NOT NULL COMMENT '网站名称',
    url VARCHAR(500) NOT NULL COMMENT '网站URL',
    icon VARCHAR(500) DEFAULT NULL COMMENT '网站图标URL',
    description VARCHAR(255) DEFAULT NULL COMMENT '网站描述',
    pinyin VARCHAR(200) DEFAULT NULL COMMENT '拼音（用于搜索）',
    pinyin_initials VARCHAR(50) DEFAULT NULL COMMENT '拼音首字母（用于搜索）',
    sort_order INT DEFAULT 0 COMMENT '排序顺序',
    click_count INT DEFAULT 0 COMMENT '点击次数',
    is_hot TINYINT(1) DEFAULT 0 COMMENT '是否热门',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (section_id) REFERENCES sections(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='公共网址表';

-- ========================================
-- 用户文件夹表 (新增 - 工作台分组)
-- ========================================
DROP TABLE IF EXISTS folders;
CREATE TABLE folders (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_uuid VARCHAR(36) NOT NULL COMMENT '关联用户UUID',
    name VARCHAR(100) NOT NULL COMMENT '文件夹名称',
    parent_id INT DEFAULT NULL COMMENT '父文件夹ID（支持嵌套）',
    icon VARCHAR(50) DEFAULT 'Folder' COMMENT '文件夹图标',
    color VARCHAR(20) DEFAULT '#6b7280' COMMENT '文件夹颜色',
    sort_order INT DEFAULT 0 COMMENT '排序顺序',
    is_collapsed TINYINT(1) DEFAULT 0 COMMENT '是否折叠',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_uuid) REFERENCES users(uuid) ON DELETE CASCADE,
    FOREIGN KEY (parent_id) REFERENCES folders(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户文件夹表';

-- ========================================
-- 用户私有网址表 (替代 workspace_items)
-- ========================================
DROP TABLE IF EXISTS user_sites;
CREATE TABLE user_sites (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_uuid VARCHAR(36) NOT NULL COMMENT '关联用户UUID',
    website_id INT DEFAULT NULL COMMENT '关联公共网址ID',
    folder_id INT DEFAULT NULL COMMENT '所属文件夹ID',
    custom_name VARCHAR(100) DEFAULT NULL COMMENT '自定义名称',
    custom_url VARCHAR(500) DEFAULT NULL COMMENT '自定义URL',
    custom_icon VARCHAR(500) DEFAULT NULL COMMENT '自定义图标',
    custom_description VARCHAR(255) DEFAULT NULL COMMENT '自定义描述',
    sort_order INT DEFAULT 0 COMMENT '排序顺序',
    click_count INT DEFAULT 0 COMMENT '用户点击次数',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_uuid) REFERENCES users(uuid) ON DELETE CASCADE,
    FOREIGN KEY (website_id) REFERENCES websites(id) ON DELETE SET NULL,
    FOREIGN KEY (folder_id) REFERENCES folders(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户私有网址表';

-- ========================================
-- 搜索历史表
-- ========================================
DROP TABLE IF EXISTS search_history;
CREATE TABLE search_history (
    id INT PRIMARY KEY AUTO_INCREMENT,
    keyword VARCHAR(200) NOT NULL COMMENT '搜索关键词',
    search_count INT DEFAULT 1 COMMENT '搜索次数',
    last_searched_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='搜索历史表';

-- ========================================
-- 励志语录表 (新增)
-- ========================================
DROP TABLE IF EXISTS quotes;
CREATE TABLE quotes (
    id INT PRIMARY KEY AUTO_INCREMENT,
    content TEXT NOT NULL COMMENT '语录内容',
    author VARCHAR(100) DEFAULT NULL COMMENT '作者',
    source VARCHAR(200) DEFAULT NULL COMMENT '出处',
    category VARCHAR(50) DEFAULT 'general' COMMENT '分类',
    is_active TINYINT(1) DEFAULT 1 COMMENT '是否启用',
    display_count INT DEFAULT 0 COMMENT '展示次数',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='励志语录表';

-- ========================================
-- 系统设置表
-- ========================================
DROP TABLE IF EXISTS system_settings;
CREATE TABLE system_settings (
    id INT PRIMARY KEY AUTO_INCREMENT,
    setting_key VARCHAR(50) NOT NULL UNIQUE COMMENT '设置键',
    setting_value TEXT COMMENT '设置值',
    description VARCHAR(255) DEFAULT NULL COMMENT '设置描述',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='系统设置表';

-- ========================================
-- 索引优化
-- ========================================
CREATE INDEX idx_websites_section ON websites(section_id);
CREATE INDEX idx_websites_click ON websites(click_count DESC);
CREATE INDEX idx_websites_hot ON websites(is_hot);
CREATE INDEX idx_websites_name ON websites(name);
CREATE INDEX idx_websites_pinyin ON websites(pinyin_initials);
CREATE INDEX idx_sections_category ON sections(category_id);
CREATE INDEX idx_folders_user ON folders(user_uuid);
CREATE INDEX idx_folders_parent ON folders(parent_id);
CREATE INDEX idx_user_sites_user ON user_sites(user_uuid);
CREATE INDEX idx_user_sites_folder ON user_sites(folder_id);
CREATE INDEX idx_search_keyword ON search_history(keyword);
CREATE INDEX idx_search_count ON search_history(search_count DESC);
CREATE INDEX idx_quotes_category ON quotes(category);
CREATE INDEX idx_quotes_active ON quotes(is_active);

-- ========================================
-- 初始化数据
-- ========================================

-- 侧边栏分类
INSERT INTO sidebar_categories (name, icon, sort_order, is_system) VALUES
('自定义工作台', 'Briefcase', 0, 1),
('常用工具', 'Tools', 1, 0),
('技术开发', 'Code', 2, 0),
('设计资源', 'Palette', 3, 0),
('学习教育', 'BookOpen', 4, 0),
('影音娱乐', 'Film', 5, 0),
('社交媒体', 'Users', 6, 0),
('新闻资讯', 'Newspaper', 7, 0),
('购物电商', 'ShoppingCart', 8, 0);

-- 常用工具分区
INSERT INTO sections (category_id, name, description, sort_order) VALUES
(2, '搜索引擎', '各大搜索引擎入口', 0),
(2, '在线翻译', '多语言翻译工具', 1),
(2, '文档办公', '在线文档和办公工具', 2),
(2, 'AI工具', '人工智能相关工具', 3);

-- 技术开发分区
INSERT INTO sections (category_id, name, description, sort_order) VALUES
(3, '代码托管', 'Git代码托管平台', 0),
(3, '技术社区', '程序员社区和论坛', 1),
(3, '开发文档', '各类技术文档', 2),
(3, '在线工具', '开发者在线工具', 3);

-- 设计资源分区
INSERT INTO sections (category_id, name, description, sort_order) VALUES
(4, '设计工具', '在线设计工具', 0),
(4, '图标素材', '图标和素材资源', 1),
(4, '配色方案', '配色工具和灵感', 2);

-- 学习教育分区
INSERT INTO sections (category_id, name, description, sort_order) VALUES
(5, '在线课程', '在线学习平台', 0),
(5, '编程学习', '编程教学资源', 1),
(5, '知识百科', '百科和知识库', 2);

-- 影音娱乐分区
INSERT INTO sections (category_id, name, description, sort_order) VALUES
(6, '视频平台', '主流视频网站', 0),
(6, '音乐平台', '音乐播放平台', 1),
(6, '直播平台', '直播网站', 2);

-- 社交媒体分区
INSERT INTO sections (category_id, name, description, sort_order) VALUES
(7, '社交网络', '社交媒体平台', 0),
(7, '即时通讯', '在线聊天工具', 1);

-- 新闻资讯分区
INSERT INTO sections (category_id, name, description, sort_order) VALUES
(8, '综合新闻', '新闻门户网站', 0),
(8, '科技资讯', '科技新闻网站', 1);

-- 购物电商分区
INSERT INTO sections (category_id, name, description, sort_order) VALUES
(9, '综合电商', '综合购物平台', 0),
(9, '数码科技', '数码产品商城', 1);

-- 搜索引擎网址
INSERT INTO websites (section_id, name, url, icon, description, pinyin, pinyin_initials, sort_order, is_hot) VALUES
(1, '百度', 'https://www.baidu.com', 'https://www.baidu.com/favicon.ico', '全球最大的中文搜索引擎', 'baidu', 'bd', 0, 1),
(1, 'Google', 'https://www.google.com', 'https://www.google.com/favicon.ico', '全球最大的搜索引擎', 'google', 'gl', 1, 1),
(1, 'Bing', 'https://www.bing.com', 'https://www.bing.com/favicon.ico', '微软搜索引擎', 'bing', 'bg', 2, 0),
(1, '搜狗', 'https://www.sogou.com', 'https://www.sogou.com/favicon.ico', '搜狗搜索引擎', 'sougou', 'sg', 3, 0);

-- 在线翻译网址
INSERT INTO websites (section_id, name, url, icon, description, pinyin, pinyin_initials, sort_order, is_hot) VALUES
(2, '百度翻译', 'https://fanyi.baidu.com', 'https://fanyi.baidu.com/favicon.ico', '百度在线翻译', 'baidufanyi', 'bdfy', 0, 1),
(2, 'Google翻译', 'https://translate.google.com', 'https://translate.google.com/favicon.ico', '谷歌在线翻译', 'googlefanyi', 'glfy', 1, 1),
(2, 'DeepL', 'https://www.deepl.com/translator', 'https://www.deepl.com/favicon.ico', 'AI翻译工具', 'deepl', 'dl', 2, 1);

-- 文档办公网址
INSERT INTO websites (section_id, name, url, icon, description, pinyin, pinyin_initials, sort_order, is_hot) VALUES
(3, '腾讯文档', 'https://docs.qq.com', 'https://docs.qq.com/favicon.ico', '腾讯在线文档协作', 'tengxunwendang', 'txwd', 0, 1),
(3, '石墨文档', 'https://shimo.im', 'https://shimo.im/favicon.ico', '云端Office办公', 'shimowendang', 'smwd', 1, 0),
(3, '语雀', 'https://www.yuque.com', 'https://www.yuque.com/favicon.ico', '阿里知识库', 'yuque', 'yq', 2, 1),
(3, 'Notion', 'https://www.notion.so', 'https://www.notion.so/favicon.ico', '全能工作空间', 'notion', 'nt', 3, 1);

-- AI工具网址
INSERT INTO websites (section_id, name, url, icon, description, pinyin, pinyin_initials, sort_order, is_hot) VALUES
(4, 'ChatGPT', 'https://chat.openai.com', 'https://chat.openai.com/favicon.ico', 'OpenAI对话AI', 'chatgpt', 'cgpt', 0, 1),
(4, '文心一言', 'https://yiyan.baidu.com', 'https://yiyan.baidu.com/favicon.ico', '百度AI助手', 'wenxinyiyan', 'wxyy', 1, 1),
(4, '通义千问', 'https://tongyi.aliyun.com', 'https://tongyi.aliyun.com/favicon.ico', '阿里AI助手', 'tongyiqianwen', 'tyqw', 2, 1),
(4, 'Claude', 'https://claude.ai', 'https://claude.ai/favicon.ico', 'Anthropic AI助手', 'claude', 'cd', 3, 1);

-- 代码托管网址
INSERT INTO websites (section_id, name, url, icon, description, pinyin, pinyin_initials, sort_order, is_hot) VALUES
(5, 'GitHub', 'https://github.com', 'https://github.com/favicon.ico', '全球最大代码托管平台', 'github', 'gh', 0, 1),
(5, 'Gitee', 'https://gitee.com', 'https://gitee.com/favicon.ico', '国内代码托管平台', 'gitee', 'ge', 1, 1),
(5, 'GitLab', 'https://gitlab.com', 'https://gitlab.com/favicon.ico', '开源代码托管平台', 'gitlab', 'gl', 2, 0);

-- 技术社区网址
INSERT INTO websites (section_id, name, url, icon, description, pinyin, pinyin_initials, sort_order, is_hot) VALUES
(6, '掘金', 'https://juejin.cn', 'https://juejin.cn/favicon.ico', '开发者社区', 'juejin', 'jj', 0, 1),
(6, 'CSDN', 'https://www.csdn.net', 'https://www.csdn.net/favicon.ico', '中文IT社区', 'csdn', 'csdn', 1, 1),
(6, 'Stack Overflow', 'https://stackoverflow.com', 'https://stackoverflow.com/favicon.ico', '程序员问答社区', 'stackoverflow', 'so', 2, 1),
(6, '博客园', 'https://www.cnblogs.com', 'https://www.cnblogs.com/favicon.ico', '开发者博客平台', 'bokeyuan', 'bky', 3, 0);

-- 开发文档网址
INSERT INTO websites (section_id, name, url, icon, description, pinyin, pinyin_initials, sort_order, is_hot) VALUES
(7, 'MDN Web Docs', 'https://developer.mozilla.org', 'https://developer.mozilla.org/favicon.ico', 'Web开发文档', 'mdn', 'mdn', 0, 1),
(7, 'Vue.js', 'https://vuejs.org', 'https://vuejs.org/favicon.ico', 'Vue框架官方文档', 'vuejs', 'vj', 1, 1),
(7, 'React', 'https://react.dev', 'https://react.dev/favicon.ico', 'React框架官方文档', 'react', 'rt', 2, 1);

-- 在线工具网址
INSERT INTO websites (section_id, name, url, icon, description, pinyin, pinyin_initials, sort_order, is_hot) VALUES
(8, 'CodePen', 'https://codepen.io', 'https://codepen.io/favicon.ico', '在线代码编辑器', 'codepen', 'cp', 0, 1),
(8, 'JSFiddle', 'https://jsfiddle.net', 'https://jsfiddle.net/favicon.ico', '在线代码测试', 'jsfiddle', 'jsf', 1, 0);

-- 设计工具网址
INSERT INTO websites (section_id, name, url, icon, description, pinyin, pinyin_initials, sort_order, is_hot) VALUES
(9, 'Figma', 'https://www.figma.com', 'https://www.figma.com/favicon.ico', '在线UI设计工具', 'figma', 'fg', 0, 1),
(9, 'Canva', 'https://www.canva.com', 'https://www.canva.com/favicon.ico', '在线设计平台', 'canva', 'cv', 1, 1),
(9, '即时设计', 'https://js.design', 'https://js.design/favicon.ico', '国产在线设计工具', 'jishisheji', 'jssj', 2, 1);

-- 图标素材网址
INSERT INTO websites (section_id, name, url, icon, description, pinyin, pinyin_initials, sort_order, is_hot) VALUES
(10, 'iconfont', 'https://www.iconfont.cn', 'https://www.iconfont.cn/favicon.ico', '阿里图标库', 'iconfont', 'if', 0, 1),
(10, 'Unsplash', 'https://unsplash.com', 'https://unsplash.com/favicon.ico', '免费高清图片', 'unsplash', 'us', 1, 1);

-- 配色方案网址
INSERT INTO websites (section_id, name, url, icon, description, pinyin, pinyin_initials, sort_order, is_hot) VALUES
(11, 'Coolors', 'https://coolors.co', 'https://coolors.co/favicon.ico', '配色生成器', 'coolors', 'cl', 0, 1);

-- 在线课程网址
INSERT INTO websites (section_id, name, url, icon, description, pinyin, pinyin_initials, sort_order, is_hot) VALUES
(12, '慕课网', 'https://www.imooc.com', 'https://www.imooc.com/favicon.ico', 'IT技能学习平台', 'mukewang', 'mkw', 0, 1),
(12, 'Coursera', 'https://www.coursera.org', 'https://www.coursera.org/favicon.ico', '全球在线学习平台', 'coursera', 'csr', 1, 1);

-- 编程学习网址
INSERT INTO websites (section_id, name, url, icon, description, pinyin, pinyin_initials, sort_order, is_hot) VALUES
(13, 'LeetCode', 'https://leetcode.cn', 'https://leetcode.cn/favicon.ico', '算法刷题平台', 'leetcode', 'lc', 0, 1),
(13, '菜鸟教程', 'https://www.runoob.com', 'https://www.runoob.com/favicon.ico', '编程入门教程', 'cainiaojiaocheng', 'cnjc', 1, 1);

-- 知识百科网址
INSERT INTO websites (section_id, name, url, icon, description, pinyin, pinyin_initials, sort_order, is_hot) VALUES
(14, '维基百科', 'https://zh.wikipedia.org', 'https://zh.wikipedia.org/favicon.ico', '自由的百科全书', 'weijibaike', 'wjbk', 0, 1),
(14, '知乎', 'https://www.zhihu.com', 'https://www.zhihu.com/favicon.ico', '知识问答社区', 'zhihu', 'zh', 1, 1);

-- 视频平台网址
INSERT INTO websites (section_id, name, url, icon, description, pinyin, pinyin_initials, sort_order, is_hot) VALUES
(15, 'Bilibili', 'https://www.bilibili.com', 'https://www.bilibili.com/favicon.ico', 'B站视频平台', 'bilibili', 'blbl', 0, 1),
(15, 'YouTube', 'https://www.youtube.com', 'https://www.youtube.com/favicon.ico', '全球视频平台', 'youtube', 'ytb', 1, 1);

-- 音乐平台网址
INSERT INTO websites (section_id, name, url, icon, description, pinyin, pinyin_initials, sort_order, is_hot) VALUES
(16, '网易云音乐', 'https://music.163.com', 'https://music.163.com/favicon.ico', '网易云音乐', 'wangyiyunyinyue', 'wyyyy', 0, 1),
(16, 'QQ音乐', 'https://y.qq.com', 'https://y.qq.com/favicon.ico', 'QQ音乐', 'qqyinyue', 'qqyy', 1, 1);

-- 直播平台网址
INSERT INTO websites (section_id, name, url, icon, description, pinyin, pinyin_initials, sort_order, is_hot) VALUES
(17, '斗鱼', 'https://www.douyu.com', 'https://www.douyu.com/favicon.ico', '斗鱼直播', 'douyu', 'dy', 0, 1),
(17, '虎牙', 'https://www.huya.com', 'https://www.huya.com/favicon.ico', '虎牙直播', 'huya', 'hy', 1, 1);

-- 社交网络网址
INSERT INTO websites (section_id, name, url, icon, description, pinyin, pinyin_initials, sort_order, is_hot) VALUES
(18, '微博', 'https://weibo.com', 'https://weibo.com/favicon.ico', '新浪微博', 'weibo', 'wb', 0, 1),
(18, 'Twitter/X', 'https://twitter.com', 'https://twitter.com/favicon.ico', '推特社交平台', 'twitter', 'tt', 1, 1);

-- 即时通讯网址
INSERT INTO websites (section_id, name, url, icon, description, pinyin, pinyin_initials, sort_order, is_hot) VALUES
(19, 'QQ邮箱', 'https://mail.qq.com', 'https://mail.qq.com/favicon.ico', 'QQ邮箱', 'qqyouxiang', 'qqyx', 0, 1),
(19, 'Gmail', 'https://mail.google.com', 'https://mail.google.com/favicon.ico', '谷歌邮箱', 'gmail', 'gm', 1, 1);

-- 综合新闻网址
INSERT INTO websites (section_id, name, url, icon, description, pinyin, pinyin_initials, sort_order, is_hot) VALUES
(20, '今日头条', 'https://www.toutiao.com', 'https://www.toutiao.com/favicon.ico', '今日头条新闻', 'jinritoutiao', 'jrtt', 0, 1);

-- 科技资讯网址
INSERT INTO websites (section_id, name, url, icon, description, pinyin, pinyin_initials, sort_order, is_hot) VALUES
(21, '36氪', 'https://36kr.com', 'https://36kr.com/favicon.ico', '创业科技媒体', '36ke', '36k', 0, 1),
(21, '虎嗅', 'https://www.huxiu.com', 'https://www.huxiu.com/favicon.ico', '科技商业媒体', 'huxiu', 'hx', 1, 1);

-- 综合电商网址
INSERT INTO websites (section_id, name, url, icon, description, pinyin, pinyin_initials, sort_order, is_hot) VALUES
(22, '淘宝', 'https://www.taobao.com', 'https://www.taobao.com/favicon.ico', '淘宝购物', 'taobao', 'tb', 0, 1),
(22, '京东', 'https://www.jd.com', 'https://www.jd.com/favicon.ico', '京东商城', 'jingdong', 'jd', 1, 1);

-- 数码科技网址
INSERT INTO websites (section_id, name, url, icon, description, pinyin, pinyin_initials, sort_order, is_hot) VALUES
(23, '苹果官网', 'https://www.apple.com.cn', 'https://www.apple.com.cn/favicon.ico', 'Apple中国', 'pingguoguanwang', 'pggw', 0, 1),
(23, '小米商城', 'https://www.mi.com', 'https://www.mi.com/favicon.ico', '小米官方商城', 'xiaomishangcheng', 'xmsc', 1, 1);

-- 系统设置初始数据
INSERT INTO system_settings (setting_key, setting_value, description) VALUES
('site_name', 'NavHub', '网站名称'),
('site_logo', '/logo.svg', '网站Logo'),
('default_search_engine', 'baidu', '默认搜索引擎'),
('footer_copyright', '© 2024 NavHub. All rights reserved.', '页脚版权信息'),
('footer_contact', 'contact@navhub.com', '联系邮箱'),
('theme_mode', 'system', '主题模式（light/dark/system）');

-- 励志语录初始数据
INSERT INTO quotes (content, author, source, category, is_active) VALUES
('千里之行，始于足下。', '老子', '道德经', 'philosophy', 1),
('不积跬步，无以至千里；不积小流，无以成江海。', '荀子', '劝学', 'philosophy', 1),
('学而不思则罔，思而不学则殆。', '孔子', '论语', 'learning', 1),
('业精于勤，荒于嬉；行成于思，毁于随。', '韩愈', '进学解', 'motivation', 1),
('天行健，君子以自强不息。', '', '周易', 'motivation', 1),
('宝剑锋从磨砺出，梅花香自苦寒来。', '', '警世贤文', 'motivation', 1),
('路漫漫其修远兮，吾将上下而求索。', '屈原', '离骚', 'motivation', 1),
('世上无难事，只怕有心人。', '', '谚语', 'motivation', 1),
('知之为知之，不知为不知，是知也。', '孔子', '论语', 'learning', 1),
('吾生也有涯，而知也无涯。', '庄子', '养生主', 'philosophy', 1),
('Stay hungry, stay foolish.', 'Steve Jobs', 'Stanford Commencement Speech', 'motivation', 1),
('The only way to do great work is to love what you do.', 'Steve Jobs', '', 'motivation', 1),
('Innovation distinguishes between a leader and a follower.', 'Steve Jobs', '', 'innovation', 1),
('Talk is cheap. Show me the code.', 'Linus Torvalds', '', 'tech', 1),
('First, solve the problem. Then, write the code.', 'John Johnson', '', 'tech', 1),
('Any fool can write code that a computer can understand. Good programmers write code that humans can understand.', 'Martin Fowler', 'Refactoring', 'tech', 1),
('Simplicity is the soul of efficiency.', 'Austin Freeman', '', 'tech', 1),
('Code is like humor. When you have to explain it, it''s bad.', 'Cory House', '', 'tech', 1);
