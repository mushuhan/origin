-- 网址导航系统数据库初始化脚本
-- MySQL 8.0+

-- 创建数据库
CREATE DATABASE IF NOT EXISTS nav_system 
CHARACTER SET utf8mb4 
COLLATE utf8mb4_unicode_ci;

USE nav_system;

-- 侧边栏分类表
DROP TABLE IF EXISTS sidebar_categories;
CREATE TABLE sidebar_categories (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(50) NOT NULL COMMENT '分类名称',
    icon VARCHAR(100) DEFAULT NULL COMMENT '分类图标',
    sort_order INT DEFAULT 0 COMMENT '排序顺序',
    is_system TINYINT(1) DEFAULT 0 COMMENT '是否系统分类(工作台)',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='侧边栏分类表';

-- 网址分区表(每个分类下的分区)
DROP TABLE IF EXISTS sections;
CREATE TABLE sections (
    id INT PRIMARY KEY AUTO_INCREMENT,
    category_id INT NOT NULL COMMENT '所属分类ID',
    name VARCHAR(100) NOT NULL COMMENT '分区名称',
    description VARCHAR(255) DEFAULT NULL COMMENT '分区描述',
    sort_order INT DEFAULT 0 COMMENT '排序顺序',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES sidebar_categories(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='网址分区表';

-- 网址表
DROP TABLE IF EXISTS websites;
CREATE TABLE websites (
    id INT PRIMARY KEY AUTO_INCREMENT,
    section_id INT NOT NULL COMMENT '所属分区ID',
    name VARCHAR(100) NOT NULL COMMENT '网站名称',
    url VARCHAR(500) NOT NULL COMMENT '网站URL',
    icon VARCHAR(500) DEFAULT NULL COMMENT '网站图标URL',
    description VARCHAR(255) DEFAULT NULL COMMENT '网站描述',
    sort_order INT DEFAULT 0 COMMENT '排序顺序',
    click_count INT DEFAULT 0 COMMENT '点击次数',
    is_hot TINYINT(1) DEFAULT 0 COMMENT '是否热门',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (section_id) REFERENCES sections(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='网址表';

-- 用户工作台表(自定义网址)
DROP TABLE IF EXISTS workspace_items;
CREATE TABLE workspace_items (
    id INT PRIMARY KEY AUTO_INCREMENT,
    website_id INT DEFAULT NULL COMMENT '关联的网址ID(从库存添加)',
    custom_name VARCHAR(100) DEFAULT NULL COMMENT '自定义名称',
    custom_url VARCHAR(500) DEFAULT NULL COMMENT '自定义URL',
    custom_icon VARCHAR(500) DEFAULT NULL COMMENT '自定义图标',
    custom_description VARCHAR(255) DEFAULT NULL COMMENT '自定义描述',
    sort_order INT DEFAULT 0 COMMENT '排序顺序',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (website_id) REFERENCES websites(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户工作台表';

-- 搜索历史表
DROP TABLE IF EXISTS search_history;
CREATE TABLE search_history (
    id INT PRIMARY KEY AUTO_INCREMENT,
    keyword VARCHAR(200) NOT NULL COMMENT '搜索关键词',
    search_count INT DEFAULT 1 COMMENT '搜索次数',
    last_searched_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='搜索历史表';

-- 系统设置表
DROP TABLE IF EXISTS system_settings;
CREATE TABLE system_settings (
    id INT PRIMARY KEY AUTO_INCREMENT,
    setting_key VARCHAR(50) NOT NULL UNIQUE COMMENT '设置键',
    setting_value TEXT COMMENT '设置值',
    description VARCHAR(255) DEFAULT NULL COMMENT '设置描述',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='系统设置表';

-- 创建索引
CREATE INDEX idx_websites_section ON websites(section_id);
CREATE INDEX idx_websites_click ON websites(click_count DESC);
CREATE INDEX idx_websites_hot ON websites(is_hot);
CREATE INDEX idx_sections_category ON sections(category_id);
CREATE INDEX idx_workspace_website ON workspace_items(website_id);
CREATE INDEX idx_search_keyword ON search_history(keyword);
CREATE INDEX idx_search_count ON search_history(search_count DESC);

-- 插入初始数据

-- 侧边栏分类
INSERT INTO sidebar_categories (name, icon, sort_order, is_system) VALUES
('自定义工作台', 'Briefcase', 0, 1),
('常用工具', 'Tools', 1, 0),
('技术开发', 'Code', 2, 0),
('设计资源', 'Palette', 3, 0),
('学习教育', 'BookOpen', 4, 0),
('影音娱乐', 'Film', 5, 0),
('社交媒体', 'Users', 6, 0),
('新闻资讯', 'Newspaper', 7, 0),
('购物电商', 'ShoppingCart', 8, 0);

-- 常用工具分区
INSERT INTO sections (category_id, name, description, sort_order) VALUES
(2, '搜索引擎', '各大搜索引擎入口', 0),
(2, '在线翻译', '多语言翻译工具', 1),
(2, '文档办公', '在线文档和办公工具', 2),
(2, 'AI工具', '人工智能相关工具', 3);

-- 技术开发分区
INSERT INTO sections (category_id, name, description, sort_order) VALUES
(3, '代码托管', 'Git代码托管平台', 0),
(3, '技术社区', '程序员社区和论坛', 1),
(3, '开发文档', '各类技术文档', 2),
(3, '在线工具', '开发者在线工具', 3);

-- 设计资源分区
INSERT INTO sections (category_id, name, description, sort_order) VALUES
(4, '设计工具', '在线设计工具', 0),
(4, '图标素材', '图标和素材资源', 1),
(4, '配色方案', '配色工具和灵感', 2);

-- 学习教育分区
INSERT INTO sections (category_id, name, description, sort_order) VALUES
(5, '在线课程', '在线学习平台', 0),
(5, '编程学习', '编程教学资源', 1),
(5, '知识百科', '百科和知识库', 2);

-- 影音娱乐分区
INSERT INTO sections (category_id, name, description, sort_order) VALUES
(6, '视频平台', '主流视频网站', 0),
(6, '音乐平台', '音乐播放平台', 1),
(6, '直播平台', '直播网站', 2);

-- 社交媒体分区
INSERT INTO sections (category_id, name, description, sort_order) VALUES
(7, '社交网络', '社交媒体平台', 0),
(7, '即时通讯', '在线聊天工具', 1);

-- 新闻资讯分区
INSERT INTO sections (category_id, name, description, sort_order) VALUES
(8, '综合新闻', '新闻门户网站', 0),
(8, '科技资讯', '科技新闻网站', 1);

-- 购物电商分区
INSERT INTO sections (category_id, name, description, sort_order) VALUES
(9, '综合电商', '综合购物平台', 0),
(9, '数码科技', '数码产品商城', 1);

-- 搜索引擎网址
INSERT INTO websites (section_id, name, url, icon, description, sort_order, is_hot) VALUES
(1, '百度', 'https://www.baidu.com', 'https://www.baidu.com/favicon.ico', '全球最大的中文搜索引擎', 0, 1),
(1, 'Google', 'https://www.google.com', 'https://www.google.com/favicon.ico', '全球最大的搜索引擎', 1, 1),
(1, 'Bing', 'https://www.bing.com', 'https://www.bing.com/favicon.ico', '微软搜索引擎', 2, 0),
(1, '搜狗', 'https://www.sogou.com', 'https://www.sogou.com/favicon.ico', '搜狗搜索引擎', 3, 0);

-- 在线翻译网址
INSERT INTO websites (section_id, name, url, icon, description, sort_order, is_hot) VALUES
(2, '百度翻译', 'https://fanyi.baidu.com', 'https://fanyi.baidu.com/favicon.ico', '百度在线翻译', 0, 1),
(2, 'Google翻译', 'https://translate.google.com', 'https://translate.google.com/favicon.ico', '谷歌在线翻译', 1, 1),
(2, 'DeepL', 'https://www.deepl.com/translator', 'https://www.deepl.com/favicon.ico', 'AI翻译工具', 2, 1);

-- 文档办公网址
INSERT INTO websites (section_id, name, url, icon, description, sort_order, is_hot) VALUES
(3, '腾讯文档', 'https://docs.qq.com', 'https://docs.qq.com/favicon.ico', '腾讯在线文档协作', 0, 1),
(3, '石墨文档', 'https://shimo.im', 'https://shimo.im/favicon.ico', '云端Office办公', 1, 0),
(3, '语雀', 'https://www.yuque.com', 'https://www.yuque.com/favicon.ico', '阿里知识库', 2, 1),
(3, 'Notion', 'https://www.notion.so', 'https://www.notion.so/favicon.ico', '全能工作空间', 3, 1);

-- AI工具网址
INSERT INTO websites (section_id, name, url, icon, description, sort_order, is_hot) VALUES
(4, 'ChatGPT', 'https://chat.openai.com', 'https://chat.openai.com/favicon.ico', 'OpenAI对话AI', 0, 1),
(4, '文心一言', 'https://yiyan.baidu.com', 'https://yiyan.baidu.com/favicon.ico', '百度AI助手', 1, 1),
(4, '通义千问', 'https://tongyi.aliyun.com', 'https://tongyi.aliyun.com/favicon.ico', '阿里AI助手', 2, 1),
(4, 'Claude', 'https://claude.ai', 'https://claude.ai/favicon.ico', 'Anthropic AI助手', 3, 1);

-- 代码托管网址
INSERT INTO websites (section_id, name, url, icon, description, sort_order, is_hot) VALUES
(5, 'GitHub', 'https://github.com', 'https://github.com/favicon.ico', '全球最大代码托管平台', 0, 1),
(5, 'Gitee', 'https://gitee.com', 'https://gitee.com/favicon.ico', '国内代码托管平台', 1, 1),
(5, 'GitLab', 'https://gitlab.com', 'https://gitlab.com/favicon.ico', '开源代码托管平台', 2, 0);

-- 技术社区网址
INSERT INTO websites (section_id, name, url, icon, description, sort_order, is_hot) VALUES
(6, '掘金', 'https://juejin.cn', 'https://juejin.cn/favicon.ico', '开发者社区', 0, 1),
(6, 'CSDN', 'https://www.csdn.net', 'https://www.csdn.net/favicon.ico', '中文IT社区', 1, 1),
(6, 'Stack Overflow', 'https://stackoverflow.com', 'https://stackoverflow.com/favicon.ico', '程序员问答社区', 2, 1),
(6, '博客园', 'https://www.cnblogs.com', 'https://www.cnblogs.com/favicon.ico', '开发者博客平台', 3, 0),
(6, 'SegmentFault', 'https://segmentfault.com', 'https://segmentfault.com/favicon.ico', '技术问答社区', 4, 0);

-- 开发文档网址
INSERT INTO websites (section_id, name, url, icon, description, sort_order, is_hot) VALUES
(7, 'MDN Web Docs', 'https://developer.mozilla.org', 'https://developer.mozilla.org/favicon.ico', 'Web开发文档', 0, 1),
(7, 'Vue.js', 'https://vuejs.org', 'https://vuejs.org/favicon.ico', 'Vue框架官方文档', 1, 1),
(7, 'React', 'https://react.dev', 'https://react.dev/favicon.ico', 'React框架官方文档', 2, 1);

-- 在线工具网址
INSERT INTO websites (section_id, name, url, icon, description, sort_order, is_hot) VALUES
(8, 'CodePen', 'https://codepen.io', 'https://codepen.io/favicon.ico', '在线代码编辑器', 0, 1),
(8, 'JSFiddle', 'https://jsfiddle.net', 'https://jsfiddle.net/favicon.ico', '在线代码测试', 1, 0),
(8, 'RegExr', 'https://regexr.com', 'https://regexr.com/favicon.ico', '正则表达式测试', 2, 0);

-- 设计工具网址
INSERT INTO websites (section_id, name, url, icon, description, sort_order, is_hot) VALUES
(9, 'Figma', 'https://www.figma.com', 'https://www.figma.com/favicon.ico', '在线UI设计工具', 0, 1),
(9, 'Canva', 'https://www.canva.com', 'https://www.canva.com/favicon.ico', '在线设计平台', 1, 1),
(9, '即时设计', 'https://js.design', 'https://js.design/favicon.ico', '国产在线设计工具', 2, 1);

-- 图标素材网址
INSERT INTO websites (section_id, name, url, icon, description, sort_order, is_hot) VALUES
(10, 'iconfont', 'https://www.iconfont.cn', 'https://www.iconfont.cn/favicon.ico', '阿里图标库', 0, 1),
(10, 'Unsplash', 'https://unsplash.com', 'https://unsplash.com/favicon.ico', '免费高清图片', 1, 1),
(10, 'Pexels', 'https://www.pexels.com', 'https://www.pexels.com/favicon.ico', '免费图片视频', 2, 0);

-- 配色方案网址
INSERT INTO websites (section_id, name, url, icon, description, sort_order, is_hot) VALUES
(11, 'Coolors', 'https://coolors.co', 'https://coolors.co/favicon.ico', '配色生成器', 0, 1),
(11, 'Color Hunt', 'https://colorhunt.co', 'https://colorhunt.co/favicon.ico', '配色方案库', 1, 0);

-- 在线课程网址
INSERT INTO websites (section_id, name, url, icon, description, sort_order, is_hot) VALUES
(12, '慕课网', 'https://www.imooc.com', 'https://www.imooc.com/favicon.ico', 'IT技能学习平台', 0, 1),
(12, '网易公开课', 'https://open.163.com', 'https://open.163.com/favicon.ico', '网易免费课程', 1, 0),
(12, 'Coursera', 'https://www.coursera.org', 'https://www.coursera.org/favicon.ico', '全球在线学习平台', 2, 1);

-- 编程学习网址
INSERT INTO websites (section_id, name, url, icon, description, sort_order, is_hot) VALUES
(13, 'LeetCode', 'https://leetcode.cn', 'https://leetcode.cn/favicon.ico', '算法刷题平台', 0, 1),
(13, '菜鸟教程', 'https://www.runoob.com', 'https://www.runoob.com/favicon.ico', '编程入门教程', 1, 1),
(13, 'W3Schools', 'https://www.w3schools.com', 'https://www.w3schools.com/favicon.ico', 'Web技术教程', 2, 0);

-- 知识百科网址
INSERT INTO websites (section_id, name, url, icon, description, sort_order, is_hot) VALUES
(14, '维基百科', 'https://zh.wikipedia.org', 'https://zh.wikipedia.org/favicon.ico', '自由的百科全书', 0, 1),
(14, '百度百科', 'https://baike.baidu.com', 'https://baike.baidu.com/favicon.ico', '中文百科全书', 1, 1),
(14, '知乎', 'https://www.zhihu.com', 'https://www.zhihu.com/favicon.ico', '知识问答社区', 2, 1);

-- 视频平台网址
INSERT INTO websites (section_id, name, url, icon, description, sort_order, is_hot) VALUES
(15, 'Bilibili', 'https://www.bilibili.com', 'https://www.bilibili.com/favicon.ico', 'B站视频平台', 0, 1),
(15, '优酷', 'https://www.youku.com', 'https://www.youku.com/favicon.ico', '优酷视频', 1, 0),
(15, '爱奇艺', 'https://www.iqiyi.com', 'https://www.iqiyi.com/favicon.ico', '爱奇艺视频', 2, 0),
(15, 'YouTube', 'https://www.youtube.com', 'https://www.youtube.com/favicon.ico', '全球视频平台', 3, 1);

-- 音乐平台网址
INSERT INTO websites (section_id, name, url, icon, description, sort_order, is_hot) VALUES
(16, '网易云音乐', 'https://music.163.com', 'https://music.163.com/favicon.ico', '网易云音乐', 0, 1),
(16, 'QQ音乐', 'https://y.qq.com', 'https://y.qq.com/favicon.ico', 'QQ音乐', 1, 1),
(16, 'Spotify', 'https://www.spotify.com', 'https://www.spotify.com/favicon.ico', '全球音乐平台', 2, 0);

-- 直播平台网址
INSERT INTO websites (section_id, name, url, icon, description, sort_order, is_hot) VALUES
(17, '斗鱼', 'https://www.douyu.com', 'https://www.douyu.com/favicon.ico', '斗鱼直播', 0, 1),
(17, '虎牙', 'https://www.huya.com', 'https://www.huya.com/favicon.ico', '虎牙直播', 1, 1);

-- 社交网络网址
INSERT INTO websites (section_id, name, url, icon, description, sort_order, is_hot) VALUES
(18, '微博', 'https://weibo.com', 'https://weibo.com/favicon.ico', '新浪微博', 0, 1),
(18, 'Twitter/X', 'https://twitter.com', 'https://twitter.com/favicon.ico', '推特社交平台', 1, 1),
(18, '豆瓣', 'https://www.douban.com', 'https://www.douban.com/favicon.ico', '豆瓣社区', 2, 0);

-- 即时通讯网址
INSERT INTO websites (section_id, name, url, icon, description, sort_order, is_hot) VALUES
(19, '微信网页版', 'https://wx.qq.com', 'https://wx.qq.com/favicon.ico', '微信网页版', 0, 1),
(19, 'QQ邮箱', 'https://mail.qq.com', 'https://mail.qq.com/favicon.ico', 'QQ邮箱', 1, 1),
(19, 'Gmail', 'https://mail.google.com', 'https://mail.google.com/favicon.ico', '谷歌邮箱', 2, 1);

-- 综合新闻网址
INSERT INTO websites (section_id, name, url, icon, description, sort_order, is_hot) VALUES
(20, '今日头条', 'https://www.toutiao.com', 'https://www.toutiao.com/favicon.ico', '今日头条新闻', 0, 1),
(20, '网易新闻', 'https://news.163.com', 'https://news.163.com/favicon.ico', '网易新闻', 1, 0),
(20, '新浪新闻', 'https://news.sina.com.cn', 'https://news.sina.com.cn/favicon.ico', '新浪新闻', 2, 0);

-- 科技资讯网址
INSERT INTO websites (section_id, name, url, icon, description, sort_order, is_hot) VALUES
(21, '36氪', 'https://36kr.com', 'https://36kr.com/favicon.ico', '创业科技媒体', 0, 1),
(21, '虎嗅', 'https://www.huxiu.com', 'https://www.huxiu.com/favicon.ico', '科技商业媒体', 1, 1),
(21, 'TechCrunch', 'https://techcrunch.com', 'https://techcrunch.com/favicon.ico', '科技新闻网站', 2, 0);

-- 综合电商网址
INSERT INTO websites (section_id, name, url, icon, description, sort_order, is_hot) VALUES
(22, '淘宝', 'https://www.taobao.com', 'https://www.taobao.com/favicon.ico', '淘宝购物', 0, 1),
(22, '京东', 'https://www.jd.com', 'https://www.jd.com/favicon.ico', '京东商城', 1, 1),
(22, '拼多多', 'https://www.pinduoduo.com', 'https://www.pinduoduo.com/favicon.ico', '拼多多购物', 2, 1);

-- 数码科技网址
INSERT INTO websites (section_id, name, url, icon, description, sort_order, is_hot) VALUES
(23, '苹果官网', 'https://www.apple.com.cn', 'https://www.apple.com.cn/favicon.ico', 'Apple中国', 0, 1),
(23, '华为商城', 'https://www.vmall.com', 'https://www.vmall.com/favicon.ico', '华为官方商城', 1, 1),
(23, '小米商城', 'https://www.mi.com', 'https://www.mi.com/favicon.ico', '小米官方商城', 2, 1);

-- 系统设置初始数据
INSERT INTO system_settings (setting_key, setting_value, description) VALUES
('site_name', 'NavHub', '网站名称'),
('site_logo', '/logo.svg', '网站Logo'),
('default_search_engine', 'baidu', '默认搜索引擎'),
('footer_copyright', '© 2024 NavHub. All rights reserved.', '页脚版权信息'),
('footer_contact', 'contact@navhub.com', '联系邮箱');

