# -*- coding: utf-8 -*-
"""
数据分析控制器
提供热门网址排行、点击统计等数据
"""
from flask import Blueprint, request
from datetime import datetime, timedelta
from sqlalchemy import func
from app import db
from app.models.website import Website
from app.models.category import SidebarCategory
from app.services.analytics_service import AnalyticsService
from app.utils.response import success_response

analytics_bp = Blueprint('analytics', __name__)


@analytics_bp.route('/hot-ranking', methods=['GET'])
def get_hot_ranking():
    """
    获取热门网址排行榜
    支持维度筛选：today（今日）、week（本周）、all（全站）
    """
    dimension = request.args.get('dimension', 'all')
    limit = request.args.get('limit', 10, type=int)
    limit = min(limit, 50)
    
    rankings = AnalyticsService.get_hot_ranking(dimension, limit)
    
    # 计算百分比（用于柱状图）
    if rankings:
        max_count = max(r['click_count'] for r in rankings)
        for rank in rankings:
            rank['percentage'] = round((rank['click_count'] / max_count) * 100, 1) if max_count > 0 else 0
    
    return success_response({
        'dimension': dimension,
        'rankings': rankings
    })


@analytics_bp.route('/category-stats', methods=['GET'])
def get_category_stats():
    """获取分类统计数据"""
    stats = AnalyticsService.get_category_stats()
    return success_response(stats)


@analytics_bp.route('/click-trends', methods=['GET'])
def get_click_trends():
    """获取点击趋势数据"""
    days = request.args.get('days', 7, type=int)
    days = min(days, 30)
    
    trends = AnalyticsService.get_click_trends(days)
    return success_response(trends)


@analytics_bp.route('/overview', methods=['GET'])
def get_overview():
    """获取数据概览"""
    from app.models.section import Section
    from app.models.user import User
    
    # 基础统计
    total_websites = Website.query.count()
    total_categories = SidebarCategory.query.filter_by(is_system=False).count()
    total_sections = Section.query.count()
    total_users = User.query.count()
    total_clicks = db.session.query(func.sum(Website.click_count)).scalar() or 0
    
    # 今日新增
    today = datetime.utcnow().date()
    new_websites_today = Website.query.filter(
        func.date(Website.created_at) == today
    ).count()
    
    return success_response({
        'total_websites': total_websites,
        'total_categories': total_categories,
        'total_sections': total_sections,
        'total_users': total_users,
        'total_clicks': total_clicks,
        'new_websites_today': new_websites_today
    })

