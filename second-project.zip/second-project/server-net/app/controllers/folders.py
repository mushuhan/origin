# -*- coding: utf-8 -*-
"""
文件夹控制器
处理用户工作台文件夹的CRUD操作
"""
from flask import Blueprint, request, g
from app import db
from app.models.folder import Folder
from app.utils.response import success_response, error_response
from app.utils.decorators import require_user
from app.services.folder_service import FolderService

folders_bp = Blueprint('folders', __name__)


@folders_bp.route('', methods=['GET'])
@require_user
def get_folders():
    """获取用户文件夹列表"""
    user_uuid = g.user_uuid
    flat = request.args.get('flat', 'false').lower() == 'true'
    include_sites = request.args.get('include_sites', 'false').lower() == 'true'
    
    if flat:
        # 扁平化列表
        folders = Folder.query.filter_by(user_uuid=user_uuid).order_by(
            Folder.sort_order
        ).all()
        return success_response([f.to_dict(include_sites=include_sites) for f in folders])
    else:
        # 树形结构
        return success_response(FolderService.get_folder_tree(user_uuid, include_sites))


@folders_bp.route('/<int:id>', methods=['GET'])
@require_user
def get_folder(id):
    """获取单个文件夹详情"""
    user_uuid = g.user_uuid
    include_sites = request.args.get('include_sites', 'true').lower() == 'true'
    
    folder = Folder.query.filter_by(id=id, user_uuid=user_uuid).first()
    if not folder:
        return error_response('文件夹不存在', 404)
    
    return success_response(folder.to_dict(include_children=True, include_sites=include_sites))


@folders_bp.route('', methods=['POST'])
@require_user
def create_folder():
    """创建文件夹"""
    user_uuid = g.user_uuid
    data = request.get_json()
    
    if not data or not data.get('name'):
        return error_response('文件夹名称不能为空', 400)
    
    # 验证父文件夹
    parent_id = data.get('parent_id')
    if parent_id:
        parent = Folder.query.filter_by(id=parent_id, user_uuid=user_uuid).first()
        if not parent:
            return error_response('父文件夹不存在', 404)
    
    # 获取同级最大排序值
    max_order = db.session.query(db.func.max(Folder.sort_order)).filter(
        Folder.user_uuid == user_uuid,
        Folder.parent_id == parent_id
    ).scalar() or 0
    
    folder = Folder(
        user_uuid=user_uuid,
        name=data['name'],
        parent_id=parent_id,
        icon=data.get('icon', 'Folder'),
        color=data.get('color', '#6b7280'),
        sort_order=max_order + 1
    )
    
    db.session.add(folder)
    db.session.commit()
    
    return success_response(folder.to_dict(), '创建成功', 201)


@folders_bp.route('/<int:id>', methods=['PUT'])
@require_user
def update_folder(id):
    """更新文件夹"""
    user_uuid = g.user_uuid
    
    folder = Folder.query.filter_by(id=id, user_uuid=user_uuid).first()
    if not folder:
        return error_response('文件夹不存在', 404)
    
    data = request.get_json()
    
    if data.get('name'):
        folder.name = data['name']
    if 'icon' in data:
        folder.icon = data['icon']
    if 'color' in data:
        folder.color = data['color']
    if 'is_collapsed' in data:
        folder.is_collapsed = data['is_collapsed']
    if 'parent_id' in data:
        # 防止循环引用
        if data['parent_id'] == id:
            return error_response('不能将文件夹移动到自身', 400)
        
        if data['parent_id']:
            parent = Folder.query.filter_by(
                id=data['parent_id'],
                user_uuid=user_uuid
            ).first()
            if not parent:
                return error_response('父文件夹不存在', 404)
            
            # 检查是否会造成循环
            if FolderService.is_descendant(parent, folder):
                return error_response('不能将文件夹移动到其子文件夹中', 400)
        
        folder.parent_id = data['parent_id']
    
    if 'sort_order' in data:
        folder.sort_order = data['sort_order']
    
    db.session.commit()
    
    return success_response(folder.to_dict(), '更新成功')


@folders_bp.route('/<int:id>', methods=['DELETE'])
@require_user
def delete_folder(id):
    """删除文件夹"""
    user_uuid = g.user_uuid
    
    folder = Folder.query.filter_by(id=id, user_uuid=user_uuid).first()
    if not folder:
        return error_response('文件夹不存在', 404)
    
    # 检查是否需要删除子项
    move_to_parent = request.args.get('move_to_parent', 'false').lower() == 'true'
    
    if move_to_parent:
        # 将子文件夹和网址移动到父级
        FolderService.move_children_to_parent(folder)
    
    db.session.delete(folder)
    db.session.commit()
    
    return success_response(None, '删除成功')


@folders_bp.route('/reorder', methods=['PUT'])
@require_user
def reorder_folders():
    """重新排序文件夹"""
    user_uuid = g.user_uuid
    data = request.get_json()
    items = data.get('items', [])
    
    for item_data in items:
        folder = Folder.query.filter_by(
            id=item_data['id'],
            user_uuid=user_uuid
        ).first()
        if folder:
            folder.sort_order = item_data['sort_order']
            if 'parent_id' in item_data:
                folder.parent_id = item_data['parent_id']
    
    db.session.commit()
    
    return success_response(None, '排序更新成功')

