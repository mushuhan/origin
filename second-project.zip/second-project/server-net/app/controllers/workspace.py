# -*- coding: utf-8 -*-
"""
工作台控制器
处理用户私有工作台的CRUD操作（已隔离）
"""
from flask import Blueprint, request, g
from app import db
from app.models.workspace import UserSite
from app.models.website import Website
from app.models.folder import Folder
from app.utils.response import success_response, error_response
from app.utils.decorators import require_user

workspace_bp = Blueprint('workspace', __name__)


@workspace_bp.route('', methods=['GET'])
@require_user
def get_workspace():
    """获取用户工作台项目"""
    user_uuid = g.user_uuid
    folder_id = request.args.get('folder_id', type=int)
    
    query = UserSite.query.filter_by(user_uuid=user_uuid)
    
    if folder_id:
        query = query.filter_by(folder_id=folder_id)
    else:
        # 默认获取未分组的项目
        query = query.filter_by(folder_id=None)
    
    items = query.order_by(UserSite.sort_order).all()
    
    return success_response([item.to_dict() for item in items])


@workspace_bp.route('/all', methods=['GET'])
@require_user
def get_all_workspace():
    """获取用户所有工作台项目（含文件夹结构）"""
    user_uuid = g.user_uuid
    
    # 获取所有文件夹（树形结构）
    root_folders = Folder.query.filter_by(
        user_uuid=user_uuid,
        parent_id=None
    ).order_by(Folder.sort_order).all()
    
    folders_data = [f.to_tree_dict() for f in root_folders]
    
    # 获取未分组的网址
    ungrouped = UserSite.query.filter_by(
        user_uuid=user_uuid,
        folder_id=None
    ).order_by(UserSite.sort_order).all()
    
    return success_response({
        'folders': folders_data,
        'ungrouped': [item.to_dict() for item in ungrouped]
    })


@workspace_bp.route('', methods=['POST'])
@require_user
def add_to_workspace():
    """添加到工作台"""
    user_uuid = g.user_uuid
    data = request.get_json()
    
    website_id = data.get('website_id')
    
    # 如果是从公共库添加
    if website_id:
        # 检查是否已添加
        existing = UserSite.query.filter_by(
            user_uuid=user_uuid,
            website_id=website_id
        ).first()
        
        if existing:
            return error_response('该网址已在工作台中', 400)
        
        # 验证网址存在
        website = Website.query.get(website_id)
        if not website:
            return error_response('网址不存在', 404)
    
    # 获取最大排序值
    max_order = db.session.query(db.func.max(UserSite.sort_order)).filter(
        UserSite.user_uuid == user_uuid,
        UserSite.folder_id == data.get('folder_id')
    ).scalar() or 0
    
    item = UserSite(
        user_uuid=user_uuid,
        website_id=website_id,
        folder_id=data.get('folder_id'),
        custom_name=data.get('custom_name'),
        custom_url=data.get('custom_url'),
        custom_icon=data.get('custom_icon'),
        custom_description=data.get('custom_description'),
        sort_order=max_order + 1
    )
    
    db.session.add(item)
    db.session.commit()
    
    return success_response(item.to_dict(), '添加成功', 201)


@workspace_bp.route('/<int:id>', methods=['PUT'])
@require_user
def update_workspace_item(id):
    """更新工作台项目"""
    user_uuid = g.user_uuid
    
    item = UserSite.query.filter_by(id=id, user_uuid=user_uuid).first()
    if not item:
        return error_response('项目不存在', 404)
    
    data = request.get_json()
    
    if 'custom_name' in data:
        item.custom_name = data['custom_name']
    if 'custom_url' in data:
        item.custom_url = data['custom_url']
    if 'custom_icon' in data:
        item.custom_icon = data['custom_icon']
    if 'custom_description' in data:
        item.custom_description = data['custom_description']
    if 'folder_id' in data:
        # 验证文件夹存在且属于当前用户
        if data['folder_id']:
            folder = Folder.query.filter_by(
                id=data['folder_id'],
                user_uuid=user_uuid
            ).first()
            if not folder:
                return error_response('文件夹不存在', 404)
        item.folder_id = data['folder_id']
    if 'sort_order' in data:
        item.sort_order = data['sort_order']
    
    db.session.commit()
    
    return success_response(item.to_dict(), '更新成功')


@workspace_bp.route('/<int:id>', methods=['DELETE'])
@require_user
def remove_from_workspace(id):
    """从工作台移除"""
    user_uuid = g.user_uuid
    
    item = UserSite.query.filter_by(id=id, user_uuid=user_uuid).first()
    if not item:
        return error_response('项目不存在', 404)
    
    db.session.delete(item)
    db.session.commit()
    
    return success_response(None, '移除成功')


@workspace_bp.route('/reorder', methods=['PUT'])
@require_user
def reorder_workspace():
    """重新排序工作台项目"""
    user_uuid = g.user_uuid
    data = request.get_json()
    items = data.get('items', [])
    
    for item_data in items:
        item = UserSite.query.filter_by(
            id=item_data['id'],
            user_uuid=user_uuid
        ).first()
        if item:
            item.sort_order = item_data['sort_order']
            if 'folder_id' in item_data:
                item.folder_id = item_data['folder_id']
    
    db.session.commit()
    
    return success_response(None, '排序更新成功')

