# -*- coding: utf-8 -*-
"""
首页控制器
聚合首页所需的所有数据
"""
from flask import Blueprint, g
from app.models.category import SidebarCategory
from app.models.website import Website
from app.models.setting import SystemSetting
from app.services.quote_service import QuoteService
from app.utils.response import success_response

home_bp = Blueprint('home', __name__)


@home_bp.route('', methods=['GET'])
def get_home_data():
    """
    获取首页聚合数据
    包含：分类列表、热门网址、系统设置、每日语录
    """
    # 获取所有分类（含分区和网址）
    categories = SidebarCategory.query.order_by(SidebarCategory.sort_order).all()
    categories_data = [c.to_dict_with_sections() for c in categories]
    
    # 获取热门网址
    hot_websites = Website.query.filter_by(is_hot=True).order_by(
        Website.click_count.desc()
    ).limit(20).all()
    
    # 如果热门网址不足，补充点击量高的
    if len(hot_websites) < 20:
        existing_ids = [w.id for w in hot_websites]
        additional = Website.query.filter(
            ~Website.id.in_(existing_ids) if existing_ids else True
        ).order_by(Website.click_count.desc()).limit(20 - len(hot_websites)).all()
        hot_websites.extend(additional)
    
    # 获取系统设置
    settings = {}
    system_settings = SystemSetting.query.all()
    for setting in system_settings:
        settings[setting.setting_key] = setting.setting_value
    
    # 获取每日语录
    daily_quote = QuoteService.get_daily_quote()
    
    return success_response({
        'categories': categories_data,
        'hot_websites': [w.to_dict() for w in hot_websites],
        'settings': settings,
        'quote': daily_quote
    })


@home_bp.route('/stats', methods=['GET'])
def get_site_stats():
    """获取网站统计数据"""
    from app import db
    from app.models.section import Section
    
    # 统计数据
    total_categories = SidebarCategory.query.count()
    total_sections = Section.query.count()
    total_websites = Website.query.count()
    total_clicks = db.session.query(db.func.sum(Website.click_count)).scalar() or 0
    
    return success_response({
        'total_categories': total_categories,
        'total_sections': total_sections,
        'total_websites': total_websites,
        'total_clicks': total_clicks
    })

