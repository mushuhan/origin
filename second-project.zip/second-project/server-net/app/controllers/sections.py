# -*- coding: utf-8 -*-
"""
分区控制器
处理网址分区的CRUD操作
"""
from flask import Blueprint, request
from app import db
from app.models.section import Section
from app.models.category import SidebarCategory
from app.utils.response import success_response, error_response

sections_bp = Blueprint('sections', __name__)


@sections_bp.route('', methods=['GET'])
def get_sections():
    """获取分区列表"""
    category_id = request.args.get('category_id', type=int)
    include_websites = request.args.get('include_websites', 'false').lower() == 'true'
    
    query = Section.query
    
    if category_id:
        query = query.filter_by(category_id=category_id)
    
    sections = query.order_by(Section.sort_order).all()
    
    if include_websites:
        data = [s.to_dict_with_websites() for s in sections]
    else:
        data = [s.to_dict() for s in sections]
    
    return success_response(data)


@sections_bp.route('/<int:id>', methods=['GET'])
def get_section(id):
    """获取单个分区详情"""
    section = Section.query.get_or_404(id)
    return success_response(section.to_dict_with_websites())


@sections_bp.route('', methods=['POST'])
def create_section():
    """创建分区"""
    data = request.get_json()
    
    if not data or not data.get('name'):
        return error_response('分区名称不能为空', 400)
    
    if not data.get('category_id'):
        return error_response('必须指定所属分类', 400)
    
    # 验证分类存在
    category = SidebarCategory.query.get(data['category_id'])
    if not category:
        return error_response('分类不存在', 404)
    
    # 获取该分类下最大排序值
    max_order = db.session.query(db.func.max(Section.sort_order)).filter(
        Section.category_id == data['category_id']
    ).scalar() or 0
    
    section = Section(
        category_id=data['category_id'],
        name=data['name'],
        description=data.get('description'),
        sort_order=max_order + 1
    )
    
    db.session.add(section)
    db.session.commit()
    
    return success_response(section.to_dict(), '创建成功', 201)


@sections_bp.route('/<int:id>', methods=['PUT'])
def update_section(id):
    """更新分区"""
    section = Section.query.get_or_404(id)
    data = request.get_json()
    
    if data.get('name'):
        section.name = data['name']
    if 'description' in data:
        section.description = data['description']
    if 'category_id' in data:
        # 验证分类存在
        category = SidebarCategory.query.get(data['category_id'])
        if not category:
            return error_response('分类不存在', 404)
        section.category_id = data['category_id']
    if 'sort_order' in data:
        section.sort_order = data['sort_order']
    
    db.session.commit()
    
    return success_response(section.to_dict(), '更新成功')


@sections_bp.route('/<int:id>', methods=['DELETE'])
def delete_section(id):
    """删除分区"""
    section = Section.query.get_or_404(id)
    
    db.session.delete(section)
    db.session.commit()
    
    return success_response(None, '删除成功')


@sections_bp.route('/batch-reorder', methods=['PUT'])
def batch_reorder():
    """批量重排序分区"""
    data = request.get_json()
    items = data.get('items', [])
    
    for item in items:
        section = Section.query.get(item['id'])
        if section:
            section.sort_order = item['sort_order']
            if 'category_id' in item:
                section.category_id = item['category_id']
    
    db.session.commit()
    
    return success_response(None, '排序更新成功')

