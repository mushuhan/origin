# -*- coding: utf-8 -*-
"""
企业级网址导航系统 - Flask应用工厂
支持负载均衡、跳板机代理链信任配置
"""
from flask import Flask
from flask_cors import CORS
from flask_sqlalchemy import SQLAlchemy

# 初始化扩展（延迟绑定）
db = SQLAlchemy()

def create_app(config_name='default'):
    """应用工厂函数"""
    from app.config import config
    
    app = Flask(__name__)
    app.config.from_object(config[config_name])
    
    # 初始化扩展
    db.init_app(app)
    
    # 配置CORS - 支持凭证和自定义头部
    CORS(
        app,
        origins=app.config.get('CORS_ORIGINS', ['*']),
        supports_credentials=True,
        allow_headers=['Content-Type', 'X-User-Token', 'X-Requested-With'],
        expose_headers=['X-User-Token']
    )
    
    # 配置代理链信任 - 生产环境关键配置
    configure_proxy_fix(app)
    
    # 注册蓝图
    register_blueprints(app)
    
    # 注册错误处理
    register_error_handlers(app)
    
    # 注册请求钩子
    register_request_hooks(app)
    
    return app


def configure_proxy_fix(app):
    """
    配置代理链信任
    当请求经过负载均衡（LB）和跳板机（Jump Host）时：
    - 信任 X-Forwarded-For 头部获取真实客户端IP
    - 信任 X-Forwarded-Proto 头部判断HTTPS
    - 信任 X-Forwarded-Host 头部获取原始Host
    """
    from werkzeug.middleware.proxy_fix import ProxyFix
    
    # 参数说明：
    # x_for: 信任几层代理的 X-Forwarded-For（客户端IP）
    # x_proto: 信任几层代理的 X-Forwarded-Proto（HTTPS卸载）
    # x_host: 信任几层代理的 X-Forwarded-Host
    # x_port: 信任几层代理的 X-Forwarded-Port
    # x_prefix: 信任几层代理的 X-Forwarded-Prefix
    
    proxy_count = app.config.get('PROXY_COUNT', 1)
    
    app.wsgi_app = ProxyFix(
        app.wsgi_app,
        x_for=proxy_count,
        x_proto=proxy_count,
        x_host=proxy_count,
        x_port=proxy_count,
        x_prefix=proxy_count
    )
    
    app.logger.info(f'ProxyFix configured with proxy_count={proxy_count}')


def register_blueprints(app):
    """注册所有蓝图（路由模块）"""
    from app.controllers.categories import categories_bp
    from app.controllers.sections import sections_bp
    from app.controllers.websites import websites_bp
    from app.controllers.workspace import workspace_bp
    from app.controllers.folders import folders_bp
    from app.controllers.search import search_bp
    from app.controllers.quotes import quotes_bp
    from app.controllers.users import users_bp
    from app.controllers.home import home_bp
    from app.controllers.settings import settings_bp
    from app.controllers.analytics import analytics_bp
    
    # API路由前缀
    api_prefix = '/api'
    
    app.register_blueprint(categories_bp, url_prefix=f'{api_prefix}/categories')
    app.register_blueprint(sections_bp, url_prefix=f'{api_prefix}/sections')
    app.register_blueprint(websites_bp, url_prefix=f'{api_prefix}/websites')
    app.register_blueprint(workspace_bp, url_prefix=f'{api_prefix}/workspace')
    app.register_blueprint(folders_bp, url_prefix=f'{api_prefix}/folders')
    app.register_blueprint(search_bp, url_prefix=f'{api_prefix}/search')
    app.register_blueprint(quotes_bp, url_prefix=f'{api_prefix}/quotes')
    app.register_blueprint(users_bp, url_prefix=f'{api_prefix}/users')
    app.register_blueprint(home_bp, url_prefix=f'{api_prefix}/home')
    app.register_blueprint(settings_bp, url_prefix=f'{api_prefix}/settings')
    app.register_blueprint(analytics_bp, url_prefix=f'{api_prefix}/analytics')


def register_error_handlers(app):
    """注册全局错误处理器"""
    from app.utils.response import error_response
    
    @app.errorhandler(400)
    def bad_request(error):
        return error_response('请求参数错误', 400)
    
    @app.errorhandler(401)
    def unauthorized(error):
        return error_response('未授权访问', 401)
    
    @app.errorhandler(403)
    def forbidden(error):
        return error_response('禁止访问', 403)
    
    @app.errorhandler(404)
    def not_found(error):
        return error_response('资源未找到', 404)
    
    @app.errorhandler(500)
    def internal_error(error):
        db.session.rollback()
        app.logger.error(f'Internal Server Error: {error}')
        return error_response('服务器内部错误', 500)


def register_request_hooks(app):
    """注册请求钩子"""
    from flask import g, request
    from app.services.user_service import UserService
    
    @app.before_request
    def before_request():
        """请求前处理 - 用户身份识别"""
        # 获取用户Token
        user_token = request.headers.get('X-User-Token')
        
        if user_token:
            # 获取或创建用户
            user = UserService.get_or_create_user(user_token)
            g.user = user
            g.user_uuid = user_token
        else:
            g.user = None
            g.user_uuid = None
        
        # 记录真实客户端IP（经过ProxyFix处理）
        g.client_ip = request.remote_addr
        
        # 记录协议类型（用于判断HTTPS卸载）
        g.is_secure = request.is_secure or request.headers.get('X-Forwarded-Proto') == 'https'
    
    @app.after_request
    def after_request(response):
        """请求后处理 - 添加安全头部"""
        # 安全相关头部
        response.headers['X-Content-Type-Options'] = 'nosniff'
        response.headers['X-Frame-Options'] = 'SAMEORIGIN'
        response.headers['X-XSS-Protection'] = '1; mode=block'
        
        # 如果是HTTPS，添加HSTS头部
        if g.get('is_secure'):
            response.headers['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains'
        
        return response

