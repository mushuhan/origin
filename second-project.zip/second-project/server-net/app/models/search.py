# -*- coding: utf-8 -*-
"""
搜索历史模型
"""
from datetime import datetime
from app import db


class SearchHistory(db.Model):
    """搜索历史模型"""
    __tablename__ = 'search_history'
    
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    keyword = db.Column(db.String(200), nullable=False, comment='搜索关键词')
    search_count = db.Column(db.Integer, default=1, comment='搜索次数')
    last_searched_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'keyword': self.keyword,
            'search_count': self.search_count,
            'last_searched_at': self.last_searched_at.isoformat() if self.last_searched_at else None,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }
    
    def __repr__(self):
        return f'<SearchHistory {self.keyword}>'
