# -*- coding: utf-8 -*-
"""
数据模型模块
定义所有ORM实体
"""
from app import db
from app.models.user import User
from app.models.folder import Folder
from app.models.category import SidebarCategory
from app.models.section import Section
from app.models.website import Website
from app.models.workspace import UserSite
from app.models.quote import Quote
from app.models.search import SearchHistory
from app.models.setting import SystemSetting

__all__ = [
    'db',
    'User',
    'Folder',
    'SidebarCategory',
    'Section',
    'Website',
    'UserSite',
    'Quote',
    'SearchHistory',
    'SystemSetting'
]

