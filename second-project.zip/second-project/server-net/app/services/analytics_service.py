# -*- coding: utf-8 -*-
"""
数据分析服务
"""
from datetime import datetime, timedelta
from sqlalchemy import func
from app import db
from app.models.website import Website
from app.models.category import SidebarCategory
from app.models.section import Section


class AnalyticsService:
    """数据分析服务类"""
    
    @staticmethod
    def get_hot_ranking(dimension='all', limit=10):
        """
        获取热门网址排行
        
        Args:
            dimension: 维度 (today/week/all)
            limit: 返回数量
        
        Returns:
            排行榜数据
        """
        query = db.session.query(
            Website.id,
            Website.name,
            Website.url,
            Website.icon,
            Website.click_count,
            Website.section_id
        )
        
        # 按维度筛选
        if dimension == 'today':
            today = datetime.utcnow().date()
            query = query.filter(func.date(Website.updated_at) == today)
        elif dimension == 'week':
            week_ago = datetime.utcnow() - timedelta(days=7)
            query = query.filter(Website.updated_at >= week_ago)
        
        # 排序并限制数量
        results = query.order_by(Website.click_count.desc()).limit(limit).all()
        
        rankings = []
        for i, r in enumerate(results, 1):
            rankings.append({
                'rank': i,
                'id': r.id,
                'name': r.name,
                'url': r.url,
                'icon': r.icon,
                'click_count': r.click_count or 0,
                'section_id': r.section_id
            })
        
        return rankings
    
    @staticmethod
    def get_category_stats():
        """
        获取分类统计
        
        Returns:
            各分类的网址数量和点击量
        """
        stats = []
        
        categories = SidebarCategory.query.filter_by(is_system=False).all()
        
        for category in categories:
            # 获取该分类下的所有网址
            section_ids = [s.id for s in category.sections.all()]
            
            if section_ids:
                website_count = Website.query.filter(
                    Website.section_id.in_(section_ids)
                ).count()
                
                total_clicks = db.session.query(
                    func.sum(Website.click_count)
                ).filter(
                    Website.section_id.in_(section_ids)
                ).scalar() or 0
            else:
                website_count = 0
                total_clicks = 0
            
            stats.append({
                'category_id': category.id,
                'category_name': category.name,
                'icon': category.icon,
                'website_count': website_count,
                'total_clicks': total_clicks
            })
        
        # 按网址数量排序
        stats.sort(key=lambda x: x['website_count'], reverse=True)
        
        return stats
    
    @staticmethod
    def get_click_trends(days=7):
        """
        获取点击趋势
        
        Args:
            days: 天数
        
        Returns:
            每日点击趋势数据
        """
        trends = []
        today = datetime.utcnow().date()
        
        for i in range(days - 1, -1, -1):
            date = today - timedelta(days=i)
            
            # 这里简化处理，实际应该有点击日志表
            # 当前只返回示例数据结构
            trends.append({
                'date': date.isoformat(),
                'clicks': 0  # 需要点击日志表支持
            })
        
        return trends
