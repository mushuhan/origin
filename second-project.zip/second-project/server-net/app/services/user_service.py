# -*- coding: utf-8 -*-
"""
用户服务
处理用户相关的业务逻辑
"""
from datetime import datetime
from app import db
from app.models.user import User
from app.models.workspace import UserSite
from app.models.folder import Folder


class UserService:
    """用户服务类"""
    
    @staticmethod
    def get_or_create_user(uuid):
        """
        获取或创建用户
        
        Args:
            uuid: 用户UUID
        
        Returns:
            User对象
        """
        user = User.query.get(uuid)
        
        if not user:
            user = User(uuid=uuid)
            db.session.add(user)
            db.session.commit()
        else:
            # 更新最后活跃时间
            user.last_active_at = datetime.utcnow()
            db.session.commit()
        
        return user
    
    @staticmethod
    def get_user_stats(user_uuid):
        """
        获取用户统计信息
        
        Args:
            user_uuid: 用户UUID
        
        Returns:
            统计数据字典
        """
        # 用户网址数量
        site_count = UserSite.query.filter_by(user_uuid=user_uuid).count()
        
        # 文件夹数量
        folder_count = Folder.query.filter_by(user_uuid=user_uuid).count()
        
        # 总点击数
        total_clicks = db.session.query(db.func.sum(UserSite.click_count)).filter(
            UserSite.user_uuid == user_uuid
        ).scalar() or 0
        
        # 最近添加
        recent_sites = UserSite.query.filter_by(user_uuid=user_uuid).order_by(
            UserSite.created_at.desc()
        ).limit(5).all()
        
        return {
            'site_count': site_count,
            'folder_count': folder_count,
            'total_clicks': total_clicks,
            'recent_sites': [s.to_dict() for s in recent_sites]
        }
    
    @staticmethod
    def update_user_settings(user_uuid, settings):
        """
        更新用户设置
        
        Args:
            user_uuid: 用户UUID
            settings: 设置字典
        
        Returns:
            更新后的设置
        """
        user = User.query.get(user_uuid)
        if not user:
            return None
        
        current_settings = user.settings or {}
        current_settings.update(settings)
        user.settings = current_settings
        
        db.session.commit()
        
        return user.settings
