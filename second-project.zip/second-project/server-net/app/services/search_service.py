# -*- coding: utf-8 -*-
"""
搜索服务
实现智能模糊搜索算法
"""
from sqlalchemy import or_, func
from app import db
from app.models.website import Website
from app.models.search import SearchHistory


class SearchService:
    """搜索服务类"""
    
    @staticmethod
    def fuzzy_search(keyword, limit=50):
        """
        模糊搜索
        检索域：网站名、URL、描述、拼音
        
        Args:
            keyword: 搜索关键词
            limit: 结果数量限制
        
        Returns:
            匹配的网站列表
        """
        keyword = keyword.strip().lower()
        
        if not keyword:
            return []
        
        # 构建模糊匹配条件
        like_pattern = f'%{keyword}%'
        
        # 多字段模糊匹配
        conditions = or_(
            func.lower(Website.name).like(like_pattern),
            func.lower(Website.url).like(like_pattern),
            func.lower(Website.description).like(like_pattern),
            func.lower(Website.pinyin).like(like_pattern),
            func.lower(Website.pinyin_initials).like(like_pattern)
        )
        
        # 查询并按相关性排序
        # 优先级：名称匹配 > 拼音匹配 > URL匹配 > 描述匹配
        websites = Website.query.filter(conditions).order_by(
            # 精确匹配名称的排在前面
            db.case(
                (func.lower(Website.name) == keyword, 0),
                (func.lower(Website.name).like(f'{keyword}%'), 1),
                (func.lower(Website.pinyin_initials) == keyword, 2),
                (func.lower(Website.pinyin).like(f'{keyword}%'), 3),
                else_=4
            ),
            Website.click_count.desc()
        ).limit(limit).all()
        
        return [w.to_dict() for w in websites]
    
    @staticmethod
    def get_suggestions(keyword, limit=10):
        """
        获取搜索建议（用于实时联想）
        
        Args:
            keyword: 输入关键词
            limit: 建议数量
        
        Returns:
            建议列表
        """
        keyword = keyword.strip().lower()
        
        if not keyword:
            return []
        
        like_pattern = f'{keyword}%'
        
        # 查询匹配的网站名称
        websites = Website.query.filter(
            or_(
                func.lower(Website.name).like(like_pattern),
                func.lower(Website.pinyin_initials).like(like_pattern),
                func.lower(Website.pinyin).like(like_pattern)
            )
        ).order_by(
            Website.click_count.desc()
        ).limit(limit).all()
        
        return [{
            'id': w.id,
            'name': w.name,
            'url': w.url,
            'icon': w.icon
        } for w in websites]
    
    @staticmethod
    def get_hot_keywords(limit=10):
        """
        获取热门搜索关键词
        
        Args:
            limit: 数量限制
        
        Returns:
            热门关键词列表
        """
        keywords = SearchHistory.query.order_by(
            SearchHistory.search_count.desc()
        ).limit(limit).all()
        
        return [k.keyword for k in keywords]
    
    @staticmethod
    def record_search(keyword):
        """
        记录搜索历史
        
        Args:
            keyword: 搜索关键词
        """
        keyword = keyword.strip()
        
        if not keyword or len(keyword) > 200:
            return
        
        # 查找现有记录
        history = SearchHistory.query.filter_by(keyword=keyword).first()
        
        if history:
            history.search_count += 1
        else:
            history = SearchHistory(keyword=keyword)
            db.session.add(history)
        
        db.session.commit()
