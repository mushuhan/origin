# -*- coding: utf-8 -*-
"""
应用配置模块
支持多环境配置：开发、测试、生产
"""
import os
from dotenv import load_dotenv

load_dotenv()


class Config:
    """基础配置"""
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'nav-system-secret-key-2024-enterprise'
    
    # MySQL数据库配置
    MYSQL_HOST = os.environ.get('MYSQL_HOST', 'localhost')
    MYSQL_PORT = int(os.environ.get('MYSQL_PORT', 3306))
    MYSQL_USER = os.environ.get('MYSQL_USER', 'root')
    MYSQL_PASSWORD = os.environ.get('MYSQL_PASSWORD', 'root')
    MYSQL_DATABASE = os.environ.get('MYSQL_DATABASE', 'nav_system')
    
    SQLALCHEMY_DATABASE_URI = (
        f"mysql+pymysql://{MYSQL_USER}:{MYSQL_PASSWORD}@"
        f"{MYSQL_HOST}:{MYSQL_PORT}/{MYSQL_DATABASE}?charset=utf8mb4"
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_ECHO = False
    
    # CORS配置
    CORS_ORIGINS = os.environ.get('CORS_ORIGINS', 'http://localhost:5173,http://127.0.0.1:5173').split(',')
    
    # 代理链配置 - 信任代理层数
    # 生产环境：根据实际代理层数配置（如 LB + Jump Host = 2）
    PROXY_COUNT = int(os.environ.get('PROXY_COUNT', 1))
    
    # 可信代理IP列表（用于额外验证）
    TRUSTED_PROXIES = os.environ.get('TRUSTED_PROXIES', '').split(',')
    
    # 分页配置
    DEFAULT_PAGE_SIZE = 20
    MAX_PAGE_SIZE = 100
    
    # 搜索配置
    SEARCH_RESULT_LIMIT = 50
    FUZZY_SEARCH_THRESHOLD = 0.6  # 模糊搜索相似度阈值
    
    # 语录配置
    QUOTES_ROTATION_INTERVAL = 10  # 语录轮换间隔（秒）


class DevelopmentConfig(Config):
    """开发环境配置"""
    DEBUG = True
    SQLALCHEMY_ECHO = True
    PROXY_COUNT = 0  # 开发环境通常无代理


class TestingConfig(Config):
    """测试环境配置"""
    TESTING = True
    SQLALCHEMY_DATABASE_URI = 'sqlite:///:memory:'


class ProductionConfig(Config):
    """生产环境配置"""
    DEBUG = False
    
    # 生产环境必须设置强密钥
    SECRET_KEY = os.environ.get('SECRET_KEY')
    if not SECRET_KEY:
        raise ValueError('生产环境必须设置 SECRET_KEY 环境变量')
    
    # 生产环境代理配置
    # 典型架构：CDN(1) -> LB(1) -> Jump Host(1) -> App
    PROXY_COUNT = int(os.environ.get('PROXY_COUNT', 2))
    
    # 数据库连接池配置
    SQLALCHEMY_POOL_SIZE = int(os.environ.get('DB_POOL_SIZE', 10))
    SQLALCHEMY_POOL_RECYCLE = 3600
    SQLALCHEMY_POOL_PRE_PING = True


class StagingConfig(ProductionConfig):
    """预发布环境配置"""
    pass


config = {
    'development': DevelopmentConfig,
    'testing': TestingConfig,
    'production': ProductionConfig,
    'staging': StagingConfig,
    'default': DevelopmentConfig
}

