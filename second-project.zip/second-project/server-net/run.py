"""
启动脚本
用于开发环境启动Flask应用
"""

from app import app

if __name__ == '__main__':
    print("=" * 50)
    print("  NavHub 后端服务启动中...")
    print("  访问地址: http://localhost:5000")
    print("  API文档: http://localhost:5000/api")
    print("=" * 50)
    
    app.run(
        debug=True,
        host='0.0.0.0',
        port=5000,
        threaded=True
    )

