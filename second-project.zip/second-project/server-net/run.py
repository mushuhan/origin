# -*- coding: utf-8 -*-
"""
企业级网址导航系统 - 启动入口
"""
import os
from app import create_app, db

# 获取环境配置
config_name = os.environ.get('FLASK_ENV', 'development')

# 创建应用实例
app = create_app(config_name)


def init_database():
    """初始化数据库（创建表）"""
    with app.app_context():
        db.create_all()
        print('数据库表创建成功')
        
        # 初始化默认语录
        from app.services.quote_service import QuoteService
        QuoteService.init_default_quotes()
        print('默认语录初始化完成')


if __name__ == '__main__':
    # 检查是否需要初始化数据库
    if os.environ.get('INIT_DB', 'false').lower() == 'true':
        init_database()
    
    # 启动开发服务器
    app.run(
        host=os.environ.get('HOST', '0.0.0.0'),
        port=int(os.environ.get('PORT', 5000)),
        debug=app.config.get('DEBUG', False)
    )
