# NavHub 前端

基于 Vue 3 + Vite 的一站式网址导航系统前端。

## 技术栈

- **框架**: Vue 3 (Composition API)
- **构建工具**: Vite
- **UI 组件库**: Element Plus
- **CSS 框架**: Tailwind CSS + SASS
- **状态管理**: Vuex 4
- **路由**: Vue Router 4
- **HTTP 客户端**: Axios
- **动画库**: GSAP
- **拖拽排序**: SortableJS / vuedraggable

## 功能特性

- 🎯 分类导航 - 清晰的网址分类展示
- 🔧 自定义工作台 - 添加和管理常用网址
- 🔍 智能搜索 - 支持关键词搜索和URL直接跳转
- 🌙 深色模式 - 支持明暗主题切换
- 📱 响应式设计 - 适配各种屏幕尺寸
- ✨ 流畅动画 - GSAP 驱动的丝滑过渡效果

## 项目结构

```
web-net/
├── public/              # 静态资源
├── src/
│   ├── api/            # API 请求
│   ├── components/     # 组件
│   │   ├── common/     # 通用组件
│   │   └── layout/     # 布局组件
│   ├── router/         # 路由配置
│   ├── store/          # Vuex 状态管理
│   ├── styles/         # 样式文件
│   ├── views/          # 页面组件
│   ├── App.vue         # 根组件
│   └── main.js         # 入口文件
├── index.html          # HTML 模板
├── vite.config.js      # Vite 配置
├── tailwind.config.js  # Tailwind 配置
└── package.json        # 依赖配置
```

## 开发指南

### 安装依赖

```bash
npm install
```

### 启动开发服务器

```bash
npm run dev
```

开发服务器将在 http://localhost:5173 启动。

### 构建生产版本

```bash
npm run build
```

### 预览生产版本

```bash
npm run preview
```

## 页面路由

| 路由 | 页面 | 描述 |
|------|------|------|
| `/` | 首页 | 展示所有分类和热门网址 |
| `/category/:id` | 分类详情 | 展示指定分类的网址 |
| `/customize` | 自定义工作台 | 管理个人收藏的网址 |
| `/hot` | 热门网址 | 展示热门排行榜 |
| `/search` | 搜索结果 | 显示搜索结果 |
| `/about` | 关于 | 站点介绍和使用说明 |

## 环境配置

开发环境下，API 请求会通过 Vite 代理转发到后端服务器 (http://localhost:5000)。

生产环境部署时，需要配置 Nginx 等反向代理。

## 注意事项

1. 确保后端服务已启动并运行在 5000 端口
2. 首次运行需要初始化数据库并导入测试数据
3. 图标使用 Google Favicon 服务获取，需要网络连接
