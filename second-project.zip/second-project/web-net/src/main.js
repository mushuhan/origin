import { createApp } from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'

// Element Plus
import ElementPlus from 'element-plus'
import 'element-plus/dist/index.css'
import * as ElementPlusIconsVue from '@element-plus/icons-vue'

// 样式
import './styles/main.scss'

// GSAP
import { gsap } from 'gsap'

const app = createApp(App)

// 注册所有 Element Plus 图标
for (const [key, component] of Object.entries(ElementPlusIconsVue)) {
  app.component(key, component)
}

// 全局属性
app.config.globalProperties.$gsap = gsap

app.use(router)
app.use(store)
app.use(ElementPlus)

// 初始化主题
store.dispatch('initTheme')

app.mount('#app')
