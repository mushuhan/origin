<script setup>
import { computed, watch, onMounted, ref } from 'vue'
import { useStore } from 'vuex'
import { useRoute, useRouter } from 'vue-router'
import SectionCard from '@/components/common/SectionCard.vue'
import { gsap } from 'gsap'

const store = useStore()
const route = useRoute()
const router = useRouter()

const category = computed(() => store.state.currentCategory)
const loading = computed(() => store.state.loading)

const pageRef = ref(null)

// 监听路由变化
watch(() => route.params.id, async (newId) => {
  if (newId) {
    await store.dispatch('fetchCategory', parseInt(newId))
    animateContent()
  }
}, { immediate: true })

const animateContent = () => {
  if (pageRef.value) {
    gsap.from(pageRef.value.querySelectorAll('.animate-item'), {
      opacity: 0,
      y: 20,
      duration: 0.5,
      stagger: 0.1,
      ease: 'power2.out'
    })
  }
}

// 返回首页
const goBack = () => {
  router.push('/')
}
</script>

<template>
  <div ref="pageRef" class="category-page">
    <!-- 页面头部 -->
    <div class="page-header mb-8 animate-item">
      <div class="flex items-center gap-4 mb-4">
        <button 
          class="back-btn w-10 h-10 rounded-xl flex items-center justify-center transition-all hover:bg-gray-100 dark:hover:bg-gray-800"
          @click="goBack"
        >
          <el-icon :size="20">
            <ArrowLeft />
          </el-icon>
        </button>
        <div>
          <h1 class="text-2xl font-bold">{{ category?.name || '加载中...' }}</h1>
          <p class="text-sm text-gray-400 mt-1">
            共 {{ category?.sections?.length || 0 }} 个分区
          </p>
        </div>
      </div>
      
      <!-- 面包屑 -->
      <el-breadcrumb separator="/">
        <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
        <el-breadcrumb-item>{{ category?.name }}</el-breadcrumb-item>
      </el-breadcrumb>
    </div>

    <!-- 加载状态 -->
    <div v-if="loading" class="loading-state py-20 text-center">
      <div class="loading-spinner mx-auto mb-4"></div>
      <p class="text-gray-400">加载中...</p>
    </div>

    <!-- 分区列表 -->
    <div v-else-if="category?.sections?.length > 0" class="sections-list space-y-8">
      <div 
        v-for="section in category.sections" 
        :key="section.id"
        class="animate-item"
      >
        <SectionCard :section="section" card-size="large" />
      </div>
    </div>

    <!-- 空状态 -->
    <div v-else class="empty-state py-20 text-center animate-item">
      <el-icon :size="80" class="text-gray-300 dark:text-gray-700 mb-6">
        <FolderOpened />
      </el-icon>
      <h3 class="text-xl font-medium text-gray-500 mb-2">该分类暂无内容</h3>
      <p class="text-gray-400 mb-6">可以添加一些网站到这个分类</p>
      <el-button type="primary" @click="goBack">
        返回首页
      </el-button>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.back-btn {
  color: #64748b;
  
  &:hover {
    color: #0ea5e9;
  }
}

.dark .back-btn {
  color: #94a3b8;
  
  &:hover {
    color: #38bdf8;
  }
}

:deep(.el-breadcrumb__item) {
  .el-breadcrumb__inner {
    color: #64748b;
    
    &.is-link:hover {
      color: #0ea5e9;
    }
  }
  
  &:last-child .el-breadcrumb__inner {
    color: #1f2937;
    font-weight: 500;
  }
}

.dark :deep(.el-breadcrumb__item) {
  .el-breadcrumb__inner {
    color: #94a3b8;
    
    &.is-link:hover {
      color: #38bdf8;
    }
  }
  
  &:last-child .el-breadcrumb__inner {
    color: #f1f5f9;
  }
}

.loading-spinner {
  width: 48px;
  height: 48px;
  border: 4px solid rgba(14, 165, 233, 0.2);
  border-top-color: #0ea5e9;
  border-radius: 50%;
  animation: spin 0.8s linear infinite;
}

@keyframes spin {
  to {
    transform: rotate(360deg);
  }
}
</style>

