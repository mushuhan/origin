<script setup>
import { computed, watch, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useStore } from 'vuex'
import SectionCard from '@/components/common/SectionCard.vue'

const route = useRoute()
const router = useRouter()
const store = useStore()

const currentCategory = computed(() => store.state.currentCategory)
const loading = computed(() => store.state.loading)

// 加载分类数据
const loadCategory = async (id) => {
  try {
    await store.dispatch('fetchCategory', id)
  } catch (e) {
    console.error('加载分类失败:', e)
    router.push('/')
  }
}

// 添加到工作台
const handleAddToWorkspace = async (website) => {
  try {
    await store.dispatch('addToWorkspace', { website_id: website.id })
  } catch (e) {
    console.error('添加失败:', e)
  }
}

// 监听路由参数变化
watch(() => route.params.id, (newId) => {
  if (newId) {
    loadCategory(newId)
  }
}, { immediate: true })

onMounted(() => {
  const id = route.params.id
  if (id) {
    loadCategory(id)
  }
})
</script>

<template>
  <div class="category-page">
    <!-- 加载状态 -->
    <div v-if="loading" class="loading-state">
      <div class="loading-spinner"></div>
      <p>加载中...</p>
    </div>
    
    <!-- 分类内容 -->
    <template v-else-if="currentCategory">
      <!-- 页面标题 -->
      <header class="page-header">
        <button class="back-btn" @click="router.back()">
          <el-icon><ArrowLeft /></el-icon>
        </button>
        <div class="header-icon">
          <el-icon>
            <component :is="currentCategory.icon || 'Folder'" />
          </el-icon>
        </div>
        <div class="header-content">
          <h1>{{ currentCategory.name }}</h1>
          <p>{{ currentCategory.sections?.length || 0 }} 个分区</p>
        </div>
      </header>
      
      <!-- 分区列表 -->
      <div class="sections-list" v-if="currentCategory.sections?.length > 0">
        <SectionCard
          v-for="section in currentCategory.sections"
          :key="section.id"
          :section="section"
          :initial-limit="18"
          :columns="6"
          @addToWorkspace="handleAddToWorkspace"
        />
      </div>
      
      <!-- 空状态 -->
      <div v-else class="empty-state">
        <el-icon :size="64"><FolderOpened /></el-icon>
        <h3>暂无网站</h3>
        <p>该分类下还没有添加任何网站</p>
      </div>
    </template>
    
    <!-- 未找到 -->
    <div v-else class="not-found">
      <el-icon :size="64"><Warning /></el-icon>
      <h3>分类不存在</h3>
      <p>该分类可能已被删除</p>
      <button class="btn" @click="router.push('/')">返回首页</button>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.category-page {
  padding: 1rem 0;
}

.page-header {
  display: flex;
  align-items: center;
  gap: 1rem;
  margin-bottom: 2rem;
  
  .back-btn {
    width: 40px;
    height: 40px;
    border-radius: 10px;
    background: var(--bg-tertiary);
    color: var(--text-secondary);
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.2s ease;
    
    &:hover {
      background: var(--border-primary);
      color: var(--text-primary);
    }
    
    .el-icon {
      font-size: 18px;
    }
  }
  
  .header-icon {
    width: 48px;
    height: 48px;
    border-radius: 14px;
    background: linear-gradient(135deg, #6366F1, #8B5CF6);
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    box-shadow: 0 4px 16px rgba(99, 102, 241, 0.3);
    
    .el-icon {
      font-size: 24px;
    }
  }
  
  h1 {
    font-size: 1.5rem;
    font-weight: 700;
    color: var(--text-primary);
    margin-bottom: 0.25rem;
  }
  
  p {
    font-size: 0.875rem;
    color: var(--text-tertiary);
  }
}

.sections-list {
  display: flex;
  flex-direction: column;
  gap: 2.5rem;
}

.loading-state {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 6rem;
  color: var(--text-tertiary);
  
  .loading-spinner {
    width: 40px;
    height: 40px;
    border: 3px solid var(--border-primary);
    border-top-color: var(--accent);
    border-radius: 50%;
    animation: spin 0.8s linear infinite;
    margin-bottom: 1rem;
  }
}

@keyframes spin {
  to {
    transform: rotate(360deg);
  }
}

.empty-state,
.not-found {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 6rem 2rem;
  text-align: center;
  
  .el-icon {
    color: var(--border-primary);
    margin-bottom: 1.5rem;
  }
  
  h3 {
    font-size: 1.25rem;
    font-weight: 600;
    color: var(--text-secondary);
    margin-bottom: 0.5rem;
  }
  
  p {
    font-size: 0.875rem;
    color: var(--text-tertiary);
    margin-bottom: 1.5rem;
  }
  
  .btn {
    padding: 0.625rem 1.25rem;
    font-size: 0.875rem;
    font-weight: 500;
    color: var(--text-inverse);
    background: var(--text-primary);
    border-radius: 10px;
    
    &:hover {
      opacity: 0.9;
    }
  }
}
</style>
