<script setup>
import { computed, onMounted, ref } from 'vue'
import { useStore } from 'vuex'
import { useRouter } from 'vue-router'
import WebsiteCard from '@/components/common/WebsiteCard.vue'
import { gsap } from 'gsap'

const store = useStore()
const router = useRouter()

const hotWebsites = computed(() => store.state.hotWebsites)
const loading = computed(() => store.state.loading)

const pageRef = ref(null)

onMounted(() => {
  if (pageRef.value) {
    gsap.from(pageRef.value.querySelectorAll('.animate-item'), {
      opacity: 0,
      y: 20,
      duration: 0.5,
      stagger: 0.1,
      ease: 'power2.out'
    })
  }
})

// 返回首页
const goBack = () => {
  router.push('/')
}
</script>

<template>
  <div ref="pageRef" class="hot-page">
    <!-- 页面头部 -->
    <div class="page-header mb-8 animate-item">
      <div class="flex items-center gap-4 mb-4">
        <button 
          class="back-btn w-10 h-10 rounded-xl flex items-center justify-center transition-all hover:bg-gray-100 dark:hover:bg-gray-800"
          @click="goBack"
        >
          <el-icon :size="20">
            <ArrowLeft />
          </el-icon>
        </button>
        <div class="flex items-center gap-3">
          <div class="w-12 h-12 rounded-2xl bg-gradient-to-br from-orange-400 to-red-500 flex items-center justify-center text-white shadow-lg">
            <el-icon :size="24"><TrendCharts /></el-icon>
          </div>
          <div>
            <h1 class="text-2xl font-bold">热门网址</h1>
            <p class="text-sm text-gray-400 mt-1">
              大家都在访问的热门网站
            </p>
          </div>
        </div>
      </div>
    </div>

    <!-- 热门统计 -->
    <div class="stats-section mb-8 grid grid-cols-2 md:grid-cols-4 gap-4 animate-item">
      <div class="stat-card p-4 rounded-2xl bg-white dark:bg-slate-800/50">
        <div class="flex items-center gap-3">
          <div class="w-10 h-10 rounded-xl bg-sky-100 dark:bg-sky-900/30 flex items-center justify-center text-sky-500">
            <el-icon :size="20"><Star /></el-icon>
          </div>
          <div>
            <p class="text-2xl font-bold">{{ hotWebsites.length }}</p>
            <p class="text-xs text-gray-400">热门网站</p>
          </div>
        </div>
      </div>
      <div class="stat-card p-4 rounded-2xl bg-white dark:bg-slate-800/50">
        <div class="flex items-center gap-3">
          <div class="w-10 h-10 rounded-xl bg-green-100 dark:bg-green-900/30 flex items-center justify-center text-green-500">
            <el-icon :size="20"><View /></el-icon>
          </div>
          <div>
            <p class="text-2xl font-bold">{{ hotWebsites.reduce((acc, w) => acc + w.click_count, 0).toLocaleString() }}</p>
            <p class="text-xs text-gray-400">总访问量</p>
          </div>
        </div>
      </div>
      <div class="stat-card p-4 rounded-2xl bg-white dark:bg-slate-800/50">
        <div class="flex items-center gap-3">
          <div class="w-10 h-10 rounded-xl bg-purple-100 dark:bg-purple-900/30 flex items-center justify-center text-purple-500">
            <el-icon :size="20"><TrendCharts /></el-icon>
          </div>
          <div>
            <p class="text-2xl font-bold">{{ hotWebsites[0]?.click_count?.toLocaleString() || 0 }}</p>
            <p class="text-xs text-gray-400">最高点击</p>
          </div>
        </div>
      </div>
      <div class="stat-card p-4 rounded-2xl bg-white dark:bg-slate-800/50">
        <div class="flex items-center gap-3">
          <div class="w-10 h-10 rounded-xl bg-orange-100 dark:bg-orange-900/30 flex items-center justify-center text-orange-500">
            <el-icon :size="20"><Histogram /></el-icon>
          </div>
          <div>
            <p class="text-2xl font-bold">{{ Math.round(hotWebsites.reduce((acc, w) => acc + w.click_count, 0) / (hotWebsites.length || 1)).toLocaleString() }}</p>
            <p class="text-xs text-gray-400">平均点击</p>
          </div>
        </div>
      </div>
    </div>

    <!-- 热门榜单 -->
    <div class="hot-list animate-item">
      <div class="section-header flex items-center justify-between mb-6">
        <h2 class="text-lg font-semibold">热门排行</h2>
      </div>

      <!-- 加载状态 -->
      <div v-if="loading" class="loading-state py-20 text-center">
        <div class="loading-spinner mx-auto mb-4"></div>
        <p class="text-gray-400">加载中...</p>
      </div>

      <!-- 网站列表 -->
      <div v-else-if="hotWebsites.length > 0" class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
        <div 
          v-for="(website, index) in hotWebsites" 
          :key="website.id"
          class="relative"
        >
          <!-- 排名标签 -->
          <div 
            class="rank-badge absolute -top-2 -left-2 w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold z-10"
            :class="index < 3 ? 'top-rank' : 'normal-rank'"
          >
            {{ index + 1 }}
          </div>
          <WebsiteCard :website="website" size="large" />
        </div>
      </div>

      <!-- 空状态 -->
      <div v-else class="empty-state py-20 text-center rounded-2xl bg-white dark:bg-slate-800/50">
        <el-icon :size="80" class="text-gray-300 dark:text-gray-700 mb-6">
          <TrendCharts />
        </el-icon>
        <h3 class="text-xl font-medium text-gray-500 mb-2">暂无热门网址</h3>
        <p class="text-gray-400">热门网址将根据点击量自动生成</p>
      </div>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.back-btn {
  color: #64748b;
  
  &:hover {
    color: #0ea5e9;
  }
}

.dark .back-btn {
  color: #94a3b8;
  
  &:hover {
    color: #38bdf8;
  }
}

.stat-card {
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);
  transition: all 0.3s ease;
  
  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
  }
}

.rank-badge {
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
  
  &.top-rank {
    background: linear-gradient(135deg, #fbbf24 0%, #f59e0b 100%);
    color: white;
  }
  
  &.normal-rank {
    background: white;
    color: #64748b;
    border: 1px solid #e2e8f0;
  }
}

.dark .rank-badge.normal-rank {
  background: #334155;
  color: #94a3b8;
  border-color: #475569;
}

.loading-spinner {
  width: 48px;
  height: 48px;
  border: 4px solid rgba(14, 165, 233, 0.2);
  border-top-color: #0ea5e9;
  border-radius: 50%;
  animation: spin 0.8s linear infinite;
}

@keyframes spin {
  to {
    transform: rotate(360deg);
  }
}
</style>

