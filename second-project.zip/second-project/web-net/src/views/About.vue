<script setup>
import { computed, onMounted, ref } from 'vue'
import { useStore } from 'vuex'
import { useRouter } from 'vue-router'
import { gsap } from 'gsap'

const store = useStore()
const router = useRouter()

const settings = computed(() => store.state.settings)

const pageRef = ref(null)

onMounted(() => {
  if (pageRef.value) {
    gsap.from(pageRef.value.querySelectorAll('.animate-item'), {
      opacity: 0,
      y: 20,
      duration: 0.5,
      stagger: 0.1,
      ease: 'power2.out'
    })
  }
})

const features = [
  {
    icon: 'Compass',
    title: '一站式导航',
    description: '整合常用网址，分类清晰，快速访问'
  },
  {
    icon: 'Briefcase',
    title: '自定义工作台',
    description: '添加您常用的网址，打造专属工作台'
  },
  {
    icon: 'Search',
    title: '智能搜索',
    description: '支持关键词搜索，快速找到目标网址'
  },
  {
    icon: 'Moon',
    title: '深色模式',
    description: '支持明暗主题切换，保护您的眼睛'
  },
  {
    icon: 'Grid',
    title: '响应式设计',
    description: '适配各种屏幕尺寸，体验始终如一'
  },
  {
    icon: 'Lightning',
    title: '极速体验',
    description: '现代化技术栈，页面加载流畅快速'
  }
]

// 返回首页
const goBack = () => {
  router.push('/')
}
</script>

<template>
  <div ref="pageRef" class="about-page">
    <!-- 页面头部 -->
    <div class="page-header mb-12 animate-item">
      <div class="flex items-center gap-4">
        <button 
          class="back-btn w-10 h-10 rounded-xl flex items-center justify-center transition-all hover:bg-gray-100 dark:hover:bg-gray-800"
          @click="goBack"
        >
          <el-icon :size="20">
            <ArrowLeft />
          </el-icon>
        </button>
        <h1 class="text-2xl font-bold">关于我们</h1>
      </div>
    </div>

    <!-- 介绍区域 -->
    <div class="intro-section mb-12 animate-item">
      <div class="intro-card p-8 rounded-3xl text-center relative overflow-hidden">
        <!-- 背景装饰 -->
        <div class="intro-bg absolute inset-0 -z-10">
          <div class="gradient-orb orb-1"></div>
          <div class="gradient-orb orb-2"></div>
        </div>

        <div class="logo-wrapper w-20 h-20 mx-auto mb-6 rounded-3xl bg-gradient-to-br from-sky-400 to-blue-600 flex items-center justify-center shadow-xl">
          <el-icon :size="40" class="text-white">
            <Compass />
          </el-icon>
        </div>
        
        <h2 class="text-3xl font-bold mb-4 bg-gradient-to-r from-sky-500 to-blue-600 bg-clip-text text-transparent">
          {{ settings.site_name || 'NavHub' }}
        </h2>
        
        <p class="text-lg text-gray-500 dark:text-gray-400 max-w-2xl mx-auto leading-relaxed">
          一站式网址导航系统，为您提供简洁高效的网址管理体验。
          支持自定义工作台、智能搜索、深色模式等功能，
          帮助您快速访问常用网站，提升工作效率。
        </p>
      </div>
    </div>

    <!-- 功能特点 -->
    <div class="features-section mb-12">
      <h3 class="text-xl font-bold mb-6 text-center animate-item">功能特点</h3>
      <div class="features-grid grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <div 
          v-for="(feature, index) in features" 
          :key="feature.title"
          class="feature-card p-6 rounded-2xl bg-white dark:bg-slate-800/50 shadow-card hover:shadow-card-hover transition-all animate-item"
          :style="{ animationDelay: `${index * 0.1}s` }"
        >
          <div class="icon-wrapper w-12 h-12 mb-4 rounded-xl bg-gradient-to-br from-sky-100 to-blue-100 dark:from-sky-900/30 dark:to-blue-900/30 flex items-center justify-center text-sky-500">
            <el-icon :size="24">
              <component :is="feature.icon" />
            </el-icon>
          </div>
          <h4 class="text-lg font-semibold mb-2">{{ feature.title }}</h4>
          <p class="text-sm text-gray-500 dark:text-gray-400">{{ feature.description }}</p>
        </div>
      </div>
    </div>

    <!-- 技术栈 -->
    <div class="tech-section mb-12 animate-item">
      <h3 class="text-xl font-bold mb-6 text-center">技术栈</h3>
      <div class="tech-list flex flex-wrap justify-center gap-4">
        <span class="tech-tag px-4 py-2 rounded-xl bg-green-100 dark:bg-green-900/30 text-green-600 dark:text-green-400">
          Vue 3
        </span>
        <span class="tech-tag px-4 py-2 rounded-xl bg-sky-100 dark:bg-sky-900/30 text-sky-600 dark:text-sky-400">
          Vite
        </span>
        <span class="tech-tag px-4 py-2 rounded-xl bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400">
          Tailwind CSS
        </span>
        <span class="tech-tag px-4 py-2 rounded-xl bg-purple-100 dark:bg-purple-900/30 text-purple-600 dark:text-purple-400">
          Element Plus
        </span>
        <span class="tech-tag px-4 py-2 rounded-xl bg-yellow-100 dark:bg-yellow-900/30 text-yellow-600 dark:text-yellow-400">
          Flask
        </span>
        <span class="tech-tag px-4 py-2 rounded-xl bg-orange-100 dark:bg-orange-900/30 text-orange-600 dark:text-orange-400">
          MySQL
        </span>
        <span class="tech-tag px-4 py-2 rounded-xl bg-pink-100 dark:bg-pink-900/30 text-pink-600 dark:text-pink-400">
          GSAP
        </span>
      </div>
    </div>

    <!-- 使用说明 -->
    <div class="usage-section mb-12 animate-item">
      <h3 class="text-xl font-bold mb-6 text-center">使用说明</h3>
      <div class="usage-card p-6 rounded-2xl bg-white dark:bg-slate-800/50 shadow-card">
        <div class="space-y-4">
          <div class="usage-item flex gap-4">
            <div class="step-number w-8 h-8 rounded-full bg-sky-100 dark:bg-sky-900/30 flex items-center justify-center text-sky-600 dark:text-sky-400 font-bold text-sm flex-shrink-0">
              1
            </div>
            <div>
              <h5 class="font-semibold mb-1">浏览分类</h5>
              <p class="text-sm text-gray-500 dark:text-gray-400">通过侧边栏选择不同分类，浏览该分类下的所有网址</p>
            </div>
          </div>
          <div class="usage-item flex gap-4">
            <div class="step-number w-8 h-8 rounded-full bg-sky-100 dark:bg-sky-900/30 flex items-center justify-center text-sky-600 dark:text-sky-400 font-bold text-sm flex-shrink-0">
              2
            </div>
            <div>
              <h5 class="font-semibold mb-1">自定义工作台</h5>
              <p class="text-sm text-gray-500 dark:text-gray-400">在工作台添加您常用的网址，支持从库存添加或自定义添加</p>
            </div>
          </div>
          <div class="usage-item flex gap-4">
            <div class="step-number w-8 h-8 rounded-full bg-sky-100 dark:bg-sky-900/30 flex items-center justify-center text-sky-600 dark:text-sky-400 font-bold text-sm flex-shrink-0">
              3
            </div>
            <div>
              <h5 class="font-semibold mb-1">搜索网址</h5>
              <p class="text-sm text-gray-500 dark:text-gray-400">使用顶部搜索框搜索网址，也可以直接输入URL快速跳转</p>
            </div>
          </div>
          <div class="usage-item flex gap-4">
            <div class="step-number w-8 h-8 rounded-full bg-sky-100 dark:bg-sky-900/30 flex items-center justify-center text-sky-600 dark:text-sky-400 font-bold text-sm flex-shrink-0">
              4
            </div>
            <div>
              <h5 class="font-semibold mb-1">切换主题</h5>
              <p class="text-sm text-gray-500 dark:text-gray-400">点击顶部右侧的主题按钮切换明暗模式</p>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- 联系方式 -->
    <div class="contact-section text-center animate-item">
      <h3 class="text-xl font-bold mb-6">联系我们</h3>
      <p class="text-gray-500 dark:text-gray-400 mb-4">
        如有问题或建议，欢迎联系我们
      </p>
      <a 
        :href="`mailto:${settings.footer_contact || 'contact@navhub.com'}`"
        class="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-sky-500 text-white hover:bg-sky-600 transition-colors"
      >
        <el-icon><Message /></el-icon>
        {{ settings.footer_contact || 'contact@navhub.com' }}
      </a>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.back-btn {
  color: #64748b;
  
  &:hover {
    color: #0ea5e9;
  }
}

.dark .back-btn {
  color: #94a3b8;
  
  &:hover {
    color: #38bdf8;
  }
}

.intro-card {
  background: rgba(255, 255, 255, 0.7);
  backdrop-filter: blur(20px);
  -webkit-backdrop-filter: blur(20px);
  border: 1px solid rgba(255, 255, 255, 0.3);
}

.dark .intro-card {
  background: rgba(30, 41, 59, 0.7);
  border: 1px solid rgba(255, 255, 255, 0.05);
}

.intro-bg {
  .gradient-orb {
    position: absolute;
    border-radius: 50%;
    filter: blur(80px);
    opacity: 0.4;
  }
  
  .orb-1 {
    width: 300px;
    height: 300px;
    background: linear-gradient(135deg, #0ea5e9 0%, #6366f1 100%);
    top: -100px;
    right: -50px;
  }
  
  .orb-2 {
    width: 250px;
    height: 250px;
    background: linear-gradient(135deg, #f472b6 0%, #8b5cf6 100%);
    bottom: -100px;
    left: -50px;
  }
}

.feature-card {
  &:hover {
    transform: translateY(-4px);
  }
}

.tech-tag {
  font-weight: 500;
  transition: all 0.3s ease;
  
  &:hover {
    transform: scale(1.05);
  }
}

.logo-wrapper {
  animation: float 3s ease-in-out infinite;
}

@keyframes float {
  0%, 100% {
    transform: translateY(0);
  }
  50% {
    transform: translateY(-10px);
  }
}
</style>

