<script setup>
import { onMounted, ref } from 'vue'
import { useRouter } from 'vue-router'
import { gsap } from 'gsap'

const router = useRouter()
const pageRef = ref(null)

onMounted(() => {
  if (pageRef.value) {
    gsap.from(pageRef.value.querySelectorAll('.animate-item'), {
      opacity: 0,
      y: 30,
      duration: 0.6,
      stagger: 0.15,
      ease: 'power3.out'
    })
  }
})

const goHome = () => {
  router.push('/')
}

const goBack = () => {
  router.go(-1)
}
</script>

<template>
  <div ref="pageRef" class="not-found-page min-h-[60vh] flex items-center justify-center">
    <div class="content text-center">
      <!-- 404图形 -->
      <div class="error-graphic mb-8 animate-item">
        <div class="number-404 text-9xl font-black bg-gradient-to-r from-sky-400 via-blue-500 to-indigo-600 bg-clip-text text-transparent">
          404
        </div>
        <div class="error-icon absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
          <el-icon :size="120" class="text-gray-200 dark:text-gray-800 opacity-50">
            <DocumentDelete />
          </el-icon>
        </div>
      </div>
      
      <h1 class="text-2xl font-bold mb-4 animate-item">页面未找到</h1>
      <p class="text-gray-500 dark:text-gray-400 mb-8 max-w-md mx-auto animate-item">
        抱歉，您访问的页面不存在或已被移动到其他位置
      </p>
      
      <div class="actions flex justify-center gap-4 animate-item">
        <el-button @click="goBack">
          <el-icon class="mr-1"><Back /></el-icon>
          返回上页
        </el-button>
        <el-button type="primary" @click="goHome">
          <el-icon class="mr-1"><HomeFilled /></el-icon>
          返回首页
        </el-button>
      </div>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.error-graphic {
  position: relative;
  
  .number-404 {
    line-height: 1;
    animation: pulse 2s ease-in-out infinite;
  }
}

@keyframes pulse {
  0%, 100% {
    opacity: 1;
  }
  50% {
    opacity: 0.8;
  }
}
</style>

