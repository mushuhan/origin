<script setup>
import { computed, watch, onMounted, ref } from 'vue'
import { useStore } from 'vuex'
import { useRoute, useRouter } from 'vue-router'
import WebsiteCard from '@/components/common/WebsiteCard.vue'
import { gsap } from 'gsap'

const store = useStore()
const route = useRoute()
const router = useRouter()

const searchKeyword = computed(() => route.query.q || '')
const searchResults = computed(() => store.state.searchResults)
const loading = computed(() => store.state.loading)
const hotKeywords = computed(() => store.state.hotKeywords)

const pageRef = ref(null)
const searchInput = ref('')

// 监听路由变化执行搜索
watch(() => route.query.q, (keyword) => {
  if (keyword) {
    searchInput.value = keyword
    store.dispatch('search', keyword)
  }
}, { immediate: true })

onMounted(() => {
  store.dispatch('fetchSearchSuggestions', '')
  
  if (pageRef.value) {
    gsap.from(pageRef.value.querySelectorAll('.animate-item'), {
      opacity: 0,
      y: 20,
      duration: 0.5,
      stagger: 0.1,
      ease: 'power2.out'
    })
  }
})

// 执行搜索
const doSearch = () => {
  const keyword = searchInput.value.trim()
  if (keyword) {
    router.push({ path: '/search', query: { q: keyword } })
  }
}

// 点击热门关键词
const searchHotKeyword = (keyword) => {
  searchInput.value = keyword
  doSearch()
}

// 返回首页
const goBack = () => {
  router.push('/')
}
</script>

<template>
  <div ref="pageRef" class="search-page">
    <!-- 页面头部 -->
    <div class="page-header mb-8 animate-item">
      <div class="flex items-center gap-4 mb-6">
        <button 
          class="back-btn w-10 h-10 rounded-xl flex items-center justify-center transition-all hover:bg-gray-100 dark:hover:bg-gray-800"
          @click="goBack"
        >
          <el-icon :size="20">
            <ArrowLeft />
          </el-icon>
        </button>
        <h1 class="text-2xl font-bold">搜索结果</h1>
      </div>

      <!-- 搜索框 -->
      <div class="search-box-wrapper flex gap-3">
        <div class="search-input flex-1 h-12 px-5 rounded-2xl flex items-center bg-white dark:bg-slate-800 shadow-card">
          <el-icon :size="18" class="text-gray-400 mr-3">
            <Search />
          </el-icon>
          <input 
            v-model="searchInput"
            type="text"
            placeholder="搜索网址..."
            class="flex-1 bg-transparent border-none outline-none"
            @keyup.enter="doSearch"
          />
        </div>
        <el-button type="primary" class="h-12 px-6" @click="doSearch">
          搜索
        </el-button>
      </div>
    </div>

    <!-- 搜索结果 -->
    <div class="search-results animate-item">
      <div v-if="searchKeyword" class="results-header mb-6">
        <p class="text-gray-500">
          搜索 "<span class="text-sky-500 font-medium">{{ searchKeyword }}</span>" 
          找到 <span class="font-medium">{{ searchResults.length }}</span> 个结果
        </p>
      </div>

      <!-- 加载状态 -->
      <div v-if="loading" class="loading-state py-20 text-center">
        <div class="loading-spinner mx-auto mb-4"></div>
        <p class="text-gray-400">搜索中...</p>
      </div>

      <!-- 结果列表 -->
      <div 
        v-else-if="searchResults.length > 0" 
        class="results-grid grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4"
      >
        <WebsiteCard 
          v-for="website in searchResults" 
          :key="website.id"
          :website="website"
          size="large"
        />
      </div>

      <!-- 无结果 -->
      <div v-else-if="searchKeyword" class="empty-state py-20 text-center rounded-2xl bg-white dark:bg-slate-800/50">
        <el-icon :size="80" class="text-gray-300 dark:text-gray-700 mb-6">
          <Search />
        </el-icon>
        <h3 class="text-xl font-medium text-gray-500 mb-2">未找到相关网址</h3>
        <p class="text-gray-400">换个关键词试试吧</p>
      </div>

      <!-- 默认状态：热门搜索 -->
      <div v-else class="hot-keywords-section">
        <h3 class="text-lg font-semibold mb-4">热门搜索</h3>
        <div class="flex flex-wrap gap-3">
          <span 
            v-for="(item, index) in hotKeywords" 
            :key="item.keyword"
            class="keyword-tag px-4 py-2 rounded-full cursor-pointer transition-all"
            :class="index < 3 ? 'hot' : ''"
            @click="searchHotKeyword(item.keyword)"
          >
            <span v-if="index < 3" class="rank mr-2 text-xs">{{ index + 1 }}</span>
            {{ item.keyword }}
            <span class="count ml-2 text-xs text-gray-400">{{ item.count }}</span>
          </span>
        </div>
      </div>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.back-btn {
  color: #64748b;
  
  &:hover {
    color: #0ea5e9;
  }
}

.dark .back-btn {
  color: #94a3b8;
  
  &:hover {
    color: #38bdf8;
  }
}

.search-input {
  input {
    font-size: 16px;
    
    &::placeholder {
      color: #9ca3af;
    }
  }
}

.keyword-tag {
  background: #f1f5f9;
  color: #475569;
  
  &:hover {
    background: #e2e8f0;
    color: #1f2937;
  }
  
  &.hot {
    background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%);
    color: #92400e;
    
    .rank {
      color: #dc2626;
      font-weight: 600;
    }
  }
}

.dark .keyword-tag {
  background: #334155;
  color: #94a3b8;
  
  &:hover {
    background: #475569;
    color: #e2e8f0;
  }
  
  &.hot {
    background: linear-gradient(135deg, #78350f 0%, #92400e 100%);
    color: #fef3c7;
  }
}

.loading-spinner {
  width: 48px;
  height: 48px;
  border: 4px solid rgba(14, 165, 233, 0.2);
  border-top-color: #0ea5e9;
  border-radius: 50%;
  animation: spin 0.8s linear infinite;
}

@keyframes spin {
  to {
    transform: rotate(360deg);
  }
}
</style>

