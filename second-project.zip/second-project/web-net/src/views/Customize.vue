<script setup>
import { computed, ref, onMounted } from 'vue'
import { useStore } from 'vuex'
import { useRouter } from 'vue-router'
import WorkspaceCard from '@/components/common/WorkspaceCard.vue'
import AddWebsiteDialog from '@/components/common/AddWebsiteDialog.vue'
import draggable from 'vuedraggable'
import { gsap } from 'gsap'

const store = useStore()
const router = useRouter()

const workspace = computed(() => store.state.workspace)
const categories = computed(() => store.state.categories.filter(c => !c.is_system))

// 对话框控制
const showAddDialog = ref(false)
const editingItem = ref(null)

// 从库存添加
const showLibraryDialog = ref(false)
const selectedCategory = ref(null)
const selectedSection = ref(null)

const pageRef = ref(null)

onMounted(() => {
  if (pageRef.value) {
    gsap.from(pageRef.value.querySelectorAll('.animate-item'), {
      opacity: 0,
      y: 20,
      duration: 0.5,
      stagger: 0.1,
      ease: 'power2.out'
    })
  }
})

// 打开添加对话框
const openAddDialog = () => {
  editingItem.value = null
  showAddDialog.value = true
}

// 打开编辑对话框
const openEditDialog = (item) => {
  editingItem.value = item
  showAddDialog.value = true
}

// 确认添加/编辑
const handleConfirm = async (data) => {
  try {
    if (data.id) {
      // 编辑
      await store.dispatch('updateWorkspaceItem', { id: data.id, data })
    } else {
      // 添加
      await store.dispatch('addToWorkspace', data)
    }
  } catch (error) {
    console.error(error)
  }
}

// 移除项目
const handleRemove = async (item) => {
  try {
    await store.dispatch('removeFromWorkspace', item.id)
  } catch (error) {
    console.error(error)
  }
}

// 拖拽排序
const onDragEnd = () => {
  const items = workspace.value.map((item, index) => ({
    id: item.id,
    sort_order: index
  }))
  store.dispatch('reorderWorkspace', items)
}

// 从库存添加
const openLibraryDialog = () => {
  showLibraryDialog.value = true
}

const selectCategoryForAdd = (category) => {
  selectedCategory.value = category
  selectedSection.value = null
}

const addFromLibrary = async (website) => {
  try {
    await store.dispatch('addToWorkspace', { website_id: website.id })
    showLibraryDialog.value = false
    selectedCategory.value = null
    selectedSection.value = null
  } catch (error) {
    console.error(error)
  }
}

// 返回首页
const goBack = () => {
  router.push('/')
}
</script>

<template>
  <div ref="pageRef" class="customize-page">
    <!-- 页面头部 -->
    <div class="page-header mb-8 animate-item">
      <div class="flex items-center justify-between">
        <div class="flex items-center gap-4">
          <button 
            class="back-btn w-10 h-10 rounded-xl flex items-center justify-center transition-all hover:bg-gray-100 dark:hover:bg-gray-800"
            @click="goBack"
          >
            <el-icon :size="20">
              <ArrowLeft />
            </el-icon>
          </button>
          <div>
            <h1 class="text-2xl font-bold">自定义工作台</h1>
            <p class="text-sm text-gray-400 mt-1">
              添加和管理您的常用网址，支持拖拽排序
            </p>
          </div>
        </div>
        
        <div class="flex gap-3">
          <el-button @click="openLibraryDialog">
            <el-icon class="mr-1"><Folder /></el-icon>
            从库存添加
          </el-button>
          <el-button type="primary" @click="openAddDialog">
            <el-icon class="mr-1"><Plus /></el-icon>
            自定义添加
          </el-button>
        </div>
      </div>
    </div>

    <!-- 工作台内容 -->
    <div class="workspace-content animate-item">
      <div 
        v-if="workspace.length > 0" 
        class="workspace-grid"
      >
        <draggable 
          v-model="workspace"
          item-key="id"
          handle=".drag-handle"
          animation="300"
          class="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 xl:grid-cols-8 gap-4"
          @end="onDragEnd"
        >
          <template #item="{ element }">
            <WorkspaceCard 
              :item="element"
              @edit="openEditDialog"
              @remove="handleRemove"
            />
          </template>
        </draggable>
      </div>

      <!-- 空状态 -->
      <div v-else class="empty-state py-20 text-center rounded-2xl bg-white dark:bg-slate-800/50">
        <el-icon :size="80" class="text-gray-300 dark:text-gray-700 mb-6">
          <Briefcase />
        </el-icon>
        <h3 class="text-xl font-medium text-gray-500 mb-2">工作台是空的</h3>
        <p class="text-gray-400 mb-6">添加一些常用网址到您的工作台吧</p>
        <div class="flex justify-center gap-4">
          <el-button @click="openLibraryDialog">
            从库存添加
          </el-button>
          <el-button type="primary" @click="openAddDialog">
            自定义添加
          </el-button>
        </div>
      </div>
    </div>

    <!-- 使用提示 -->
    <div class="tips-section mt-8 p-6 rounded-2xl bg-sky-50 dark:bg-sky-900/20 animate-item">
      <h4 class="text-sm font-semibold text-sky-700 dark:text-sky-300 mb-3 flex items-center gap-2">
        <el-icon><InfoFilled /></el-icon>
        使用提示
      </h4>
      <ul class="text-sm text-sky-600 dark:text-sky-400 space-y-2">
        <li>• 鼠标悬停在卡片上显示操作按钮</li>
        <li>• 按住卡片左上角的拖拽图标可以调整顺序</li>
        <li>• 右上角可以编辑、复制链接或移除网址</li>
        <li>• 支持从库存添加或自定义添加网址</li>
      </ul>
    </div>

    <!-- 添加/编辑对话框 -->
    <AddWebsiteDialog 
      v-model:visible="showAddDialog"
      :edit-item="editingItem"
      @confirm="handleConfirm"
    />

    <!-- 从库存添加对话框 -->
    <el-dialog 
      v-model="showLibraryDialog"
      title="从库存添加"
      width="800px"
      :close-on-click-modal="false"
    >
      <div class="library-content flex gap-4 h-[500px]">
        <!-- 分类列表 -->
        <div class="category-list w-48 flex-shrink-0 overflow-y-auto border-r border-gray-100 dark:border-gray-800 pr-4">
          <div 
            v-for="category in categories"
            :key="category.id"
            class="category-item p-3 rounded-xl cursor-pointer transition-all mb-2"
            :class="selectedCategory?.id === category.id ? 'bg-sky-100 dark:bg-sky-900/30 text-sky-600 dark:text-sky-400' : 'hover:bg-gray-100 dark:hover:bg-gray-800'"
            @click="selectCategoryForAdd(category)"
          >
            <span class="font-medium">{{ category.name }}</span>
          </div>
        </div>

        <!-- 网站列表 -->
        <div class="website-list flex-1 overflow-y-auto">
          <template v-if="selectedCategory">
            <div v-for="section in selectedCategory.sections" :key="section.id" class="mb-6">
              <h4 class="text-sm font-semibold text-gray-500 mb-3">{{ section.name }}</h4>
              <div class="grid grid-cols-4 gap-3">
                <div 
                  v-for="website in section.websites"
                  :key="website.id"
                  class="website-item p-3 rounded-xl border border-gray-100 dark:border-gray-800 cursor-pointer transition-all hover:border-sky-500 hover:bg-sky-50 dark:hover:bg-sky-900/20"
                  @click="addFromLibrary(website)"
                >
                  <div class="flex items-center gap-2">
                    <img 
                      :src="website.icon || `https://www.google.com/s2/favicons?domain=${website.url}&sz=32`"
                      class="w-6 h-6 rounded"
                      @error="$event.target.src = 'data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 24 24%22 fill=%22%2394a3b8%22><circle cx=%2212%22 cy=%2212%22 r=%2210%22/></svg>'"
                    />
                    <span class="text-sm truncate">{{ website.name }}</span>
                  </div>
                </div>
              </div>
            </div>
          </template>
          <div v-else class="flex items-center justify-center h-full text-gray-400">
            请先选择一个分类
          </div>
        </div>
      </div>
    </el-dialog>
  </div>
</template>

<style lang="scss" scoped>
.back-btn {
  color: #64748b;
  
  &:hover {
    color: #0ea5e9;
  }
}

.dark .back-btn {
  color: #94a3b8;
  
  &:hover {
    color: #38bdf8;
  }
}

.library-content {
  .category-list::-webkit-scrollbar,
  .website-list::-webkit-scrollbar {
    width: 4px;
  }
  
  .category-list::-webkit-scrollbar-thumb,
  .website-list::-webkit-scrollbar-thumb {
    background: rgba(0, 0, 0, 0.1);
    border-radius: 2px;
  }
}
</style>

