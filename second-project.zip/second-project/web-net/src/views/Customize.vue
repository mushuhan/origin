<script setup>
import { ref, computed, onMounted } from 'vue'
import { useStore } from 'vuex'
import { ElMessageBox } from 'element-plus'
import FolderTree from '@/components/common/FolderTree.vue'
import WebsiteCard from '@/components/common/WebsiteCard.vue'
import AddWebsiteDialog from '@/components/common/AddWebsiteDialog.vue'

const store = useStore()

// 状态
const workspace = computed(() => store.state.workspace)
const folders = computed(() => store.state.folders)
const loading = ref(false)

const selectedFolderId = ref(null)
const expandedFolderIds = ref([])
const showAddDialog = ref(false)

// 当前文件夹
const currentFolder = computed(() => {
  if (!selectedFolderId.value) return null
  return findFolderById(folders.value, selectedFolderId.value)
})

// 当前显示的网址
const currentSites = computed(() => {
  if (selectedFolderId.value && currentFolder.value) {
    return currentFolder.value.sites || []
  }
  return workspace.value
})

// 查找文件夹
const findFolderById = (list, id) => {
  for (const folder of list) {
    if (folder.id === id) return folder
    if (folder.children) {
      const found = findFolderById(folder.children, id)
      if (found) return found
    }
  }
  return null
}

// 选择文件夹
const handleSelectFolder = (folder) => {
  selectedFolderId.value = folder.id
}

// 切换文件夹展开
const handleToggleFolder = (id) => {
  const index = expandedFolderIds.value.indexOf(id)
  if (index > -1) {
    expandedFolderIds.value.splice(index, 1)
  } else {
    expandedFolderIds.value.push(id)
  }
}

// 创建文件夹
const handleCreateFolder = async (data) => {
  try {
    await store.dispatch('createFolder', data)
  } catch (e) {
    console.error('创建文件夹失败:', e)
  }
}

// 重命名文件夹
const handleRenameFolder = async (id, name) => {
  try {
    await store.dispatch('updateFolder', { id, data: { name } })
  } catch (e) {
    console.error('重命名失败:', e)
  }
}

// 删除文件夹
const handleDeleteFolder = async (folder) => {
  try {
    await ElMessageBox.confirm(
      `确定要删除文件夹"${folder.name}"吗？文件夹中的网址将移至根目录。`,
      '删除确认',
      {
        confirmButtonText: '删除',
        cancelButtonText: '取消',
        type: 'warning'
      }
    )
    await store.dispatch('deleteFolder', folder.id)
    if (selectedFolderId.value === folder.id) {
      selectedFolderId.value = null
    }
  } catch (e) {
    // 用户取消
  }
}

// 移除网址
const handleRemoveWebsite = async (website) => {
  try {
    await ElMessageBox.confirm(
      `确定要从工作台移除"${website.name}"吗？`,
      '移除确认',
      {
        confirmButtonText: '移除',
        cancelButtonText: '取消',
        type: 'warning'
      }
    )
    await store.dispatch('removeFromWorkspace', website.id)
  } catch (e) {
    // 用户取消
  }
}

// 查看所有
const viewAll = () => {
  selectedFolderId.value = null
}

// 添加网址
const handleAddWebsite = async (data) => {
  try {
    await store.dispatch('addToWorkspace', {
      ...data,
      folder_id: selectedFolderId.value
    })
    showAddDialog.value = false
  } catch (e) {
    console.error('添加失败:', e)
  }
}

onMounted(() => {
  store.dispatch('fetchWorkspace')
})
</script>

<template>
  <div class="customize-page">
    <!-- 页面标题 -->
    <header class="page-header">
      <div class="header-icon">
        <el-icon><Briefcase /></el-icon>
      </div>
      <div class="header-content">
        <h1>我的工作台</h1>
        <p>管理您收藏的网站和文件夹</p>
      </div>
      <div class="header-actions">
        <button class="btn btn-primary" @click="showAddDialog = true">
          <el-icon><Plus /></el-icon>
          添加网址
        </button>
      </div>
    </header>
    
    <!-- 双栏布局 -->
    <div class="content-layout">
      <!-- 左侧：文件夹树 -->
      <aside class="folder-panel">
        <div class="panel-header">
          <h3>文件夹</h3>
        </div>
        
        <!-- 全部网址 -->
        <div 
          class="all-sites-item"
          :class="{ 'is-active': !selectedFolderId }"
          @click="viewAll"
        >
          <el-icon><Grid /></el-icon>
          <span>全部网址</span>
          <span class="count">{{ workspace.length }}</span>
        </div>
        
        <!-- 文件夹树 -->
        <FolderTree
          :folders="folders"
          :selected-id="selectedFolderId"
          :expanded-ids="expandedFolderIds"
          :editable="true"
          @select="handleSelectFolder"
          @toggle="handleToggleFolder"
          @create="handleCreateFolder"
          @rename="handleRenameFolder"
          @delete="handleDeleteFolder"
        />
      </aside>
      
      <!-- 右侧：网址列表 -->
      <main class="sites-panel">
        <div class="panel-header">
          <div class="breadcrumb">
            <span class="breadcrumb-item" @click="viewAll">全部</span>
            <template v-if="currentFolder">
              <el-icon><ArrowRight /></el-icon>
              <span class="breadcrumb-item active">{{ currentFolder.name }}</span>
            </template>
          </div>
          <span class="count">{{ currentSites.length }} 个网址</span>
        </div>
        
        <!-- 网址网格 -->
        <div v-if="currentSites.length > 0" class="sites-grid">
          <div 
            v-for="site in currentSites" 
            :key="site.id"
            class="site-item"
          >
            <WebsiteCard :website="site" />
            <button class="remove-btn" @click="handleRemoveWebsite(site)" title="移除">
              <el-icon><Close /></el-icon>
            </button>
          </div>
        </div>
        
        <!-- 空状态 -->
        <div v-else class="empty-state">
          <el-icon :size="48"><FolderOpened /></el-icon>
          <h3>暂无网址</h3>
          <p>点击"添加网址"按钮添加您喜欢的网站</p>
          <button class="btn btn-secondary" @click="showAddDialog = true">
            <el-icon><Plus /></el-icon>
            添加网址
          </button>
        </div>
      </main>
    </div>
    
    <!-- 添加网址对话框 -->
    <AddWebsiteDialog
      v-model:visible="showAddDialog"
      :folder-id="selectedFolderId"
      @submit="handleAddWebsite"
    />
  </div>
</template>

<style lang="scss" scoped>
.customize-page {
  padding: 1rem 0;
}

.page-header {
  display: flex;
  align-items: center;
  gap: 1rem;
  margin-bottom: 2rem;
  
  .header-icon {
    width: 48px;
    height: 48px;
    border-radius: 14px;
    background: linear-gradient(135deg, #3B82F6, #8B5CF6);
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    box-shadow: 0 4px 16px rgba(59, 130, 246, 0.3);
    
    .el-icon {
      font-size: 24px;
    }
  }
  
  .header-content {
    flex: 1;
    
    h1 {
      font-size: 1.5rem;
      font-weight: 700;
      color: var(--text-primary);
      margin-bottom: 0.25rem;
    }
    
    p {
      font-size: 0.875rem;
      color: var(--text-tertiary);
    }
  }
}

.btn {
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.625rem 1rem;
  font-size: 0.875rem;
  font-weight: 500;
  border-radius: 10px;
  transition: all 0.2s ease;
}

.btn-primary {
  background: var(--text-primary);
  color: var(--text-inverse);
  
  &:hover {
    opacity: 0.9;
  }
}

.btn-secondary {
  background: var(--bg-tertiary);
  color: var(--text-primary);
  
  &:hover {
    background: var(--border-primary);
  }
}

.content-layout {
  display: grid;
  grid-template-columns: 280px 1fr;
  gap: 1.5rem;
  
  @media (max-width: 768px) {
    grid-template-columns: 1fr;
  }
}

.folder-panel {
  background: var(--card-bg);
  border-radius: 16px;
  border: 1px solid var(--border-secondary);
  padding: 1rem;
  height: fit-content;
  position: sticky;
  top: calc(var(--header-height, 64px) + 1.5rem);
  
  .panel-header {
    margin-bottom: 1rem;
    
    h3 {
      font-size: 0.875rem;
      font-weight: 600;
      color: var(--text-primary);
    }
  }
}

.all-sites-item {
  display: flex;
  align-items: center;
  gap: 0.625rem;
  padding: 0.625rem 0.75rem;
  margin-bottom: 0.5rem;
  border-radius: 10px;
  cursor: pointer;
  color: var(--text-secondary);
  transition: all 0.15s ease;
  
  &:hover {
    background: var(--bg-tertiary);
    color: var(--text-primary);
  }
  
  &.is-active {
    background: var(--accent-light);
    color: var(--accent);
  }
  
  .el-icon {
    font-size: 16px;
  }
  
  span:not(.count) {
    flex: 1;
    font-size: 0.875rem;
    font-weight: 500;
  }
  
  .count {
    font-size: 0.75rem;
    padding: 2px 6px;
    background: var(--bg-tertiary);
    border-radius: 4px;
  }
}

.sites-panel {
  .panel-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 1rem;
    
    .count {
      font-size: 0.8125rem;
      color: var(--text-tertiary);
    }
  }
  
  .breadcrumb {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    
    .breadcrumb-item {
      font-size: 0.875rem;
      color: var(--text-secondary);
      cursor: pointer;
      
      &:hover {
        color: var(--text-primary);
      }
      
      &.active {
        color: var(--text-primary);
        font-weight: 500;
        cursor: default;
      }
    }
    
    .el-icon {
      font-size: 12px;
      color: var(--text-tertiary);
    }
  }
}

.sites-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(100px, 1fr));
  gap: 0.75rem;
}

.site-item {
  position: relative;
  
  &:hover .remove-btn {
    opacity: 1;
  }
}

.remove-btn {
  position: absolute;
  top: 4px;
  right: 4px;
  width: 24px;
  height: 24px;
  border-radius: 6px;
  background: var(--bg-secondary);
  border: 1px solid var(--border-primary);
  color: var(--text-tertiary);
  display: flex;
  align-items: center;
  justify-content: center;
  opacity: 0;
  transition: all 0.15s ease;
  z-index: 10;
  
  &:hover {
    background: #FEE2E2;
    border-color: #FEE2E2;
    color: #EF4444;
  }
  
  .el-icon {
    font-size: 14px;
  }
}

.empty-state {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 4rem 2rem;
  text-align: center;
  background: var(--card-bg);
  border-radius: 16px;
  border: 1px solid var(--border-secondary);
  
  .el-icon {
    color: var(--border-primary);
    margin-bottom: 1rem;
  }
  
  h3 {
    font-size: 1.125rem;
    font-weight: 600;
    color: var(--text-secondary);
    margin-bottom: 0.5rem;
  }
  
  p {
    font-size: 0.875rem;
    color: var(--text-tertiary);
    margin-bottom: 1.5rem;
  }
}
</style>
