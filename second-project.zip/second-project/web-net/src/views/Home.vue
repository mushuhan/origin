<script setup>
import { computed, onMounted, ref, watch } from 'vue'
import { useStore } from 'vuex'
import { useRouter } from 'vue-router'
import { gsap } from 'gsap'
import SearchBox from '@/components/common/SearchBox.vue'
import QuoteTicker from '@/components/common/QuoteTicker.vue'
import CoverflowCarousel from '@/components/common/CoverflowCarousel.vue'
import HotRankingChart from '@/components/common/HotRankingChart.vue'
import SectionCard from '@/components/common/SectionCard.vue'
import WebsiteCard from '@/components/common/WebsiteCard.vue'
import { getHotRanking, addToWorkspace } from '@/api'

const store = useStore()
const router = useRouter()

// 状态
const categories = computed(() => store.state.categories.filter(c => !c.is_system))
const hotWebsites = computed(() => store.state.hotWebsites)
const loading = computed(() => store.state.loading)
const workspace = computed(() => store.state.workspace)
const quote = computed(() => store.state.quote)

// 热门排行
const hotRankings = ref([])
const rankingDimension = ref('all')
const rankingLoading = ref(false)

// 轮播数据（使用热门网站）
const carouselItems = computed(() => {
  return hotWebsites.value.slice(0, 5).map(w => ({
    ...w,
    title: w.name,
    image: null // 可以添加封面图
  }))
})

// Refs
const heroRef = ref(null)
const contentRef = ref(null)

// 获取热门排行
const fetchHotRankings = async (dimension = 'all') => {
  rankingLoading.value = true
  try {
    const data = await getHotRanking(dimension, 10)
    hotRankings.value = data.rankings || []
  } catch (e) {
    console.error('获取热门排行失败:', e)
  } finally {
    rankingLoading.value = false
  }
}

// 切换排行维度
const handleDimensionChange = (dimension) => {
  rankingDimension.value = dimension
  fetchHotRankings(dimension)
}

// 点击排行项
const handleRankingClick = (item) => {
  window.open(item.url, '_blank')
}

// 导航到分类
const goToCategory = (category) => {
  router.push(`/category/${category.id}`)
}

// 导航到工作台
const goToWorkspace = () => {
  router.push('/customize')
}

// 添加到工作台
const handleAddToWorkspace = async (website) => {
  try {
    await store.dispatch('addToWorkspace', { website_id: website.id })
  } catch (e) {
    console.error('添加失败:', e)
  }
}

// 搜索
const handleSearch = (keyword) => {
  router.push({ path: '/search', query: { q: keyword } })
}

// 页面动画
onMounted(() => {
  fetchHotRankings()
  
  // Hero区域动画
  if (heroRef.value) {
    gsap.from(heroRef.value.children, {
      opacity: 0,
      y: 30,
      duration: 0.8,
      stagger: 0.12,
      ease: 'power3.out'
    })
  }
  
  // 内容区动画
  if (contentRef.value) {
    gsap.from(contentRef.value.children, {
      opacity: 0,
      y: 20,
      duration: 0.6,
      stagger: 0.1,
      delay: 0.3,
      ease: 'power2.out'
    })
  }
})
</script>

<template>
  <div class="home-page">
    <!-- Hero区域 - 沉浸式体验 -->
    <section ref="heroRef" class="hero-section">
      <!-- 背景装饰 -->
      <div class="hero-bg">
        <div class="bg-gradient"></div>
        <div class="bg-noise"></div>
      </div>
      
      <!-- 搜索框 -->
      <div class="search-container">
        <SearchBox 
          size="large"
          placeholder="搜索网站、工具... (⌘K)"
          @search="handleSearch"
        />
      </div>
      
      <!-- 励志语录 -->
      <QuoteTicker 
        v-if="quote"
        :quotes="[quote]"
        :auto-play="false"
        class="quote-section"
      />
      
      <!-- 快捷入口 -->
      <div class="quick-actions">
        <button class="action-btn primary" @click="goToWorkspace">
          <el-icon><Briefcase /></el-icon>
          <span>我的工作台</span>
          <span v-if="workspace.length" class="badge">{{ workspace.length }}</span>
        </button>
        <button class="action-btn" @click="router.push('/hot')">
          <el-icon><TrendCharts /></el-icon>
          <span>热门网址</span>
        </button>
      </div>
    </section>
    
    <!-- 主内容区 -->
    <div ref="contentRef" class="main-content">
      <!-- Bento Grid 布局 -->
      <div class="bento-grid">
        <!-- 热门网址轮播 -->
        <section class="bento-item carousel-section">
          <div class="section-header">
            <h2 class="section-title">
              <el-icon><Star /></el-icon>
              精选推荐
            </h2>
          </div>
          <div class="carousel-wrapper" v-if="carouselItems.length > 0">
            <CoverflowCarousel 
              :items="carouselItems"
              :auto-play="true"
              :interval="6000"
              @click="(item) => window.open(item.url, '_blank')"
            >
              <template #card="{ item, isActive }">
                <div class="feature-card" :class="{ active: isActive }">
                  <div class="card-icon" :style="{ background: `linear-gradient(135deg, ${item.color || '#3B82F6'}, ${item.color || '#8B5CF6'})` }">
                    {{ item.name?.charAt(0) }}
                  </div>
                  <h3 class="card-title">{{ item.name }}</h3>
                  <p class="card-desc">{{ item.description }}</p>
                  <span class="card-clicks">{{ item.click_count }} 次访问</span>
                </div>
              </template>
            </CoverflowCarousel>
          </div>
        </section>
        
        <!-- 热门排行榜 -->
        <section class="bento-item ranking-section">
          <HotRankingChart
            :rankings="hotRankings"
            :dimension="rankingDimension"
            :loading="rankingLoading"
            @dimension-change="handleDimensionChange"
            @click="handleRankingClick"
          />
        </section>
      </div>
      
      <!-- 热门网址快捷入口 -->
      <section class="hot-websites-section" v-if="hotWebsites.length > 0">
        <div class="section-header">
          <div class="header-left">
            <div class="icon-wrapper">
              <el-icon><Star /></el-icon>
            </div>
            <div>
              <h2 class="section-title">热门推荐</h2>
              <p class="section-subtitle">大家都在用的网站</p>
            </div>
          </div>
          <router-link to="/hot" class="view-all">
            查看更多
            <el-icon><ArrowRight /></el-icon>
          </router-link>
        </div>
        
        <div class="hot-grid">
          <WebsiteCard
            v-for="(website, index) in hotWebsites.slice(0, 16)"
            :key="website.id"
            :website="website"
            :style="{ animationDelay: `${index * 0.04}s` }"
            class="animate-in"
            @addToWorkspace="handleAddToWorkspace"
          />
        </div>
      </section>
      
      <!-- 加载状态 -->
      <div v-if="loading" class="loading-state">
        <div class="loading-spinner"></div>
        <p>加载中...</p>
      </div>
      
      <!-- 分类列表 -->
      <section v-else class="categories-section">
        <template v-for="category in categories" :key="category.id">
          <div class="category-block">
            <!-- 分类标题 -->
            <div class="category-header" @click="goToCategory(category)">
              <h2 class="category-name">{{ category.name }}</h2>
              <el-icon class="category-arrow"><ArrowRight /></el-icon>
            </div>
            
            <!-- 分区列表 -->
            <div class="sections-list">
              <SectionCard
                v-for="section in category.sections"
                :key="section.id"
                :section="section"
                :initial-limit="12"
                @addToWorkspace="handleAddToWorkspace"
              />
            </div>
          </div>
        </template>
      </section>
      
      <!-- 空状态 -->
      <div v-if="!loading && categories.length === 0" class="empty-state">
        <el-icon :size="64"><FolderOpened /></el-icon>
        <h3>暂无数据</h3>
        <p>请先配置网址分类和网站</p>
      </div>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.home-page {
  min-height: 100vh;
}

// ========================================
// Hero Section
// ========================================
.hero-section {
  position: relative;
  padding: 4rem 2rem 2rem;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 1.5rem;
  overflow: hidden;
}

.hero-bg {
  position: absolute;
  inset: 0;
  z-index: -1;
  
  .bg-gradient {
    position: absolute;
    inset: 0;
    background: radial-gradient(ellipse 80% 50% at 50% -20%, var(--accent-light), transparent);
  }
  
  .bg-noise {
    position: absolute;
    inset: 0;
    opacity: 0.03;
    background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.65' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)'/%3E%3C/svg%3E");
  }
}

.search-container {
  width: 100%;
  max-width: 600px;
}

.quote-section {
  max-width: 700px;
}

.quick-actions {
  display: flex;
  gap: 0.75rem;
  flex-wrap: wrap;
  justify-content: center;
}

.action-btn {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.75rem 1.25rem;
  font-size: 0.875rem;
  font-weight: 500;
  color: var(--text-primary);
  background: var(--glass-bg);
  backdrop-filter: blur(20px);
  border: 1px solid var(--glass-border);
  border-radius: 12px;
  transition: all 0.2s ease;
  
  &:hover {
    background: var(--card-bg);
    border-color: var(--border-primary);
    transform: translateY(-2px);
    box-shadow: var(--shadow-md);
  }
  
  &.primary {
    background: var(--text-primary);
    color: var(--text-inverse);
    border-color: transparent;
    
    &:hover {
      opacity: 0.9;
    }
  }
  
  .badge {
    padding: 2px 8px;
    font-size: 0.75rem;
    background: rgba(255, 255, 255, 0.2);
    border-radius: 10px;
  }
}

// ========================================
// Main Content
// ========================================
.main-content {
  padding: 0 2rem 4rem;
  max-width: 1400px;
  margin: 0 auto;
}

// ========================================
// Bento Grid
// ========================================
.bento-grid {
  display: grid;
  grid-template-columns: 2fr 1fr;
  gap: 1.5rem;
  margin-bottom: 3rem;
  
  @media (max-width: 1024px) {
    grid-template-columns: 1fr;
  }
}

.bento-item {
  background: var(--card-bg);
  border-radius: 20px;
  border: 1px solid var(--border-secondary);
  overflow: hidden;
}

.carousel-section {
  padding: 1.5rem;
  
  .section-header {
    margin-bottom: 1rem;
  }
  
  .section-title {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    font-size: 1rem;
    font-weight: 600;
    color: var(--text-primary);
    
    .el-icon {
      color: var(--accent);
    }
  }
}

.carousel-wrapper {
  height: 320px;
}

.feature-card {
  width: 100%;
  height: 100%;
  padding: 2rem;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  text-align: center;
  background: var(--bg-secondary);
  
  .card-icon {
    width: 64px;
    height: 64px;
    border-radius: 16px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.75rem;
    font-weight: 700;
    color: white;
    margin-bottom: 1rem;
  }
  
  .card-title {
    font-size: 1.25rem;
    font-weight: 700;
    color: var(--text-primary);
    margin-bottom: 0.5rem;
  }
  
  .card-desc {
    font-size: 0.875rem;
    color: var(--text-secondary);
    margin-bottom: 1rem;
    max-width: 200px;
  }
  
  .card-clicks {
    font-size: 0.75rem;
    color: var(--text-tertiary);
    padding: 4px 12px;
    background: var(--bg-tertiary);
    border-radius: 20px;
  }
}

// ========================================
// Hot Websites
// ========================================
.hot-websites-section {
  margin-bottom: 3rem;
}

.section-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1.5rem;
  
  .header-left {
    display: flex;
    align-items: center;
    gap: 0.75rem;
  }
  
  .icon-wrapper {
    width: 40px;
    height: 40px;
    border-radius: 12px;
    background: linear-gradient(135deg, #F59E0B, #EF4444);
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    box-shadow: 0 4px 12px rgba(245, 158, 11, 0.3);
  }
  
  .section-title {
    font-size: 1.125rem;
    font-weight: 700;
    color: var(--text-primary);
  }
  
  .section-subtitle {
    font-size: 0.8125rem;
    color: var(--text-tertiary);
  }
  
  .view-all {
    display: flex;
    align-items: center;
    gap: 0.25rem;
    font-size: 0.875rem;
    color: var(--text-secondary);
    
    &:hover {
      color: var(--accent);
    }
  }
}

.hot-grid {
  display: grid;
  grid-template-columns: repeat(8, 1fr);
  gap: 0.75rem;
  
  @media (max-width: 1280px) {
    grid-template-columns: repeat(6, 1fr);
  }
  
  @media (max-width: 1024px) {
    grid-template-columns: repeat(5, 1fr);
  }
  
  @media (max-width: 768px) {
    grid-template-columns: repeat(4, 1fr);
  }
  
  @media (max-width: 480px) {
    grid-template-columns: repeat(3, 1fr);
  }
}

.animate-in {
  animation: slideUpFade 0.5s ease forwards;
  opacity: 0;
}

@keyframes slideUpFade {
  from {
    opacity: 0;
    transform: translateY(16px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

// ========================================
// Categories
// ========================================
.categories-section {
  display: flex;
  flex-direction: column;
  gap: 3rem;
}

.category-block {
  .category-header {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    margin-bottom: 1.5rem;
    cursor: pointer;
    
    &:hover {
      .category-name {
        color: var(--accent);
      }
      
      .category-arrow {
        color: var(--accent);
        transform: translateX(4px);
      }
    }
  }
  
  .category-name {
    font-size: 1.25rem;
    font-weight: 700;
    color: var(--text-primary);
    transition: color 0.2s ease;
  }
  
  .category-arrow {
    color: var(--text-tertiary);
    transition: all 0.2s ease;
  }
}

.sections-list {
  display: flex;
  flex-direction: column;
  gap: 2rem;
}

// ========================================
// Loading & Empty States
// ========================================
.loading-state {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 4rem;
  color: var(--text-tertiary);
  
  .loading-spinner {
    width: 40px;
    height: 40px;
    border: 3px solid var(--border-primary);
    border-top-color: var(--accent);
    border-radius: 50%;
    animation: spin 0.8s linear infinite;
    margin-bottom: 1rem;
  }
}

@keyframes spin {
  to {
    transform: rotate(360deg);
  }
}

.empty-state {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 6rem 2rem;
  text-align: center;
  
  .el-icon {
    color: var(--border-primary);
    margin-bottom: 1.5rem;
  }
  
  h3 {
    font-size: 1.25rem;
    font-weight: 600;
    color: var(--text-secondary);
    margin-bottom: 0.5rem;
  }
  
  p {
    font-size: 0.875rem;
    color: var(--text-tertiary);
  }
}
</style>
