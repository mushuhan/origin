<script setup>
import { computed, onMounted, ref } from 'vue'
import { useStore } from 'vuex'
import { useRouter } from 'vue-router'
import SectionCard from '@/components/common/SectionCard.vue'
import WebsiteCard from '@/components/common/WebsiteCard.vue'
import { gsap } from 'gsap'

const store = useStore()
const router = useRouter()

const categories = computed(() => store.state.categories.filter(c => !c.is_system))
const hotWebsites = computed(() => store.state.hotWebsites)
const loading = computed(() => store.state.loading)
const workspace = computed(() => store.state.workspace)

const heroRef = ref(null)
const hotSectionRef = ref(null)

onMounted(() => {
  // Hero区域动画
  if (heroRef.value) {
    gsap.from(heroRef.value.children, {
      opacity: 0,
      y: 30,
      duration: 0.8,
      stagger: 0.15,
      ease: 'power3.out'
    })
  }
})

// 导航到分类
const goToCategory = (category) => {
  router.push(`/category/${category.id}`)
}

// 导航到工作台
const goToWorkspace = () => {
  router.push('/customize')
}
</script>

<template>
  <div class="home-page">
    <!-- Hero区域 -->
    <div ref="heroRef" class="hero-section mb-10">
      <div class="hero-content text-center py-12 px-6 rounded-3xl relative overflow-hidden">
        <!-- 背景装饰 -->
        <div class="hero-bg absolute inset-0 -z-10">
          <div class="gradient-orb orb-1"></div>
          <div class="gradient-orb orb-2"></div>
          <div class="gradient-orb orb-3"></div>
        </div>
        
        <h1 class="text-4xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-sky-500 via-blue-600 to-indigo-600 bg-clip-text text-transparent">
          一站式网址导航
        </h1>
        <p class="text-lg text-gray-500 dark:text-gray-400 mb-6 max-w-2xl mx-auto">
          高效管理您的常用网址，快速访问，提升工作效率
        </p>
        
        <!-- 快捷入口 -->
        <div class="quick-actions flex justify-center gap-4 flex-wrap">
          <button 
            class="action-btn px-6 py-3 rounded-2xl text-sm font-medium flex items-center gap-2 transition-all hover:scale-105"
            @click="goToWorkspace"
          >
            <el-icon><Briefcase /></el-icon>
            我的工作台
            <span v-if="workspace.length" class="count">{{ workspace.length }}</span>
          </button>
          <button 
            class="action-btn secondary px-6 py-3 rounded-2xl text-sm font-medium flex items-center gap-2 transition-all hover:scale-105"
            @click="router.push('/hot')"
          >
            <el-icon><TrendCharts /></el-icon>
            热门网址
          </button>
        </div>
      </div>
    </div>

    <!-- 热门网址 -->
    <section v-if="hotWebsites.length > 0" ref="hotSectionRef" class="hot-section mb-10">
      <div class="section-header flex items-center justify-between mb-6">
        <div class="flex items-center gap-3">
          <div class="icon-wrapper w-10 h-10 rounded-xl bg-gradient-to-br from-orange-400 to-red-500 flex items-center justify-center text-white">
            <el-icon :size="20"><Star /></el-icon>
          </div>
          <div>
            <h2 class="text-xl font-bold">热门推荐</h2>
            <p class="text-sm text-gray-400">大家都在用的网站</p>
          </div>
        </div>
        <router-link 
          to="/hot" 
          class="text-sm text-sky-500 hover:text-sky-600 flex items-center gap-1"
        >
          查看更多
          <el-icon><ArrowRight /></el-icon>
        </router-link>
      </div>
      
      <div class="hot-grid grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 xl:grid-cols-8 gap-4">
        <WebsiteCard 
          v-for="website in hotWebsites.slice(0, 16)" 
          :key="website.id"
          :website="website"
          size="normal"
        />
      </div>
    </section>

    <!-- 加载状态 -->
    <div v-if="loading" class="loading-state py-20 text-center">
      <div class="loading-spinner mx-auto mb-4"></div>
      <p class="text-gray-400">加载中...</p>
    </div>

    <!-- 分类列表 -->
    <section v-else class="categories-section">
      <template v-for="category in categories" :key="category.id">
        <div class="category-block mb-12">
          <!-- 分类标题 -->
          <div class="category-header flex items-center justify-between mb-6">
            <div 
              class="flex items-center gap-3 cursor-pointer group"
              @click="goToCategory(category)"
            >
              <h2 class="text-xl font-bold group-hover:text-sky-500 transition-colors">
                {{ category.name }}
              </h2>
              <el-icon class="text-gray-400 group-hover:text-sky-500 transition-colors">
                <ArrowRight />
              </el-icon>
            </div>
          </div>

          <!-- 分区列表 -->
          <div class="sections-list space-y-8">
            <SectionCard 
              v-for="section in category.sections" 
              :key="section.id"
              :section="section"
            />
          </div>
        </div>
      </template>
    </section>

    <!-- 空状态 -->
    <div v-if="!loading && categories.length === 0" class="empty-state py-20 text-center">
      <el-icon :size="80" class="text-gray-300 dark:text-gray-700 mb-6">
        <FolderOpened />
      </el-icon>
      <h3 class="text-xl font-medium text-gray-500 mb-2">暂无数据</h3>
      <p class="text-gray-400">请先配置网址分类和网站</p>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.hero-content {
  background: rgba(255, 255, 255, 0.6);
  backdrop-filter: blur(20px);
  -webkit-backdrop-filter: blur(20px);
  border: 1px solid rgba(255, 255, 255, 0.3);
}

.dark .hero-content {
  background: rgba(30, 41, 59, 0.6);
  border: 1px solid rgba(255, 255, 255, 0.05);
}

.hero-bg {
  .gradient-orb {
    position: absolute;
    border-radius: 50%;
    filter: blur(60px);
    opacity: 0.5;
    animation: float 8s ease-in-out infinite;
  }
  
  .orb-1 {
    width: 300px;
    height: 300px;
    background: linear-gradient(135deg, #0ea5e9 0%, #6366f1 100%);
    top: -100px;
    left: -50px;
  }
  
  .orb-2 {
    width: 200px;
    height: 200px;
    background: linear-gradient(135deg, #f472b6 0%, #8b5cf6 100%);
    top: 50%;
    right: -50px;
    animation-delay: -2s;
  }
  
  .orb-3 {
    width: 250px;
    height: 250px;
    background: linear-gradient(135deg, #34d399 0%, #0ea5e9 100%);
    bottom: -100px;
    left: 50%;
    animation-delay: -4s;
  }
}

@keyframes float {
  0%, 100% {
    transform: translate(0, 0) scale(1);
  }
  33% {
    transform: translate(10px, -10px) scale(1.05);
  }
  66% {
    transform: translate(-10px, 10px) scale(0.95);
  }
}

.action-btn {
  background: linear-gradient(135deg, #0ea5e9 0%, #3b82f6 100%);
  color: white;
  box-shadow: 0 4px 15px rgba(14, 165, 233, 0.3);
  
  &:hover {
    box-shadow: 0 6px 20px rgba(14, 165, 233, 0.4);
  }
  
  &.secondary {
    background: rgba(255, 255, 255, 0.8);
    color: #374151;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
    
    &:hover {
      background: white;
    }
  }
  
  .count {
    padding: 2px 8px;
    background: rgba(255, 255, 255, 0.2);
    border-radius: 10px;
    font-size: 12px;
  }
}

.dark .action-btn.secondary {
  background: rgba(30, 41, 59, 0.8);
  color: #e2e8f0;
  
  &:hover {
    background: #334155;
  }
}

.icon-wrapper {
  box-shadow: 0 4px 12px rgba(251, 146, 60, 0.3);
}

.loading-spinner {
  width: 48px;
  height: 48px;
  border: 4px solid rgba(14, 165, 233, 0.2);
  border-top-color: #0ea5e9;
  border-radius: 50%;
  animation: spin 0.8s linear infinite;
}

@keyframes spin {
  to {
    transform: rotate(360deg);
  }
}
</style>

