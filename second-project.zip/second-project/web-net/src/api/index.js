import axios from 'axios'

// 创建axios实例
const api = axios.create({
  baseURL: '/api',
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json'
  }
})

// 请求拦截器
api.interceptors.request.use(
  config => {
    return config
  },
  error => {
    return Promise.reject(error)
  }
)

// 响应拦截器
api.interceptors.response.use(
  response => {
    const { data } = response
    if (data.code === 200) {
      return data.data
    }
    return Promise.reject(new Error(data.message || '请求失败'))
  },
  error => {
    console.error('API Error:', error)
    return Promise.reject(error)
  }
)

// ==================== 分类相关API ====================

export const getCategories = () => api.get('/categories')

export const getCategory = (id) => api.get(`/categories/${id}`)

export const createCategory = (data) => api.post('/categories', data)

export const updateCategory = (id, data) => api.put(`/categories/${id}`, data)

export const deleteCategory = (id) => api.delete(`/categories/${id}`)

export const reorderCategories = (items) => api.put('/categories/batch-reorder', { items })

// ==================== 分区相关API ====================

export const getSections = (categoryId) => {
  const params = categoryId ? { category_id: categoryId } : {}
  return api.get('/sections', { params })
}

export const getSection = (id) => api.get(`/sections/${id}`)

export const createSection = (data) => api.post('/sections', data)

export const updateSection = (id, data) => api.put(`/sections/${id}`, data)

export const deleteSection = (id) => api.delete(`/sections/${id}`)

export const reorderSections = (items) => api.put('/sections/batch-reorder', { items })

// ==================== 网址相关API ====================

export const getWebsites = (params) => api.get('/websites', { params })

export const getHotWebsites = (limit = 20) => api.get('/websites/hot', { params: { limit } })

export const getWebsite = (id) => api.get(`/websites/${id}`)

export const createWebsite = (data) => api.post('/websites', data)

export const updateWebsite = (id, data) => api.put(`/websites/${id}`, data)

export const deleteWebsite = (id) => api.delete(`/websites/${id}`)

export const clickWebsite = (id) => api.post(`/websites/${id}/click`)

export const reorderWebsites = (items) => api.put('/websites/batch-reorder', { items })

// ==================== 工作台相关API ====================

export const getWorkspace = () => api.get('/workspace')

export const addToWorkspace = (data) => api.post('/workspace', data)

export const updateWorkspaceItem = (id, data) => api.put(`/workspace/${id}`, data)

export const removeFromWorkspace = (id) => api.delete(`/workspace/${id}`)

export const reorderWorkspace = (items) => api.put('/workspace/reorder', { items })

// ==================== 搜索相关API ====================

export const search = (keyword) => api.get('/search', { params: { keyword } })

export const getSearchSuggestions = (keyword) => api.get('/search/suggestions', { params: { keyword } })

// ==================== 系统设置相关API ====================

export const getSettings = () => api.get('/settings')

export const updateSetting = (key, value) => api.put(`/settings/${key}`, { value })

// ==================== 首页数据API ====================

export const getHomeData = () => api.get('/home')

export default api

