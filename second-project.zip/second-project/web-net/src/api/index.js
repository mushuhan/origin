import axios from 'axios'

// ==================== 用户Token管理 ====================

const USER_TOKEN_KEY = 'nav_user_token'

/**
 * 生成UUID v4
 */
function generateUUID() {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
    const r = Math.random() * 16 | 0
    const v = c === 'x' ? r : (r & 0x3 | 0x8)
    return v.toString(16)
  })
}

/**
 * 获取或创建用户Token
 */
export function getUserToken() {
  let token = localStorage.getItem(USER_TOKEN_KEY)
  
  if (!token) {
    token = generateUUID()
    localStorage.setItem(USER_TOKEN_KEY, token)
  }
  
  return token
}

/**
 * 清除用户Token（用于重置）
 */
export function clearUserToken() {
  localStorage.removeItem(USER_TOKEN_KEY)
}

// ==================== Axios实例配置 ====================

const api = axios.create({
  baseURL: '/api',
  timeout: 15000,
  headers: {
    'Content-Type': 'application/json'
  }
})

// 请求拦截器 - 自动添加用户Token
api.interceptors.request.use(
  config => {
    // 添加用户Token到请求头
    const token = getUserToken()
    if (token) {
      config.headers['X-User-Token'] = token
    }
    return config
  },
  error => {
    return Promise.reject(error)
  }
)

// 响应拦截器
api.interceptors.response.use(
  response => {
    const { data } = response
    if (data.code === 200 || data.code === 201) {
      return data.data
    }
    return Promise.reject(new Error(data.message || '请求失败'))
  },
  error => {
    console.error('API Error:', error)
    const message = error.response?.data?.message || error.message || '网络错误'
    return Promise.reject(new Error(message))
  }
)

// ==================== 首页数据API ====================

export const getHomeData = () => api.get('/home')

export const getSiteStats = () => api.get('/home/stats')

// ==================== 分类相关API ====================

export const getCategories = (includeSections = false) => 
  api.get('/categories', { params: { include_sections: includeSections } })

export const getCategory = (id) => api.get(`/categories/${id}`)

export const createCategory = (data) => api.post('/categories', data)

export const updateCategory = (id, data) => api.put(`/categories/${id}`, data)

export const deleteCategory = (id) => api.delete(`/categories/${id}`)

export const reorderCategories = (items) => api.put('/categories/batch-reorder', { items })

// ==================== 分区相关API ====================

export const getSections = (categoryId, includeWebsites = false) => 
  api.get('/sections', { 
    params: { 
      category_id: categoryId, 
      include_websites: includeWebsites 
    } 
  })

export const getSection = (id) => api.get(`/sections/${id}`)

export const createSection = (data) => api.post('/sections', data)

export const updateSection = (id, data) => api.put(`/sections/${id}`, data)

export const deleteSection = (id) => api.delete(`/sections/${id}`)

export const reorderSections = (items) => api.put('/sections/batch-reorder', { items })

// ==================== 网址相关API ====================

export const getWebsites = (params) => api.get('/websites', { params })

export const getHotWebsites = (limit = 20) => api.get('/websites/hot', { params: { limit } })

export const getWebsite = (id) => api.get(`/websites/${id}`)

export const createWebsite = (data) => api.post('/websites', data)

export const updateWebsite = (id, data) => api.put(`/websites/${id}`, data)

export const deleteWebsite = (id) => api.delete(`/websites/${id}`)

export const clickWebsite = (id) => api.post(`/websites/${id}/click`)

export const reorderWebsites = (items) => api.put('/websites/batch-reorder', { items })

// ==================== 工作台相关API ====================

export const getWorkspace = (folderId) => 
  api.get('/workspace', { params: { folder_id: folderId } })

export const getAllWorkspace = () => api.get('/workspace/all')

export const addToWorkspace = (data) => api.post('/workspace', data)

export const updateWorkspaceItem = (id, data) => api.put(`/workspace/${id}`, data)

export const removeFromWorkspace = (id) => api.delete(`/workspace/${id}`)

export const reorderWorkspace = (items) => api.put('/workspace/reorder', { items })

// ==================== 文件夹相关API ====================

export const getFolders = (flat = false, includeSites = false) => 
  api.get('/folders', { params: { flat, include_sites: includeSites } })

export const getFolder = (id, includeSites = true) => 
  api.get(`/folders/${id}`, { params: { include_sites: includeSites } })

export const createFolder = (data) => api.post('/folders', data)

export const updateFolder = (id, data) => api.put(`/folders/${id}`, data)

export const deleteFolder = (id, moveToParent = false) => 
  api.delete(`/folders/${id}`, { params: { move_to_parent: moveToParent } })

export const reorderFolders = (items) => api.put('/folders/reorder', { items })

// ==================== 搜索相关API ====================

export const search = (keyword, limit = 50) => 
  api.get('/search', { params: { keyword, limit } })

export const getSearchSuggestions = (keyword, limit = 10) => 
  api.get('/search/suggestions', { params: { keyword, limit } })

export const getSearchHistory = (limit = 20) => 
  api.get('/search/history', { params: { limit } })

export const clearSearchHistory = () => api.delete('/search/history')

// ==================== 语录相关API ====================

export const getQuotes = (category, page = 1, perPage = 20) => 
  api.get('/quotes', { params: { category, page, per_page: perPage } })

export const getRandomQuote = (count = 1) => 
  api.get('/quotes/random', { params: { count } })

export const getDailyQuote = () => api.get('/quotes/daily')

export const getQuoteCategories = () => api.get('/quotes/categories')

// ==================== 数据分析API ====================

export const getHotRanking = (dimension = 'all', limit = 10) => 
  api.get('/analytics/hot-ranking', { params: { dimension, limit } })

export const getCategoryStats = () => api.get('/analytics/category-stats')

export const getClickTrends = (days = 7) => 
  api.get('/analytics/click-trends', { params: { days } })

export const getAnalyticsOverview = () => api.get('/analytics/overview')

// ==================== 用户相关API ====================

export const registerUser = (uuid) => api.post('/users/register', { uuid })

export const getCurrentUser = () => api.get('/users/me')

export const getUserSettings = () => api.get('/users/me/settings')

export const updateUserSettings = (settings) => api.put('/users/me/settings', settings)

export const getUserStats = () => api.get('/users/me/stats')

// ==================== 系统设置API ====================

export const getSettings = () => api.get('/settings')

export const getSetting = (key) => api.get(`/settings/${key}`)

export const updateSetting = (key, value) => api.put(`/settings/${key}`, { value })

export const batchUpdateSettings = (settings) => api.put('/settings/batch', settings)

export default api
