import { createStore } from 'vuex'
import * as api from '@/api'

export default createStore({
  state: {
    // 主题
    isDark: localStorage.getItem('theme') === 'dark',
    
    // 侧边栏
    sidebarCollapsed: localStorage.getItem('sidebarCollapsed') === 'true',
    
    // 用户信息
    user: null,
    userToken: api.getUserToken(),
    
    // 分类数据
    categories: [],
    currentCategory: null,
    
    // 工作台数据
    workspace: [],
    folders: [],
    
    // 热门网址
    hotWebsites: [],
    
    // 语录
    quote: null,
    
    // 系统设置
    settings: {},
    
    // 搜索
    searchKeyword: '',
    searchResults: [],
    searchSuggestions: [],
    hotKeywords: [],
    
    // 加载状态
    loading: false,
    
    // 全局消息
    message: null
  },
  
  getters: {
    // 获取非系统分类
    regularCategories: state => state.categories.filter(c => !c.is_system),
    
    // 获取工作台分类
    workspaceCategory: state => state.categories.find(c => c.is_system),
    
    // 当前主题
    theme: state => state.isDark ? 'dark' : 'light',
    
    // 是否已登录（有用户Token）
    isLoggedIn: state => !!state.userToken,
    
    // 工作台网址数量
    workspaceCount: state => state.workspace.length,
    
    // 文件夹树
    folderTree: state => state.folders
  },
  
  mutations: {
    // 设置主题
    SET_THEME(state, isDark) {
      state.isDark = isDark
      localStorage.setItem('theme', isDark ? 'dark' : 'light')
      
      if (isDark) {
        document.documentElement.classList.add('dark')
        document.body.classList.add('dark')
      } else {
        document.documentElement.classList.remove('dark')
        document.body.classList.remove('dark')
      }
    },
    
    // 切换侧边栏
    TOGGLE_SIDEBAR(state) {
      state.sidebarCollapsed = !state.sidebarCollapsed
      localStorage.setItem('sidebarCollapsed', state.sidebarCollapsed)
    },
    
    // 设置侧边栏状态
    SET_SIDEBAR_COLLAPSED(state, collapsed) {
      state.sidebarCollapsed = collapsed
      localStorage.setItem('sidebarCollapsed', collapsed)
    },
    
    // 设置用户
    SET_USER(state, user) {
      state.user = user
    },
    
    // 设置分类
    SET_CATEGORIES(state, categories) {
      state.categories = categories
    },
    
    // 设置当前分类
    SET_CURRENT_CATEGORY(state, category) {
      state.currentCategory = category
    },
    
    // 设置工作台
    SET_WORKSPACE(state, workspace) {
      state.workspace = workspace
    },
    
    // 设置文件夹
    SET_FOLDERS(state, folders) {
      state.folders = folders
    },
    
    // 添加到工作台
    ADD_TO_WORKSPACE(state, item) {
      state.workspace.push(item)
    },
    
    // 从工作台移除
    REMOVE_FROM_WORKSPACE(state, id) {
      state.workspace = state.workspace.filter(item => item.id !== id)
    },
    
    // 更新工作台项目
    UPDATE_WORKSPACE_ITEM(state, updatedItem) {
      const index = state.workspace.findIndex(item => item.id === updatedItem.id)
      if (index !== -1) {
        state.workspace.splice(index, 1, updatedItem)
      }
    },
    
    // 设置热门网址
    SET_HOT_WEBSITES(state, websites) {
      state.hotWebsites = websites
    },
    
    // 设置语录
    SET_QUOTE(state, quote) {
      state.quote = quote
    },
    
    // 设置系统设置
    SET_SETTINGS(state, settings) {
      state.settings = settings
    },
    
    // 设置搜索关键词
    SET_SEARCH_KEYWORD(state, keyword) {
      state.searchKeyword = keyword
    },
    
    // 设置搜索结果
    SET_SEARCH_RESULTS(state, results) {
      state.searchResults = results
    },
    
    // 设置搜索建议
    SET_SEARCH_SUGGESTIONS(state, { suggestions, hotKeywords }) {
      state.searchSuggestions = suggestions || []
      state.hotKeywords = hotKeywords || []
    },
    
    // 设置加载状态
    SET_LOADING(state, loading) {
      state.loading = loading
    },
    
    // 设置消息
    SET_MESSAGE(state, message) {
      state.message = message
    },
    
    // 添加文件夹
    ADD_FOLDER(state, folder) {
      state.folders.push(folder)
    },
    
    // 更新文件夹
    UPDATE_FOLDER(state, updatedFolder) {
      const index = state.folders.findIndex(f => f.id === updatedFolder.id)
      if (index !== -1) {
        state.folders.splice(index, 1, updatedFolder)
      }
    },
    
    // 删除文件夹
    REMOVE_FOLDER(state, id) {
      state.folders = state.folders.filter(f => f.id !== id)
    }
  },
  
  actions: {
    // 初始化主题
    initTheme({ commit, state }) {
      // 检查系统偏好
      if (localStorage.getItem('theme') === null) {
        const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches
        commit('SET_THEME', prefersDark)
      } else {
        commit('SET_THEME', state.isDark)
      }
    },
    
    // 切换主题
    toggleTheme({ commit, state }) {
      commit('SET_THEME', !state.isDark)
    },
    
    // 初始化用户
    async initUser({ commit, state }) {
      try {
        // 注册/获取用户
        const user = await api.registerUser(state.userToken)
        commit('SET_USER', user)
      } catch (error) {
        console.error('初始化用户失败:', error)
      }
    },
    
    // 获取首页数据
    async fetchHomeData({ commit }) {
      commit('SET_LOADING', true)
      try {
        const data = await api.getHomeData()
        commit('SET_CATEGORIES', data.categories || [])
        commit('SET_HOT_WEBSITES', data.hot_websites || [])
        commit('SET_SETTINGS', data.settings || {})
        commit('SET_QUOTE', data.quote || null)
      } catch (error) {
        console.error('获取首页数据失败:', error)
        commit('SET_MESSAGE', { type: 'error', text: '获取数据失败' })
      } finally {
        commit('SET_LOADING', false)
      }
    },
    
    // 获取分类数据
    async fetchCategories({ commit }) {
      try {
        const categories = await api.getCategories(true)
        commit('SET_CATEGORIES', categories)
      } catch (error) {
        console.error('获取分类失败:', error)
      }
    },
    
    // 获取单个分类详情
    async fetchCategory({ commit }, id) {
      commit('SET_LOADING', true)
      try {
        const category = await api.getCategory(id)
        commit('SET_CURRENT_CATEGORY', category)
        return category
      } catch (error) {
        console.error('获取分类详情失败:', error)
        throw error
      } finally {
        commit('SET_LOADING', false)
      }
    },
    
    // 获取工作台数据
    async fetchWorkspace({ commit }) {
      try {
        const data = await api.getAllWorkspace()
        commit('SET_WORKSPACE', data.ungrouped || [])
        commit('SET_FOLDERS', data.folders || [])
      } catch (error) {
        console.error('获取工作台数据失败:', error)
      }
    },
    
    // 添加到工作台
    async addToWorkspace({ commit }, data) {
      try {
        const item = await api.addToWorkspace(data)
        commit('ADD_TO_WORKSPACE', item)
        commit('SET_MESSAGE', { type: 'success', text: '添加成功' })
        return item
      } catch (error) {
        commit('SET_MESSAGE', { type: 'error', text: error.message || '添加失败' })
        throw error
      }
    },
    
    // 更新工作台项目
    async updateWorkspaceItem({ commit }, { id, data }) {
      try {
        const item = await api.updateWorkspaceItem(id, data)
        commit('UPDATE_WORKSPACE_ITEM', item)
        commit('SET_MESSAGE', { type: 'success', text: '更新成功' })
        return item
      } catch (error) {
        commit('SET_MESSAGE', { type: 'error', text: '更新失败' })
        throw error
      }
    },
    
    // 从工作台移除
    async removeFromWorkspace({ commit }, id) {
      try {
        await api.removeFromWorkspace(id)
        commit('REMOVE_FROM_WORKSPACE', id)
        commit('SET_MESSAGE', { type: 'success', text: '移除成功' })
      } catch (error) {
        commit('SET_MESSAGE', { type: 'error', text: '移除失败' })
        throw error
      }
    },
    
    // 重新排序工作台
    async reorderWorkspace({ commit }, items) {
      try {
        await api.reorderWorkspace(items)
      } catch (error) {
        console.error('排序失败:', error)
      }
    },
    
    // 创建文件夹
    async createFolder({ commit }, data) {
      try {
        const folder = await api.createFolder(data)
        commit('ADD_FOLDER', folder)
        commit('SET_MESSAGE', { type: 'success', text: '文件夹创建成功' })
        return folder
      } catch (error) {
        commit('SET_MESSAGE', { type: 'error', text: '创建失败' })
        throw error
      }
    },
    
    // 更新文件夹
    async updateFolder({ commit }, { id, data }) {
      try {
        const folder = await api.updateFolder(id, data)
        commit('UPDATE_FOLDER', folder)
        return folder
      } catch (error) {
        commit('SET_MESSAGE', { type: 'error', text: '更新失败' })
        throw error
      }
    },
    
    // 删除文件夹
    async deleteFolder({ commit }, id) {
      try {
        await api.deleteFolder(id)
        commit('REMOVE_FOLDER', id)
        commit('SET_MESSAGE', { type: 'success', text: '文件夹已删除' })
      } catch (error) {
        commit('SET_MESSAGE', { type: 'error', text: '删除失败' })
        throw error
      }
    },
    
    // 搜索
    async search({ commit }, keyword) {
      if (!keyword.trim()) {
        commit('SET_SEARCH_RESULTS', [])
        return
      }
      
      commit('SET_LOADING', true)
      try {
        const results = await api.search(keyword)
        commit('SET_SEARCH_RESULTS', results)
        commit('SET_SEARCH_KEYWORD', keyword)
      } catch (error) {
        console.error('搜索失败:', error)
      } finally {
        commit('SET_LOADING', false)
      }
    },
    
    // 获取搜索建议
    async fetchSearchSuggestions({ commit }, keyword) {
      try {
        const data = await api.getSearchSuggestions(keyword)
        commit('SET_SEARCH_SUGGESTIONS', {
          suggestions: data.suggestions,
          hotKeywords: data.hot_keywords
        })
      } catch (error) {
        console.error('获取搜索建议失败:', error)
      }
    },
    
    // 网站点击
    async clickWebsite(_, id) {
      try {
        await api.clickWebsite(id)
      } catch (error) {
        console.error('记录点击失败:', error)
      }
    },
    
    // 获取随机语录
    async fetchRandomQuote({ commit }) {
      try {
        const quote = await api.getRandomQuote()
        commit('SET_QUOTE', quote)
      } catch (error) {
        console.error('获取语录失败:', error)
      }
    }
  }
})
