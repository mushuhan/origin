<script setup>
import { ref, reactive, watch } from 'vue'

const props = defineProps({
  visible: {
    type: Boolean,
    default: false
  },
  editItem: {
    type: Object,
    default: null
  }
})

const emit = defineEmits(['update:visible', 'confirm'])

const dialogVisible = ref(false)
const formRef = ref(null)

const form = reactive({
  custom_name: '',
  custom_url: '',
  custom_icon: '',
  custom_description: ''
})

const rules = {
  custom_name: [
    { required: true, message: '请输入网站名称', trigger: 'blur' }
  ],
  custom_url: [
    { required: true, message: '请输入网站URL', trigger: 'blur' },
    { 
      pattern: /^(https?:\/\/)?([\da-z.-]+)\.([a-z.]{2,6})([/\w .-]*)*\/?$/,
      message: '请输入有效的URL',
      trigger: 'blur'
    }
  ]
}

watch(() => props.visible, (val) => {
  dialogVisible.value = val
  if (val && props.editItem) {
    form.custom_name = props.editItem.name || ''
    form.custom_url = props.editItem.url || ''
    form.custom_icon = props.editItem.icon || ''
    form.custom_description = props.editItem.description || ''
  } else if (val) {
    resetForm()
  }
})

watch(dialogVisible, (val) => {
  emit('update:visible', val)
})

const resetForm = () => {
  form.custom_name = ''
  form.custom_url = ''
  form.custom_icon = ''
  form.custom_description = ''
  formRef.value?.resetFields()
}

const handleConfirm = async () => {
  if (!formRef.value) return
  
  await formRef.value.validate((valid) => {
    if (valid) {
      // 格式化URL
      let url = form.custom_url.trim()
      if (!url.startsWith('http://') && !url.startsWith('https://')) {
        url = 'https://' + url
      }
      
      emit('confirm', {
        ...form,
        custom_url: url,
        id: props.editItem?.id
      })
      dialogVisible.value = false
      resetForm()
    }
  })
}

const handleClose = () => {
  dialogVisible.value = false
  resetForm()
}

// 自动获取图标
const autoFetchIcon = () => {
  if (form.custom_url) {
    let url = form.custom_url.trim()
    if (!url.startsWith('http://') && !url.startsWith('https://')) {
      url = 'https://' + url
    }
    form.custom_icon = `https://www.google.com/s2/favicons?domain=${url}&sz=64`
  }
}
</script>

<template>
  <el-dialog 
    v-model="dialogVisible"
    :title="editItem ? '编辑网址' : '添加自定义网址'"
    width="480px"
    :close-on-click-modal="false"
    @close="handleClose"
  >
    <el-form 
      ref="formRef"
      :model="form"
      :rules="rules"
      label-position="top"
      class="add-website-form"
    >
      <el-form-item label="网站名称" prop="custom_name">
        <el-input 
          v-model="form.custom_name"
          placeholder="请输入网站名称"
          maxlength="50"
          show-word-limit
        />
      </el-form-item>

      <el-form-item label="网站URL" prop="custom_url">
        <el-input 
          v-model="form.custom_url"
          placeholder="请输入网站URL，如: www.example.com"
          @blur="autoFetchIcon"
        >
          <template #prefix>
            <el-icon><Link /></el-icon>
          </template>
        </el-input>
      </el-form-item>

      <el-form-item label="图标URL（可选）" prop="custom_icon">
        <div class="flex items-center gap-3">
          <el-input 
            v-model="form.custom_icon"
            placeholder="留空将自动获取网站图标"
            class="flex-1"
          />
          <div 
            v-if="form.custom_icon || form.custom_url" 
            class="icon-preview w-10 h-10 rounded-lg flex items-center justify-center overflow-hidden bg-gray-100 dark:bg-gray-800"
          >
            <img 
              :src="form.custom_icon || `https://www.google.com/s2/favicons?domain=${form.custom_url}&sz=64`"
              class="w-6 h-6"
              @error="$event.target.style.display='none'"
            />
          </div>
        </div>
      </el-form-item>

      <el-form-item label="描述（可选）" prop="custom_description">
        <el-input 
          v-model="form.custom_description"
          type="textarea"
          placeholder="请输入网站描述"
          :rows="3"
          maxlength="200"
          show-word-limit
        />
      </el-form-item>
    </el-form>

    <template #footer>
      <div class="flex justify-end gap-3">
        <el-button @click="handleClose">取消</el-button>
        <el-button type="primary" @click="handleConfirm">
          {{ editItem ? '保存' : '添加' }}
        </el-button>
      </div>
    </template>
  </el-dialog>
</template>

<style lang="scss" scoped>
.add-website-form {
  :deep(.el-form-item__label) {
    font-weight: 500;
  }
}

.icon-preview {
  flex-shrink: 0;
}
</style>

