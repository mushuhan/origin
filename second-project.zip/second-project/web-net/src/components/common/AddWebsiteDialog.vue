<script setup>
import { ref, computed, watch } from 'vue'
import { search } from '@/api'
import { debounce } from '@/utils/helpers'

const props = defineProps({
  visible: {
    type: Boolean,
    default: false
  },
  folderId: {
    type: [Number, String],
    default: null
  }
})

const emit = defineEmits(['update:visible', 'submit'])

// 标签页
const activeTab = ref('library') // 'library' | 'custom'

// 公共库搜索
const searchKeyword = ref('')
const searchResults = ref([])
const searchLoading = ref(false)

// 自定义表单
const customForm = ref({
  name: '',
  url: '',
  description: ''
})

// 关闭对话框
const close = () => {
  emit('update:visible', false)
  resetForm()
}

// 重置表单
const resetForm = () => {
  searchKeyword.value = ''
  searchResults.value = []
  customForm.value = {
    name: '',
    url: '',
    description: ''
  }
}

// 搜索公共库
const handleSearch = debounce(async (keyword) => {
  if (!keyword.trim()) {
    searchResults.value = []
    return
  }
  
  searchLoading.value = true
  try {
    searchResults.value = await search(keyword, 20)
  } catch (e) {
    searchResults.value = []
  } finally {
    searchLoading.value = false
  }
}, 300)

// 监听搜索关键词
watch(searchKeyword, (value) => {
  handleSearch(value)
})

// 从公共库添加
const addFromLibrary = (website) => {
  emit('submit', { website_id: website.id })
}

// 添加自定义网址
const addCustom = () => {
  if (!customForm.value.name.trim() || !customForm.value.url.trim()) {
    return
  }
  
  // 确保URL有协议
  let url = customForm.value.url.trim()
  if (!url.startsWith('http://') && !url.startsWith('https://')) {
    url = 'https://' + url
  }
  
  emit('submit', {
    custom_name: customForm.value.name.trim(),
    custom_url: url,
    custom_description: customForm.value.description.trim()
  })
}

// 表单验证
const isCustomFormValid = computed(() => {
  return customForm.value.name.trim() && customForm.value.url.trim()
})
</script>

<template>
  <el-dialog
    :model-value="visible"
    title="添加网址"
    width="560px"
    :close-on-click-modal="false"
    @close="close"
  >
    <!-- 标签页 -->
    <div class="tabs">
      <button
        class="tab"
        :class="{ active: activeTab === 'library' }"
        @click="activeTab = 'library'"
      >
        从公共库添加
      </button>
      <button
        class="tab"
        :class="{ active: activeTab === 'custom' }"
        @click="activeTab = 'custom'"
      >
        自定义网址
      </button>
    </div>
    
    <!-- 公共库搜索 -->
    <div v-if="activeTab === 'library'" class="library-panel">
      <div class="search-box">
        <el-icon class="search-icon"><Search /></el-icon>
        <input
          v-model="searchKeyword"
          type="text"
          placeholder="搜索网站名称、URL..."
          class="search-input"
        />
      </div>
      
      <!-- 搜索结果 -->
      <div class="results-list">
        <div v-if="searchLoading" class="loading-state">
          <div class="loading-spinner"></div>
          <span>搜索中...</span>
        </div>
        
        <div v-else-if="searchResults.length > 0" class="results">
          <div
            v-for="item in searchResults"
            :key="item.id"
            class="result-item"
            @click="addFromLibrary(item)"
          >
            <div class="item-icon">{{ item.name?.charAt(0) }}</div>
            <div class="item-info">
              <span class="item-name">{{ item.name }}</span>
              <span class="item-desc">{{ item.description }}</span>
            </div>
            <el-icon class="add-icon"><Plus /></el-icon>
          </div>
        </div>
        
        <div v-else-if="searchKeyword" class="empty-state">
          <p>未找到相关网站</p>
          <button class="switch-btn" @click="activeTab = 'custom'">
            手动添加网址
          </button>
        </div>
        
        <div v-else class="hint-state">
          <el-icon :size="40"><Search /></el-icon>
          <p>输入关键词搜索公共网址库</p>
        </div>
      </div>
    </div>
    
    <!-- 自定义表单 -->
    <div v-else class="custom-panel">
      <div class="form-group">
        <label>网站名称 <span class="required">*</span></label>
        <input
          v-model="customForm.name"
          type="text"
          placeholder="例如：我的博客"
          class="form-input"
        />
      </div>
      
      <div class="form-group">
        <label>网址 <span class="required">*</span></label>
        <input
          v-model="customForm.url"
          type="text"
          placeholder="例如：https://example.com"
          class="form-input"
        />
      </div>
      
      <div class="form-group">
        <label>描述 <span class="optional">(可选)</span></label>
        <textarea
          v-model="customForm.description"
          placeholder="简短描述这个网站..."
          class="form-input form-textarea"
          rows="3"
        ></textarea>
      </div>
      
      <button
        class="submit-btn"
        :disabled="!isCustomFormValid"
        @click="addCustom"
      >
        添加到工作台
      </button>
    </div>
  </el-dialog>
</template>

<style lang="scss" scoped>
.tabs {
  display: flex;
  gap: 0.5rem;
  margin-bottom: 1.5rem;
  padding: 4px;
  background: var(--bg-tertiary);
  border-radius: 10px;
}

.tab {
  flex: 1;
  padding: 0.625rem 1rem;
  font-size: 0.875rem;
  font-weight: 500;
  color: var(--text-secondary);
  border-radius: 8px;
  transition: all 0.2s ease;
  
  &:hover {
    color: var(--text-primary);
  }
  
  &.active {
    background: var(--card-bg);
    color: var(--text-primary);
    box-shadow: var(--shadow-sm);
  }
}

// 公共库面板
.library-panel {
  min-height: 300px;
}

.search-box {
  position: relative;
  margin-bottom: 1rem;
  
  .search-icon {
    position: absolute;
    left: 1rem;
    top: 50%;
    transform: translateY(-50%);
    color: var(--text-tertiary);
  }
  
  .search-input {
    width: 100%;
    padding: 0.75rem 1rem 0.75rem 2.75rem;
    background: var(--bg-tertiary);
    border: 1px solid var(--border-primary);
    border-radius: 10px;
    font-size: 0.875rem;
    color: var(--text-primary);
    
    &:focus {
      border-color: var(--accent);
    }
    
    &::placeholder {
      color: var(--text-tertiary);
    }
  }
}

.results-list {
  max-height: 280px;
  overflow-y: auto;
}

.result-item {
  display: flex;
  align-items: center;
  gap: 0.75rem;
  padding: 0.75rem;
  border-radius: 10px;
  cursor: pointer;
  transition: background 0.15s ease;
  
  &:hover {
    background: var(--bg-tertiary);
    
    .add-icon {
      opacity: 1;
    }
  }
  
  .item-icon {
    width: 40px;
    height: 40px;
    border-radius: 10px;
    background: var(--accent);
    color: white;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1rem;
    font-weight: 600;
    flex-shrink: 0;
  }
  
  .item-info {
    flex: 1;
    min-width: 0;
    
    .item-name {
      display: block;
      font-size: 0.875rem;
      font-weight: 500;
      color: var(--text-primary);
      margin-bottom: 2px;
    }
    
    .item-desc {
      display: block;
      font-size: 0.75rem;
      color: var(--text-tertiary);
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
  }
  
  .add-icon {
    color: var(--accent);
    opacity: 0;
    transition: opacity 0.15s ease;
  }
}

.loading-state,
.empty-state,
.hint-state {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 3rem;
  color: var(--text-tertiary);
  text-align: center;
  
  .loading-spinner {
    width: 24px;
    height: 24px;
    border: 2px solid var(--border-primary);
    border-top-color: var(--accent);
    border-radius: 50%;
    animation: spin 0.8s linear infinite;
    margin-bottom: 0.5rem;
  }
  
  .el-icon {
    margin-bottom: 0.75rem;
    opacity: 0.5;
  }
  
  p {
    font-size: 0.875rem;
  }
}

.switch-btn {
  margin-top: 0.75rem;
  padding: 0.5rem 1rem;
  font-size: 0.8125rem;
  color: var(--accent);
  background: var(--accent-light);
  border-radius: 8px;
  
  &:hover {
    background: var(--accent);
    color: white;
  }
}

@keyframes spin {
  to {
    transform: rotate(360deg);
  }
}

// 自定义表单
.custom-panel {
  .form-group {
    margin-bottom: 1.25rem;
    
    label {
      display: block;
      font-size: 0.8125rem;
      font-weight: 500;
      color: var(--text-primary);
      margin-bottom: 0.5rem;
      
      .required {
        color: #EF4444;
      }
      
      .optional {
        font-weight: 400;
        color: var(--text-tertiary);
      }
    }
  }
  
  .form-input {
    width: 100%;
    padding: 0.75rem 1rem;
    background: var(--bg-tertiary);
    border: 1px solid var(--border-primary);
    border-radius: 10px;
    font-size: 0.875rem;
    color: var(--text-primary);
    transition: border-color 0.2s ease;
    
    &:focus {
      border-color: var(--accent);
    }
    
    &::placeholder {
      color: var(--text-tertiary);
    }
  }
  
  .form-textarea {
    resize: vertical;
    min-height: 80px;
  }
  
  .submit-btn {
    width: 100%;
    padding: 0.875rem 1.5rem;
    font-size: 0.9375rem;
    font-weight: 600;
    color: white;
    background: var(--text-primary);
    border-radius: 10px;
    transition: all 0.2s ease;
    
    &:hover:not(:disabled) {
      opacity: 0.9;
    }
    
    &:disabled {
      opacity: 0.5;
      cursor: not-allowed;
    }
  }
}
</style>
