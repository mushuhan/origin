<script setup>
import { ref } from 'vue'
import { useStore } from 'vuex'
import { gsap } from 'gsap'

const props = defineProps({
  website: {
    type: Object,
    required: true
  },
  showActions: {
    type: Boolean,
    default: true
  },
  size: {
    type: String,
    default: 'normal' // normal, large, small
  }
})

const emit = defineEmits(['click', 'add-to-workspace'])

const store = useStore()
const cardRef = ref(null)
const isHovered = ref(false)

// 点击网站
const handleClick = () => {
  window.open(props.website.url, '_blank')
  store.dispatch('clickWebsite', props.website.id)
  emit('click', props.website)
}

// 添加到工作台
const addToWorkspace = (e) => {
  e.stopPropagation()
  store.dispatch('addToWorkspace', { website_id: props.website.id })
  emit('add-to-workspace', props.website)
}

// 复制链接
const copyLink = async (e) => {
  e.stopPropagation()
  try {
    await navigator.clipboard.writeText(props.website.url)
    store.commit('SET_MESSAGE', { type: 'success', text: '链接已复制' })
  } catch (err) {
    store.commit('SET_MESSAGE', { type: 'error', text: '复制失败' })
  }
}

// 鼠标进入动画
const onMouseEnter = () => {
  isHovered.value = true
  gsap.to(cardRef.value, {
    scale: 1.05,
    y: -4,
    duration: 0.3,
    ease: 'power2.out'
  })
}

// 鼠标离开动画
const onMouseLeave = () => {
  isHovered.value = false
  gsap.to(cardRef.value, {
    scale: 1,
    y: 0,
    duration: 0.3,
    ease: 'power2.out'
  })
}

// 图标加载失败
const onIconError = (e) => {
  e.target.src = `https://www.google.com/s2/favicons?domain=${props.website.url}&sz=64`
}
</script>

<template>
  <div 
    ref="cardRef"
    class="website-card relative rounded-2xl cursor-pointer transition-shadow"
    :class="[
      `size-${size}`,
      isHovered ? 'shadow-card-hover' : 'shadow-card'
    ]"
    @click="handleClick"
    @mouseenter="onMouseEnter"
    @mouseleave="onMouseLeave"
    @contextmenu.prevent
  >
    <div class="card-content p-4 flex flex-col items-center text-center">
      <!-- 图标 -->
      <div 
        class="icon-wrapper mb-3 rounded-2xl flex items-center justify-center overflow-hidden"
        :class="size === 'large' ? 'w-16 h-16' : size === 'small' ? 'w-10 h-10' : 'w-14 h-14'"
      >
        <img 
          :src="website.icon || `https://www.google.com/s2/favicons?domain=${website.url}&sz=64`"
          :alt="website.name"
          class="w-full h-full object-contain"
          @error="onIconError"
        />
      </div>
      
      <!-- 名称 -->
      <h4 
        class="font-medium truncate w-full"
        :class="size === 'large' ? 'text-base' : size === 'small' ? 'text-xs' : 'text-sm'"
      >
        {{ website.name }}
      </h4>
      
      <!-- 描述（悬浮时显示） -->
      <transition name="fade">
        <p 
          v-if="isHovered && website.description" 
          class="description text-xs text-gray-400 mt-1 line-clamp-2"
        >
          {{ website.description }}
        </p>
      </transition>
    </div>

    <!-- 操作按钮（悬浮时显示） -->
    <transition name="fade">
      <div 
        v-if="isHovered && showActions" 
        class="actions absolute top-2 right-2 flex gap-1"
      >
        <el-tooltip content="添加到工作台" placement="top">
          <button 
            class="action-btn w-7 h-7 rounded-lg flex items-center justify-center transition-colors"
            @click="addToWorkspace"
          >
            <el-icon :size="14">
              <Plus />
            </el-icon>
          </button>
        </el-tooltip>
        <el-tooltip content="复制链接" placement="top">
          <button 
            class="action-btn w-7 h-7 rounded-lg flex items-center justify-center transition-colors"
            @click="copyLink"
          >
            <el-icon :size="14">
              <CopyDocument />
            </el-icon>
          </button>
        </el-tooltip>
      </div>
    </transition>

    <!-- 热门标签 -->
    <div 
      v-if="website.is_hot" 
      class="hot-badge absolute -top-1 -right-1 w-5 h-5 rounded-full bg-gradient-to-br from-orange-400 to-red-500 flex items-center justify-center"
    >
      <el-icon :size="12" class="text-white">
        <Star />
      </el-icon>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.website-card {
  background: white;
  min-width: 100px;
  
  &.size-large {
    min-width: 140px;
    
    .card-content {
      padding: 20px;
    }
  }
  
  &.size-small {
    min-width: 80px;
    
    .card-content {
      padding: 12px;
    }
  }
}

.dark .website-card {
  background: #1e293b;
  border: 1px solid rgba(255, 255, 255, 0.05);
}

.icon-wrapper {
  background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
  padding: 8px;
}

.dark .icon-wrapper {
  background: linear-gradient(135deg, #334155 0%, #1e293b 100%);
}

.action-btn {
  background: rgba(255, 255, 255, 0.9);
  color: #64748b;
  backdrop-filter: blur(4px);
  
  &:hover {
    background: white;
    color: #0ea5e9;
  }
}

.dark .action-btn {
  background: rgba(30, 41, 59, 0.9);
  color: #94a3b8;
  
  &:hover {
    background: #334155;
    color: #38bdf8;
  }
}

.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.2s ease;
}

.fade-enter-from,
.fade-leave-to {
  opacity: 0;
}
</style>

