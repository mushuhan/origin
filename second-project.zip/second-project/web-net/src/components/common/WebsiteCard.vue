<script setup>
import { ref, computed } from 'vue'
import { useStore } from 'vuex'
import { clickWebsite } from '@/api'

const props = defineProps({
  website: {
    type: Object,
    required: true
  },
  size: {
    type: String,
    default: 'normal', // 'small' | 'normal' | 'large'
    validator: (v) => ['small', 'normal', 'large'].includes(v)
  },
  showTooltip: {
    type: Boolean,
    default: true
  }
})

const emit = defineEmits(['click', 'addToWorkspace'])

const store = useStore()
const isHovering = ref(false)
const tooltipVisible = ref(false)
let tooltipTimer = null

// 网站名称（优先使用自定义名称）
const displayName = computed(() => {
  return props.website.custom_name || props.website.name
})

// 网站描述
const displayDescription = computed(() => {
  return props.website.custom_description || props.website.description
})

// 首字母（用于无图标时显示）
const initial = computed(() => {
  const name = displayName.value || ''
  return name.charAt(0).toUpperCase()
})

// 随机颜色（基于名称生成一致的颜色）
const bgColor = computed(() => {
  const name = displayName.value || ''
  const colors = [
    '#3B82F6', '#10B981', '#F59E0B', '#EF4444', 
    '#8B5CF6', '#EC4899', '#06B6D4', '#84CC16'
  ]
  let hash = 0
  for (let i = 0; i < name.length; i++) {
    hash = name.charCodeAt(i) + ((hash << 5) - hash)
  }
  return colors[Math.abs(hash) % colors.length]
})

// 鼠标进入
const handleMouseEnter = () => {
  isHovering.value = true
  if (props.showTooltip && displayDescription.value) {
    tooltipTimer = setTimeout(() => {
      tooltipVisible.value = true
    }, 300)
  }
}

// 鼠标离开
const handleMouseLeave = () => {
  isHovering.value = false
  tooltipVisible.value = false
  if (tooltipTimer) {
    clearTimeout(tooltipTimer)
  }
}

// 点击卡片
const handleClick = async () => {
  emit('click', props.website)
  
  // 记录点击
  try {
    await clickWebsite(props.website.id)
    store.dispatch('clickWebsite', props.website.id)
  } catch (e) {
    // 忽略错误
  }
  
  // 跳转
  window.open(props.website.url || props.website.custom_url, '_blank')
}

// 添加到工作台
const handleAddToWorkspace = (e) => {
  e.stopPropagation()
  emit('addToWorkspace', props.website)
}
</script>

<template>
  <div 
    class="website-card"
    :class="[`size-${size}`, { 'is-hovering': isHovering }]"
    @mouseenter="handleMouseEnter"
    @mouseleave="handleMouseLeave"
    @click="handleClick"
  >
    <!-- 卡片内容 -->
    <div class="card-inner">
      <!-- 纯文本设计 - 不使用图标 -->
      <div class="card-initial" :style="{ backgroundColor: bgColor }">
        {{ initial }}
      </div>
      
      <!-- 网站名称 -->
      <span class="card-name">{{ displayName }}</span>
    </div>
    
    <!-- Tooltip -->
    <transition name="tooltip">
      <div 
        v-if="tooltipVisible && displayDescription" 
        class="card-tooltip"
      >
        <p>{{ displayDescription }}</p>
        <div class="tooltip-arrow"></div>
      </div>
    </transition>
    
    <!-- 快捷操作 -->
    <transition name="fade">
      <div v-if="isHovering" class="card-actions">
        <button 
          class="action-btn"
          title="添加到工作台"
          @click="handleAddToWorkspace"
        >
          <el-icon><Plus /></el-icon>
        </button>
      </div>
    </transition>
  </div>
</template>

<style lang="scss" scoped>
.website-card {
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 1rem 0.75rem;
  background: var(--card-bg);
  border-radius: 12px;
  border: 1px solid transparent;
  cursor: pointer;
  transition: all 0.2s ease;
  
  &:hover {
    background: var(--card-hover-bg);
    border-color: var(--border-primary);
    transform: translateY(-2px);
    box-shadow: var(--shadow-md);
  }
  
  &.is-hovering {
    z-index: 10;
  }
}

.card-inner {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 0.625rem;
  width: 100%;
}

.card-initial {
  width: 44px;
  height: 44px;
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 1.125rem;
  font-weight: 700;
  color: white;
  flex-shrink: 0;
  transition: transform 0.2s ease;
  
  .website-card:hover & {
    transform: scale(1.05);
  }
}

.card-name {
  font-size: 0.8125rem;
  font-weight: 600;
  color: var(--text-primary);
  text-align: center;
  line-height: 1.3;
  max-width: 100%;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

// 尺寸变体
.size-small {
  padding: 0.75rem 0.5rem;
  
  .card-initial {
    width: 36px;
    height: 36px;
    font-size: 0.875rem;
    border-radius: 10px;
  }
  
  .card-name {
    font-size: 0.75rem;
  }
}

.size-large {
  padding: 1.25rem 1rem;
  
  .card-initial {
    width: 56px;
    height: 56px;
    font-size: 1.375rem;
    border-radius: 14px;
  }
  
  .card-name {
    font-size: 0.875rem;
  }
}

// Tooltip
.card-tooltip {
  position: absolute;
  bottom: calc(100% + 8px);
  left: 50%;
  transform: translateX(-50%);
  padding: 0.625rem 0.875rem;
  background: var(--text-primary);
  color: var(--text-inverse);
  border-radius: 8px;
  font-size: 0.75rem;
  line-height: 1.5;
  max-width: 200px;
  text-align: center;
  box-shadow: var(--shadow-lg);
  z-index: 100;
  
  p {
    margin: 0;
  }
  
  .tooltip-arrow {
    position: absolute;
    bottom: -6px;
    left: 50%;
    transform: translateX(-50%);
    width: 0;
    height: 0;
    border-left: 6px solid transparent;
    border-right: 6px solid transparent;
    border-top: 6px solid var(--text-primary);
  }
}

.tooltip-enter-active,
.tooltip-leave-active {
  transition: all 0.2s ease;
}

.tooltip-enter-from,
.tooltip-leave-to {
  opacity: 0;
  transform: translateX(-50%) translateY(4px);
}

// 快捷操作
.card-actions {
  position: absolute;
  top: 4px;
  right: 4px;
}

.action-btn {
  width: 24px;
  height: 24px;
  border-radius: 6px;
  background: var(--bg-secondary);
  border: 1px solid var(--border-primary);
  color: var(--text-secondary);
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.15s ease;
  
  &:hover {
    background: var(--accent);
    border-color: var(--accent);
    color: white;
  }
  
  .el-icon {
    font-size: 14px;
  }
}

.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.15s ease;
}

.fade-enter-from,
.fade-leave-to {
  opacity: 0;
}
</style>
