<script setup>
import { ref, computed, watch } from 'vue'
import { useStore } from 'vuex'
import { useRouter } from 'vue-router'
import { gsap } from 'gsap'

const store = useStore()
const router = useRouter()

const searchInput = ref('')
const isFocused = ref(false)
const showDropdown = ref(false)
const dropdownRef = ref(null)

const suggestions = computed(() => store.state.searchSuggestions)
const hotKeywords = computed(() => store.state.hotKeywords)

// 监听输入变化
watch(searchInput, (value) => {
  if (value.trim()) {
    store.dispatch('fetchSearchSuggestions', value)
    showDropdown.value = true
  } else {
    showDropdown.value = isFocused.value
  }
})

// 获取焦点
const onFocus = () => {
  isFocused.value = true
  showDropdown.value = true
  store.dispatch('fetchSearchSuggestions', searchInput.value)
  
  if (dropdownRef.value) {
    gsap.fromTo(dropdownRef.value, 
      { opacity: 0, y: -10 },
      { opacity: 1, y: 0, duration: 0.2, ease: 'power2.out' }
    )
  }
}

// 失去焦点
const onBlur = () => {
  setTimeout(() => {
    isFocused.value = false
    showDropdown.value = false
  }, 200)
}

// 执行搜索
const doSearch = () => {
  const keyword = searchInput.value.trim()
  if (!keyword) return
  
  // 检查是否是URL
  if (isValidUrl(keyword)) {
    window.open(formatUrl(keyword), '_blank')
    return
  }
  
  // 跳转到搜索结果页
  router.push({ path: '/search', query: { q: keyword } })
  showDropdown.value = false
}

// 选择建议
const selectSuggestion = (item) => {
  if (item.type === 'website') {
    window.open(item.url, '_blank')
    store.dispatch('clickWebsite', item.id)
  } else if (item.type === 'keyword') {
    searchInput.value = item.keyword
    doSearch()
  }
  showDropdown.value = false
}

// 验证URL
const isValidUrl = (string) => {
  try {
    new URL(formatUrl(string))
    return string.includes('.') && !string.includes(' ')
  } catch (_) {
    return false
  }
}

// 格式化URL
const formatUrl = (url) => {
  if (!url.startsWith('http://') && !url.startsWith('https://')) {
    return 'https://' + url
  }
  return url
}

// 使用搜索引擎搜索
const searchWithEngine = (engine) => {
  const keyword = searchInput.value.trim()
  if (!keyword) return
  
  const engines = {
    baidu: `https://www.baidu.com/s?wd=${encodeURIComponent(keyword)}`,
    google: `https://www.google.com/search?q=${encodeURIComponent(keyword)}`,
    bing: `https://www.bing.com/search?q=${encodeURIComponent(keyword)}`
  }
  
  window.open(engines[engine], '_blank')
  showDropdown.value = false
}
</script>

<template>
  <div class="search-box relative">
    <div 
      class="search-input-wrapper relative flex items-center h-11 px-4 rounded-2xl transition-all duration-300"
      :class="isFocused ? 'focused' : ''"
    >
      <el-icon :size="18" class="text-gray-400 mr-3">
        <Search />
      </el-icon>
      <input 
        v-model="searchInput"
        type="text"
        placeholder="搜索网址或输入URL直接访问..."
        class="flex-1 bg-transparent border-none outline-none text-sm"
        @focus="onFocus"
        @blur="onBlur"
        @keyup.enter="doSearch"
      />
      <button 
        v-if="searchInput"
        class="clear-btn w-6 h-6 rounded-full flex items-center justify-center hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors"
        @click="searchInput = ''"
      >
        <el-icon :size="14">
          <Close />
        </el-icon>
      </button>
    </div>

    <!-- 搜索下拉框 -->
    <transition name="slide-down">
      <div 
        v-show="showDropdown"
        ref="dropdownRef"
        class="search-dropdown absolute top-full left-0 right-0 mt-2 rounded-2xl overflow-hidden shadow-xl z-50"
      >
        <!-- 搜索建议 -->
        <div v-if="suggestions.length > 0" class="suggestions-section p-3">
          <h4 class="text-xs font-medium text-gray-400 mb-2 px-2">搜索建议</h4>
          <div 
            v-for="item in suggestions" 
            :key="item.id || item.keyword"
            class="suggestion-item flex items-center gap-3 px-3 py-2.5 rounded-xl cursor-pointer transition-all hover:bg-gray-100 dark:hover:bg-gray-800"
            @click="selectSuggestion(item)"
          >
            <div v-if="item.type === 'website'" class="w-8 h-8 rounded-lg bg-gray-100 dark:bg-gray-800 flex items-center justify-center overflow-hidden">
              <img 
                :src="item.icon || `https://www.google.com/s2/favicons?domain=${item.url}&sz=32`" 
                :alt="item.name"
                class="w-5 h-5"
                @error="$event.target.src = 'data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 24 24%22 fill=%22%2394a3b8%22><circle cx=%2212%22 cy=%2212%22 r=%2210%22/></svg>'"
              />
            </div>
            <el-icon v-else :size="18" class="text-gray-400">
              <Search />
            </el-icon>
            <div class="flex-1 min-w-0">
              <p class="text-sm font-medium truncate">{{ item.name || item.keyword }}</p>
              <p v-if="item.url" class="text-xs text-gray-400 truncate">{{ item.url }}</p>
            </div>
            <el-icon v-if="item.type === 'website'" :size="14" class="text-gray-400">
              <TopRight />
            </el-icon>
          </div>
        </div>

        <!-- 热门搜索 -->
        <div v-if="hotKeywords.length > 0" class="hot-section p-3 border-t border-gray-100 dark:border-gray-800">
          <h4 class="text-xs font-medium text-gray-400 mb-2 px-2">热门搜索</h4>
          <div class="flex flex-wrap gap-2 px-2">
            <span 
              v-for="(item, index) in hotKeywords.slice(0, 8)" 
              :key="item.keyword"
              class="hot-tag px-3 py-1.5 rounded-full text-xs cursor-pointer transition-all"
              :class="index < 3 ? 'hot' : ''"
              @click="selectSuggestion({ type: 'keyword', keyword: item.keyword })"
            >
              <span v-if="index < 3" class="rank mr-1">{{ index + 1 }}</span>
              {{ item.keyword }}
            </span>
          </div>
        </div>

        <!-- 搜索引擎 -->
        <div v-if="searchInput" class="engines-section p-3 border-t border-gray-100 dark:border-gray-800">
          <h4 class="text-xs font-medium text-gray-400 mb-2 px-2">使用搜索引擎搜索</h4>
          <div class="flex gap-2 px-2">
            <button 
              class="engine-btn flex items-center gap-2 px-3 py-2 rounded-lg text-xs transition-all hover:bg-gray-100 dark:hover:bg-gray-800"
              @click="searchWithEngine('baidu')"
            >
              <img src="https://www.baidu.com/favicon.ico" class="w-4 h-4" alt="百度" />
              百度
            </button>
            <button 
              class="engine-btn flex items-center gap-2 px-3 py-2 rounded-lg text-xs transition-all hover:bg-gray-100 dark:hover:bg-gray-800"
              @click="searchWithEngine('google')"
            >
              <img src="https://www.google.com/favicon.ico" class="w-4 h-4" alt="Google" />
              Google
            </button>
            <button 
              class="engine-btn flex items-center gap-2 px-3 py-2 rounded-lg text-xs transition-all hover:bg-gray-100 dark:hover:bg-gray-800"
              @click="searchWithEngine('bing')"
            >
              <img src="https://www.bing.com/favicon.ico" class="w-4 h-4" alt="Bing" />
              Bing
            </button>
          </div>
        </div>
      </div>
    </transition>
  </div>
</template>

<style lang="scss" scoped>
.search-input-wrapper {
  background: rgba(241, 245, 249, 0.8);
  border: 2px solid transparent;
  
  &.focused {
    background: white;
    border-color: #0ea5e9;
    box-shadow: 0 0 0 4px rgba(14, 165, 233, 0.1);
  }
  
  input {
    color: #1f2937;
    
    &::placeholder {
      color: #9ca3af;
    }
  }
}

.dark .search-input-wrapper {
  background: rgba(30, 41, 59, 0.8);
  
  &.focused {
    background: #1e293b;
    border-color: #38bdf8;
    box-shadow: 0 0 0 4px rgba(56, 189, 248, 0.1);
  }
  
  input {
    color: #f1f5f9;
    
    &::placeholder {
      color: #64748b;
    }
  }
}

.search-dropdown {
  background: white;
  border: 1px solid rgba(0, 0, 0, 0.05);
}

.dark .search-dropdown {
  background: #1e293b;
  border: 1px solid rgba(255, 255, 255, 0.05);
}

.hot-tag {
  background: #f1f5f9;
  color: #64748b;
  
  &:hover {
    background: #e2e8f0;
    color: #374151;
  }
  
  &.hot {
    background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%);
    color: #92400e;
    
    .rank {
      color: #dc2626;
      font-weight: 600;
    }
  }
}

.dark .hot-tag {
  background: #334155;
  color: #94a3b8;
  
  &:hover {
    background: #475569;
    color: #e2e8f0;
  }
  
  &.hot {
    background: linear-gradient(135deg, #78350f 0%, #92400e 100%);
    color: #fef3c7;
  }
}

.slide-down-enter-active,
.slide-down-leave-active {
  transition: all 0.2s ease;
}

.slide-down-enter-from,
.slide-down-leave-to {
  opacity: 0;
  transform: translateY(-10px);
}
</style>

