<script setup>
import { ref, onMounted, onUnmounted, computed } from 'vue'

const props = defineProps({
  quotes: {
    type: Array,
    default: () => []
  },
  interval: {
    type: Number,
    default: 10000 // 10秒切换
  },
  autoPlay: {
    type: Boolean,
    default: true
  }
})

const currentIndex = ref(0)
const isAnimating = ref(false)
let timer = null

const currentQuote = computed(() => {
  if (props.quotes.length === 0) return null
  return props.quotes[currentIndex.value]
})

const nextQuote = () => {
  if (props.quotes.length <= 1) return
  
  isAnimating.value = true
  
  setTimeout(() => {
    currentIndex.value = (currentIndex.value + 1) % props.quotes.length
    isAnimating.value = false
  }, 300)
}

const startAutoPlay = () => {
  if (props.autoPlay && props.quotes.length > 1) {
    timer = setInterval(nextQuote, props.interval)
  }
}

const stopAutoPlay = () => {
  if (timer) {
    clearInterval(timer)
    timer = null
  }
}

onMounted(() => {
  startAutoPlay()
})

onUnmounted(() => {
  stopAutoPlay()
})
</script>

<template>
  <div class="quote-ticker" v-if="currentQuote">
    <div class="quote-container" :class="{ 'is-animating': isAnimating }">
      <!-- 引号装饰 -->
      <span class="quote-mark quote-mark-left">"</span>
      
      <!-- 语录内容 -->
      <p class="quote-content">{{ currentQuote.content }}</p>
      
      <span class="quote-mark quote-mark-right">"</span>
      
      <!-- 作者 -->
      <span class="quote-author" v-if="currentQuote.author">
        —— {{ currentQuote.author }}
        <span class="quote-source" v-if="currentQuote.source">《{{ currentQuote.source }}》</span>
      </span>
    </div>
    
    <!-- 指示点 -->
    <div class="quote-dots" v-if="quotes.length > 1">
      <span 
        v-for="(_, index) in quotes" 
        :key="index"
        class="dot"
        :class="{ active: index === currentIndex }"
        @click="currentIndex = index"
      ></span>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.quote-ticker {
  position: relative;
  padding: 1.5rem 2rem;
  text-align: center;
  overflow: hidden;
}

.quote-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 0.5rem;
  transition: all 0.3s ease;
  
  &.is-animating {
    opacity: 0;
    transform: translateY(-10px);
  }
}

.quote-mark {
  font-family: Georgia, 'Times New Roman', serif;
  font-size: 2rem;
  line-height: 1;
  color: var(--text-tertiary);
  opacity: 0.3;
  
  &.quote-mark-left {
    align-self: flex-start;
    margin-left: 1rem;
  }
  
  &.quote-mark-right {
    align-self: flex-end;
    margin-right: 1rem;
  }
}

.quote-content {
  font-family: 'Noto Serif SC', 'Source Han Serif SC', Georgia, serif;
  font-size: 0.95rem;
  line-height: 1.8;
  color: var(--text-secondary);
  max-width: 600px;
  margin: 0 auto;
  letter-spacing: 0.5px;
}

.quote-author {
  font-size: 0.8rem;
  color: var(--text-tertiary);
  margin-top: 0.5rem;
  font-style: italic;
  
  .quote-source {
    opacity: 0.7;
  }
}

.quote-dots {
  display: flex;
  justify-content: center;
  gap: 6px;
  margin-top: 1rem;
  
  .dot {
    width: 4px;
    height: 4px;
    border-radius: 50%;
    background: var(--border-primary);
    cursor: pointer;
    transition: all 0.3s ease;
    
    &:hover {
      background: var(--text-tertiary);
    }
    
    &.active {
      width: 16px;
      border-radius: 2px;
      background: var(--text-secondary);
    }
  }
}

// 暗黑模式微调
.dark .quote-content {
  color: var(--text-tertiary);
}
</style>

