<script setup>
import { ref, onMounted } from 'vue'
import WebsiteCard from './WebsiteCard.vue'
import { gsap } from 'gsap'

const props = defineProps({
  section: {
    type: Object,
    required: true
  },
  showHeader: {
    type: Boolean,
    default: true
  },
  cardSize: {
    type: String,
    default: 'normal'
  }
})

const sectionRef = ref(null)
const websitesRef = ref(null)

onMounted(() => {
  // 入场动画
  if (websitesRef.value) {
    const cards = websitesRef.value.querySelectorAll('.website-card')
    gsap.from(cards, {
      opacity: 0,
      y: 20,
      duration: 0.4,
      stagger: 0.05,
      ease: 'power2.out',
      delay: 0.1
    })
  }
})
</script>

<template>
  <div ref="sectionRef" class="section-card mb-8">
    <!-- 分区标题 -->
    <div v-if="showHeader" class="section-header flex items-center justify-between mb-4">
      <div class="flex items-center gap-3">
        <div class="w-1 h-6 rounded-full bg-gradient-to-b from-sky-400 to-blue-600"></div>
        <h3 class="text-lg font-semibold">{{ section.name }}</h3>
        <span 
          v-if="section.description" 
          class="text-sm text-gray-400"
        >
          {{ section.description }}
        </span>
      </div>
      <span class="text-xs text-gray-400">{{ section.websites?.length || 0 }} 个网站</span>
    </div>

    <!-- 网站列表 -->
    <div 
      ref="websitesRef"
      class="websites-grid grid gap-4"
      :class="[
        cardSize === 'large' ? 'grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6' :
        cardSize === 'small' ? 'grid-cols-4 sm:grid-cols-5 md:grid-cols-6 lg:grid-cols-8 xl:grid-cols-10' :
        'grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 xl:grid-cols-8'
      ]"
    >
      <WebsiteCard 
        v-for="website in section.websites" 
        :key="website.id"
        :website="website"
        :size="cardSize"
      />
    </div>

    <!-- 空状态 -->
    <div 
      v-if="!section.websites || section.websites.length === 0" 
      class="empty-state py-12 text-center text-gray-400"
    >
      <el-icon :size="48" class="mb-3 opacity-50">
        <FolderOpened />
      </el-icon>
      <p>暂无网站</p>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.section-header {
  h3 {
    color: #1f2937;
  }
}

.dark .section-header {
  h3 {
    color: #f1f5f9;
  }
}

.websites-grid {
  @media (max-width: 640px) {
    grid-template-columns: repeat(3, 1fr);
  }
}
</style>

