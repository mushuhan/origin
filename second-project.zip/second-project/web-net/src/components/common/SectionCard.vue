<script setup>
import { ref, computed } from 'vue'
import WebsiteCard from './WebsiteCard.vue'

const props = defineProps({
  section: {
    type: Object,
    required: true
  },
  initialLimit: {
    type: Number,
    default: 12
  },
  columns: {
    type: Number,
    default: 6
  }
})

const emit = defineEmits(['addToWorkspace'])

const isExpanded = ref(false)

// 可见的网站列表
const visibleWebsites = computed(() => {
  if (!props.section.websites) return []
  if (isExpanded.value) return props.section.websites
  return props.section.websites.slice(0, props.initialLimit)
})

// 是否有更多
const hasMore = computed(() => {
  return props.section.websites && props.section.websites.length > props.initialLimit
})

// 剩余数量
const remainingCount = computed(() => {
  if (!props.section.websites) return 0
  return props.section.websites.length - props.initialLimit
})

// 切换展开
const toggleExpand = () => {
  isExpanded.value = !isExpanded.value
}

// 添加到工作台
const handleAddToWorkspace = (website) => {
  emit('addToWorkspace', website)
}
</script>

<template>
  <div class="section-card">
    <!-- 分区标题 -->
    <div class="section-header">
      <h3 class="section-name">{{ section.name }}</h3>
      <p v-if="section.description" class="section-desc">{{ section.description }}</p>
    </div>
    
    <!-- 网站网格 -->
    <div 
      class="websites-grid"
      :style="{ '--columns': columns }"
    >
      <WebsiteCard
        v-for="(website, index) in visibleWebsites"
        :key="website.id"
        :website="website"
        :style="{ 
          animationDelay: `${index * 0.03}s`,
          '--index': index
        }"
        class="animate-in"
        @addToWorkspace="handleAddToWorkspace"
      />
    </div>
    
    <!-- 展开/收起按钮 -->
    <div v-if="hasMore" class="expand-section">
      <button class="expand-btn" @click="toggleExpand">
        <span v-if="!isExpanded">
          展开更多 ({{ remainingCount }})
        </span>
        <span v-else>收起</span>
        <el-icon :class="{ 'is-expanded': isExpanded }">
          <ArrowDown />
        </el-icon>
      </button>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.section-card {
  margin-bottom: 1.5rem;
}

.section-header {
  margin-bottom: 1rem;
  
  .section-name {
    font-size: 1rem;
    font-weight: 600;
    color: var(--text-primary);
    margin-bottom: 0.25rem;
  }
  
  .section-desc {
    font-size: 0.8125rem;
    color: var(--text-tertiary);
  }
}

.websites-grid {
  display: grid;
  grid-template-columns: repeat(var(--columns), 1fr);
  gap: 0.75rem;
  
  @media (max-width: 1280px) {
    grid-template-columns: repeat(5, 1fr);
  }
  
  @media (max-width: 1024px) {
    grid-template-columns: repeat(4, 1fr);
  }
  
  @media (max-width: 768px) {
    grid-template-columns: repeat(3, 1fr);
  }
  
  @media (max-width: 480px) {
    grid-template-columns: repeat(2, 1fr);
  }
}

.animate-in {
  animation: slideUpFade 0.4s ease forwards;
  opacity: 0;
}

@keyframes slideUpFade {
  from {
    opacity: 0;
    transform: translateY(10px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.expand-section {
  margin-top: 1rem;
  text-align: center;
}

.expand-btn {
  display: inline-flex;
  align-items: center;
  gap: 0.375rem;
  padding: 0.5rem 1rem;
  font-size: 0.8125rem;
  color: var(--text-secondary);
  background: var(--bg-tertiary);
  border-radius: 8px;
  transition: all 0.2s ease;
  
  &:hover {
    background: var(--border-primary);
    color: var(--text-primary);
  }
  
  .el-icon {
    transition: transform 0.2s ease;
    
    &.is-expanded {
      transform: rotate(180deg);
    }
  }
}
</style>
