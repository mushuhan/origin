<script setup>
import { computed, onMounted, ref } from 'vue'
import { useStore } from 'vuex'
import AppHeader from './AppHeader.vue'
import AppSidebar from './AppSidebar.vue'
import AppFooter from './AppFooter.vue'
import { gsap } from 'gsap'

const store = useStore()
const sidebarCollapsed = computed(() => store.state.sidebarCollapsed)
const mainRef = ref(null)

onMounted(() => {
  // 入场动画
  gsap.from(mainRef.value, {
    opacity: 0,
    y: 20,
    duration: 0.6,
    ease: 'power3.out'
  })
})
</script>

<template>
  <div class="main-layout min-h-screen flex flex-col">
    <!-- 顶部栏 -->
    <AppHeader />
    
    <div class="flex flex-1 pt-16">
      <!-- 侧边栏 -->
      <AppSidebar />
      
      <!-- 主内容区 -->
      <main 
        ref="mainRef"
        class="main-content flex-1 transition-all duration-300"
        :class="sidebarCollapsed ? 'ml-[72px]' : 'ml-[240px]'"
      >
        <div class="content-wrapper min-h-full p-6">
          <slot />
        </div>
        
        <!-- 底部 -->
        <AppFooter />
      </main>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.main-layout {
  background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
  min-height: 100vh;
}

.dark .main-layout {
  background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%);
}

.content-wrapper {
  max-width: 1600px;
  margin: 0 auto;
}

@media (max-width: 768px) {
  .main-content {
    margin-left: 0 !important;
  }
  
  .content-wrapper {
    padding: 16px;
  }
}
</style>

