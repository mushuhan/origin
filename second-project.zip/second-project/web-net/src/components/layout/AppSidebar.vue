<script setup>
import { computed, ref, watch } from 'vue'
import { useStore } from 'vuex'
import { useRouter, useRoute } from 'vue-router'
import { gsap } from 'gsap'

const store = useStore()
const router = useRouter()
const route = useRoute()

const collapsed = computed(() => store.state.sidebarCollapsed)
const categories = computed(() => store.state.categories)

// 图标映射
const iconMap = {
  'Briefcase': 'Briefcase',
  'Tools': 'Tools',
  'Code': 'Monitor',
  'Palette': 'Brush',
  'BookOpen': 'Reading',
  'Film': 'VideoPlay',
  'Users': 'User',
  'Newspaper': 'Document',
  'ShoppingCart': 'ShoppingCart'
}

// 当前选中的分类
const activeCategory = ref(null)

watch(() => route.params.id, (newId) => {
  if (newId) {
    activeCategory.value = parseInt(newId)
  }
}, { immediate: true })

// 切换侧边栏
const toggleSidebar = () => {
  store.commit('TOGGLE_SIDEBAR')
}

// 导航到分类
const navigateToCategory = (category) => {
  activeCategory.value = category.id
  
  if (category.is_system) {
    router.push('/customize')
  } else {
    router.push(`/category/${category.id}`)
  }
}

// 导航到首页
const goHome = () => {
  activeCategory.value = null
  router.push('/')
}

// 鼠标悬停动画
const onMouseEnter = (event) => {
  gsap.to(event.currentTarget, {
    scale: 1.02,
    duration: 0.2,
    ease: 'power2.out'
  })
}

const onMouseLeave = (event) => {
  gsap.to(event.currentTarget, {
    scale: 1,
    duration: 0.2,
    ease: 'power2.out'
  })
}
</script>

<template>
  <aside 
    class="app-sidebar fixed left-0 top-16 bottom-0 z-40 transition-all duration-300 glass"
    :class="collapsed ? 'w-[72px]' : 'w-[240px]'"
  >
    <div class="sidebar-content h-full flex flex-col py-4">
      <!-- 收起/展开按钮 -->
      <button 
        class="collapse-btn mx-3 mb-4 h-10 rounded-xl flex items-center justify-center transition-all hover:bg-gray-100 dark:hover:bg-gray-800"
        @click="toggleSidebar"
      >
        <el-icon :size="20" class="transition-transform" :class="collapsed ? 'rotate-180' : ''">
          <Fold />
        </el-icon>
        <span v-if="!collapsed" class="ml-2 text-sm">收起菜单</span>
      </button>

      <!-- 首页链接 -->
      <div 
        class="nav-item mx-3 mb-2 h-12 rounded-xl flex items-center cursor-pointer transition-all"
        :class="[
          !activeCategory ? 'active' : '',
          collapsed ? 'justify-center px-0' : 'px-4'
        ]"
        @click="goHome"
        @mouseenter="onMouseEnter"
        @mouseleave="onMouseLeave"
      >
        <el-icon :size="22">
          <HomeFilled />
        </el-icon>
        <span v-if="!collapsed" class="ml-3 font-medium">首页</span>
      </div>

      <!-- 分割线 -->
      <div class="divider mx-4 my-3 h-px bg-gray-200 dark:bg-gray-700"></div>

      <!-- 分类列表 -->
      <div class="categories-list flex-1 overflow-y-auto">
        <div 
          v-for="category in categories" 
          :key="category.id"
          class="nav-item mx-3 mb-2 h-12 rounded-xl flex items-center cursor-pointer transition-all"
          :class="[
            activeCategory === category.id ? 'active' : '',
            collapsed ? 'justify-center px-0' : 'px-4'
          ]"
          @click="navigateToCategory(category)"
          @mouseenter="onMouseEnter"
          @mouseleave="onMouseLeave"
        >
          <el-tooltip 
            :content="category.name" 
            placement="right" 
            :disabled="!collapsed"
          >
            <el-icon :size="22">
              <component :is="iconMap[category.icon] || 'Folder'" />
            </el-icon>
          </el-tooltip>
          <span v-if="!collapsed" class="ml-3 font-medium truncate">{{ category.name }}</span>
          <span 
            v-if="!collapsed && category.is_system" 
            class="ml-auto text-xs px-2 py-0.5 rounded-full bg-sky-100 text-sky-600 dark:bg-sky-900 dark:text-sky-300"
          >
            自定义
          </span>
        </div>
      </div>

      <!-- 底部快捷链接 -->
      <div class="quick-links mt-4">
        <div class="divider mx-4 mb-3 h-px bg-gray-200 dark:bg-gray-700"></div>
        
        <div 
          class="nav-item mx-3 mb-2 h-10 rounded-xl flex items-center cursor-pointer transition-all"
          :class="collapsed ? 'justify-center px-0' : 'px-4'"
          @click="router.push('/hot')"
          @mouseenter="onMouseEnter"
          @mouseleave="onMouseLeave"
        >
          <el-icon :size="20" class="text-orange-500">
            <TrendCharts />
          </el-icon>
          <span v-if="!collapsed" class="ml-3 text-sm">热门网址</span>
        </div>
        
        <div 
          class="nav-item mx-3 h-10 rounded-xl flex items-center cursor-pointer transition-all"
          :class="collapsed ? 'justify-center px-0' : 'px-4'"
          @click="router.push('/about')"
          @mouseenter="onMouseEnter"
          @mouseleave="onMouseLeave"
        >
          <el-icon :size="20" class="text-gray-400">
            <InfoFilled />
          </el-icon>
          <span v-if="!collapsed" class="ml-3 text-sm">关于</span>
        </div>
      </div>
    </div>
  </aside>
</template>

<style lang="scss" scoped>
.app-sidebar {
  background: rgba(255, 255, 255, 0.7);
  backdrop-filter: blur(20px);
  -webkit-backdrop-filter: blur(20px);
  border-right: 1px solid rgba(0, 0, 0, 0.05);
}

.dark .app-sidebar {
  background: rgba(15, 23, 42, 0.7);
  border-right: 1px solid rgba(255, 255, 255, 0.05);
}

.nav-item {
  color: #64748b;
  
  &:hover {
    background: rgba(14, 165, 233, 0.1);
    color: #0ea5e9;
  }
  
  &.active {
    background: linear-gradient(135deg, rgba(14, 165, 233, 0.15) 0%, rgba(59, 130, 246, 0.15) 100%);
    color: #0ea5e9;
    
    &::before {
      content: '';
      position: absolute;
      left: 0;
      top: 50%;
      transform: translateY(-50%);
      width: 4px;
      height: 24px;
      background: linear-gradient(135deg, #0ea5e9 0%, #3b82f6 100%);
      border-radius: 0 4px 4px 0;
    }
  }
}

.dark .nav-item {
  color: #94a3b8;
  
  &:hover {
    background: rgba(56, 189, 248, 0.1);
    color: #38bdf8;
  }
  
  &.active {
    background: linear-gradient(135deg, rgba(56, 189, 248, 0.15) 0%, rgba(59, 130, 246, 0.15) 100%);
    color: #38bdf8;
  }
}

.collapse-btn {
  color: #64748b;
  
  &:hover {
    color: #0ea5e9;
  }
}

.dark .collapse-btn {
  color: #94a3b8;
  
  &:hover {
    color: #38bdf8;
  }
}

.categories-list {
  &::-webkit-scrollbar {
    width: 4px;
  }
  
  &::-webkit-scrollbar-thumb {
    background: rgba(0, 0, 0, 0.1);
    border-radius: 2px;
  }
}

@media (max-width: 768px) {
  .app-sidebar {
    transform: translateX(-100%);
    
    &.show {
      transform: translateX(0);
    }
  }
}
</style>

