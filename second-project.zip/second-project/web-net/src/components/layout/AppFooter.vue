<script setup>
import { computed } from 'vue'
import { useStore } from 'vuex'

const store = useStore()
const settings = computed(() => store.state.settings)

const currentYear = new Date().getFullYear()

const socialLinks = [
  { name: 'GitHub', icon: 'Link', url: 'https://github.com' },
  { name: 'Twitter', icon: 'ChatDotRound', url: 'https://twitter.com' },
  { name: '微博', icon: 'ChatLineRound', url: 'https://weibo.com' }
]

const quickLinks = [
  { name: '关于我们', path: '/about' },
  { name: '热门网址', path: '/hot' },
  { name: '使用帮助', path: '/about' }
]
</script>

<template>
  <footer class="app-footer mt-auto py-8 px-6">
    <div class="footer-content max-w-6xl mx-auto">
      <!-- 上部分 -->
      <div class="footer-top flex flex-wrap justify-between items-start gap-8 mb-8">
        <!-- 品牌信息 -->
        <div class="brand-info">
          <div class="flex items-center gap-3 mb-3">
            <div class="w-10 h-10 rounded-xl bg-gradient-to-br from-sky-400 to-blue-600 flex items-center justify-center">
              <el-icon :size="24" class="text-white">
                <Compass />
              </el-icon>
            </div>
            <span class="text-xl font-bold">{{ settings.site_name || 'NavHub' }}</span>
          </div>
          <p class="text-sm text-gray-500 dark:text-gray-400 max-w-xs">
            一站式网址导航，快速访问您常用的网站，提升工作效率。
          </p>
        </div>

        <!-- 快捷链接 -->
        <div class="quick-links">
          <h4 class="text-sm font-semibold mb-3 text-gray-700 dark:text-gray-300">快捷链接</h4>
          <ul class="space-y-2">
            <li v-for="link in quickLinks" :key="link.name">
              <router-link 
                :to="link.path" 
                class="text-sm text-gray-500 dark:text-gray-400 hover:text-sky-500 dark:hover:text-sky-400 transition-colors"
              >
                {{ link.name }}
              </router-link>
            </li>
          </ul>
        </div>

        <!-- 社交媒体 -->
        <div class="social-links">
          <h4 class="text-sm font-semibold mb-3 text-gray-700 dark:text-gray-300">关注我们</h4>
          <div class="flex gap-3">
            <a 
              v-for="social in socialLinks" 
              :key="social.name"
              :href="social.url"
              target="_blank"
              rel="noopener noreferrer"
              class="w-9 h-9 rounded-lg bg-gray-100 dark:bg-gray-800 flex items-center justify-center text-gray-500 dark:text-gray-400 hover:bg-sky-100 hover:text-sky-500 dark:hover:bg-sky-900 dark:hover:text-sky-400 transition-all"
            >
              <el-icon :size="18">
                <component :is="social.icon" />
              </el-icon>
            </a>
          </div>
        </div>

        <!-- 联系方式 -->
        <div class="contact-info">
          <h4 class="text-sm font-semibold mb-3 text-gray-700 dark:text-gray-300">联系我们</h4>
          <p class="text-sm text-gray-500 dark:text-gray-400">
            {{ settings.footer_contact || 'contact@navhub.com' }}
          </p>
        </div>
      </div>

      <!-- 分割线 -->
      <div class="border-t border-gray-200 dark:border-gray-700 pt-6">
        <!-- 版权信息 -->
        <div class="copyright text-center text-sm text-gray-400 dark:text-gray-500">
          <p>{{ settings.footer_copyright || `© ${currentYear} NavHub. All rights reserved.` }}</p>
          <p class="mt-1">
            Made with 
            <el-icon class="text-red-500 mx-1"><svg viewBox="0 0 1024 1024" xmlns="http://www.w3.org/2000/svg"><path fill="currentColor" d="M512 896a384 384 0 0 1-384-384c0-212.096 172.352-384 384-384s384 171.904 384 384a384 384 0 0 1-384 384zM512 192c-176.448 0-320 143.552-320 320s143.552 320 320 320 320-143.552 320-320-143.552-320-320-320z"/><path fill="currentColor" d="M512 704c-106.048 0-192-85.952-192-192s85.952-192 192-192 192 85.952 192 192-85.952 192-192 192z"/></svg></el-icon>
            by NavHub Team
          </p>
        </div>
      </div>
    </div>
  </footer>
</template>

<style lang="scss" scoped>
.app-footer {
  background: rgba(255, 255, 255, 0.5);
  border-top: 1px solid rgba(0, 0, 0, 0.05);
}

.dark .app-footer {
  background: rgba(15, 23, 42, 0.5);
  border-top: 1px solid rgba(255, 255, 255, 0.05);
}

@media (max-width: 768px) {
  .footer-top {
    flex-direction: column;
    align-items: center;
    text-align: center;
  }
  
  .brand-info p {
    max-width: 100%;
  }
}
</style>

