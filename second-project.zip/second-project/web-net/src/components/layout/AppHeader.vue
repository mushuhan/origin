<script setup>
import { ref, computed, onMounted, onUnmounted } from 'vue'
import { useStore } from 'vuex'
import { useRouter } from 'vue-router'
import SearchBox from '@/components/common/SearchBox.vue'

const store = useStore()
const router = useRouter()

const isDark = computed(() => store.state.isDark)
const settings = computed(() => store.state.settings)

// 当前时间
const currentTime = ref('')
const updateTime = () => {
  const now = new Date()
  const options = {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    weekday: 'long',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: false
  }
  currentTime.value = now.toLocaleString('zh-CN', options)
}

let timeInterval = null
onMounted(() => {
  updateTime()
  timeInterval = setInterval(updateTime, 1000)
})

onUnmounted(() => {
  if (timeInterval) {
    clearInterval(timeInterval)
  }
})

// 切换主题
const toggleTheme = () => {
  store.dispatch('toggleTheme')
}

// 打开设置
const openSettings = () => {
  // 可以弹出设置对话框
  router.push('/about')
}

// 回到首页
const goHome = () => {
  router.push('/')
}
</script>

<template>
  <header class="app-header fixed top-0 left-0 right-0 z-50 h-16 flex items-center justify-between px-6 glass">
    <!-- 左侧 Logo -->
    <div class="flex items-center gap-3 cursor-pointer" @click="goHome">
      <div class="logo-wrapper w-10 h-10 rounded-xl bg-gradient-to-br from-sky-400 to-blue-600 flex items-center justify-center shadow-lg">
        <el-icon :size="24" class="text-white">
          <Compass />
        </el-icon>
      </div>
      <span class="text-xl font-bold bg-gradient-to-r from-sky-500 to-blue-600 bg-clip-text text-transparent">
        {{ settings.site_name || 'NavHub' }}
      </span>
    </div>

    <!-- 中间搜索框 -->
    <div class="search-area flex-1 max-w-xl mx-8">
      <SearchBox />
    </div>

    <!-- 右侧工具栏 -->
    <div class="flex items-center gap-4">
      <!-- 当前时间 -->
      <div class="time-display hidden lg:flex items-center gap-2 text-sm text-gray-500 dark:text-gray-400">
        <el-icon><Clock /></el-icon>
        <span>{{ currentTime }}</span>
      </div>

      <!-- 分割线 -->
      <div class="hidden lg:block w-px h-6 bg-gray-200 dark:bg-gray-700"></div>

      <!-- 主题切换 -->
      <el-tooltip :content="isDark ? '切换到浅色模式' : '切换到深色模式'" placement="bottom">
        <button 
          class="theme-toggle w-10 h-10 rounded-xl flex items-center justify-center transition-all hover:bg-gray-100 dark:hover:bg-gray-800"
          @click="toggleTheme"
        >
          <el-icon :size="20" class="transition-transform" :class="isDark ? 'rotate-0' : 'rotate-180'">
            <component :is="isDark ? 'Sunny' : 'Moon'" />
          </el-icon>
        </button>
      </el-tooltip>

      <!-- 设置按钮 -->
      <el-tooltip content="设置" placement="bottom">
        <button 
          class="settings-btn w-10 h-10 rounded-xl flex items-center justify-center transition-all hover:bg-gray-100 dark:hover:bg-gray-800"
          @click="openSettings"
        >
          <el-icon :size="20">
            <Setting />
          </el-icon>
        </button>
      </el-tooltip>
    </div>
  </header>
</template>

<style lang="scss" scoped>
.app-header {
  background: rgba(255, 255, 255, 0.8);
  backdrop-filter: blur(20px);
  -webkit-backdrop-filter: blur(20px);
  border-bottom: 1px solid rgba(0, 0, 0, 0.05);
}

.dark .app-header {
  background: rgba(15, 23, 42, 0.8);
  border-bottom: 1px solid rgba(255, 255, 255, 0.05);
}

.logo-wrapper {
  transition: transform 0.3s ease;
  
  &:hover {
    transform: scale(1.05) rotate(-5deg);
  }
}

.theme-toggle,
.settings-btn {
  color: #64748b;
  
  &:hover {
    color: #0ea5e9;
  }
}

.dark .theme-toggle,
.dark .settings-btn {
  color: #94a3b8;
  
  &:hover {
    color: #38bdf8;
  }
}

@media (max-width: 768px) {
  .search-area {
    display: none;
  }
}
</style>

