<script setup>
import { onMounted, watch } from 'vue'
import { useStore } from 'vuex'
import MainLayout from '@/components/layout/MainLayout.vue'
import { ElMessage } from 'element-plus'

const store = useStore()

// 监听消息
watch(() => store.state.message, (message) => {
  if (message) {
    ElMessage({
      message: message.text,
      type: message.type,
      duration: 3000
    })
    store.commit('SET_MESSAGE', null)
  }
})

onMounted(() => {
  // 获取首页数据
  store.dispatch('fetchHomeData')
  // 获取工作台数据
  store.dispatch('fetchWorkspace')
})
</script>

<template>
  <MainLayout>
    <router-view v-slot="{ Component }">
      <transition name="fade" mode="out-in">
        <component :is="Component" />
      </transition>
    </router-view>
  </MainLayout>
</template>

<style scoped>
.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.3s ease;
}

.fade-enter-from,
.fade-leave-to {
  opacity: 0;
}
</style>
