# API接口文档

## 基础信息

- **基础URL**: `http://localhost:8080`
- **数据格式**: JSON
- **字符编码**: UTF-8

## 通用响应格式

```json
{
  "code": 200,
  "message": "success",
  "data": {}
}
```

### 状态码说明

| 状态码 | 说明 |
|--------|------|
| 200 | 请求成功 |
| 400 | 请求参数错误 |
| 401 | 未授权/token失效 |
| 403 | 无权限访问 |
| 404 | 资源不存在 |
| 500 | 服务器内部错误 |

## 认证相关

### 1. 用户登录

**接口**: `POST /api/auth/login`

**请求参数**:
```json
{
  "username": "admin",
  "password": "admin123",
  "role": "admin"
}
```

**响应示例**:
```json
{
  "code": 200,
  "message": "登录成功",
  "data": {
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "userInfo": {
      "id": 1,
      "username": "admin",
      "email": "admin@example.com",
      "role": "admin",
      "avatar": ""
    }
  }
}
```

### 2. 用户登出

**接口**: `POST /api/auth/logout`

**请求头**: `Authorization: Bearer {token}`

**响应示例**:
```json
{
  "code": 200,
  "message": "登出成功"
}
```

### 3. 检查认证状态

**接口**: `GET /api/auth/check`

**请求头**: `Authorization: Bearer {token}`

## 用户相关

### 1. 获取用户信息

**接口**: `GET /api/user/info`

**请求参数**: `userId` (可选，不传则获取当前用户)

### 2. 更新用户信息

**接口**: `POST /api/user/update`

**请求体**:
```json
{
  "username": "张三",
  "email": "zhangsan@example.com",
  "phone": "13800138000",
  "department": "技术部",
  "position": "工程师"
}
```

### 3. 上传头像

**接口**: `POST /api/user/avatar`

**请求类型**: `multipart/form-data`

**请求参数**: `avatar` (文件)

## 公告相关

### 1. 获取公告列表

**接口**: `GET /api/announcement/list`

**请求参数**:
- `page`: 页码（默认1）
- `pageSize`: 每页数量（默认10）
- `priority`: 优先级筛选（可选）
- `status`: 状态筛选（可选）

### 2. 获取公告详情

**接口**: `GET /api/announcement/detail`

**请求参数**: `id` (公告ID)

### 3. 创建公告

**接口**: `POST /api/announcement/create`

**权限**: 需要管理员权限

**请求体**:
```json
{
  "title": "公告标题",
  "content": "公告内容",
  "priority": "high"
}
```

### 4. 更新公告

**接口**: `POST /api/announcement/update`

**权限**: 需要管理员权限

**请求体**:
```json
{
  "id": 1,
  "title": "更新的标题",
  "content": "更新的内容",
  "priority": "medium"
}
```

### 5. 删除公告

**接口**: `POST /api/announcement/delete`

**权限**: 需要管理员权限

**请求体**:
```json
{
  "id": 1
}
```

## 员工相关

### 1. 获取员工列表

**接口**: `GET /api/employee/list`

**请求参数**:
- `page`: 页码
- `pageSize`: 每页数量
- `section`: 工段筛选（可选）
- `status`: 状态筛选（可选）

### 2. 获取员工详情

**接口**: `GET /api/employee/detail`

**请求参数**: `id` (员工ID)

### 3. 创建员工

**接口**: `POST /api/employee/create`

**权限**: 需要管理员权限

**请求体**:
```json
{
  "employeeId": "E001",
  "name": "张三",
  "section": 1,
  "position": "技术员",
  "phone": "13800138000",
  "email": "zhangsan@company.com",
  "isLeader": false,
  "status": "active",
  "joinDate": "2024-01-01",
  "skills": ["焊接", "机械加工"]
}
```

### 4. 更新员工

**接口**: `POST /api/employee/update`

**权限**: 需要管理员权限

### 5. 删除员工

**接口**: `POST /api/employee/delete`

**权限**: 需要管理员权限

### 6. 导入员工Excel

**接口**: `POST /api/employee/import`

**权限**: 需要管理员权限

**请求类型**: `multipart/form-data`

**请求参数**: `file` (Excel文件)

**Excel格式**:
| 工号 | 姓名 | 工段 | 职位 | 电话 | 邮箱 | 状态 |
|------|------|------|------|------|------|------|
| E001 | 张三 | 1 | 技术员 | 13800138000 | zhangsan@company.com | active |

### 7. 导出员工Excel

**接口**: `GET /api/employee/export`

**权限**: 需要管理员权限

**响应**: Excel文件下载

## 轮播图相关

### 1. 获取轮播图列表

**接口**: `GET /api/carousel/list`

### 2. 创建轮播图

**接口**: `POST /api/carousel/create`

**权限**: 需要管理员权限

**请求体**:
```json
{
  "title": "标题",
  "description": "描述",
  "image": "图片URL",
  "link": "跳转链接",
  "sortOrder": 1
}
```

### 3. 更新轮播图

**接口**: `POST /api/carousel/update`

**权限**: 需要管理员权限

### 4. 删除轮播图

**接口**: `POST /api/carousel/delete`

**权限**: 需要管理员权限

## 常用网址相关

### 1. 获取网址列表

**接口**: `GET /api/link/list`

**请求参数**:
- `category`: 分类筛选（可选）

### 2. 创建网址

**接口**: `POST /api/link/create`

**请求体**:
```json
{
  "name": "网址名称",
  "url": "http://example.com",
  "category": "office",
  "description": "描述"
}
```

### 3. 导入网址Excel

**接口**: `POST /api/link/import`

**权限**: 需要管理员权限

**请求类型**: `multipart/form-data`

**Excel格式**:
| 名称 | 网址 | 分类 | 描述 |
|------|------|------|------|
| OA系统 | http://oa.example.com | office | 办公系统 |

## 待办事项相关

### 1. 获取待办列表

**接口**: `GET /api/todo/list`

**请求参数**:
- `userId`: 用户ID（可选）
- `completed`: 完成状态筛选（可选）

### 2. 创建待办

**接口**: `POST /api/todo/create`

**请求体**:
```json
{
  "title": "待办标题",
  "description": "待办描述",
  "deadline": "2024-01-31 18:00:00",
  "priority": "high"
}
```

### 3. 完成待办

**接口**: `POST /api/todo/complete`

**请求体**:
```json
{
  "id": 1
}
```

### 4. 删除待办

**接口**: `POST /api/todo/delete`

**请求体**:
```json
{
  "id": 1
}
```

## 搜索相关

### 1. 全局搜索

**接口**: `GET /api/search/all`

**请求参数**: `keyword` (搜索关键词)

**响应示例**:
```json
{
  "code": 200,
  "data": [
    {
      "type": "employee",
      "id": 1,
      "name": "张三",
      "department": "技术部"
    },
    {
      "type": "announcement",
      "id": 1,
      "title": "重要公告"
    }
  ]
}
```

### 2. 搜索员工

**接口**: `GET /api/search/employees`

**请求参数**: `keyword`

### 3. 搜索公告

**接口**: `GET /api/search/announcements`

**请求参数**: `keyword`

### 4. 搜索网址

**接口**: `GET /api/search/links`

**请求参数**: `keyword`

## 管理员后台相关

### 1. 获取统计数据

**接口**: `GET /api/admin/stats`

**权限**: 需要管理员权限

**响应示例**:
```json
{
  "code": 200,
  "data": {
    "totalUsers": 45,
    "totalAnnouncements": 12,
    "totalLinks": 28,
    "totalEmployees": 38,
    "loginToday": 20,
    "activeUsers": 35
  }
}
```

### 2. 获取系统信息

**接口**: `GET /api/admin/system`

**权限**: 需要管理员权限

## 错误码说明

| 错误码 | 说明 | 解决方案 |
|--------|------|---------|
| 10001 | 用户名或密码错误 | 检查登录信息 |
| 10002 | 用户不存在 | 检查用户ID |
| 10003 | token失效 | 重新登录 |
| 10004 | 无权限访问 | 检查用户权限 |
| 20001 | 参数验证失败 | 检查请求参数 |
| 20002 | 数据不存在 | 检查资源ID |
| 30001 | 文件上传失败 | 检查文件格式和大小 |
| 30002 | Excel解析失败 | 检查Excel格式 |

## 开发注意事项

1. 所有需要认证的接口都需要在请求头中携带token
2. token格式：`Authorization: Bearer {token}`
3. 分页参数从1开始
4. 时间格式统一使用：`YYYY-MM-DD HH:mm:ss`
5. 文件上传大小限制：10MB
6. 支持的图片格式：jpg, jpeg, png, gif
7. Excel导入/导出统一使用xlsx格式

## 测试账号

### 管理员账号
- 用户名: admin
- 密码: admin123
- 角色: admin

### 普通用户账号
- 用户名: user
- 密码: user123
- 角色: user

