import { createRouter, createWebHistory } from 'vue-router'
import { useUserStore } from '@/store/user'

const routes = [
  {
    path: '/',
    redirect: '/login',
  },
  {
    path: '/login',
    name: 'Login',
    component: () => import('@/views/Login.vue'),
    meta: { title: '登录', requiresAuth: false },
  },
  {
    path: '/home',
    name: 'Home',
    component: () => import('@/views/Home.vue'),
    meta: { title: '首页', requiresAuth: true },
  },
  {
    path: '/employee',
    name: 'Employee',
    component: () => import('@/views/Employee.vue'),
    meta: { title: '人员架构', requiresAuth: true },
  },
  {
    path: '/usercenter',
    name: 'UserCenter',
    component: () => import('@/views/UserCenter.vue'),
    meta: { title: '用户中心', requiresAuth: true },
  },
  {
    path: '/transpath',
    name: 'TransPath',
    component: () => import('@/views/TransPath.vue'),
    meta: { title: '常用网址', requiresAuth: true },
  },
  {
    path: '/console',
    name: 'Console',
    component: () => import('@/views/Console.vue'),
    meta: { title: '管理员后台', requiresAuth: true, requiresAdmin: true },
  },
]

const router = createRouter({
  history: createWebHistory(),
  routes,
})

// 路由守卫
router.beforeEach((to, from, next) => {
  const userStore = useUserStore()

  // 设置页面标题
  document.title = to.meta.title ? `${to.meta.title} - 部门信息管理系统` : '部门信息管理系统'

  // 检查是否需要认证
  if (to.meta.requiresAuth) {
    if (!userStore.isAuthenticated) {
      next('/login')
      return
    }

    // 检查是否需要管理员权限
    if (to.meta.requiresAdmin && !userStore.isAdmin) {
      next('/home')
      return
    }
  }

  // 已登录用户访问登录页，跳转到首页
  if (to.path === '/login' && userStore.isAuthenticated) {
    next('/home')
    return
  }

  next()
})

export default router
