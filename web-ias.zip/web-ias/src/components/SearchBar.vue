<template>
  <div class="search-bar" :class="{ 'is-mobile': isMobile }">
    <div class="search-wrapper">
      <el-input
        v-model="searchKeyword"
        :placeholder="placeholder"
        class="search-input"
        clearable
        @input="handleSearch"
        @keyup.enter="handleEnter"
      >
        <template #prefix>
          <el-icon><Search /></el-icon>
        </template>
      </el-input>
      
      <!-- 搜索结果下拉框 -->
      <transition name="slide-down">
        <div v-if="showResults && searchResults.length > 0" class="search-results">
          <div
            v-for="(item, index) in searchResults"
            :key="index"
            class="result-item"
            @click="handleResultClick(item)"
          >
            <div class="result-icon">
              <el-icon v-if="item.type === 'employee'"><User /></el-icon>
              <el-icon v-else-if="item.type === 'announcement'"><Bell /></el-icon>
              <el-icon v-else-if="item.type === 'link'"><Link /></el-icon>
              <el-icon v-else><Document /></el-icon>
            </div>
            <div class="result-content">
              <div class="result-title">{{ item.title || item.name }}</div>
              <div class="result-desc">{{ item.description || item.department }}</div>
            </div>
            <div class="result-type">{{ getTypeText(item.type) }}</div>
          </div>
        </div>
      </transition>
      
      <!-- 无结果提示 -->
      <transition name="slide-down">
        <div v-if="showResults && searched && searchResults.length === 0" class="search-no-result">
          <el-icon><InfoFilled /></el-icon>
          <span>未找到相关结果</span>
        </div>
      </transition>
    </div>
  </div>
</template>

<script setup>
import { ref, watch, onMounted, onUnmounted } from 'vue'
import { searchAPI } from '@/api'
import { ElMessage } from 'element-plus'
import { Search, User, Bell, Link, Document, InfoFilled } from '@element-plus/icons-vue'

const props = defineProps({
  placeholder: {
    type: String,
    default: '搜索...'
  },
  searchType: {
    type: String,
    default: 'all', // all, employee, announcement, link
    validator: (value) => ['all', 'employee', 'announcement', 'link'].includes(value)
  },
  localSearch: {
    type: Boolean,
    default: false
  },
  localData: {
    type: Array,
    default: () => []
  }
})

const emit = defineEmits(['search', 'select'])

const searchKeyword = ref('')
const searchResults = ref([])
const showResults = ref(false)
const searched = ref(false)
const isMobile = ref(false)
let searchTimer = null

// 检测移动端
const checkMobile = () => {
  isMobile.value = window.innerWidth <= 768
}

onMounted(() => {
  checkMobile()
  window.addEventListener('resize', checkMobile)
  document.addEventListener('click', handleClickOutside)
})

onUnmounted(() => {
  window.removeEventListener('resize', checkMobile)
  document.removeEventListener('click', handleClickOutside)
})

// 点击外部关闭结果框
const handleClickOutside = (e) => {
  if (!e.target.closest('.search-bar')) {
    showResults.value = false
  }
}

// 搜索处理（防抖）
const handleSearch = () => {
  if (searchTimer) {
    clearTimeout(searchTimer)
  }
  
  if (!searchKeyword.value.trim()) {
    searchResults.value = []
    showResults.value = false
    searched.value = false
    return
  }
  
  searchTimer = setTimeout(() => {
    performSearch()
  }, 300)
}

// 执行搜索
const performSearch = async () => {
  try {
    const keyword = searchKeyword.value.trim()
    
    if (props.localSearch) {
      // 本地搜索
      searchResults.value = props.localData.filter(item => {
        const searchStr = JSON.stringify(item).toLowerCase()
        return searchStr.includes(keyword.toLowerCase())
      })
    } else {
      // API搜索
      let response
      switch (props.searchType) {
        case 'employee':
          response = await searchAPI.searchEmployees(keyword)
          break
        case 'announcement':
          response = await searchAPI.searchAnnouncements(keyword)
          break
        case 'link':
          response = await searchAPI.searchLinks(keyword)
          break
        default:
          response = await searchAPI.searchAll(keyword)
      }
      
      searchResults.value = response.data || []
    }
    
    showResults.value = true
    searched.value = true
    
    emit('search', searchResults.value)
  } catch (error) {
    console.error('搜索失败:', error)
    // 在未连接后端的情况下，使用本地mock数据
    if (!import.meta.env.VITE_API_CONNECTED) {
      searchResults.value = getMockSearchResults()
      showResults.value = true
      searched.value = true
    }
  }
}

// Mock搜索结果（测试用）
const getMockSearchResults = () => {
  const keyword = searchKeyword.value.toLowerCase()
  const mockData = [
    { type: 'employee', name: '张三', department: '1工段', position: '工段长' },
    { type: 'employee', name: '李四', department: '2工段', position: '员工' },
    { type: 'announcement', title: '重要公告', description: '请注意查看' },
    { type: 'link', name: 'OA系统', url: 'http://oa.example.com' }
  ]
  
  return mockData.filter(item => {
    const searchStr = JSON.stringify(item).toLowerCase()
    return searchStr.includes(keyword)
  })
}

// 回车搜索
const handleEnter = () => {
  emit('search', searchResults.value)
}

// 点击搜索结果
const handleResultClick = (item) => {
  emit('select', item)
  showResults.value = false
}

// 获取类型文本
const getTypeText = (type) => {
  const typeMap = {
    employee: '员工',
    announcement: '公告',
    link: '网址',
    todo: '待办'
  }
  return typeMap[type] || '其他'
}

// 暴露方法
defineExpose({
  clear: () => {
    searchKeyword.value = ''
    searchResults.value = []
    showResults.value = false
    searched.value = false
  }
})
</script>

<style lang="scss" scoped>
.search-bar {
  width: 100%;
  position: relative;
  
  .search-wrapper {
    position: relative;
    
    .search-input {
      :deep(.el-input__wrapper) {
        border-radius: var(--border-radius-lg);
        padding: 8px 16px;
        background: var(--ios-card-bg);
        box-shadow: var(--ios-shadow);
        transition: all 0.3s ease;
        
        &:hover {
          box-shadow: var(--ios-shadow-hover);
        }
      }
      
      :deep(.el-input__inner) {
        font-size: 15px;
      }
    }
    
    .search-results,
    .search-no-result {
      position: absolute;
      top: calc(100% + 8px);
      left: 0;
      right: 0;
      background: var(--ios-card-bg);
      border-radius: var(--border-radius-lg);
      box-shadow: var(--ios-shadow-hover);
      max-height: 400px;
      overflow-y: auto;
      z-index: 1000;
    }
    
    .search-results {
      .result-item {
        display: flex;
        align-items: center;
        padding: 12px 16px;
        cursor: pointer;
        transition: all 0.2s ease;
        border-bottom: 1px solid var(--ios-separator);
        
        &:last-child {
          border-bottom: none;
        }
        
        &:hover {
          background: var(--ios-bg);
        }
        
        .result-icon {
          width: 40px;
          height: 40px;
          display: flex;
          align-items: center;
          justify-content: center;
          background: var(--ios-bg);
          border-radius: 50%;
          margin-right: 12px;
          
          .el-icon {
            font-size: 20px;
            color: var(--ios-primary);
          }
        }
        
        .result-content {
          flex: 1;
          
          .result-title {
            font-size: 15px;
            font-weight: 500;
            color: var(--ios-text-primary);
            margin-bottom: 4px;
          }
          
          .result-desc {
            font-size: 13px;
            color: var(--ios-text-tertiary);
          }
        }
        
        .result-type {
          font-size: 12px;
          color: var(--ios-text-tertiary);
          padding: 4px 8px;
          background: var(--ios-bg);
          border-radius: var(--border-radius-sm);
        }
      }
    }
    
    .search-no-result {
      padding: 24px;
      text-align: center;
      color: var(--ios-text-tertiary);
      
      .el-icon {
        font-size: 32px;
        margin-bottom: 8px;
      }
      
      span {
        display: block;
        font-size: 14px;
      }
    }
  }
  
  &.is-mobile {
    .search-input {
      :deep(.el-input__wrapper) {
        padding: 6px 12px;
      }
    }
  }
}

.slide-down-enter-active,
.slide-down-leave-active {
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
}

.slide-down-enter-from,
.slide-down-leave-to {
  opacity: 0;
  transform: translateY(-10px);
}
</style>

