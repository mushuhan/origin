<template>
  <div class="layout-header">
    <div class="header-container">
      <!-- Logo和标题 -->
      <div class="header-left">
        <div class="logo">
          <el-icon><OfficeBuilding /></el-icon>
        </div>
        <h1 class="title">部门信息管理系统</h1>
      </div>
      
      <!-- 导航菜单 -->
      <div class="header-center">
        <nav class="nav-menu">
          <router-link
            v-for="item in navItems"
            :key="item.path"
            :to="item.path"
            class="nav-item"
            :class="{ active: isActive(item.path) }"
          >
            <el-icon>
              <component :is="item.icon" />
            </el-icon>
            <span>{{ item.name }}</span>
          </router-link>
        </nav>
      </div>
      
      <!-- 用户信息 -->
      <div class="header-right">
        <el-dropdown trigger="click" @command="handleCommand">
          <div class="user-info">
            <el-avatar :src="userStore.avatar" :size="36">
              {{ userStore.username.charAt(0) }}
            </el-avatar>
            <span class="username">{{ userStore.username }}</span>
            <el-icon><ArrowDown /></el-icon>
          </div>
          <template #dropdown>
            <el-dropdown-menu>
              <el-dropdown-item command="profile">
                <el-icon><User /></el-icon>
                个人中心
              </el-dropdown-item>
              <el-dropdown-item v-if="userStore.isAdmin" command="console">
                <el-icon><Setting /></el-icon>
                管理后台
              </el-dropdown-item>
              <el-dropdown-item divided command="logout">
                <el-icon><SwitchButton /></el-icon>
                退出登录
              </el-dropdown-item>
            </el-dropdown-menu>
          </template>
        </el-dropdown>
      </div>
    </div>
  </div>
</template>

<script setup>
import { computed } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { useUserStore } from '@/store/user'
import { ElMessageBox, ElMessage } from 'element-plus'
import {
  OfficeBuilding,
  HomeFilled,
  User,
  Link,
  UserFilled,
  Setting,
  ArrowDown,
  SwitchButton
} from '@element-plus/icons-vue'

const router = useRouter()
const route = useRoute()
const userStore = useUserStore()

// 导航菜单项
const navItems = computed(() => {
  const items = [
    { name: '首页', path: '/home', icon: 'HomeFilled' },
    { name: '人员架构', path: '/employee', icon: 'UserFilled' },
    { name: '常用网址', path: '/transpath', icon: 'Link' }
  ]
  
  if (userStore.isAdmin) {
    items.push({ name: '管理后台', path: '/console', icon: 'Setting' })
  }
  
  return items
})

// 判断当前路由是否激活
const isActive = (path) => {
  return route.path === path
}

// 下拉菜单命令处理
const handleCommand = async (command) => {
  switch (command) {
    case 'profile':
      router.push('/usercenter')
      break
    case 'console':
      router.push('/console')
      break
    case 'logout':
      try {
        await ElMessageBox.confirm('确定要退出登录吗？', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        })
        
        await userStore.logout()
        ElMessage.success('已退出登录')
        router.push('/login')
      } catch (error) {
        // 取消操作
      }
      break
  }
}
</script>

<style lang="scss" scoped>
.layout-header {
  background: rgba(255, 255, 255, 0.9);
  backdrop-filter: blur(20px);
  -webkit-backdrop-filter: blur(20px);
  border-bottom: 1px solid var(--ios-separator);
  position: sticky;
  top: 0;
  z-index: 100;
  
  .header-container {
    max-width: 1400px;
    margin: 0 auto;
    padding: 0 24px;
    height: 64px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    
    .header-left {
      display: flex;
      align-items: center;
      gap: 12px;
      
      .logo {
        width: 40px;
        height: 40px;
        background: linear-gradient(135deg, var(--ios-primary), var(--ios-info));
        border-radius: var(--border-radius-md);
        display: flex;
        align-items: center;
        justify-content: center;
        
        .el-icon {
          font-size: 24px;
          color: white;
        }
      }
      
      .title {
        font-size: 18px;
        font-weight: 600;
        color: var(--ios-text-primary);
        margin: 0;
      }
    }
    
    .header-center {
      flex: 1;
      display: flex;
      justify-content: center;
      
      .nav-menu {
        display: flex;
        gap: 8px;
        
        .nav-item {
          display: flex;
          align-items: center;
          gap: 6px;
          padding: 8px 16px;
          border-radius: var(--border-radius-md);
          text-decoration: none;
          color: var(--ios-text-secondary);
          font-size: 14px;
          font-weight: 500;
          transition: all 0.2s ease;
          
          .el-icon {
            font-size: 18px;
          }
          
          &:hover {
            background: var(--ios-bg);
            color: var(--ios-primary);
          }
          
          &.active {
            background: var(--ios-primary);
            color: white;
          }
        }
      }
    }
    
    .header-right {
      .user-info {
        display: flex;
        align-items: center;
        gap: 8px;
        padding: 4px 12px 4px 4px;
        border-radius: 24px;
        background: var(--ios-bg);
        cursor: pointer;
        transition: all 0.2s ease;
        
        &:hover {
          background: var(--ios-separator);
        }
        
        .username {
          font-size: 14px;
          font-weight: 500;
          color: var(--ios-text-primary);
        }
        
        .el-icon {
          font-size: 12px;
          color: var(--ios-text-tertiary);
        }
      }
    }
  }
}

@media (max-width: 768px) {
  .layout-header {
    .header-container {
      padding: 0 16px;
      
      .header-left {
        .title {
          display: none;
        }
      }
      
      .header-center {
        .nav-menu {
          .nav-item {
            span {
              display: none;
            }
          }
        }
      }
      
      .header-right {
        .user-info {
          .username {
            display: none;
          }
        }
      }
    }
  }
}
</style>

