<template>
  <div class="home-page">
    <layout-header />
    
    <div class="home-container">
      <!-- 搜索栏 -->
      <div class="search-section">
        <search-bar
          placeholder="搜索公告、人员、网址..."
          search-type="all"
          @select="handleSearchSelect"
        />
      </div>
      
      <!-- 轮播图 -->
      <div class="carousel-section">
        <el-carousel :interval="5000" height="400px" class="ios-carousel">
          <el-carousel-item v-for="item in carouselList" :key="item.id">
            <div class="carousel-item" :style="{ backgroundImage: `url(${item.image})` }">
              <div class="carousel-content">
                <h2>{{ item.title }}</h2>
                <p>{{ item.description }}</p>
              </div>
            </div>
          </el-carousel-item>
        </el-carousel>
      </div>
      
      <!-- 主要内容区 -->
      <div class="content-grid">
        <!-- 公告栏 -->
        <div class="section announcement-section">
          <div class="section-header">
            <div class="header-left">
              <el-icon class="section-icon"><Bell /></el-icon>
              <h2 class="section-title">公告栏</h2>
            </div>
            <el-button text type="primary" @click="viewAllAnnouncements">
              查看全部 <el-icon><ArrowRight /></el-icon>
            </el-button>
          </div>
          
          <div class="announcement-list">
            <div
              v-for="item in announcementList"
              :key="item.id"
              class="announcement-item"
              @click="viewAnnouncement(item)"
            >
              <div class="announcement-badge" :class="item.priority">
                {{ getPriorityText(item.priority) }}
              </div>
              <div class="announcement-content">
                <h3 class="announcement-title">{{ item.title }}</h3>
                <p class="announcement-desc">{{ item.content }}</p>
                <div class="announcement-meta">
                  <span class="meta-item">
                    <el-icon><User /></el-icon>
                    {{ item.publisher }}
                  </span>
                  <span class="meta-item">
                    <el-icon><Clock /></el-icon>
                    {{ formatDate(item.publishTime) }}
                  </span>
                </div>
              </div>
              <el-icon class="arrow-icon"><ArrowRight /></el-icon>
            </div>
            
            <el-empty v-if="announcementList.length === 0" description="暂无公告" />
          </div>
        </div>
        
        <!-- 待办事项 -->
        <div class="section todo-section">
          <div class="section-header">
            <div class="header-left">
              <el-icon class="section-icon"><Calendar /></el-icon>
              <h2 class="section-title">我的待办</h2>
            </div>
            <el-button text type="primary" @click="addTodo">
              <el-icon><Plus /></el-icon> 添加
            </el-button>
          </div>
          
          <div class="todo-list">
            <div
              v-for="item in todoList"
              :key="item.id"
              class="todo-item"
              :class="{ completed: item.completed }"
            >
              <el-checkbox
                v-model="item.completed"
                @change="toggleTodo(item)"
              />
              <div class="todo-content">
                <p class="todo-title">{{ item.title }}</p>
                <p class="todo-time">{{ formatDate(item.deadline) }}</p>
              </div>
              <el-button
                text
                type="danger"
                size="small"
                @click="deleteTodo(item)"
              >
                <el-icon><Delete /></el-icon>
              </el-button>
            </div>
            
            <el-empty v-if="todoList.length === 0" description="暂无待办事项" />
          </div>
        </div>
      </div>
      
      <!-- 快捷入口 -->
      <div class="quick-links">
        <h2 class="quick-title">快捷入口</h2>
        <div class="quick-grid">
          <div
            v-for="link in quickLinks"
            :key="link.path"
            class="quick-item"
            @click="navigateTo(link.path)"
          >
            <div class="quick-icon" :style="{ background: link.color }">
              <el-icon>
                <component :is="link.icon" />
              </el-icon>
            </div>
            <p class="quick-name">{{ link.name }}</p>
          </div>
        </div>
      </div>
    </div>
    
    <!-- 公告详情对话框 -->
    <el-dialog
      v-model="announcementDialogVisible"
      :title="currentAnnouncement?.title"
      width="600px"
      class="announcement-dialog"
    >
      <div class="announcement-detail">
        <div class="detail-meta">
          <el-tag :type="getPriorityType(currentAnnouncement?.priority)">
            {{ getPriorityText(currentAnnouncement?.priority) }}
          </el-tag>
          <span>发布人: {{ currentAnnouncement?.publisher }}</span>
          <span>发布时间: {{ formatDate(currentAnnouncement?.publishTime) }}</span>
        </div>
        <div class="detail-content">
          {{ currentAnnouncement?.content }}
        </div>
      </div>
    </el-dialog>
    
    <!-- 添加待办对话框 -->
    <el-dialog v-model="todoDialogVisible" title="添加待办" width="500px">
      <el-form :model="todoForm" label-width="80px">
        <el-form-item label="标题">
          <el-input v-model="todoForm.title" placeholder="请输入待办标题" />
        </el-form-item>
        <el-form-item label="截止日期">
          <el-date-picker
            v-model="todoForm.deadline"
            type="datetime"
            placeholder="选择截止日期"
            style="width: 100%"
          />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="todoDialogVisible = false">取消</el-button>
        <el-button type="primary" @click="saveTodo">确定</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import {
  Bell,
  Calendar,
  User,
  Clock,
  ArrowRight,
  Plus,
  Delete,
  UserFilled,
  Link,
  Setting
} from '@element-plus/icons-vue'
import LayoutHeader from '@/components/LayoutHeader.vue'
import SearchBar from '@/components/SearchBar.vue'
import { announcementAPI, todoAPI, carouselAPI } from '@/api'

const router = useRouter()

// 轮播图数据
const carouselList = ref([
  {
    id: 1,
    title: '欢迎使用部门信息管理系统',
    description: '高效管理，智能办公',
    image: 'https://images.unsplash.com/photo-1497366216548-37526070297c?w=1200&h=400&fit=crop'
  },
  {
    id: 2,
    title: '人员架构一目了然',
    description: '清晰展示部门组织结构',
    image: 'https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=1200&h=400&fit=crop'
  },
  {
    id: 3,
    title: '信息管理更便捷',
    description: '让工作更加高效有序',
    image: 'https://images.unsplash.com/photo-1542744173-8e7e53415bb0?w=1200&h=400&fit=crop'
  }
])

// 公告数据
const announcementList = ref([
  {
    id: 1,
    title: '关于召开部门例会的通知',
    content: '定于本周五下午3点召开部门例会，请各工段长准时参加。会议内容包括本月工作总结和下月工作计划。',
    publisher: '张经理',
    publishTime: new Date('2024-01-15 10:00:00'),
    priority: 'high'
  },
  {
    id: 2,
    title: '系统维护公告',
    content: '本周六晚上10点至周日早上6点进行系统维护，期间系统将无法访问，请提前做好工作安排。',
    publisher: '技术部',
    publishTime: new Date('2024-01-14 15:30:00'),
    priority: 'medium'
  },
  {
    id: 3,
    title: '新员工培训通知',
    content: '本月新入职员工请于下周一上午9点到会议室参加入职培训。',
    publisher: '人事部',
    publishTime: new Date('2024-01-13 09:00:00'),
    priority: 'normal'
  }
])

// 待办事项数据
const todoList = ref([
  {
    id: 1,
    title: '完成本月工作报告',
    deadline: new Date('2024-01-31 18:00:00'),
    completed: false
  },
  {
    id: 2,
    title: '审核员工考勤记录',
    deadline: new Date('2024-01-20 17:00:00'),
    completed: false
  }
])

// 快捷链接
const quickLinks = [
  {
    name: '人员架构',
    path: '/employee',
    icon: 'UserFilled',
    color: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)'
  },
  {
    name: '用户中心',
    path: '/usercenter',
    icon: 'User',
    color: 'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)'
  },
  {
    name: '常用网址',
    path: '/transpath',
    icon: 'Link',
    color: 'linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)'
  },
  {
    name: '管理后台',
    path: '/console',
    icon: 'Setting',
    color: 'linear-gradient(135deg, #43e97b 0%, #38f9d7 100%)'
  }
]

// 公告对话框
const announcementDialogVisible = ref(false)
const currentAnnouncement = ref(null)

// 待办对话框
const todoDialogVisible = ref(false)
const todoForm = reactive({
  title: '',
  deadline: null
})

// 页面加载
onMounted(() => {
  loadData()
})

// 加载数据
const loadData = async () => {
  try {
    // 加载轮播图
    const carouselRes = await carouselAPI.getList()
    if (carouselRes.code === 200 && carouselRes.data) {
      carouselList.value = carouselRes.data
    }
    
    // 加载公告
    const announcementRes = await announcementAPI.getList({ page: 1, pageSize: 10 })
    if (announcementRes.code === 200 && announcementRes.data) {
      // 处理分页数据
      const data = announcementRes.data.records || announcementRes.data
      announcementList.value = Array.isArray(data) ? data.slice(0, 3) : []
    }
    
    // 加载待办
    const todoRes = await todoAPI.getList({ completed: false })
    if (todoRes.code === 200 && todoRes.data) {
      todoList.value = todoRes.data
    }
  } catch (error) {
    console.error('加载数据失败:', error)
    // 如果加载失败，保留mock数据作为后备
  }
}

// 搜索选择
const handleSearchSelect = (item) => {
  if (item.type === 'employee') {
    router.push('/employee')
  } else if (item.type === 'announcement') {
    viewAnnouncement(item)
  } else if (item.type === 'link') {
    router.push('/transpath')
  }
}

// 查看公告
const viewAnnouncement = (item) => {
  currentAnnouncement.value = item
  announcementDialogVisible.value = true
}

// 查看全部公告
const viewAllAnnouncements = () => {
  ElMessage.info('跳转到公告列表页面')
}

// 获取优先级文本
const getPriorityText = (priority) => {
  const map = {
    high: '重要',
    medium: '中等',
    normal: '普通'
  }
  return map[priority] || '普通'
}

// 获取优先级类型
const getPriorityType = (priority) => {
  const map = {
    high: 'danger',
    medium: 'warning',
    normal: 'info'
  }
  return map[priority] || 'info'
}

// 格式化日期
const formatDate = (date) => {
  if (!date) return ''
  const d = new Date(date)
  const now = new Date()
  const diff = now - d
  const minute = 60 * 1000
  const hour = 60 * minute
  const day = 24 * hour
  
  if (diff < minute) {
    return '刚刚'
  } else if (diff < hour) {
    return Math.floor(diff / minute) + '分钟前'
  } else if (diff < day) {
    return Math.floor(diff / hour) + '小时前'
  } else if (diff < 7 * day) {
    return Math.floor(diff / day) + '天前'
  } else {
    return d.toLocaleDateString()
  }
}

// 切换待办状态
const toggleTodo = async (item) => {
  try {
    if (item.completed) {
      await todoAPI.complete({ id: item.id })
    } else {
      await todoAPI.update(item.id, { completed: false })
    }
    ElMessage.success(item.completed ? '已完成' : '未完成')
  } catch (error) {
    console.error('更新待办失败:', error)
    item.completed = !item.completed // 恢复状态
  }
}

// 删除待办
const deleteTodo = async (item) => {
  try {
    await ElMessageBox.confirm('确定要删除这条待办吗？', '提示', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning'
    })
    
    await todoAPI.delete({ id: item.id })
    
    const index = todoList.value.findIndex(t => t.id === item.id)
    if (index > -1) {
      todoList.value.splice(index, 1)
      ElMessage.success('删除成功')
    }
  } catch (error) {
    if (error !== 'cancel') {
      console.error('删除待办失败:', error)
    }
  }
}

// 添加待办
const addTodo = () => {
  todoForm.title = ''
  todoForm.deadline = null
  todoDialogVisible.value = true
}

// 保存待办
const saveTodo = async () => {
  if (!todoForm.title) {
    ElMessage.warning('请输入待办标题')
    return
  }
  
  try {
    const res = await todoAPI.create({
      title: todoForm.title,
      deadline: todoForm.deadline || new Date(),
      completed: false
    })
    
    if (res.code === 200) {
      // 重新加载待办列表
      const todoRes = await todoAPI.getList({ completed: false })
      if (todoRes.code === 200 && todoRes.data) {
        todoList.value = todoRes.data
      }
      
      todoDialogVisible.value = false
      ElMessage.success('添加成功')
    }
  } catch (error) {
    console.error('添加待办失败:', error)
  }
}

// 导航
const navigateTo = (path) => {
  router.push(path)
}
</script>

<style lang="scss" scoped>
.home-page {
  min-height: 100vh;
  background: var(--ios-bg);
  
  .home-container {
    max-width: 1400px;
    margin: 0 auto;
    padding: 24px;
    
    .search-section {
      margin-bottom: 24px;
    }
    
    .carousel-section {
      margin-bottom: 24px;
      
      .ios-carousel {
        border-radius: var(--border-radius-xl);
        overflow: hidden;
        box-shadow: var(--ios-shadow);
        
        .carousel-item {
          width: 100%;
          height: 100%;
          background-size: cover;
          background-position: center;
          position: relative;
          
          &::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(to bottom, rgba(0, 0, 0, 0.3), rgba(0, 0, 0, 0.6));
          }
          
          .carousel-content {
            position: absolute;
            bottom: 40px;
            left: 40px;
            right: 40px;
            color: white;
            z-index: 1;
            
            h2 {
              font-size: 32px;
              font-weight: 600;
              margin: 0 0 12px 0;
              text-shadow: 0 2px 8px rgba(0, 0, 0, 0.3);
            }
            
            p {
              font-size: 18px;
              margin: 0;
              opacity: 0.95;
              text-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
            }
          }
        }
      }
    }
    
    .content-grid {
      display: grid;
      grid-template-columns: 2fr 1fr;
      gap: 24px;
      margin-bottom: 24px;
      
      .section {
        background: var(--ios-card-bg);
        border-radius: var(--border-radius-xl);
        padding: 24px;
        box-shadow: var(--ios-shadow);
        
        .section-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          margin-bottom: 20px;
          
          .header-left {
            display: flex;
            align-items: center;
            gap: 12px;
            
            .section-icon {
              font-size: 24px;
              color: var(--ios-primary);
            }
            
            .section-title {
              font-size: 20px;
              font-weight: 600;
              margin: 0;
              color: var(--ios-text-primary);
            }
          }
        }
        
        .announcement-list {
          .announcement-item {
            display: flex;
            align-items: flex-start;
            gap: 12px;
            padding: 16px;
            border-radius: var(--border-radius-lg);
            cursor: pointer;
            transition: all 0.2s ease;
            margin-bottom: 12px;
            
            &:hover {
              background: var(--ios-bg);
            }
            
            .announcement-badge {
              padding: 4px 12px;
              border-radius: var(--border-radius-sm);
              font-size: 12px;
              font-weight: 500;
              white-space: nowrap;
              
              &.high {
                background: #ffe4e1;
                color: var(--ios-danger);
              }
              
              &.medium {
                background: #fff3e0;
                color: var(--ios-warning);
              }
              
              &.normal {
                background: #e3f2fd;
                color: var(--ios-info);
              }
            }
            
            .announcement-content {
              flex: 1;
              
              .announcement-title {
                font-size: 15px;
                font-weight: 500;
                margin: 0 0 8px 0;
                color: var(--ios-text-primary);
              }
              
              .announcement-desc {
                font-size: 13px;
                color: var(--ios-text-tertiary);
                margin: 0 0 8px 0;
                overflow: hidden;
                text-overflow: ellipsis;
                display: -webkit-box;
                -webkit-line-clamp: 2;
                -webkit-box-orient: vertical;
              }
              
              .announcement-meta {
                display: flex;
                gap: 16px;
                
                .meta-item {
                  display: flex;
                  align-items: center;
                  gap: 4px;
                  font-size: 12px;
                  color: var(--ios-text-tertiary);
                  
                  .el-icon {
                    font-size: 14px;
                  }
                }
              }
            }
            
            .arrow-icon {
              color: var(--ios-text-tertiary);
              margin-top: 4px;
            }
          }
        }
        
        .todo-list {
          .todo-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px;
            border-radius: var(--border-radius-md);
            transition: all 0.2s ease;
            margin-bottom: 8px;
            
            &:hover {
              background: var(--ios-bg);
            }
            
            &.completed {
              opacity: 0.6;
              
              .todo-title {
                text-decoration: line-through;
              }
            }
            
            .todo-content {
              flex: 1;
              
              .todo-title {
                font-size: 14px;
                color: var(--ios-text-primary);
                margin: 0 0 4px 0;
              }
              
              .todo-time {
                font-size: 12px;
                color: var(--ios-text-tertiary);
                margin: 0;
              }
            }
          }
        }
      }
    }
    
    .quick-links {
      background: var(--ios-card-bg);
      border-radius: var(--border-radius-xl);
      padding: 24px;
      box-shadow: var(--ios-shadow);
      
      .quick-title {
        font-size: 20px;
        font-weight: 600;
        margin: 0 0 20px 0;
        color: var(--ios-text-primary);
      }
      
      .quick-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(120px, 1fr));
        gap: 16px;
        
        .quick-item {
          display: flex;
          flex-direction: column;
          align-items: center;
          padding: 20px;
          border-radius: var(--border-radius-lg);
          cursor: pointer;
          transition: all 0.3s ease;
          
          &:hover {
            background: var(--ios-bg);
            transform: translateY(-4px);
          }
          
          .quick-icon {
            width: 64px;
            height: 64px;
            border-radius: var(--border-radius-lg);
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 12px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            
            .el-icon {
              font-size: 32px;
              color: white;
            }
          }
          
          .quick-name {
            font-size: 14px;
            font-weight: 500;
            color: var(--ios-text-primary);
            margin: 0;
          }
        }
      }
    }
  }
}

.announcement-dialog {
  .announcement-detail {
    .detail-meta {
      display: flex;
      align-items: center;
      gap: 16px;
      padding-bottom: 16px;
      border-bottom: 1px solid var(--ios-separator);
      margin-bottom: 16px;
      font-size: 13px;
      color: var(--ios-text-tertiary);
    }
    
    .detail-content {
      font-size: 15px;
      line-height: 1.8;
      color: var(--ios-text-primary);
    }
  }
}

@media (max-width: 768px) {
  .home-page {
    .home-container {
      padding: 16px;
      
      .content-grid {
        grid-template-columns: 1fr;
      }
      
      .quick-links {
        .quick-grid {
          grid-template-columns: repeat(auto-fill, minmax(100px, 1fr));
        }
      }
    }
  }
}
</style>

