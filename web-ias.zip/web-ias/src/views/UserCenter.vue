<template>
  <div class="usercenter-page">
    <layout-header />
    
    <div class="usercenter-container">
      <!-- 搜索栏 -->
      <div class="search-section">
        <search-bar placeholder="搜索设置..." />
      </div>
      
      <div class="content-wrapper">
        <!-- 左侧个人信息卡片 -->
        <div class="profile-card ios-card">
          <div class="avatar-section">
            <el-avatar :src="userInfo.avatar" :size="120">
              {{ userInfo.username?.charAt(0) }}
            </el-avatar>
            <el-upload
              class="avatar-uploader"
              :show-file-list="false"
              :before-upload="beforeAvatarUpload"
              :http-request="handleAvatarUpload"
            >
              <el-button size="small" type="primary" circle>
                <el-icon><Camera /></el-icon>
              </el-button>
            </el-upload>
          </div>
          
          <h2 class="username">{{ userInfo.username }}</h2>
          <p class="user-role">
            <el-tag v-if="userStore.isAdmin" type="warning">管理员</el-tag>
            <el-tag v-else type="info">普通用户</el-tag>
          </p>
          
          <div class="user-stats">
            <div class="stat-item">
              <div class="stat-value">{{ stats.loginDays }}</div>
              <div class="stat-label">登录天数</div>
            </div>
            <div class="stat-divider"></div>
            <div class="stat-item">
              <div class="stat-value">{{ stats.todosCompleted }}</div>
              <div class="stat-label">完成待办</div>
            </div>
            <div class="stat-divider"></div>
            <div class="stat-item">
              <div class="stat-value">{{ stats.announcements }}</div>
              <div class="stat-label">查看公告</div>
            </div>
          </div>
        </div>
        
        <!-- 右侧信息编辑 -->
        <div class="info-section">
          <!-- 基本信息 -->
          <div class="info-card ios-card">
            <div class="card-header">
              <h3 class="card-title">
                <el-icon><User /></el-icon>
                基本信息
              </h3>
              <el-button
                v-if="!isEditing"
                type="primary"
                text
                @click="startEdit"
              >
                <el-icon><Edit /></el-icon>
                编辑
              </el-button>
              <div v-else class="edit-actions">
                <el-button size="small" @click="cancelEdit">取消</el-button>
                <el-button size="small" type="primary" @click="saveEdit">保存</el-button>
              </div>
            </div>
            
            <el-form
              ref="userFormRef"
              :model="editForm"
              :rules="formRules"
              label-width="100px"
              class="user-form"
            >
              <el-form-item label="用户名" prop="username">
                <el-input
                  v-model="editForm.username"
                  :disabled="!isEditing"
                  placeholder="请输入用户名"
                />
              </el-form-item>
              
              <el-form-item label="邮箱" prop="email">
                <el-input
                  v-model="editForm.email"
                  :disabled="!isEditing"
                  placeholder="请输入邮箱"
                />
              </el-form-item>
              
              <el-form-item label="手机号" prop="phone">
                <el-input
                  v-model="editForm.phone"
                  :disabled="!isEditing"
                  placeholder="请输入手机号"
                />
              </el-form-item>
              
              <el-form-item label="部门">
                <el-input
                  v-model="editForm.department"
                  :disabled="!isEditing"
                  placeholder="请输入部门"
                />
              </el-form-item>
              
              <el-form-item label="职位">
                <el-input
                  v-model="editForm.position"
                  :disabled="!isEditing"
                  placeholder="请输入职位"
                />
              </el-form-item>
            </el-form>
          </div>
          
          <!-- 安全设置 -->
          <div class="info-card ios-card">
            <div class="card-header">
              <h3 class="card-title">
                <el-icon><Lock /></el-icon>
                安全设置
              </h3>
            </div>
            
            <div class="security-items">
              <div class="security-item">
                <div class="item-left">
                  <el-icon class="item-icon"><Key /></el-icon>
                  <div class="item-info">
                    <div class="item-title">登录密码</div>
                    <div class="item-desc">定期修改密码可以提高账号安全性</div>
                  </div>
                </div>
                <el-button type="primary" text @click="changePassword">
                  修改
                </el-button>
              </div>
              
              <div class="security-item">
                <div class="item-left">
                  <el-icon class="item-icon"><Message /></el-icon>
                  <div class="item-info">
                    <div class="item-title">绑定邮箱</div>
                    <div class="item-desc">{{ userInfo.email || '未绑定' }}</div>
                  </div>
                </div>
                <el-button type="primary" text>
                  {{ userInfo.email ? '修改' : '绑定' }}
                </el-button>
              </div>
              
              <div class="security-item">
                <div class="item-left">
                  <el-icon class="item-icon"><Phone /></el-icon>
                  <div class="item-info">
                    <div class="item-title">绑定手机</div>
                    <div class="item-desc">{{ userInfo.phone || '未绑定' }}</div>
                  </div>
                </div>
                <el-button type="primary" text>
                  {{ userInfo.phone ? '修改' : '绑定' }}
                </el-button>
              </div>
            </div>
          </div>
          
          <!-- 系统设置 -->
          <div class="info-card ios-card">
            <div class="card-header">
              <h3 class="card-title">
                <el-icon><Setting /></el-icon>
                系统设置
              </h3>
            </div>
            
            <div class="settings-items">
              <div class="setting-item">
                <div class="setting-label">
                  <el-icon><Bell /></el-icon>
                  接收通知
                </div>
                <el-switch v-model="settings.notifications" />
              </div>
              
              <div class="setting-item">
                <div class="setting-label">
                  <el-icon><Message /></el-icon>
                  邮件提醒
                </div>
                <el-switch v-model="settings.emailNotifications" />
              </div>
              
              <div class="setting-item">
                <div class="setting-label">
                  <el-icon><Moon /></el-icon>
                  夜间模式
                </div>
                <el-switch v-model="settings.darkMode" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    
    <!-- 修改密码对话框 -->
    <el-dialog v-model="passwordDialogVisible" title="修改密码" width="500px">
      <el-form
        ref="passwordFormRef"
        :model="passwordForm"
        :rules="passwordRules"
        label-width="100px"
      >
        <el-form-item label="原密码" prop="oldPassword">
          <el-input
            v-model="passwordForm.oldPassword"
            type="password"
            placeholder="请输入原密码"
            show-password
          />
        </el-form-item>
        
        <el-form-item label="新密码" prop="newPassword">
          <el-input
            v-model="passwordForm.newPassword"
            type="password"
            placeholder="请输入新密码"
            show-password
          />
        </el-form-item>
        
        <el-form-item label="确认密码" prop="confirmPassword">
          <el-input
            v-model="passwordForm.confirmPassword"
            type="password"
            placeholder="请再次输入新密码"
            show-password
          />
        </el-form-item>
      </el-form>
      
      <template #footer>
        <el-button @click="passwordDialogVisible = false">取消</el-button>
        <el-button type="primary" @click="submitPasswordChange">确定</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, computed, onMounted } from 'vue'
import { useUserStore } from '@/store/user'
import { ElMessage } from 'element-plus'
import {
  User,
  Edit,
  Lock,
  Key,
  Message,
  Phone,
  Setting,
  Bell,
  Moon,
  Camera
} from '@element-plus/icons-vue'
import LayoutHeader from '@/components/LayoutHeader.vue'
import SearchBar from '@/components/SearchBar.vue'
import { userAPI } from '@/api'

const userStore = useUserStore()
const userInfo = computed(() => userStore.userInfo || {})

// 用户统计
const stats = ref({
  loginDays: 156,
  todosCompleted: 48,
  announcements: 125
})

// 编辑状态
const isEditing = ref(false)
const userFormRef = ref(null)

// 编辑表单
const editForm = reactive({
  username: '',
  email: '',
  phone: '',
  department: '',
  position: ''
})

// 表单验证规则
const formRules = {
  username: [
    { required: true, message: '请输入用户名', trigger: 'blur' },
    { min: 2, max: 20, message: '用户名长度在 2 到 20 个字符', trigger: 'blur' }
  ],
  email: [
    { type: 'email', message: '请输入正确的邮箱地址', trigger: 'blur' }
  ],
  phone: [
    { pattern: /^1[3-9]\d{9}$/, message: '请输入正确的手机号', trigger: 'blur' }
  ]
}

// 系统设置
const settings = reactive({
  notifications: true,
  emailNotifications: true,
  darkMode: false
})

// 修改密码
const passwordDialogVisible = ref(false)
const passwordFormRef = ref(null)
const passwordForm = reactive({
  oldPassword: '',
  newPassword: '',
  confirmPassword: ''
})

const passwordRules = {
  oldPassword: [
    { required: true, message: '请输入原密码', trigger: 'blur' }
  ],
  newPassword: [
    { required: true, message: '请输入新密码', trigger: 'blur' },
    { min: 6, max: 20, message: '密码长度在 6 到 20 个字符', trigger: 'blur' }
  ],
  confirmPassword: [
    { required: true, message: '请再次输入新密码', trigger: 'blur' },
    {
      validator: (rule, value, callback) => {
        if (value !== passwordForm.newPassword) {
          callback(new Error('两次输入的密码不一致'))
        } else {
          callback()
        }
      },
      trigger: 'blur'
    }
  ]
}

// 初始化
onMounted(() => {
  loadUserInfo()
})

// 加载用户信息
const loadUserInfo = () => {
  Object.assign(editForm, {
    username: userInfo.value.username || '',
    email: userInfo.value.email || '',
    phone: userInfo.value.phone || '',
    department: userInfo.value.department || '',
    position: userInfo.value.position || ''
  })
}

// 开始编辑
const startEdit = () => {
  isEditing.value = true
}

// 取消编辑
const cancelEdit = () => {
  isEditing.value = false
  loadUserInfo()
}

// 保存编辑
const saveEdit = async () => {
  try {
    await userFormRef.value.validate()
    
    // 调用API更新用户信息
    // await userAPI.updateUserInfo(editForm)
    
    userStore.updateUserInfo(editForm)
    isEditing.value = false
    ElMessage.success('保存成功')
  } catch (error) {
    console.error('保存失败:', error)
  }
}

// 上传头像前的验证
const beforeAvatarUpload = (file) => {
  const isImage = file.type.startsWith('image/')
  const isLt2M = file.size / 1024 / 1024 < 2
  
  if (!isImage) {
    ElMessage.error('只能上传图片文件!')
    return false
  }
  if (!isLt2M) {
    ElMessage.error('图片大小不能超过 2MB!')
    return false
  }
  return true
}

// 自定义上传头像
const handleAvatarUpload = async ({ file }) => {
  try {
    // 实际使用时调用API上传
    // const response = await userAPI.uploadAvatar(file)
    // userStore.updateUserInfo({ avatar: response.data.url })
    
    // Mock: 使用本地预览
    const reader = new FileReader()
    reader.onload = (e) => {
      userStore.updateUserInfo({ avatar: e.target.result })
      ElMessage.success('头像上传成功')
    }
    reader.readAsDataURL(file)
  } catch (error) {
    console.error('头像上传失败:', error)
    ElMessage.error('头像上传失败')
  }
}

// 修改密码
const changePassword = () => {
  passwordForm.oldPassword = ''
  passwordForm.newPassword = ''
  passwordForm.confirmPassword = ''
  passwordDialogVisible.value = true
}

// 提交密码修改
const submitPasswordChange = async () => {
  try {
    await passwordFormRef.value.validate()
    
    // 调用API修改密码
    // await userAPI.changePassword(passwordForm)
    
    passwordDialogVisible.value = false
    ElMessage.success('密码修改成功，请重新登录')
    
    // 可以选择自动登出
    // setTimeout(() => {
    //   userStore.logout()
    //   router.push('/login')
    // }, 1500)
  } catch (error) {
    if (error !== false) {
      console.error('密码修改失败:', error)
      ElMessage.error('密码修改失败')
    }
  }
}
</script>

<style lang="scss" scoped>
.usercenter-page {
  min-height: 100vh;
  background: var(--ios-bg);
  
  .usercenter-container {
    max-width: 1400px;
    margin: 0 auto;
    padding: 24px;
    
    .search-section {
      margin-bottom: 24px;
    }
    
    .content-wrapper {
      display: grid;
      grid-template-columns: 320px 1fr;
      gap: 24px;
      
      .profile-card {
        height: fit-content;
        text-align: center;
        
        .avatar-section {
          position: relative;
          display: inline-block;
          margin-bottom: 16px;
          
          .avatar-uploader {
            position: absolute;
            bottom: 0;
            right: 0;
            
            :deep(.el-button) {
              box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
            }
          }
        }
        
        .username {
          font-size: 24px;
          font-weight: 600;
          margin: 0 0 8px 0;
          color: var(--ios-text-primary);
        }
        
        .user-role {
          margin: 0 0 24px 0;
        }
        
        .user-stats {
          display: flex;
          align-items: center;
          justify-content: space-around;
          padding: 24px 0 0;
          border-top: 1px solid var(--ios-separator);
          
          .stat-item {
            text-align: center;
            
            .stat-value {
              font-size: 24px;
              font-weight: 600;
              color: var(--ios-primary);
              margin-bottom: 4px;
            }
            
            .stat-label {
              font-size: 13px;
              color: var(--ios-text-tertiary);
            }
          }
          
          .stat-divider {
            width: 1px;
            height: 40px;
            background: var(--ios-separator);
          }
        }
      }
      
      .info-section {
        display: flex;
        flex-direction: column;
        gap: 24px;
        
        .info-card {
          .card-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 24px;
            
            .card-title {
              display: flex;
              align-items: center;
              gap: 8px;
              font-size: 18px;
              font-weight: 600;
              margin: 0;
              color: var(--ios-text-primary);
              
              .el-icon {
                font-size: 20px;
                color: var(--ios-primary);
              }
            }
            
            .edit-actions {
              display: flex;
              gap: 8px;
            }
          }
          
          .user-form {
            :deep(.el-form-item) {
              margin-bottom: 20px;
            }
            
            :deep(.el-input.is-disabled) {
              .el-input__wrapper {
                background: var(--ios-bg);
              }
            }
          }
          
          .security-items {
            .security-item {
              display: flex;
              align-items: center;
              justify-content: space-between;
              padding: 16px 0;
              border-bottom: 1px solid var(--ios-separator);
              
              &:last-child {
                border-bottom: none;
              }
              
              .item-left {
                display: flex;
                align-items: center;
                gap: 12px;
                
                .item-icon {
                  font-size: 24px;
                  color: var(--ios-primary);
                }
                
                .item-info {
                  .item-title {
                    font-size: 15px;
                    font-weight: 500;
                    color: var(--ios-text-primary);
                    margin-bottom: 4px;
                  }
                  
                  .item-desc {
                    font-size: 13px;
                    color: var(--ios-text-tertiary);
                  }
                }
              }
            }
          }
          
          .settings-items {
            .setting-item {
              display: flex;
              align-items: center;
              justify-content: space-between;
              padding: 16px 0;
              border-bottom: 1px solid var(--ios-separator);
              
              &:last-child {
                border-bottom: none;
              }
              
              .setting-label {
                display: flex;
                align-items: center;
                gap: 8px;
                font-size: 15px;
                font-weight: 500;
                color: var(--ios-text-primary);
                
                .el-icon {
                  font-size: 18px;
                  color: var(--ios-primary);
                }
              }
            }
          }
        }
      }
    }
  }
}

@media (max-width: 768px) {
  .usercenter-page {
    .usercenter-container {
      padding: 16px;
      
      .content-wrapper {
        grid-template-columns: 1fr;
      }
    }
  }
}
</style>

