<template>
  <div class="login-page">
    <div class="login-background">
      <div class="bg-shape shape-1"></div>
      <div class="bg-shape shape-2"></div>
      <div class="bg-shape shape-3"></div>
    </div>
    
    <div class="login-container">
      <div class="login-card ios-card">
        <!-- Logo和标题 -->
        <div class="login-header">
          <div class="login-logo">
            <el-icon><OfficeBuilding /></el-icon>
          </div>
          <h1 class="login-title">部门信息管理系统</h1>
          <p class="login-subtitle">欢迎登录</p>
        </div>
        
        <!-- 登录表单 -->
        <el-form
          ref="loginFormRef"
          :model="loginForm"
          :rules="loginRules"
          class="login-form"
          @submit.prevent="handleLogin"
        >
          <!-- 角色选择 -->
          <div class="role-selector">
            <div
              class="role-item"
              :class="{ active: loginForm.role === 'user' }"
              @click="loginForm.role = 'user'"
            >
              <el-icon><User /></el-icon>
              <span>普通用户</span>
            </div>
            <div
              class="role-item"
              :class="{ active: loginForm.role === 'admin' }"
              @click="loginForm.role = 'admin'"
            >
              <el-icon><UserFilled /></el-icon>
              <span>管理员</span>
            </div>
          </div>
          
          <!-- 用户名 -->
          <el-form-item prop="username">
            <el-input
              v-model="loginForm.username"
              placeholder="请输入用户名"
              size="large"
              clearable
            >
              <template #prefix>
                <el-icon><User /></el-icon>
              </template>
            </el-input>
          </el-form-item>
          
          <!-- 密码 -->
          <el-form-item prop="password">
            <el-input
              v-model="loginForm.password"
              type="password"
              placeholder="请输入密码"
              size="large"
              show-password
              clearable
              @keyup.enter="handleLogin"
            >
              <template #prefix>
                <el-icon><Lock /></el-icon>
              </template>
            </el-input>
          </el-form-item>
          
          <!-- 记住我 -->
          <el-form-item>
            <el-checkbox v-model="loginForm.remember">记住我</el-checkbox>
          </el-form-item>
          
          <!-- 登录按钮 -->
          <el-form-item>
            <el-button
              type="primary"
              size="large"
              :loading="loading"
              class="login-button"
              @click="handleLogin"
            >
              {{ loading ? '登录中...' : '登 录' }}
            </el-button>
          </el-form-item>
        </el-form>
        
        <!-- 提示信息 -->
        <div class="login-tips">
          <el-alert
            title="测试模式提示"
            type="info"
            :closable="false"
            show-icon
          >
            <template #default>
              <p>当前为测试模式，未绑定数据库前可直接登录</p>
              <p>用户名和密码随意输入即可</p>
            </template>
          </el-alert>
        </div>
      </div>
      
      <!-- 底部版权 -->
      <div class="login-footer">
        <p>© 2024 部门信息管理系统. All Rights Reserved.</p>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive } from 'vue'
import { useRouter } from 'vue-router'
import { useUserStore } from '@/store/user'
import { ElMessage } from 'element-plus'
import { OfficeBuilding, User, UserFilled, Lock } from '@element-plus/icons-vue'

const router = useRouter()
const userStore = useUserStore()

const loginFormRef = ref(null)
const loading = ref(false)

// 登录表单
const loginForm = reactive({
  username: '',
  password: '',
  role: 'user',
  remember: false
})

// 表单验证规则
const loginRules = {
  username: [
    { required: true, message: '请输入用户名', trigger: 'blur' },
    { min: 2, max: 20, message: '用户名长度在 2 到 20 个字符', trigger: 'blur' }
  ],
  password: [
    { required: true, message: '请输入密码', trigger: 'blur' },
    { min: 4, max: 20, message: '密码长度在 4 到 20 个字符', trigger: 'blur' }
  ]
}

// 处理登录
const handleLogin = async () => {
  try {
    // 表单验证
    await loginFormRef.value.validate()
    
    loading.value = true
    
    // 调用登录API
    const response = await userStore.login(
      loginForm.username,
      loginForm.password,
      loginForm.role
    )
    
    if (response.code === 200) {
      ElMessage.success(response.message || '登录成功')
      
      // 跳转到首页
      setTimeout(() => {
        router.push('/home')
      }, 500)
    }
  } catch (error) {
    if (error !== false) { // 验证失败时error为false
      console.error('登录失败:', error)
      ElMessage.error('登录失败，请检查用户名和密码')
    }
  } finally {
    loading.value = false
  }
}
</script>

<style lang="scss" scoped>
.login-page {
  width: 100%;
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  position: relative;
  overflow: hidden;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  
  .login-background {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    overflow: hidden;
    
    .bg-shape {
      position: absolute;
      border-radius: 50%;
      opacity: 0.1;
      animation: float 20s infinite ease-in-out;
      
      &.shape-1 {
        width: 300px;
        height: 300px;
        background: white;
        top: -100px;
        left: -100px;
        animation-delay: 0s;
      }
      
      &.shape-2 {
        width: 400px;
        height: 400px;
        background: white;
        bottom: -150px;
        right: -150px;
        animation-delay: 5s;
      }
      
      &.shape-3 {
        width: 200px;
        height: 200px;
        background: white;
        top: 50%;
        right: 10%;
        animation-delay: 10s;
      }
    }
  }
  
  .login-container {
    position: relative;
    z-index: 1;
    width: 100%;
    max-width: 440px;
    padding: 24px;
    animation: slideInUp 0.6s cubic-bezier(0.4, 0, 0.2, 1);
    
    .login-card {
      padding: 40px;
      
      .login-header {
        text-align: center;
        margin-bottom: 32px;
        
        .login-logo {
          width: 80px;
          height: 80px;
          margin: 0 auto 16px;
          background: linear-gradient(135deg, var(--ios-primary), var(--ios-info));
          border-radius: var(--border-radius-xl);
          display: flex;
          align-items: center;
          justify-content: center;
          box-shadow: 0 8px 24px rgba(0, 122, 255, 0.3);
          
          .el-icon {
            font-size: 40px;
            color: white;
          }
        }
        
        .login-title {
          font-size: 24px;
          font-weight: 600;
          color: var(--ios-text-primary);
          margin: 0 0 8px 0;
        }
        
        .login-subtitle {
          font-size: 14px;
          color: var(--ios-text-tertiary);
          margin: 0;
        }
      }
      
      .login-form {
        .role-selector {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 12px;
          margin-bottom: 24px;
          
          .role-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 8px;
            padding: 16px;
            border: 2px solid var(--ios-separator);
            border-radius: var(--border-radius-lg);
            cursor: pointer;
            transition: all 0.3s ease;
            
            .el-icon {
              font-size: 32px;
              color: var(--ios-text-tertiary);
              transition: color 0.3s ease;
            }
            
            span {
              font-size: 14px;
              font-weight: 500;
              color: var(--ios-text-secondary);
              transition: color 0.3s ease;
            }
            
            &:hover {
              border-color: var(--ios-primary);
              background: rgba(0, 122, 255, 0.05);
            }
            
            &.active {
              border-color: var(--ios-primary);
              background: rgba(0, 122, 255, 0.1);
              
              .el-icon,
              span {
                color: var(--ios-primary);
              }
            }
          }
        }
        
        .el-form-item {
          margin-bottom: 20px;
        }
        
        .login-button {
          width: 100%;
          height: 48px;
          font-size: 16px;
          font-weight: 600;
          border-radius: var(--border-radius-lg);
          margin-top: 8px;
        }
      }
      
      .login-tips {
        margin-top: 24px;
        
        :deep(.el-alert) {
          border-radius: var(--border-radius-md);
          
          .el-alert__description {
            margin-top: 8px;
            
            p {
              margin: 4px 0;
              font-size: 13px;
            }
          }
        }
      }
    }
    
    .login-footer {
      margin-top: 24px;
      text-align: center;
      
      p {
        color: rgba(255, 255, 255, 0.8);
        font-size: 13px;
        margin: 0;
      }
    }
  }
}

@keyframes float {
  0%, 100% {
    transform: translate(0, 0) scale(1);
  }
  33% {
    transform: translate(30px, -30px) scale(1.1);
  }
  66% {
    transform: translate(-20px, 20px) scale(0.9);
  }
}

@media (max-width: 768px) {
  .login-page {
    .login-container {
      padding: 16px;
      
      .login-card {
        padding: 24px;
      }
    }
  }
}
</style>

