<template>
  <div class="employee-page">
    <layout-header />
    
    <div class="employee-container">
      <!-- 搜索栏 -->
      <div class="search-section">
        <search-bar
          placeholder="搜索员工姓名、工段..."
          search-type="employee"
          :local-search="true"
          :local-data="allEmployees"
          @select="viewEmployeeDetail"
        />
      </div>
      
      <!-- 工段切换标签 -->
      <div class="section-tabs">
        <div
          v-for="section in sections"
          :key="section.id"
          class="tab-item"
          :class="{ active: currentSection === section.id }"
          @click="switchSection(section.id)"
        >
          <div class="tab-icon">{{ section.id }}</div>
          <div class="tab-info">
            <div class="tab-name">{{ section.name }}</div>
            <div class="tab-count">{{ section.employees.length }}人</div>
          </div>
        </div>
      </div>
      
      <!-- 人员架构图 -->
      <transition name="fade" mode="out-in">
        <div :key="currentSection" class="org-chart">
          <!-- 工段长 -->
          <div class="leader-section">
            <div
              v-if="currentLeader"
              class="employee-card leader-card"
              @click="viewEmployeeDetail(currentLeader)"
            >
              <div class="card-header">
                <el-avatar :src="currentLeader.avatar" :size="80">
                  {{ currentLeader.name.charAt(0) }}
                </el-avatar>
                <div class="leader-badge">
                  <el-icon><Star /></el-icon>
                  工段长
                </div>
              </div>
              <div class="card-body">
                <h3 class="employee-name">{{ currentLeader.name }}</h3>
                <p class="employee-position">{{ currentLeader.position }}</p>
                <div class="employee-info">
                  <div class="info-item">
                    <el-icon><Phone /></el-icon>
                    {{ currentLeader.phone }}
                  </div>
                  <div class="info-item">
                    <el-icon><Message /></el-icon>
                    {{ currentLeader.email }}
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <!-- 连接线 -->
          <div class="connection-line"></div>
          
          <!-- 普通员工 -->
          <div class="employees-grid">
            <div
              v-for="employee in currentEmployees"
              :key="employee.id"
              class="employee-card"
              @click="viewEmployeeDetail(employee)"
            >
              <div class="card-header">
                <el-avatar :src="employee.avatar" :size="60">
                  {{ employee.name.charAt(0) }}
                </el-avatar>
                <el-tag
                  v-if="employee.status === 'active'"
                  size="small"
                  type="success"
                  effect="plain"
                >
                  在岗
                </el-tag>
                <el-tag
                  v-else
                  size="small"
                  type="info"
                  effect="plain"
                >
                  离岗
                </el-tag>
              </div>
              <div class="card-body">
                <h4 class="employee-name">{{ employee.name }}</h4>
                <p class="employee-position">{{ employee.position }}</p>
                <div class="employee-stats">
                  <div class="stat-item">
                    <span class="stat-label">工号</span>
                    <span class="stat-value">{{ employee.employeeId }}</span>
                  </div>
                  <div class="stat-item">
                    <span class="stat-label">入职</span>
                    <span class="stat-value">{{ formatDate(employee.joinDate) }}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </transition>
    </div>
    
    <!-- 员工详情对话框 -->
    <el-dialog
      v-model="detailDialogVisible"
      :title="selectedEmployee?.name"
      width="600px"
      class="employee-dialog"
    >
      <div v-if="selectedEmployee" class="employee-detail">
        <div class="detail-header">
          <el-avatar :src="selectedEmployee.avatar" :size="100">
            {{ selectedEmployee.name.charAt(0) }}
          </el-avatar>
          <div class="detail-basic">
            <h2>{{ selectedEmployee.name }}</h2>
            <p class="position">{{ selectedEmployee.position }}</p>
            <div class="badges">
              <el-tag v-if="selectedEmployee.isLeader" type="warning">
                <el-icon><Star /></el-icon>
                工段长
              </el-tag>
              <el-tag :type="selectedEmployee.status === 'active' ? 'success' : 'info'">
                {{ selectedEmployee.status === 'active' ? '在岗' : '离岗' }}
              </el-tag>
            </div>
          </div>
        </div>
        
        <el-divider />
        
        <div class="detail-content">
          <div class="detail-row">
            <div class="detail-label">
              <el-icon><User /></el-icon>
              工号
            </div>
            <div class="detail-value">{{ selectedEmployee.employeeId }}</div>
          </div>
          <div class="detail-row">
            <div class="detail-label">
              <el-icon><OfficeBuilding /></el-icon>
              工段
            </div>
            <div class="detail-value">{{ selectedEmployee.section }}工段</div>
          </div>
          <div class="detail-row">
            <div class="detail-label">
              <el-icon><Phone /></el-icon>
              电话
            </div>
            <div class="detail-value">{{ selectedEmployee.phone }}</div>
          </div>
          <div class="detail-row">
            <div class="detail-label">
              <el-icon><Message /></el-icon>
              邮箱
            </div>
            <div class="detail-value">{{ selectedEmployee.email }}</div>
          </div>
          <div class="detail-row">
            <div class="detail-label">
              <el-icon><Calendar /></el-icon>
              入职日期
            </div>
            <div class="detail-value">{{ formatFullDate(selectedEmployee.joinDate) }}</div>
          </div>
          <div v-if="selectedEmployee.skills && selectedEmployee.skills.length" class="detail-row">
            <div class="detail-label">
              <el-icon><Medal /></el-icon>
              技能
            </div>
            <div class="detail-value">
              <el-tag
                v-for="skill in selectedEmployee.skills"
                :key="skill"
                size="small"
                style="margin-right: 8px"
              >
                {{ skill }}
              </el-tag>
            </div>
          </div>
        </div>
      </div>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import {
  Star,
  Phone,
  Message,
  User,
  OfficeBuilding,
  Calendar,
  Medal
} from '@element-plus/icons-vue'
import LayoutHeader from '@/components/LayoutHeader.vue'
import SearchBar from '@/components/SearchBar.vue'
import { employeeAPI } from '@/api'

// 当前选中工段
const currentSection = ref(1)

// Mock数据 - 实际使用时从API获取
const sections = ref([
  {
    id: 1,
    name: '第一工段',
    leader: {
      id: 101,
      name: '张三',
      position: '工段长',
      section: 1,
      employeeId: 'E001',
      phone: '13800138001',
      email: 'zhangsan@company.com',
      avatar: '',
      isLeader: true,
      status: 'active',
      joinDate: new Date('2020-01-15'),
      skills: ['管理', '技术指导', '质量把控']
    },
    employees: [
      {
        id: 102,
        name: '李四',
        position: '技术员',
        section: 1,
        employeeId: 'E002',
        phone: '13800138002',
        email: 'lisi@company.com',
        avatar: '',
        isLeader: false,
        status: 'active',
        joinDate: new Date('2021-03-20'),
        skills: ['焊接', '机械加工']
      },
      {
        id: 103,
        name: '王五',
        position: '技术员',
        section: 1,
        employeeId: 'E003',
        phone: '13800138003',
        email: 'wangwu@company.com',
        avatar: '',
        isLeader: false,
        status: 'active',
        joinDate: new Date('2021-06-10'),
        skills: ['电气', '维修']
      },
      {
        id: 104,
        name: '赵六',
        position: '操作工',
        section: 1,
        employeeId: 'E004',
        phone: '13800138004',
        email: 'zhaoliu@company.com',
        avatar: '',
        isLeader: false,
        status: 'active',
        joinDate: new Date('2022-01-05'),
        skills: ['设备操作']
      }
    ]
  },
  {
    id: 2,
    name: '第二工段',
    leader: {
      id: 201,
      name: '孙七',
      position: '工段长',
      section: 2,
      employeeId: 'E005',
      phone: '13800138005',
      email: 'sunqi@company.com',
      avatar: '',
      isLeader: true,
      status: 'active',
      joinDate: new Date('2019-08-12'),
      skills: ['管理', '生产调度', '安全管理']
    },
    employees: [
      {
        id: 202,
        name: '周八',
        position: '技术员',
        section: 2,
        employeeId: 'E006',
        phone: '13800138006',
        email: 'zhouba@company.com',
        avatar: '',
        isLeader: false,
        status: 'active',
        joinDate: new Date('2020-11-20'),
        skills: ['数控', '编程']
      },
      {
        id: 203,
        name: '吴九',
        position: '技术员',
        section: 2,
        employeeId: 'E007',
        phone: '13800138007',
        email: 'wujiu@company.com',
        avatar: '',
        isLeader: false,
        status: 'active',
        joinDate: new Date('2021-04-15'),
        skills: ['检测', '质量控制']
      }
    ]
  },
  {
    id: 3,
    name: '第三工段',
    leader: {
      id: 301,
      name: '郑十',
      position: '工段长',
      section: 3,
      employeeId: 'E008',
      phone: '13800138008',
      email: 'zhengshi@company.com',
      avatar: '',
      isLeader: true,
      status: 'active',
      joinDate: new Date('2018-05-20'),
      skills: ['管理', '工艺改进', '成本控制']
    },
    employees: [
      {
        id: 302,
        name: '冯十一',
        position: '技术员',
        section: 3,
        employeeId: 'E009',
        phone: '13800138009',
        email: 'fengshiyi@company.com',
        avatar: '',
        isLeader: false,
        status: 'active',
        joinDate: new Date('2020-07-08'),
        skills: ['装配', '调试']
      }
    ]
  },
  {
    id: 4,
    name: '第四工段',
    leader: {
      id: 401,
      name: '陈十二',
      position: '工段长',
      section: 4,
      employeeId: 'E010',
      phone: '13800138010',
      email: 'chenshier@company.com',
      avatar: '',
      isLeader: true,
      status: 'active',
      joinDate: new Date('2019-02-14'),
      skills: ['管理', '技术创新']
    },
    employees: []
  },
  {
    id: 5,
    name: '第五工段',
    leader: {
      id: 501,
      name: '褚十三',
      position: '工段长',
      section: 5,
      employeeId: 'E011',
      phone: '13800138011',
      email: 'chushisan@company.com',
      avatar: '',
      isLeader: true,
      status: 'active',
      joinDate: new Date('2018-09-25'),
      skills: ['管理', '设备管理']
    },
    employees: []
  }
])

// 当前工段信息
const currentSectionData = computed(() => {
  return sections.value.find(s => s.id === currentSection.value)
})

// 当前工段长
const currentLeader = computed(() => {
  return currentSectionData.value?.leader
})

// 当前工段员工
const currentEmployees = computed(() => {
  return currentSectionData.value?.employees || []
})

// 所有员工（用于搜索）
const allEmployees = computed(() => {
  const employees = []
  sections.value.forEach(section => {
    employees.push(section.leader)
    employees.push(...section.employees)
  })
  return employees
})

// 员工详情对话框
const detailDialogVisible = ref(false)
const selectedEmployee = ref(null)

// 页面加载
onMounted(() => {
  loadEmployees()
})

// 加载员工数据
const loadEmployees = async () => {
  try {
    const response = await employeeAPI.getList()
    if (response.code === 200 && response.data) {
      // 处理员工数据，按工段分组
      const employees = response.data
      
      // 重置sections数据
      sections.value.forEach(section => {
        const sectionEmployees = employees.filter(emp => emp.section === section.id)
        const leader = sectionEmployees.find(emp => emp.isLeader)
        const members = sectionEmployees.filter(emp => !emp.isLeader)
        
        if (leader) {
          section.leader = leader
        }
        section.employees = members
      })
    }
  } catch (error) {
    console.error('加载员工数据失败:', error)
    // 如果加载失败，保留mock数据
  }
}

// 切换工段
const switchSection = (sectionId) => {
  currentSection.value = sectionId
}

// 查看员工详情
const viewEmployeeDetail = (employee) => {
  selectedEmployee.value = employee
  detailDialogVisible.value = true
}

// 格式化日期
const formatDate = (date) => {
  if (!date) return '-'
  const d = new Date(date)
  const year = d.getFullYear()
  return `${year}年`
}

// 格式化完整日期
const formatFullDate = (date) => {
  if (!date) return '-'
  const d = new Date(date)
  return d.toLocaleDateString('zh-CN')
}
</script>

<style lang="scss" scoped>
.employee-page {
  min-height: 100vh;
  background: var(--ios-bg);
  
  .employee-container {
    max-width: 1400px;
    margin: 0 auto;
    padding: 24px;
    
    .search-section {
      margin-bottom: 24px;
    }
    
    .section-tabs {
      display: flex;
      gap: 16px;
      margin-bottom: 32px;
      overflow-x: auto;
      padding-bottom: 8px;
      
      &::-webkit-scrollbar {
        height: 4px;
      }
      
      .tab-item {
        flex-shrink: 0;
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 16px 20px;
        background: var(--ios-card-bg);
        border-radius: var(--border-radius-lg);
        box-shadow: var(--ios-shadow);
        cursor: pointer;
        transition: all 0.3s ease;
        
        &:hover {
          transform: translateY(-2px);
          box-shadow: var(--ios-shadow-hover);
        }
        
        &.active {
          background: linear-gradient(135deg, var(--ios-primary), var(--ios-info));
          color: white;
          
          .tab-icon {
            background: rgba(255, 255, 255, 0.2);
            color: white;
          }
          
          .tab-info {
            .tab-name,
            .tab-count {
              color: white;
            }
          }
        }
        
        .tab-icon {
          width: 48px;
          height: 48px;
          display: flex;
          align-items: center;
          justify-content: center;
          background: var(--ios-bg);
          border-radius: var(--border-radius-md);
          font-size: 20px;
          font-weight: 600;
          color: var(--ios-primary);
        }
        
        .tab-info {
          .tab-name {
            font-size: 15px;
            font-weight: 600;
            color: var(--ios-text-primary);
            margin-bottom: 4px;
          }
          
          .tab-count {
            font-size: 13px;
            color: var(--ios-text-tertiary);
          }
        }
      }
    }
    
    .org-chart {
      .leader-section {
        display: flex;
        justify-content: center;
        margin-bottom: 40px;
        
        .leader-card {
          width: 320px;
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          color: white;
          border: none;
          
          .card-header {
            position: relative;
            display: flex;
            justify-content: center;
            margin-bottom: 16px;
            
            .leader-badge {
              position: absolute;
              top: 0;
              right: 0;
              display: flex;
              align-items: center;
              gap: 4px;
              padding: 4px 12px;
              background: rgba(255, 255, 255, 0.2);
              border-radius: var(--border-radius-sm);
              font-size: 12px;
              font-weight: 600;
              backdrop-filter: blur(10px);
            }
          }
          
          .card-body {
            .employee-name {
              color: white;
            }
            
            .employee-position {
              color: rgba(255, 255, 255, 0.9);
            }
            
            .employee-info {
              .info-item {
                color: rgba(255, 255, 255, 0.9);
              }
            }
          }
        }
      }
      
      .connection-line {
        height: 40px;
        width: 2px;
        background: linear-gradient(to bottom, var(--ios-primary), transparent);
        margin: 0 auto 40px;
      }
      
      .employees-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
        gap: 20px;
      }
      
      .employee-card {
        background: var(--ios-card-bg);
        border-radius: var(--border-radius-xl);
        padding: 24px;
        box-shadow: var(--ios-shadow);
        cursor: pointer;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        
        &:hover {
          transform: translateY(-4px);
          box-shadow: var(--ios-shadow-hover);
        }
        
        .card-header {
          display: flex;
          flex-direction: column;
          align-items: center;
          margin-bottom: 16px;
          gap: 12px;
        }
        
        .card-body {
          text-align: center;
          
          .employee-name {
            font-size: 17px;
            font-weight: 600;
            color: var(--ios-text-primary);
            margin: 0 0 8px 0;
          }
          
          .employee-position {
            font-size: 14px;
            color: var(--ios-text-tertiary);
            margin: 0 0 16px 0;
          }
          
          .employee-info {
            display: flex;
            flex-direction: column;
            gap: 8px;
            
            .info-item {
              display: flex;
              align-items: center;
              justify-content: center;
              gap: 6px;
              font-size: 13px;
              color: var(--ios-text-secondary);
              
              .el-icon {
                font-size: 14px;
              }
            }
          }
          
          .employee-stats {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 12px;
            margin-top: 16px;
            padding-top: 16px;
            border-top: 1px solid var(--ios-separator);
            
            .stat-item {
              display: flex;
              flex-direction: column;
              gap: 4px;
              
              .stat-label {
                font-size: 12px;
                color: var(--ios-text-tertiary);
              }
              
              .stat-value {
                font-size: 14px;
                font-weight: 500;
                color: var(--ios-text-primary);
              }
            }
          }
        }
      }
    }
  }
}

.employee-dialog {
  .employee-detail {
    .detail-header {
      display: flex;
      gap: 20px;
      align-items: center;
      
      .detail-basic {
        flex: 1;
        
        h2 {
          font-size: 24px;
          font-weight: 600;
          margin: 0 0 8px 0;
        }
        
        .position {
          font-size: 16px;
          color: var(--ios-text-tertiary);
          margin: 0 0 12px 0;
        }
        
        .badges {
          display: flex;
          gap: 8px;
        }
      }
    }
    
    .detail-content {
      .detail-row {
        display: flex;
        align-items: center;
        padding: 12px 0;
        border-bottom: 1px solid var(--ios-separator);
        
        &:last-child {
          border-bottom: none;
        }
        
        .detail-label {
          display: flex;
          align-items: center;
          gap: 8px;
          width: 120px;
          font-size: 14px;
          font-weight: 500;
          color: var(--ios-text-secondary);
          
          .el-icon {
            font-size: 16px;
            color: var(--ios-primary);
          }
        }
        
        .detail-value {
          flex: 1;
          font-size: 14px;
          color: var(--ios-text-primary);
        }
      }
    }
  }
}

@media (max-width: 768px) {
  .employee-page {
    .employee-container {
      padding: 16px;
      
      .employees-grid {
        grid-template-columns: 1fr;
      }
    }
  }
}
</style>

