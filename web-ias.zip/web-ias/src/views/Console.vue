<template>
  <div class="console-page">
    <layout-header />
    
    <div class="console-container">
      <!-- 搜索栏 -->
      <div class="search-section">
        <search-bar placeholder="搜索管理内容..." />
      </div>
      
      <!-- 统计卡片 -->
      <div class="stats-grid">
        <div class="stat-card" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%)">
          <div class="stat-icon">
            <el-icon><User /></el-icon>
          </div>
          <div class="stat-content">
            <div class="stat-value">{{ stats.totalUsers }}</div>
            <div class="stat-label">总用户数</div>
          </div>
        </div>
        
        <div class="stat-card" style="background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%)">
          <div class="stat-icon">
            <el-icon><Bell /></el-icon>
          </div>
          <div class="stat-content">
            <div class="stat-value">{{ stats.totalAnnouncements }}</div>
            <div class="stat-label">公告总数</div>
          </div>
        </div>
        
        <div class="stat-card" style="background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)">
          <div class="stat-icon">
            <el-icon><Link /></el-icon>
          </div>
          <div class="stat-content">
            <div class="stat-value">{{ stats.totalLinks }}</div>
            <div class="stat-label">网址总数</div>
          </div>
        </div>
        
        <div class="stat-card" style="background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%)">
          <div class="stat-icon">
            <el-icon><UserFilled /></el-icon>
          </div>
          <div class="stat-content">
            <div class="stat-value">{{ stats.totalEmployees }}</div>
            <div class="stat-label">员工总数</div>
          </div>
        </div>
      </div>
      
      <!-- 管理标签页 -->
      <div class="management-section">
        <el-tabs v-model="activeTab" type="card" class="console-tabs">
          <!-- 公告管理 -->
          <el-tab-pane label="公告管理" name="announcement">
            <template #label>
              <span class="tab-label">
                <el-icon><Bell /></el-icon>
                公告管理
              </span>
            </template>
            
            <div class="tab-content">
              <div class="content-header">
                <el-button type="primary" @click="openAnnouncementDialog()">
                  <el-icon><Plus /></el-icon>
                  添加公告
                </el-button>
              </div>
              
              <el-table :data="announcements" stripe class="data-table">
                <el-table-column prop="id" label="ID" width="80" />
                <el-table-column prop="title" label="标题" min-width="200" />
                <el-table-column prop="priority" label="优先级" width="100">
                  <template #default="{ row }">
                    <el-tag :type="getPriorityType(row.priority)">
                      {{ getPriorityText(row.priority) }}
                    </el-tag>
                  </template>
                </el-table-column>
                <el-table-column prop="publisher" label="发布人" width="120" />
                <el-table-column prop="publishTime" label="发布时间" width="180">
                  <template #default="{ row }">
                    {{ formatDateTime(row.publishTime) }}
                  </template>
                </el-table-column>
                <el-table-column label="操作" width="150" fixed="right">
                  <template #default="{ row }">
                    <el-button text type="primary" @click="openAnnouncementDialog(row)">
                      编辑
                    </el-button>
                    <el-button text type="danger" @click="deleteAnnouncement(row)">
                      删除
                    </el-button>
                  </template>
                </el-table-column>
              </el-table>
            </div>
          </el-tab-pane>
          
          <!-- 员工管理 -->
          <el-tab-pane label="员工管理" name="employee">
            <template #label>
              <span class="tab-label">
                <el-icon><UserFilled /></el-icon>
                员工管理
              </span>
            </template>
            
            <div class="tab-content">
              <div class="content-header">
                <el-button type="primary" @click="openEmployeeImport">
                  <el-icon><Upload /></el-icon>
                  导入Excel
                </el-button>
                <el-button @click="exportEmployees">
                  <el-icon><Download /></el-icon>
                  导出Excel
                </el-button>
              </div>
              
              <el-table :data="employees" stripe class="data-table">
                <el-table-column prop="employeeId" label="工号" width="100" />
                <el-table-column prop="name" label="姓名" width="120" />
                <el-table-column prop="section" label="工段" width="100">
                  <template #default="{ row }">
                    {{ row.section }}工段
                  </template>
                </el-table-column>
                <el-table-column prop="position" label="职位" width="120" />
                <el-table-column prop="phone" label="电话" width="140" />
                <el-table-column prop="email" label="邮箱" min-width="200" />
                <el-table-column prop="status" label="状态" width="100">
                  <template #default="{ row }">
                    <el-tag :type="row.status === 'active' ? 'success' : 'info'">
                      {{ row.status === 'active' ? '在岗' : '离岗' }}
                    </el-tag>
                  </template>
                </el-table-column>
                <el-table-column label="操作" width="150" fixed="right">
                  <template #default="{ row }">
                    <el-button text type="primary" @click="openEmployeeDialog(row)">
                      编辑
                    </el-button>
                    <el-button text type="danger" @click="deleteEmployee(row)">
                      删除
                    </el-button>
                  </template>
                </el-table-column>
              </el-table>
            </div>
          </el-tab-pane>
          
          <!-- 轮播图管理 -->
          <el-tab-pane label="轮播图管理" name="carousel">
            <template #label>
              <span class="tab-label">
                <el-icon><Picture /></el-icon>
                轮播图管理
              </span>
            </template>
            
            <div class="tab-content">
              <div class="content-header">
                <el-button type="primary" @click="openCarouselDialog()">
                  <el-icon><Plus /></el-icon>
                  添加轮播图
                </el-button>
              </div>
              
              <div class="carousel-grid">
                <div
                  v-for="item in carousels"
                  :key="item.id"
                  class="carousel-item"
                >
                  <div class="carousel-image" :style="{ backgroundImage: `url(${item.image})` }">
                    <div class="carousel-overlay">
                      <el-button type="primary" circle @click="openCarouselDialog(item)">
                        <el-icon><Edit /></el-icon>
                      </el-button>
                      <el-button type="danger" circle @click="deleteCarousel(item)">
                        <el-icon><Delete /></el-icon>
                      </el-button>
                    </div>
                  </div>
                  <div class="carousel-info">
                    <h4>{{ item.title }}</h4>
                    <p>{{ item.description }}</p>
                  </div>
                </div>
              </div>
            </div>
          </el-tab-pane>
          
          <!-- 网址管理 -->
          <el-tab-pane label="网址管理" name="link">
            <template #label>
              <span class="tab-label">
                <el-icon><Link /></el-icon>
                网址管理
              </span>
            </template>
            
            <div class="tab-content">
              <div class="content-header">
                <el-button type="primary" @click="openLinkDialog()">
                  <el-icon><Plus /></el-icon>
                  添加网址
                </el-button>
                <el-button @click="importLinksExcel">
                  <el-icon><Upload /></el-icon>
                  导入Excel
                </el-button>
              </div>
              
              <el-table :data="links" stripe class="data-table">
                <el-table-column prop="id" label="ID" width="80" />
                <el-table-column prop="name" label="名称" width="200" />
                <el-table-column prop="url" label="网址" min-width="300" />
                <el-table-column prop="category" label="分类" width="120">
                  <template #default="{ row }">
                    <el-tag>{{ getCategoryName(row.category) }}</el-tag>
                  </template>
                </el-table-column>
                <el-table-column label="操作" width="150" fixed="right">
                  <template #default="{ row }">
                    <el-button text type="primary" @click="openLinkDialog(row)">
                      编辑
                    </el-button>
                    <el-button text type="danger" @click="deleteLink(row)">
                      删除
                    </el-button>
                  </template>
                </el-table-column>
              </el-table>
            </div>
          </el-tab-pane>
        </el-tabs>
      </div>
    </div>
    
    <!-- 公告编辑对话框 -->
    <el-dialog
      v-model="announcementDialogVisible"
      :title="announcementForm.id ? '编辑公告' : '添加公告'"
      width="600px"
    >
      <el-form :model="announcementForm" label-width="80px">
        <el-form-item label="标题">
          <el-input v-model="announcementForm.title" placeholder="请输入标题" />
        </el-form-item>
        <el-form-item label="内容">
          <el-input
            v-model="announcementForm.content"
            type="textarea"
            :rows="5"
            placeholder="请输入内容"
          />
        </el-form-item>
        <el-form-item label="优先级">
          <el-select v-model="announcementForm.priority" placeholder="请选择优先级">
            <el-option label="普通" value="normal" />
            <el-option label="中等" value="medium" />
            <el-option label="重要" value="high" />
          </el-select>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="announcementDialogVisible = false">取消</el-button>
        <el-button type="primary" @click="saveAnnouncement">保存</el-button>
      </template>
    </el-dialog>
    
    <!-- 员工导入对话框 -->
    <el-dialog v-model="employeeImportVisible" title="导入员工" width="600px">
      <el-alert
        title="导入说明"
        type="info"
        :closable="false"
        style="margin-bottom: 20px"
      >
        <template #default>
          <p>Excel文件应包含以下列：</p>
          <ul>
            <li>工号、姓名、工段、职位、电话、邮箱、状态</li>
          </ul>
        </template>
      </el-alert>
      
      <el-upload
        ref="employeeUploadRef"
        :auto-upload="false"
        :limit="1"
        accept=".xlsx,.xls"
        drag
      >
        <el-icon class="el-icon--upload"><UploadFilled /></el-icon>
        <div class="el-upload__text">
          将文件拖到此处，或<em>点击上传</em>
        </div>
      </el-upload>
      
      <template #footer>
        <el-button @click="employeeImportVisible = false">取消</el-button>
        <el-button type="primary" @click="submitEmployeeImport">确定导入</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { useUserStore } from '@/store/user'
import { ElMessage, ElMessageBox } from 'element-plus'
import {
  User,
  Bell,
  Link,
  UserFilled,
  Plus,
  Edit,
  Delete,
  Upload,
  Download,
  Picture,
  UploadFilled
} from '@element-plus/icons-vue'
import LayoutHeader from '@/components/LayoutHeader.vue'
import SearchBar from '@/components/SearchBar.vue'
import { announcementAPI, employeeAPI, carouselAPI, linkAPI, adminAPI } from '@/api'
import * as XLSX from 'xlsx'

const router = useRouter()
const userStore = useUserStore()

// 引入API
import { announcementAPI, employeeAPI, carouselAPI, linkAPI, adminAPI } from '@/api'

// 检查管理员权限
onMounted(() => {
  if (!userStore.isAdmin) {
    ElMessage.error('无权访问管理后台')
    router.push('/home')
  }
  loadData()
})

// 统计数据
const stats = ref({
  totalUsers: 45,
  totalAnnouncements: 12,
  totalLinks: 28,
  totalEmployees: 38
})

// 当前标签页
const activeTab = ref('announcement')

// 公告数据
const announcements = ref([
  {
    id: 1,
    title: '关于召开部门例会的通知',
    content: '定于本周五下午3点召开部门例会，请各工段长准时参加。',
    publisher: '张经理',
    publishTime: new Date('2024-01-15 10:00:00'),
    priority: 'high'
  },
  {
    id: 2,
    title: '系统维护公告',
    content: '本周六晚上10点至周日早上6点进行系统维护。',
    publisher: '技术部',
    publishTime: new Date('2024-01-14 15:30:00'),
    priority: 'medium'
  }
])

// 员工数据
const employees = ref([
  {
    id: 101,
    employeeId: 'E001',
    name: '张三',
    section: 1,
    position: '工段长',
    phone: '13800138001',
    email: 'zhangsan@company.com',
    status: 'active'
  },
  {
    id: 102,
    employeeId: 'E002',
    name: '李四',
    section: 1,
    position: '技术员',
    phone: '13800138002',
    email: 'lisi@company.com',
    status: 'active'
  }
])

// 轮播图数据
const carousels = ref([
  {
    id: 1,
    title: '欢迎使用部门信息管理系统',
    description: '高效管理，智能办公',
    image: 'https://images.unsplash.com/photo-1497366216548-37526070297c?w=800&h=400&fit=crop'
  },
  {
    id: 2,
    title: '人员架构一目了然',
    description: '清晰展示部门组织结构',
    image: 'https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=800&h=400&fit=crop'
  }
])

// 网址数据
const links = ref([
  {
    id: 1,
    name: 'OA办公系统',
    url: 'http://oa.example.com',
    category: 'office'
  },
  {
    id: 2,
    name: 'ERP管理系统',
    url: 'http://erp.example.com',
    category: 'business'
  }
])

// 公告对话框
const announcementDialogVisible = ref(false)
const announcementForm = reactive({
  id: null,
  title: '',
  content: '',
  priority: 'normal'
})

// 员工导入对话框
const employeeImportVisible = ref(false)
const employeeUploadRef = ref(null)

// 加载数据
const loadData = async () => {
  try {
    // 加载统计数据
    const statsRes = await adminAPI.getDashboardStats()
    if (statsRes.code === 200 && statsRes.data) {
      stats.value = statsRes.data
    }
    
    // 加载公告数据
    const announcementRes = await announcementAPI.getList({ page: 1, pageSize: 100 })
    if (announcementRes.code === 200) {
      announcements.value = announcementRes.data.records || announcementRes.data || []
    }
    
    // 加载员工数据
    const employeeRes = await employeeAPI.getList()
    if (employeeRes.code === 200 && employeeRes.data) {
      employees.value = employeeRes.data
    }
    
    // 加载轮播图数据
    const carouselRes = await carouselAPI.getList()
    if (carouselRes.code === 200 && carouselRes.data) {
      carousels.value = carouselRes.data
    }
    
    // 加载网址数据
    const linkRes = await linkAPI.getList()
    if (linkRes.code === 200 && linkRes.data) {
      links.value = linkRes.data
    }
  } catch (error) {
    console.error('加载数据失败:', error)
    // 如果加载失败，保留mock数据
  }
}

// 打开公告对话框
const openAnnouncementDialog = (item = null) => {
  if (item) {
    Object.assign(announcementForm, item)
  } else {
    announcementForm.id = null
    announcementForm.title = ''
    announcementForm.content = ''
    announcementForm.priority = 'normal'
  }
  announcementDialogVisible.value = true
}

// 保存公告
const saveAnnouncement = async () => {
  if (!announcementForm.title || !announcementForm.content) {
    ElMessage.warning('请填写完整信息')
    return
  }
  
  try {
    if (announcementForm.id) {
      // 更新
      await announcementAPI.update(announcementForm.id, announcementForm)
      ElMessage.success('更新成功')
    } else {
      // 添加
      const createData = {
        ...announcementForm,
        publisherId: userStore.userId,
        publisherName: userStore.username
      }
      await announcementAPI.create(createData)
      ElMessage.success('添加成功')
    }
    
    // 重新加载数据
    const announcementRes = await announcementAPI.getList({ page: 1, pageSize: 100 })
    if (announcementRes.code === 200) {
      announcements.value = announcementRes.data.records || announcementRes.data || []
    }
    
    announcementDialogVisible.value = false
  } catch (error) {
    console.error('保存公告失败:', error)
  }
}

// 删除公告
const deleteAnnouncement = async (item) => {
  try {
    await ElMessageBox.confirm('确定要删除这条公告吗？', '提示', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning'
    })
    
    await announcementAPI.delete({ id: item.id })
    
    const index = announcements.value.findIndex(a => a.id === item.id)
    if (index > -1) {
      announcements.value.splice(index, 1)
      ElMessage.success('删除成功')
    }
  } catch (error) {
    if (error !== 'cancel') {
      console.error('删除公告失败:', error)
    }
  }
}

// 打开员工导入
const openEmployeeImport = () => {
  employeeImportVisible.value = true
}

// 提交员工导入
const submitEmployeeImport = async () => {
  const files = employeeUploadRef.value?.uploadFiles
  if (!files || files.length === 0) {
    ElMessage.warning('请选择文件')
    return
  }
  
  try {
    const file = files[0].raw
    const res = await employeeAPI.importExcel(file)
    
    if (res.code === 200) {
      ElMessage.success(res.message || '导入成功')
      
      // 重新加载员工数据
      const employeeRes = await employeeAPI.getList()
      if (employeeRes.code === 200 && employeeRes.data) {
        employees.value = employeeRes.data
      }
      
      employeeImportVisible.value = false
      employeeUploadRef.value?.clearFiles()
    }
  } catch (error) {
    console.error('导入失败:', error)
  }
}

// 导出员工
const exportEmployees = async () => {
  try {
    // 调用后端导出接口
    const response = await employeeAPI.exportExcel()
    
    // 创建下载链接
    const url = window.URL.createObjectURL(new Blob([response]))
    const link = document.createElement('a')
    link.href = url
    link.setAttribute('download', `员工列表_${new Date().toLocaleDateString()}.xlsx`)
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
    window.URL.revokeObjectURL(url)
    
    ElMessage.success('导出成功')
  } catch (error) {
    console.error('导出失败:', error)
    ElMessage.error('导出失败')
  }
}

// 打开员工编辑对话框
const openEmployeeDialog = (item) => {
  ElMessage.info('打开员工编辑对话框')
}

// 删除员工
const deleteEmployee = async (item) => {
  try {
    await ElMessageBox.confirm('确定要删除这个员工吗？', '提示', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning'
    })
    
    await employeeAPI.delete({ id: item.id })
    
    const index = employees.value.findIndex(e => e.id === item.id)
    if (index > -1) {
      employees.value.splice(index, 1)
      ElMessage.success('删除成功')
    }
  } catch (error) {
    if (error !== 'cancel') {
      console.error('删除员工失败:', error)
    }
  }
}

// 轮播图相关
const openCarouselDialog = (item) => {
  ElMessage.info('打开轮播图编辑对话框')
}

const deleteCarousel = async (item) => {
  try {
    await ElMessageBox.confirm('确定要删除这个轮播图吗？', '提示', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning'
    })
    
    const index = carousels.value.findIndex(c => c.id === item.id)
    if (index > -1) {
      carousels.value.splice(index, 1)
      ElMessage.success('删除成功')
    }
  } catch (error) {
    // 取消操作
  }
}

// 网址相关
const openLinkDialog = (item) => {
  ElMessage.info('打开网址编辑对话框')
}

const importLinksExcel = () => {
  ElMessage.info('导入网址Excel')
}

const deleteLink = async (item) => {
  try {
    await ElMessageBox.confirm('确定要删除这个网址吗？', '提示', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning'
    })
    
    const index = links.value.findIndex(l => l.id === item.id)
    if (index > -1) {
      links.value.splice(index, 1)
      ElMessage.success('删除成功')
    }
  } catch (error) {
    // 取消操作
  }
}

// 工具函数
const getPriorityType = (priority) => {
  const map = {
    high: 'danger',
    medium: 'warning',
    normal: 'info'
  }
  return map[priority] || 'info'
}

const getPriorityText = (priority) => {
  const map = {
    high: '重要',
    medium: '中等',
    normal: '普通'
  }
  return map[priority] || '普通'
}

const getCategoryName = (category) => {
  const map = {
    office: '办公系统',
    business: '业务系统',
    learning: '学习培训',
    tool: '工具网站',
    other: '其他'
  }
  return map[category] || '其他'
}

const formatDateTime = (date) => {
  if (!date) return '-'
  return new Date(date).toLocaleString('zh-CN')
}
</script>

<style lang="scss" scoped>
.console-page {
  min-height: 100vh;
  background: var(--ios-bg);
  
  .console-container {
    max-width: 1400px;
    margin: 0 auto;
    padding: 24px;
    
    .search-section {
      margin-bottom: 24px;
    }
    
    .stats-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 20px;
      margin-bottom: 24px;
      
      .stat-card {
        display: flex;
        align-items: center;
        gap: 20px;
        padding: 24px;
        border-radius: var(--border-radius-xl);
        color: white;
        box-shadow: var(--ios-shadow-hover);
        
        .stat-icon {
          width: 64px;
          height: 64px;
          display: flex;
          align-items: center;
          justify-content: center;
          background: rgba(255, 255, 255, 0.2);
          border-radius: var(--border-radius-lg);
          
          .el-icon {
            font-size: 32px;
          }
        }
        
        .stat-content {
          .stat-value {
            font-size: 32px;
            font-weight: 600;
            margin-bottom: 4px;
          }
          
          .stat-label {
            font-size: 14px;
            opacity: 0.9;
          }
        }
      }
    }
    
    .management-section {
      background: var(--ios-card-bg);
      border-radius: var(--border-radius-xl);
      padding: 24px;
      box-shadow: var(--ios-shadow);
      
      .console-tabs {
        :deep(.el-tabs__header) {
          margin-bottom: 24px;
        }
        
        :deep(.el-tabs__item) {
          .tab-label {
            display: flex;
            align-items: center;
            gap: 6px;
          }
        }
        
        .tab-content {
          .content-header {
            display: flex;
            gap: 12px;
            margin-bottom: 20px;
          }
          
          .data-table {
            border-radius: var(--border-radius-lg);
            overflow: hidden;
          }
          
          .carousel-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 20px;
            
            .carousel-item {
              border-radius: var(--border-radius-lg);
              overflow: hidden;
              box-shadow: var(--ios-shadow);
              transition: all 0.3s ease;
              
              &:hover {
                box-shadow: var(--ios-shadow-hover);
                
                .carousel-overlay {
                  opacity: 1;
                }
              }
              
              .carousel-image {
                height: 200px;
                background-size: cover;
                background-position: center;
                position: relative;
                
                .carousel-overlay {
                  position: absolute;
                  top: 0;
                  left: 0;
                  right: 0;
                  bottom: 0;
                  background: rgba(0, 0, 0, 0.5);
                  display: flex;
                  align-items: center;
                  justify-content: center;
                  gap: 12px;
                  opacity: 0;
                  transition: opacity 0.3s ease;
                }
              }
              
              .carousel-info {
                padding: 16px;
                
                h4 {
                  font-size: 16px;
                  font-weight: 600;
                  margin: 0 0 8px 0;
                  color: var(--ios-text-primary);
                }
                
                p {
                  font-size: 13px;
                  color: var(--ios-text-tertiary);
                  margin: 0;
                  overflow: hidden;
                  text-overflow: ellipsis;
                  white-space: nowrap;
                }
              }
            }
          }
        }
      }
    }
  }
}

@media (max-width: 768px) {
  .console-page {
    .console-container {
      padding: 16px;
      
      .stats-grid {
        grid-template-columns: 1fr;
      }
    }
  }
}
</style>

