<template>
  <div class="transpath-page">
    <layout-header />
    
    <div class="transpath-container">
      <!-- 搜索栏 -->
      <div class="search-section">
        <search-bar
          placeholder="搜索网址名称..."
          search-type="link"
          :local-search="true"
          :local-data="links"
          @select="openLink"
        />
      </div>
      
      <!-- 页面标题 -->
      <div class="page-header">
        <div class="header-left">
          <h1 class="page-title">常用网址导航</h1>
          <p class="page-desc">快速访问常用业务网址</p>
        </div>
        <div class="header-right">
          <el-button v-if="userStore.isAdmin" type="primary" @click="importLinks">
            <el-icon><Upload /></el-icon>
            导入Excel
          </el-button>
        </div>
      </div>
      
      <!-- 分类标签 -->
      <div class="category-tabs">
        <div
          v-for="category in categories"
          :key="category.id"
          class="category-tab"
          :class="{ active: currentCategory === category.id }"
          @click="switchCategory(category.id)"
        >
          <el-icon>
            <component :is="category.icon" />
          </el-icon>
          <span>{{ category.name }}</span>
          <el-badge :value="category.count" />
        </div>
      </div>
      
      <!-- 网址列表 -->
      <transition name="fade" mode="out-in">
        <div :key="currentCategory" class="links-grid">
          <div
            v-for="link in filteredLinks"
            :key="link.id"
            class="link-card"
            @click="openLink(link)"
          >
            <div class="link-icon" :style="{ background: link.color }">
              <el-icon v-if="link.icon">
                <component :is="link.icon" />
              </el-icon>
              <span v-else class="icon-text">{{ link.name.charAt(0) }}</span>
            </div>
            <div class="link-content">
              <h3 class="link-name">{{ link.name }}</h3>
              <p class="link-url">{{ link.url }}</p>
              <div v-if="link.description" class="link-desc">
                {{ link.description }}
              </div>
            </div>
            <div class="link-actions">
              <el-button text circle @click.stop="copyLink(link)">
                <el-icon><DocumentCopy /></el-icon>
              </el-button>
              <el-button v-if="userStore.isAdmin" text circle type="danger" @click.stop="deleteLink(link)">
                <el-icon><Delete /></el-icon>
              </el-button>
            </div>
          </div>
          
          <!-- 空状态 -->
          <div v-if="filteredLinks.length === 0" class="empty-state">
            <el-empty description="该分类下暂无网址" />
          </div>
        </div>
      </transition>
    </div>
    
    <!-- Excel导入对话框 -->
    <el-dialog v-model="importDialogVisible" title="导入网址" width="600px">
      <div class="import-dialog">
        <el-alert
          title="导入说明"
          type="info"
          :closable="false"
          style="margin-bottom: 20px"
        >
          <template #default>
            <p>请上传包含以下列的Excel文件：</p>
            <ul>
              <li>名称（必填）</li>
              <li>网址（必填）</li>
              <li>分类（可选，如：办公、业务、学习等）</li>
              <li>描述（可选）</li>
            </ul>
          </template>
        </el-alert>
        
        <el-upload
          ref="uploadRef"
          :auto-upload="false"
          :limit="1"
          accept=".xlsx,.xls"
          :on-change="handleFileChange"
          drag
        >
          <el-icon class="el-icon--upload"><UploadFilled /></el-icon>
          <div class="el-upload__text">
            将文件拖到此处，或<em>点击上传</em>
          </div>
          <template #tip>
            <div class="el-upload__tip">
              只能上传 xlsx/xls 文件，且不超过 5MB
            </div>
          </template>
        </el-upload>
      </div>
      
      <template #footer>
        <el-button @click="importDialogVisible = false">取消</el-button>
        <el-button type="primary" :loading="uploading" @click="submitImport">
          确定导入
        </el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'
import { useUserStore } from '@/store/user'
import { ElMessage, ElMessageBox } from 'element-plus'
import {
  Upload,
  UploadFilled,
  Link,
  OfficeBuilding,
  Reading,
  Monitor,
  ShoppingCart,
  DocumentCopy,
  Delete
} from '@element-plus/icons-vue'
import LayoutHeader from '@/components/LayoutHeader.vue'
import SearchBar from '@/components/SearchBar.vue'
import { linkAPI } from '@/api'
import * as XLSX from 'xlsx'

const userStore = useUserStore()

// 当前分类
const currentCategory = ref('all')

// 在组件挂载时加载数据
import { onMounted } from 'vue'

onMounted(async () => {
  await loadLinks()
})

// 加载网址数据
const loadLinks = async () => {
  try {
    const res = await linkAPI.getList()
    if (res.code === 200 && res.data) {
      links.value = res.data
      updateCategoryCounts()
    }
  } catch (error) {
    console.error('加载网址失败:', error)
    // 如果加载失败，保留mock数据
  }
}

// 分类列表
const categories = ref([
  { id: 'all', name: '全部', icon: 'Grid', count: 0 },
  { id: 'office', name: '办公系统', icon: 'OfficeBuilding', count: 0 },
  { id: 'business', name: '业务系统', icon: 'Monitor', count: 0 },
  { id: 'learning', name: '学习培训', icon: 'Reading', count: 0 },
  { id: 'tool', name: '工具网站', icon: 'ShoppingCart', count: 0 },
  { id: 'other', name: '其他', icon: 'Link', count: 0 }
])

// 网址数据
const links = ref([
  {
    id: 1,
    name: 'OA办公系统',
    url: 'http://oa.example.com',
    category: 'office',
    description: '企业内部办公系统',
    icon: 'OfficeBuilding',
    color: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)'
  },
  {
    id: 2,
    name: 'ERP管理系统',
    url: 'http://erp.example.com',
    category: 'business',
    description: '企业资源管理系统',
    icon: 'Monitor',
    color: 'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)'
  },
  {
    id: 3,
    name: '在线培训平台',
    url: 'http://training.example.com',
    category: 'learning',
    description: '员工技能培训平台',
    icon: 'Reading',
    color: 'linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)'
  },
  {
    id: 4,
    name: '考勤管理系统',
    url: 'http://attendance.example.com',
    category: 'office',
    description: '员工考勤打卡系统',
    icon: 'Clock',
    color: 'linear-gradient(135deg, #43e97b 0%, #38f9d7 100%)'
  },
  {
    id: 5,
    name: '项目管理系统',
    url: 'http://project.example.com',
    category: 'business',
    description: '项目进度跟踪管理',
    icon: 'Files',
    color: 'linear-gradient(135deg, #fa709a 0%, #fee140 100%)'
  },
  {
    id: 6,
    name: '财务报表系统',
    url: 'http://finance.example.com',
    category: 'business',
    description: '财务数据统计分析',
    icon: 'Coin',
    color: 'linear-gradient(135deg, #30cfd0 0%, #330867 100%)'
  },
  {
    id: 7,
    name: '企业邮箱',
    url: 'http://mail.example.com',
    category: 'office',
    description: '内部邮件系统',
    icon: 'Message',
    color: 'linear-gradient(135deg, #a8edea 0%, #fed6e3 100%)'
  },
  {
    id: 8,
    name: '技术文档中心',
    url: 'http://docs.example.com',
    category: 'learning',
    description: '技术资料和文档',
    icon: 'Document',
    color: 'linear-gradient(135deg, #ffecd2 0%, #fcb69f 100%)'
  }
])

// 更新分类计数
const updateCategoryCounts = () => {
  categories.value.forEach(cat => {
    if (cat.id === 'all') {
      cat.count = links.value.length
    } else {
      cat.count = links.value.filter(link => link.category === cat.id).length
    }
  })
}

updateCategoryCounts()

// 过滤后的网址列表
const filteredLinks = computed(() => {
  if (currentCategory.value === 'all') {
    return links.value
  }
  return links.value.filter(link => link.category === currentCategory.value)
})

// 切换分类
const switchCategory = (categoryId) => {
  currentCategory.value = categoryId
}

// 打开链接
const openLink = (link) => {
  window.open(link.url, '_blank')
  ElMessage.success(`正在打开: ${link.name}`)
}

// 复制链接
const copyLink = async (link) => {
  try {
    await navigator.clipboard.writeText(link.url)
    ElMessage.success('链接已复制到剪贴板')
  } catch (error) {
    console.error('复制失败:', error)
    ElMessage.error('复制失败，请手动复制')
  }
}

// 删除链接
const deleteLink = async (link) => {
  try {
    await ElMessageBox.confirm(`确定要删除 "${link.name}" 吗？`, '提示', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning'
    })
    
    // 调用API删除
    await linkAPI.delete({ id: link.id })
    
    const index = links.value.findIndex(l => l.id === link.id)
    if (index > -1) {
      links.value.splice(index, 1)
      updateCategoryCounts()
      ElMessage.success('删除成功')
    }
  } catch (error) {
    if (error !== 'cancel') {
      console.error('删除链接失败:', error)
    }
  }
}

// 导入对话框
const importDialogVisible = ref(false)
const uploadRef = ref(null)
const uploading = ref(false)
const importFile = ref(null)

// 导入网址
const importLinks = () => {
  importDialogVisible.value = true
}

// 文件选择
const handleFileChange = (file) => {
  importFile.value = file.raw
}

// 提交导入
const submitImport = async () => {
  if (!importFile.value) {
    ElMessage.warning('请选择要导入的文件')
    return
  }
  
  try {
    uploading.value = true
    
    // 调用后端API导入
    const res = await linkAPI.importExcel(importFile.value)
    
    if (res.code === 200) {
      ElMessage.success(res.message || '导入成功')
      
      // 重新加载网址列表
      await loadLinks()
      
      importDialogVisible.value = false
      uploadRef.value?.clearFiles()
      importFile.value = null
    }
  } catch (error) {
    console.error('导入失败:', error)
    ElMessage.error('导入失败')
  } finally {
    uploading.value = false
  }
}

// 获取分类ID
const getCategoryId = (categoryName) => {
  const map = {
    '办公': 'office',
    '办公系统': 'office',
    '业务': 'business',
    '业务系统': 'business',
    '学习': 'learning',
    '学习培训': 'learning',
    '工具': 'tool',
    '工具网站': 'tool'
  }
  return map[categoryName]
}
</script>

<style lang="scss" scoped>
.transpath-page {
  min-height: 100vh;
  background: var(--ios-bg);
  
  .transpath-container {
    max-width: 1400px;
    margin: 0 auto;
    padding: 24px;
    
    .search-section {
      margin-bottom: 24px;
    }
    
    .page-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 24px;
      
      .header-left {
        .page-title {
          font-size: 28px;
          font-weight: 600;
          margin: 0 0 8px 0;
          color: var(--ios-text-primary);
        }
        
        .page-desc {
          font-size: 14px;
          color: var(--ios-text-tertiary);
          margin: 0;
        }
      }
    }
    
    .category-tabs {
      display: flex;
      gap: 12px;
      margin-bottom: 24px;
      overflow-x: auto;
      padding-bottom: 8px;
      
      &::-webkit-scrollbar {
        height: 4px;
      }
      
      .category-tab {
        flex-shrink: 0;
        display: flex;
        align-items: center;
        gap: 8px;
        padding: 12px 20px;
        background: var(--ios-card-bg);
        border-radius: var(--border-radius-lg);
        box-shadow: var(--ios-shadow);
        cursor: pointer;
        transition: all 0.3s ease;
        
        .el-icon {
          font-size: 18px;
          color: var(--ios-text-tertiary);
          transition: color 0.3s ease;
        }
        
        span {
          font-size: 14px;
          font-weight: 500;
          color: var(--ios-text-secondary);
          transition: color 0.3s ease;
        }
        
        &:hover {
          transform: translateY(-2px);
          box-shadow: var(--ios-shadow-hover);
        }
        
        &.active {
          background: var(--ios-primary);
          color: white;
          
          .el-icon,
          span {
            color: white;
          }
          
          :deep(.el-badge__content) {
            background: white;
            color: var(--ios-primary);
          }
        }
      }
    }
    
    .links-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
      gap: 20px;
      
      .link-card {
        display: flex;
        align-items: center;
        gap: 16px;
        background: var(--ios-card-bg);
        border-radius: var(--border-radius-xl);
        padding: 20px;
        box-shadow: var(--ios-shadow);
        cursor: pointer;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        
        &:hover {
          transform: translateY(-4px);
          box-shadow: var(--ios-shadow-hover);
          
          .link-actions {
            opacity: 1;
          }
        }
        
        .link-icon {
          flex-shrink: 0;
          width: 60px;
          height: 60px;
          display: flex;
          align-items: center;
          justify-content: center;
          border-radius: var(--border-radius-lg);
          box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
          
          .el-icon {
            font-size: 28px;
            color: white;
          }
          
          .icon-text {
            font-size: 24px;
            font-weight: 600;
            color: white;
          }
        }
        
        .link-content {
          flex: 1;
          min-width: 0;
          
          .link-name {
            font-size: 16px;
            font-weight: 600;
            color: var(--ios-text-primary);
            margin: 0 0 4px 0;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
          }
          
          .link-url {
            font-size: 12px;
            color: var(--ios-text-tertiary);
            margin: 0 0 4px 0;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
          }
          
          .link-desc {
            font-size: 13px;
            color: var(--ios-text-secondary);
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
          }
        }
        
        .link-actions {
          display: flex;
          gap: 4px;
          opacity: 0;
          transition: opacity 0.3s ease;
        }
      }
      
      .empty-state {
        grid-column: 1 / -1;
        padding: 60px 0;
      }
    }
  }
}

.import-dialog {
  :deep(.el-alert) {
    ul {
      margin: 8px 0 0 20px;
      
      li {
        margin: 4px 0;
      }
    }
  }
}

@media (max-width: 768px) {
  .transpath-page {
    .transpath-container {
      padding: 16px;
      
      .page-header {
        flex-direction: column;
        align-items: flex-start;
        gap: 16px;
      }
      
      .links-grid {
        grid-template-columns: 1fr;
      }
    }
  }
}
</style>

