import request from './request'
import { API_ENDPOINTS } from './config'

// 认证API
export const authAPI = {
  // 登录
  login(username, password, role = 'user') {
    return request({
      url: API_ENDPOINTS.LOGIN,
      method: 'post',
      data: { username, password, role }
    })
  },
  
  // 登出
  logout() {
    return request({
      url: API_ENDPOINTS.LOGOUT,
      method: 'post'
    })
  },
  
  // 检查认证状态
  checkAuth() {
    return request({
      url: API_ENDPOINTS.CHECK_AUTH,
      method: 'get'
    })
  }
}

// 用户API
export const userAPI = {
  // 获取用户信息
  getUserInfo(userId) {
    return request({
      url: API_ENDPOINTS.GET_USER_INFO,
      method: 'get',
      params: { userId }
    })
  },
  
  // 更新用户信息
  updateUserInfo(data) {
    return request({
      url: API_ENDPOINTS.UPDATE_USER_INFO,
      method: 'post',
      data
    })
  },
  
  // 上传头像
  uploadAvatar(file) {
    const formData = new FormData()
    formData.append('avatar', file)
    return request({
      url: API_ENDPOINTS.UPLOAD_AVATAR,
      method: 'post',
      data: formData,
      headers: { 'Content-Type': 'multipart/form-data' }
    })
  },
  
  // 获取用户待办事项
  getUserTodos() {
    return request({
      url: API_ENDPOINTS.GET_USER_TODOS,
      method: 'get'
    })
  }
}

// 公告API
export const announcementAPI = {
  // 获取公告列表
  getList(params) {
    return request({
      url: API_ENDPOINTS.GET_ANNOUNCEMENTS,
      method: 'get',
      params
    })
  },
  
  // 获取公告详情
  getDetail(id) {
    return request({
      url: API_ENDPOINTS.GET_ANNOUNCEMENT_DETAIL,
      method: 'get',
      params: { id }
    })
  },
  
  // 创建公告
  create(data) {
    return request({
      url: API_ENDPOINTS.CREATE_ANNOUNCEMENT,
      method: 'post',
      data
    })
  },
  
  // 更新公告
  update(id, data) {
    return request({
      url: API_ENDPOINTS.UPDATE_ANNOUNCEMENT,
      method: 'post',
      data: { id, ...data }
    })
  },
  
  // 删除公告
  delete(id) {
    return request({
      url: API_ENDPOINTS.DELETE_ANNOUNCEMENT,
      method: 'post',
      data: { id }
    })
  }
}

// 轮播图API
export const carouselAPI = {
  // 获取轮播图列表
  getList() {
    return request({
      url: API_ENDPOINTS.GET_CAROUSEL,
      method: 'get'
    })
  },
  
  // 创建轮播图
  create(data) {
    return request({
      url: API_ENDPOINTS.CREATE_CAROUSEL,
      method: 'post',
      data
    })
  },
  
  // 更新轮播图
  update(id, data) {
    return request({
      url: API_ENDPOINTS.UPDATE_CAROUSEL,
      method: 'post',
      data: { id, ...data }
    })
  },
  
  // 删除轮播图
  delete(id) {
    return request({
      url: API_ENDPOINTS.DELETE_CAROUSEL,
      method: 'post',
      data: { id }
    })
  }
}

// 人员架构API
export const employeeAPI = {
  // 获取员工列表
  getList(params) {
    return request({
      url: API_ENDPOINTS.GET_EMPLOYEES,
      method: 'get',
      params
    })
  },
  
  // 获取员工详情
  getDetail(id) {
    return request({
      url: API_ENDPOINTS.GET_EMPLOYEE_DETAIL,
      method: 'get',
      params: { id }
    })
  },
  
  // 创建员工
  create(data) {
    return request({
      url: API_ENDPOINTS.CREATE_EMPLOYEE,
      method: 'post',
      data
    })
  },
  
  // 更新员工
  update(id, data) {
    return request({
      url: API_ENDPOINTS.UPDATE_EMPLOYEE,
      method: 'post',
      data: { id, ...data }
    })
  },
  
  // 删除员工
  delete(id) {
    return request({
      url: API_ENDPOINTS.DELETE_EMPLOYEE,
      method: 'post',
      data: { id }
    })
  },
  
  // 导入员工（Excel）
  importExcel(file) {
    const formData = new FormData()
    formData.append('file', file)
    return request({
      url: API_ENDPOINTS.IMPORT_EMPLOYEES,
      method: 'post',
      data: formData,
      headers: { 'Content-Type': 'multipart/form-data' }
    })
  },
  
  // 导出员工（Excel）
  exportExcel() {
    return request({
      url: API_ENDPOINTS.EXPORT_EMPLOYEES,
      method: 'get',
      responseType: 'blob'
    }).then(response => {
      // 直接返回blob数据，不经过响应拦截器处理
      return response
    })
  }
}

// 常用网址API
export const linkAPI = {
  // 获取网址列表
  getList(params) {
    return request({
      url: API_ENDPOINTS.GET_LINKS,
      method: 'get',
      params
    })
  },
  
  // 创建网址
  create(data) {
    return request({
      url: API_ENDPOINTS.CREATE_LINK,
      method: 'post',
      data
    })
  },
  
  // 更新网址
  update(id, data) {
    return request({
      url: API_ENDPOINTS.UPDATE_LINK,
      method: 'post',
      data: { id, ...data }
    })
  },
  
  // 删除网址
  delete(id) {
    return request({
      url: API_ENDPOINTS.DELETE_LINK,
      method: 'post',
      data: { id }
    })
  },
  
  // 导入网址（Excel）
  importExcel(file) {
    const formData = new FormData()
    formData.append('file', file)
    return request({
      url: API_ENDPOINTS.IMPORT_LINKS,
      method: 'post',
      data: formData,
      headers: { 'Content-Type': 'multipart/form-data' }
    })
  }
}

// 待办事项API
export const todoAPI = {
  // 获取待办列表
  getList(params) {
    return request({
      url: API_ENDPOINTS.GET_TODOS,
      method: 'get',
      params
    })
  },
  
  // 创建待办
  create(data) {
    return request({
      url: API_ENDPOINTS.CREATE_TODO,
      method: 'post',
      data
    })
  },
  
  // 更新待办
  update(id, data) {
    return request({
      url: API_ENDPOINTS.UPDATE_TODO,
      method: 'post',
      data: { id, ...data }
    })
  },
  
  // 删除待办
  delete(id) {
    return request({
      url: API_ENDPOINTS.DELETE_TODO,
      method: 'post',
      data: { id }
    })
  },
  
  // 完成待办
  complete(id) {
    return request({
      url: API_ENDPOINTS.COMPLETE_TODO,
      method: 'post',
      data: { id }
    })
  }
}

// 搜索API
export const searchAPI = {
  // 全局搜索
  searchAll(keyword) {
    return request({
      url: API_ENDPOINTS.SEARCH_ALL,
      method: 'get',
      params: { keyword }
    })
  },
  
  // 搜索员工
  searchEmployees(keyword) {
    return request({
      url: API_ENDPOINTS.SEARCH_EMPLOYEES,
      method: 'get',
      params: { keyword }
    })
  },
  
  // 搜索公告
  searchAnnouncements(keyword) {
    return request({
      url: API_ENDPOINTS.SEARCH_ANNOUNCEMENTS,
      method: 'get',
      params: { keyword }
    })
  },
  
  // 搜索网址
  searchLinks(keyword) {
    return request({
      url: API_ENDPOINTS.SEARCH_LINKS,
      method: 'get',
      params: { keyword }
    })
  }
}

// 管理员API
export const adminAPI = {
  // 获取统计数据
  getDashboardStats() {
    return request({
      url: API_ENDPOINTS.GET_DASHBOARD_STATS,
      method: 'get'
    })
  },
  
  // 获取系统信息
  getSystemInfo() {
    return request({
      url: API_ENDPOINTS.GET_SYSTEM_INFO,
      method: 'get'
    })
  }
}

export default {
  auth: authAPI,
  user: userAPI,
  announcement: announcementAPI,
  carousel: carouselAPI,
  employee: employeeAPI,
  link: linkAPI,
  todo: todoAPI,
  search: searchAPI,
  admin: adminAPI
}

