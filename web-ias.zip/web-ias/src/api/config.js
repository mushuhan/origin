// API配置
// 直接连接后端，不通过代理
export const API_BASE_URL = 'http://localhost:8080'

// API端点
export const API_ENDPOINTS = {
  // 认证相关
  LOGIN: '/auth/login',
  LOGOUT: '/auth/logout',
  REGISTER: '/auth/register',
  CHECK_AUTH: '/auth/check',
  
  // 用户相关
  GET_USER_INFO: '/user/info',
  UPDATE_USER_INFO: '/user/update',
  UPLOAD_AVATAR: '/user/avatar',
  GET_USER_TODOS: '/user/todos',
  
  // 公告相关
  GET_ANNOUNCEMENTS: '/announcement/list',
  GET_ANNOUNCEMENT_DETAIL: '/announcement/detail',
  CREATE_ANNOUNCEMENT: '/announcement/create',
  UPDATE_ANNOUNCEMENT: '/announcement/update',
  DELETE_ANNOUNCEMENT: '/announcement/delete',
  
  // 轮播图相关
  GET_CAROUSEL: '/carousel/list',
  CREATE_CAROUSEL: '/carousel/create',
  UPDATE_CAROUSEL: '/carousel/update',
  DELETE_CAROUSEL: '/carousel/delete',
  
  // 人员架构相关
  GET_EMPLOYEES: '/employee/list',
  GET_EMPLOYEE_DETAIL: '/employee/detail',
  CREATE_EMPLOYEE: '/employee/create',
  UPDATE_EMPLOYEE: '/employee/update',
  DELETE_EMPLOYEE: '/employee/delete',
  IMPORT_EMPLOYEES: '/employee/import',
  EXPORT_EMPLOYEES: '/employee/export',
  
  // 常用网址相关
  GET_LINKS: '/link/list',
  CREATE_LINK: '/link/create',
  UPDATE_LINK: '/link/update',
  DELETE_LINK: '/link/delete',
  IMPORT_LINKS: '/link/import',
  
  // 待办事项相关
  GET_TODOS: '/todo/list',
  CREATE_TODO: '/todo/create',
  UPDATE_TODO: '/todo/update',
  DELETE_TODO: '/todo/delete',
  COMPLETE_TODO: '/todo/complete',
  
  // 搜索相关
  SEARCH_ALL: '/search/all',
  SEARCH_EMPLOYEES: '/search/employees',
  SEARCH_ANNOUNCEMENTS: '/search/announcements',
  SEARCH_LINKS: '/search/links',
  
  // 统计相关（管理员后台）
  GET_DASHBOARD_STATS: '/admin/stats',
  GET_SYSTEM_INFO: '/admin/system',
}

