import { defineStore } from 'pinia'
import { authAPI } from '@/api'

export const useUserStore = defineStore('user', {
  state: () => ({
    token: '',
    userInfo: null,
    isAdmin: false,
    isAuthenticated: false
  }),
  
  getters: {
    userId: (state) => state.userInfo?.id || null,
    username: (state) => state.userInfo?.username || '',
    avatar: (state) => state.userInfo?.avatar || '',
    email: (state) => state.userInfo?.email || '',
    role: (state) => state.userInfo?.role || 'user'
  },
  
  actions: {
    // 登录
    async login(username, password, role = 'user') {
      try {
        // 调用后端API
        const response = await authAPI.login(username, password, role)
        if (response.code === 200) {
          this.token = response.data.token
          this.userInfo = response.data.userInfo
          this.isAdmin = response.data.userInfo.role === 'admin'
          this.isAuthenticated = true
          
          // 保存到localStorage
          this.saveToStorage()
        }
        
        return response
      } catch (error) {
        console.error('登录失败:', error)
        throw error
      }
    },
    
    // 登出
    async logout() {
      try {
        if (this.token) {
          await authAPI.logout()
        }
      } catch (error) {
        console.error('登出失败:', error)
      } finally {
        this.token = ''
        this.userInfo = null
        this.isAdmin = false
        this.isAuthenticated = false
        this.clearStorage()
      }
    },
    
    // 更新用户信息
    updateUserInfo(data) {
      if (this.userInfo) {
        this.userInfo = { ...this.userInfo, ...data }
        this.saveToStorage()
      }
    },
    
    // 保存到localStorage
    saveToStorage() {
      localStorage.setItem('token', this.token)
      localStorage.setItem('userInfo', JSON.stringify(this.userInfo))
      localStorage.setItem('isAdmin', String(this.isAdmin))
    },
    
    // 从localStorage加载
    loadUserFromStorage() {
      const token = localStorage.getItem('token')
      const userInfo = localStorage.getItem('userInfo')
      const isAdmin = localStorage.getItem('isAdmin')
      
      if (token && userInfo) {
        this.token = token
        this.userInfo = JSON.parse(userInfo)
        this.isAdmin = isAdmin === 'true'
        this.isAuthenticated = true
      }
    },
    
    // 清除localStorage
    clearStorage() {
      localStorage.removeItem('token')
      localStorage.removeItem('userInfo')
      localStorage.removeItem('isAdmin')
    }
  }
})

