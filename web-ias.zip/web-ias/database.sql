-- ========================================
-- 部门信息管理系统数据库
-- Database: web_ias
-- ========================================

-- 创建数据库
CREATE DATABASE IF NOT EXISTS web_ias DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE web_ias;

-- ========================================
-- 1. 用户表
-- ========================================
CREATE TABLE IF NOT EXISTS `users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY COMMENT '用户ID',
  `username` VARCHAR(50) NOT NULL UNIQUE COMMENT '用户名',
  `password` VARCHAR(255) NOT NULL COMMENT '密码（加密）',
  `email` VARCHAR(100) COMMENT '邮箱',
  `phone` VARCHAR(20) COMMENT '手机号',
  `avatar` VARCHAR(255) COMMENT '头像URL',
  `role` ENUM('admin', 'user') DEFAULT 'user' COMMENT '角色：admin-管理员, user-普通用户',
  `department` VARCHAR(50) COMMENT '部门',
  `position` VARCHAR(50) COMMENT '职位',
  `status` ENUM('active', 'inactive') DEFAULT 'active' COMMENT '状态',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  INDEX idx_username (`username`),
  INDEX idx_role (`role`),
  INDEX idx_status (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户表';

-- ========================================
-- 2. 公告表
-- ========================================
CREATE TABLE IF NOT EXISTS `announcements` (
  `id` INT AUTO_INCREMENT PRIMARY KEY COMMENT '公告ID',
  `title` VARCHAR(200) NOT NULL COMMENT '标题',
  `content` TEXT NOT NULL COMMENT '内容',
  `priority` ENUM('normal', 'medium', 'high') DEFAULT 'normal' COMMENT '优先级：normal-普通, medium-中等, high-重要',
  `publisher_id` INT NOT NULL COMMENT '发布人ID',
  `publisher_name` VARCHAR(50) NOT NULL COMMENT '发布人姓名',
  `publish_time` TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '发布时间',
  `views` INT DEFAULT 0 COMMENT '查看次数',
  `status` ENUM('draft', 'published', 'archived') DEFAULT 'published' COMMENT '状态',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  FOREIGN KEY (`publisher_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  INDEX idx_priority (`priority`),
  INDEX idx_publish_time (`publish_time`),
  INDEX idx_status (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='公告表';

-- ========================================
-- 3. 员工表
-- ========================================
CREATE TABLE IF NOT EXISTS `employees` (
  `id` INT AUTO_INCREMENT PRIMARY KEY COMMENT '员工ID',
  `employee_id` VARCHAR(50) NOT NULL UNIQUE COMMENT '工号',
  `name` VARCHAR(50) NOT NULL COMMENT '姓名',
  `section` INT NOT NULL COMMENT '工段（1-5）',
  `position` VARCHAR(50) NOT NULL COMMENT '职位',
  `phone` VARCHAR(20) COMMENT '电话',
  `email` VARCHAR(100) COMMENT '邮箱',
  `avatar` VARCHAR(255) COMMENT '头像URL',
  `is_leader` BOOLEAN DEFAULT FALSE COMMENT '是否为工段长',
  `status` ENUM('active', 'inactive') DEFAULT 'active' COMMENT '状态：active-在岗, inactive-离岗',
  `join_date` DATE COMMENT '入职日期',
  `skills` JSON COMMENT '技能标签（JSON数组）',
  `description` TEXT COMMENT '个人描述',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  INDEX idx_employee_id (`employee_id`),
  INDEX idx_section (`section`),
  INDEX idx_is_leader (`is_leader`),
  INDEX idx_status (`status`),
  CONSTRAINT chk_section CHECK (`section` BETWEEN 1 AND 5)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='员工表';

-- ========================================
-- 4. 轮播图表
-- ========================================
CREATE TABLE IF NOT EXISTS `carousels` (
  `id` INT AUTO_INCREMENT PRIMARY KEY COMMENT '轮播图ID',
  `title` VARCHAR(100) NOT NULL COMMENT '标题',
  `description` VARCHAR(255) COMMENT '描述',
  `image` VARCHAR(255) NOT NULL COMMENT '图片URL',
  `link` VARCHAR(255) COMMENT '跳转链接',
  `sort_order` INT DEFAULT 0 COMMENT '排序顺序',
  `status` ENUM('active', 'inactive') DEFAULT 'active' COMMENT '状态',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  INDEX idx_sort_order (`sort_order`),
  INDEX idx_status (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='轮播图表';

-- ========================================
-- 5. 常用网址表
-- ========================================
CREATE TABLE IF NOT EXISTS `links` (
  `id` INT AUTO_INCREMENT PRIMARY KEY COMMENT '网址ID',
  `name` VARCHAR(100) NOT NULL COMMENT '名称',
  `url` VARCHAR(500) NOT NULL COMMENT '网址',
  `category` ENUM('office', 'business', 'learning', 'tool', 'other') DEFAULT 'other' COMMENT '分类',
  `description` VARCHAR(255) COMMENT '描述',
  `icon` VARCHAR(50) COMMENT '图标',
  `color` VARCHAR(100) COMMENT '颜色样式',
  `sort_order` INT DEFAULT 0 COMMENT '排序顺序',
  `clicks` INT DEFAULT 0 COMMENT '点击次数',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  INDEX idx_category (`category`),
  INDEX idx_sort_order (`sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='常用网址表';

-- ========================================
-- 6. 待办事项表
-- ========================================
CREATE TABLE IF NOT EXISTS `todos` (
  `id` INT AUTO_INCREMENT PRIMARY KEY COMMENT '待办ID',
  `user_id` INT NOT NULL COMMENT '用户ID',
  `title` VARCHAR(200) NOT NULL COMMENT '标题',
  `description` TEXT COMMENT '描述',
  `deadline` TIMESTAMP NULL COMMENT '截止时间',
  `completed` BOOLEAN DEFAULT FALSE COMMENT '是否完成',
  `completed_at` TIMESTAMP NULL COMMENT '完成时间',
  `priority` ENUM('low', 'medium', 'high') DEFAULT 'medium' COMMENT '优先级',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  INDEX idx_user_id (`user_id`),
  INDEX idx_completed (`completed`),
  INDEX idx_deadline (`deadline`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='待办事项表';

-- ========================================
-- 7. 系统日志表
-- ========================================
CREATE TABLE IF NOT EXISTS `system_logs` (
  `id` INT AUTO_INCREMENT PRIMARY KEY COMMENT '日志ID',
  `user_id` INT COMMENT '用户ID',
  `action` VARCHAR(100) NOT NULL COMMENT '操作动作',
  `module` VARCHAR(50) NOT NULL COMMENT '模块',
  `description` TEXT COMMENT '描述',
  `ip_address` VARCHAR(50) COMMENT 'IP地址',
  `user_agent` VARCHAR(255) COMMENT '用户代理',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE SET NULL,
  INDEX idx_user_id (`user_id`),
  INDEX idx_action (`action`),
  INDEX idx_created_at (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='系统日志表';

-- ========================================
-- 8. 用户登录记录表
-- ========================================
CREATE TABLE IF NOT EXISTS `login_records` (
  `id` INT AUTO_INCREMENT PRIMARY KEY COMMENT '记录ID',
  `user_id` INT NOT NULL COMMENT '用户ID',
  `login_time` TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '登录时间',
  `logout_time` TIMESTAMP NULL COMMENT '登出时间',
  `ip_address` VARCHAR(50) COMMENT 'IP地址',
  `user_agent` VARCHAR(255) COMMENT '用户代理',
  `status` ENUM('success', 'failed') DEFAULT 'success' COMMENT '状态',
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  INDEX idx_user_id (`user_id`),
  INDEX idx_login_time (`login_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='登录记录表';

-- ========================================
-- 插入测试数据
-- ========================================

-- 插入管理员用户（密码：admin123，请在实际使用中修改为加密后的密码）
INSERT INTO `users` (`username`, `password`, `email`, `phone`, `avatar`, `role`, `department`, `position`) VALUES
('admin', '$2a$10$YourHashedPasswordHere', 'admin@example.com', '13800138000', '', 'admin', '管理部', '系统管理员'),
('zhangsan', '$2a$10$YourHashedPasswordHere', 'zhangsan@example.com', '13800138001', '', 'user', '技术部', '技术员');

-- 插入公告数据
INSERT INTO `announcements` (`title`, `content`, `priority`, `publisher_id`, `publisher_name`) VALUES
('关于召开部门例会的通知', '定于本周五下午3点召开部门例会，请各工段长准时参加。会议内容包括本月工作总结和下月工作计划。', 'high', 1, '张经理'),
('系统维护公告', '本周六晚上10点至周日早上6点进行系统维护，期间系统将无法访问，请提前做好工作安排。', 'medium', 1, '技术部'),
('新员工培训通知', '本月新入职员工请于下周一上午9点到会议室参加入职培训。', 'normal', 1, '人事部');

-- 插入员工数据
INSERT INTO `employees` (`employee_id`, `name`, `section`, `position`, `phone`, `email`, `is_leader`, `status`, `join_date`, `skills`) VALUES
('E001', '张三', 1, '工段长', '13800138001', 'zhangsan@company.com', TRUE, 'active', '2020-01-15', '["管理", "技术指导", "质量把控"]'),
('E002', '李四', 1, '技术员', '13800138002', 'lisi@company.com', FALSE, 'active', '2021-03-20', '["焊接", "机械加工"]'),
('E003', '王五', 1, '技术员', '13800138003', 'wangwu@company.com', FALSE, 'active', '2021-06-10', '["电气", "维修"]'),
('E004', '赵六', 1, '操作工', '13800138004', 'zhaoliu@company.com', FALSE, 'active', '2022-01-05', '["设备操作"]'),
('E005', '孙七', 2, '工段长', '13800138005', 'sunqi@company.com', TRUE, 'active', '2019-08-12', '["管理", "生产调度", "安全管理"]'),
('E006', '周八', 2, '技术员', '13800138006', 'zhouba@company.com', FALSE, 'active', '2020-11-20', '["数控", "编程"]'),
('E007', '吴九', 2, '技术员', '13800138007', 'wujiu@company.com', FALSE, 'active', '2021-04-15', '["检测", "质量控制"]'),
('E008', '郑十', 3, '工段长', '13800138008', 'zhengshi@company.com', TRUE, 'active', '2018-05-20', '["管理", "工艺改进", "成本控制"]'),
('E009', '冯十一', 3, '技术员', '13800138009', 'fengshiyi@company.com', FALSE, 'active', '2020-07-08', '["装配", "调试"]'),
('E010', '陈十二', 4, '工段长', '13800138010', 'chenshier@company.com', TRUE, 'active', '2019-02-14', '["管理", "技术创新"]'),
('E011', '褚十三', 5, '工段长', '13800138011', 'chushisan@company.com', TRUE, 'active', '2018-09-25', '["管理", "设备管理"]');

-- 插入轮播图数据
INSERT INTO `carousels` (`title`, `description`, `image`, `sort_order`) VALUES
('欢迎使用部门信息管理系统', '高效管理，智能办公', 'https://images.unsplash.com/photo-1497366216548-37526070297c?w=1200&h=400&fit=crop', 1),
('人员架构一目了然', '清晰展示部门组织结构', 'https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=1200&h=400&fit=crop', 2),
('信息管理更便捷', '让工作更加高效有序', 'https://images.unsplash.com/photo-1542744173-8e7e53415bb0?w=1200&h=400&fit=crop', 3);

-- 插入常用网址数据
INSERT INTO `links` (`name`, `url`, `category`, `description`, `sort_order`) VALUES
('OA办公系统', 'http://oa.example.com', 'office', '企业内部办公系统', 1),
('ERP管理系统', 'http://erp.example.com', 'business', '企业资源管理系统', 2),
('在线培训平台', 'http://training.example.com', 'learning', '员工技能培训平台', 3),
('考勤管理系统', 'http://attendance.example.com', 'office', '员工考勤打卡系统', 4),
('项目管理系统', 'http://project.example.com', 'business', '项目进度跟踪管理', 5),
('财务报表系统', 'http://finance.example.com', 'business', '财务数据统计分析', 6),
('企业邮箱', 'http://mail.example.com', 'office', '内部邮件系统', 7),
('技术文档中心', 'http://docs.example.com', 'learning', '技术资料和文档', 8);

-- 插入待办事项数据
INSERT INTO `todos` (`user_id`, `title`, `deadline`, `priority`) VALUES
(2, '完成本月工作报告', '2024-01-31 18:00:00', 'high'),
(2, '审核员工考勤记录', '2024-01-20 17:00:00', 'medium');

-- ========================================
-- 创建视图
-- ========================================

-- 员工统计视图
CREATE OR REPLACE VIEW `v_employee_stats` AS
SELECT 
  section AS '工段',
  COUNT(*) AS '总人数',
  SUM(CASE WHEN is_leader = TRUE THEN 1 ELSE 0 END) AS '工段长',
  SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) AS '在岗人数',
  SUM(CASE WHEN status = 'inactive' THEN 1 ELSE 0 END) AS '离岗人数'
FROM employees
GROUP BY section
ORDER BY section;

-- 公告统计视图
CREATE OR REPLACE VIEW `v_announcement_stats` AS
SELECT 
  publisher_name AS '发布人',
  COUNT(*) AS '发布数量',
  SUM(views) AS '总查看次数',
  AVG(views) AS '平均查看次数'
FROM announcements
WHERE status = 'published'
GROUP BY publisher_name
ORDER BY COUNT(*) DESC;

-- ========================================
-- 创建存储过程
-- ========================================

-- 获取工段详细信息的存储过程
DELIMITER //
CREATE PROCEDURE `sp_get_section_detail`(IN section_num INT)
BEGIN
  SELECT 
    e.*,
    CASE WHEN e.is_leader THEN '工段长' ELSE '员工' END AS role_name
  FROM employees e
  WHERE e.section = section_num AND e.status = 'active'
  ORDER BY e.is_leader DESC, e.join_date ASC;
END //
DELIMITER ;

-- 统计用户活跃度的存储过程
DELIMITER //
CREATE PROCEDURE `sp_user_activity_stats`(IN user_id_param INT)
BEGIN
  SELECT 
    u.username,
    COUNT(DISTINCT lr.id) AS login_count,
    COUNT(DISTINCT t.id) AS todo_count,
    COUNT(DISTINCT CASE WHEN t.completed THEN t.id END) AS completed_todo_count
  FROM users u
  LEFT JOIN login_records lr ON u.id = lr.user_id
  LEFT JOIN todos t ON u.id = t.user_id
  WHERE u.id = user_id_param
  GROUP BY u.id, u.username;
END //
DELIMITER ;

-- ========================================
-- 创建触发器
-- ========================================

-- 公告查看次数自动增加触发器（示例，实际使用时通过应用层控制更好）
DELIMITER //
CREATE TRIGGER `tr_announcement_view_increment`
AFTER INSERT ON system_logs
FOR EACH ROW
BEGIN
  IF NEW.action = 'view_announcement' THEN
    UPDATE announcements 
    SET views = views + 1 
    WHERE id = CAST(SUBSTRING_INDEX(NEW.description, ':', -1) AS UNSIGNED);
  END IF;
END //
DELIMITER ;

-- ========================================
-- 创建索引优化查询
-- ========================================

-- 组合索引优化常见查询
CREATE INDEX idx_announcements_status_time ON announcements(status, publish_time DESC);
CREATE INDEX idx_employees_section_status ON employees(section, status);
CREATE INDEX idx_todos_user_completed ON todos(user_id, completed);

-- ========================================
-- 授权设置（根据实际需要调整）
-- ========================================

-- 创建应用程序使用的数据库用户
-- CREATE USER 'web_ias_user'@'localhost' IDENTIFIED BY 'your_password_here';
-- GRANT SELECT, INSERT, UPDATE, DELETE ON web_ias.* TO 'web_ias_user'@'localhost';
-- FLUSH PRIVILEGES;

-- ========================================
-- 备份建议
-- ========================================
-- 1. 定期备份数据库：mysqldump -u root -p web_ias > backup.sql
-- 2. 备份重要表数据
-- 3. 定期清理日志表中的旧数据
-- 4. 监控数据库性能

-- ========================================
-- 数据库维护
-- ========================================
-- 1. 定期优化表：OPTIMIZE TABLE table_name;
-- 2. 分析表：ANALYZE TABLE table_name;
-- 3. 检查表：CHECK TABLE table_name;
-- 4. 修复表：REPAIR TABLE table_name;

