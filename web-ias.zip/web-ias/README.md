# 部门信息管理系统

一个采用iOS浅色风格的Vue.js部门主页系统

## 功能特性

- 🔐 登录认证（管理员/普通用户）
- 🏠 首页（轮播图、公告栏、待办事项）
- 👥 人员架构图（可交互式展示）
- 👤 用户中心（个人信息管理）
- 🔗 常用网址导航
- ⚙️ 管理员后台（数据管理、Excel导入）
- 🔍 全局搜索功能

## 技术栈

- Vue 3
- Vue Router
- Pinia
- Element Plus
- Axios
- Vite

## 安装运行

```bash
# 安装依赖
npm install

# 启动开发服务器
npm run dev

# 构建生产版本
npm run build
```

## 项目结构

```
web-ias/
├── src/
│   ├── api/           # API接口
│   ├── assets/        # 静态资源
│   ├── components/    # 公共组件
│   ├── router/        # 路由配置
│   ├── store/         # 状态管理
│   ├── views/         # 页面组件
│   ├── styles/        # 全局样式
│   └── utils/         # 工具函数
├── public/            # 公共资源
└── index.html         # 入口HTML
```

## 后端接口

后端接口地址配置在 `src/api/config.js` 中，默认为 `http://localhost:8080`

## 数据库

数据库SQL文件将在后端开发时生成。
