-- ========================================
-- 初始化测试数据
-- ========================================

USE web_ias;

-- 清空现有数据（可选）
-- TRUNCATE TABLE users;
-- TRUNCATE TABLE announcements;
-- TRUNCATE TABLE employees;
-- TRUNCATE TABLE carousels;
-- TRUNCATE TABLE links;
-- TRUNCATE TABLE todos;

-- 插入管理员用户
-- 密码: admin123 (BCrypt加密后)
INSERT INTO users (username, password, email, phone, role, department, position, status) VALUES
('admin', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lIdtRHxELKToS16Xq', 'admin@webias.com', '13800138000', 'admin', '管理部', '系统管理员', 'active'),
('user', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lIdtRHxELKToS16Xq', 'user@webias.com', '13800138001', 'user', '技术部', '员工', 'active');

-- 插入公告
INSERT INTO announcements (title, content, priority, publisher_id, publisher_name, publish_time, views, status) VALUES
('系统上线通知', '部门信息管理系统正式上线，欢迎大家使用！', 'high', 1, '系统管理员', NOW(), 125, 'published'),
('关于召开部门例会的通知', '定于本周五下午3点召开部门例会，请各工段长准时参加。会议内容包括本月工作总结和下月工作计划。', 'high', 1, '张经理', NOW(), 98, 'published'),
('系统维护公告', '本周六晚上10点至周日早上6点进行系统维护，期间系统将无法访问，请提前做好工作安排。', 'medium', 1, '技术部', NOW(), 67, 'published'),
('新员工培训通知', '本月新入职员工请于下周一上午9点到会议室参加入职培训。', 'normal', 1, '人事部', NOW(), 45, 'published');

-- 插入员工信息
INSERT INTO employees (employee_id, name, section, position, phone, email, is_leader, status, join_date, skills) VALUES
('E001', '张三', 1, '工段长', '13800138001', 'zhangsan@webias.com', TRUE, 'active', '2020-01-15', '["管理", "技术指导", "质量把控"]'),
('E002', '李四', 1, '技术员', '13800138002', 'lisi@webias.com', FALSE, 'active', '2021-03-20', '["焊接", "机械加工"]'),
('E003', '王五', 1, '技术员', '13800138003', 'wangwu@webias.com', FALSE, 'active', '2021-06-10', '["电气", "维修"]'),
('E004', '赵六', 1, '操作工', '13800138004', 'zhaoliu@webias.com', FALSE, 'active', '2022-01-05', '["设备操作"]'),
('E005', '孙七', 2, '工段长', '13800138005', 'sunqi@webias.com', TRUE, 'active', '2019-08-12', '["管理", "生产调度", "安全管理"]'),
('E006', '周八', 2, '技术员', '13800138006', 'zhouba@webias.com', FALSE, 'active', '2020-11-20', '["数控", "编程"]'),
('E007', '吴九', 2, '技术员', '13800138007', 'wujiu@webias.com', FALSE, 'active', '2021-04-15', '["检测", "质量控制"]'),
('E008', '郑十', 3, '工段长', '13800138008', 'zhengshi@webias.com', TRUE, 'active', '2018-05-20', '["管理", "工艺改进", "成本控制"]'),
('E009', '冯十一', 3, '技术员', '13800138009', 'fengshiyi@webias.com', FALSE, 'active', '2020-07-08', '["装配", "调试"]'),
('E010', '陈十二', 4, '工段长', '13800138010', 'chenshier@webias.com', TRUE, 'active', '2019-02-14', '["管理", "技术创新"]'),
('E011', '褚十三', 5, '工段长', '13800138011', 'chushisan@webias.com', TRUE, 'active', '2018-09-25', '["管理", "设备管理"]');

-- 插入轮播图
INSERT INTO carousels (title, description, image, link, sort_order, status) VALUES
('欢迎使用部门信息管理系统', '高效管理，智能办公', 'https://images.unsplash.com/photo-1497366216548-37526070297c?w=1200&h=400&fit=crop', NULL, 1, 'active'),
('人员架构一目了然', '清晰展示部门组织结构', 'https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=1200&h=400&fit=crop', NULL, 2, 'active'),
('信息管理更便捷', '让工作更加高效有序', 'https://images.unsplash.com/photo-1542744173-8e7e53415bb0?w=1200&h=400&fit=crop', NULL, 3, 'active');

-- 插入常用网址
INSERT INTO links (name, url, category, description, icon, color, sort_order, clicks) VALUES
('OA办公系统', 'http://oa.example.com', 'office', '企业内部办公系统', 'OfficeBuilding', 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)', 1, 0),
('ERP管理系统', 'http://erp.example.com', 'business', '企业资源管理系统', 'Monitor', 'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)', 2, 0),
('在线培训平台', 'http://training.example.com', 'learning', '员工技能培训平台', 'Reading', 'linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)', 3, 0),
('考勤管理系统', 'http://attendance.example.com', 'office', '员工考勤打卡系统', 'Clock', 'linear-gradient(135deg, #43e97b 0%, #38f9d7 100%)', 4, 0),
('项目管理系统', 'http://project.example.com', 'business', '项目进度跟踪管理', 'Files', 'linear-gradient(135deg, #fa709a 0%, #fee140 100%)', 5, 0),
('财务报表系统', 'http://finance.example.com', 'business', '财务数据统计分析', 'Coin', 'linear-gradient(135deg, #30cfd0 0%, #330867 100%)', 6, 0),
('企业邮箱', 'http://mail.example.com', 'office', '内部邮件系统', 'Message', 'linear-gradient(135deg, #a8edea 0%, #fed6e3 100%)', 7, 0),
('技术文档中心', 'http://docs.example.com', 'learning', '技术资料和文档', 'Document', 'linear-gradient(135deg, #ffecd2 0%, #fcb69f 100%)', 8, 0);

-- 插入待办事项（测试用）
INSERT INTO todos (user_id, title, description, deadline, completed, priority) VALUES
(2, '完成本月工作报告', '整理本月工作成果，编写工作报告', '2024-01-31 18:00:00', FALSE, 'high'),
(2, '审核员工考勤记录', '审核并汇总员工考勤数据', '2024-01-20 17:00:00', FALSE, 'medium'),
(2, '参加部门例会', '准备会议材料', '2024-01-19 15:00:00', TRUE, 'medium');

-- 查询验证
SELECT '=== 用户数据 ===' AS '';
SELECT id, username, role, department, position, status FROM users;

SELECT '=== 公告数据 ===' AS '';
SELECT id, title, priority, publisher_name, publish_time FROM announcements;

SELECT '=== 员工数据 ===' AS '';
SELECT id, employee_id, name, section, position, is_leader FROM employees;

SELECT '=== 轮播图数据 ===' AS '';
SELECT id, title, description, sort_order FROM carousels;

SELECT '=== 网址数据 ===' AS '';
SELECT id, name, url, category FROM links;

SELECT '=== 待办数据 ===' AS '';
SELECT id, user_id, title, completed FROM todos;

SELECT '数据初始化完成！' AS '提示';

