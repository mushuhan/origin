package com.webias.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.webias.common.Result;
import com.webias.entity.Announcement;
import com.webias.mapper.AnnouncementMapper;
import com.webias.websocket.WebSocketServer;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

/**
 * 公告Controller
 */
@RestController
@RequestMapping("/announcement")
public class AnnouncementController {
    
    private final AnnouncementMapper announcementMapper;
    private final WebSocketServer webSocketServer;
    
    public AnnouncementController(AnnouncementMapper announcementMapper, 
                                 WebSocketServer webSocketServer) {
        this.announcementMapper = announcementMapper;
        this.webSocketServer = webSocketServer;
    }
    
    /**
     * 获取公告列表
     */
    @GetMapping("/list")
    public Result<IPage<Announcement>> getList(
            @RequestParam(defaultValue = "1") Integer page,
            @RequestParam(defaultValue = "10") Integer pageSize,
            @RequestParam(required = false) String priority,
            @RequestParam(required = false) String status) {
        
        Page<Announcement> pageInfo = new Page<>(page, pageSize);
        LambdaQueryWrapper<Announcement> wrapper = new LambdaQueryWrapper<>();
        
        if (priority != null) {
            wrapper.eq(Announcement::getPriority, priority);
        }
        if (status != null) {
            wrapper.eq(Announcement::getStatus, status);
        } else {
            wrapper.eq(Announcement::getStatus, "published");
        }
        
        wrapper.orderByDesc(Announcement::getPublishTime);
        IPage<Announcement> result = announcementMapper.selectPage(pageInfo, wrapper);
        
        return Result.success(result);
    }
    
    /**
     * 获取公告详情
     */
    @GetMapping("/detail")
    public Result<Announcement> getDetail(@RequestParam Integer id) {
        Announcement announcement = announcementMapper.selectById(id);
        if (announcement != null) {
            // 增加浏览次数
            announcement.setViews(announcement.getViews() + 1);
            announcementMapper.updateById(announcement);
        }
        return Result.success(announcement);
    }
    
    /**
     * 创建公告
     */
    @PostMapping("/create")
    @PreAuthorize("hasRole('ADMIN')")
    public Result<Void> create(@RequestBody Announcement announcement) {
        announcement.setPublishTime(LocalDateTime.now());
        announcement.setViews(0);
        if (announcement.getStatus() == null) {
            announcement.setStatus("published");
        }
        announcementMapper.insert(announcement);
        
        // WebSocket通知
        webSocketServer.broadcastMessage("announcement", "新公告发布：" + announcement.getTitle());
        
        return Result.success("创建成功", null);
    }
    
    /**
     * 更新公告
     */
    @PostMapping("/update")
    @PreAuthorize("hasRole('ADMIN')")
    public Result<Void> update(@RequestBody Announcement announcement) {
        announcementMapper.updateById(announcement);
        
        // WebSocket通知
        webSocketServer.broadcastMessage("announcement", "公告已更新");
        
        return Result.success("更新成功", null);
    }
    
    /**
     * 删除公告
     */
    @PostMapping("/delete")
    @PreAuthorize("hasRole('ADMIN')")
    public Result<Void> delete(@RequestBody Announcement announcement) {
        announcementMapper.deleteById(announcement.getId());
        return Result.success("删除成功", null);
    }
}

