package com.webias.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.webias.entity.Todo;
import org.apache.ibatis.annotations.Mapper;

/**
 * 待办事项Mapper
 */
@Mapper
public interface TodoMapper extends BaseMapper<Todo> {
}

