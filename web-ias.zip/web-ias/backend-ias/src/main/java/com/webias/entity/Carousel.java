package com.webias.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.webias.common.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 轮播图实体
 */
@Data
@EqualsAndHashCode(callSuper = true)
@TableName("carousels")
public class Carousel extends BaseEntity {
    
    @TableId(type = IdType.AUTO)
    private Integer id;
    
    private String title;
    
    private String description;
    
    private String image;
    
    private String link;
    
    private Integer sortOrder;
    
    private String status; // active, inactive
}

