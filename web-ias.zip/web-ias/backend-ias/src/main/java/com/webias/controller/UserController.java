package com.webias.controller;

import com.webias.common.Result;
import com.webias.entity.User;
import com.webias.service.UserService;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

/**
 * 用户Controller
 */
@RestController
@RequestMapping("/user")
public class UserController {
    
    private final UserService userService;
    
    public UserController(UserService userService) {
        this.userService = userService;
    }
    
    /**
     * 获取当前用户信息
     */
    @GetMapping("/info")
    public Result<User> getUserInfo() {
        Integer userId = getCurrentUserId();
        User user = userService.getById(userId);
        if (user != null) {
            user.setPassword(null); // 不返回密码
        }
        return Result.success(user);
    }
    
    /**
     * 更新用户信息
     */
    @PostMapping("/update")
    public Result<Void> updateUserInfo(@RequestBody User user) {
        Integer userId = getCurrentUserId();
        user.setId(userId);
        user.setPassword(null); // 防止修改密码
        userService.updateUserInfo(user);
        return Result.success("更新成功", null);
    }
    
    /**
     * 上传头像
     */
    @PostMapping("/avatar")
    public Result<String> uploadAvatar(@RequestParam("avatar") MultipartFile file) {
        // TODO: 实现文件上传逻辑
        String avatarUrl = "/uploads/avatar/default.png";
        return Result.success("上传成功", avatarUrl);
    }
    
    /**
     * 获取当前用户ID
     */
    private Integer getCurrentUserId() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication != null && authentication.getPrincipal() instanceof Integer) {
            return (Integer) authentication.getPrincipal();
        }
        throw new RuntimeException("未找到当前用户");
    }
}

