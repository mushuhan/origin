package com.webias.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.webias.common.Result;
import com.webias.entity.Announcement;
import com.webias.entity.Employee;
import com.webias.entity.Link;
import com.webias.mapper.AnnouncementMapper;
import com.webias.mapper.EmployeeMapper;
import com.webias.mapper.LinkMapper;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 搜索Controller
 */
@RestController
@RequestMapping("/search")
public class SearchController {
    
    private final EmployeeMapper employeeMapper;
    private final AnnouncementMapper announcementMapper;
    private final LinkMapper linkMapper;
    
    public SearchController(EmployeeMapper employeeMapper,
                          AnnouncementMapper announcementMapper,
                          LinkMapper linkMapper) {
        this.employeeMapper = employeeMapper;
        this.announcementMapper = announcementMapper;
        this.linkMapper = linkMapper;
    }
    
    /**
     * 全局搜索
     */
    @GetMapping("/all")
    public Result<List<Map<String, Object>>> searchAll(@RequestParam String keyword) {
        List<Map<String, Object>> results = new ArrayList<>();
        
        // 搜索员工
        LambdaQueryWrapper<Employee> empWrapper = new LambdaQueryWrapper<>();
        empWrapper.like(Employee::getName, keyword)
                  .or()
                  .like(Employee::getEmployeeId, keyword)
                  .or()
                  .like(Employee::getPosition, keyword);
        
        List<Employee> employees = employeeMapper.selectList(empWrapper);
        for (Employee emp : employees) {
            Map<String, Object> map = new HashMap<>();
            map.put("type", "employee");
            map.put("id", emp.getId());
            map.put("name", emp.getName());
            map.put("department", emp.getSection() + "工段");
            results.add(map);
        }
        
        // 搜索公告
        LambdaQueryWrapper<Announcement> annWrapper = new LambdaQueryWrapper<>();
        annWrapper.like(Announcement::getTitle, keyword)
                  .or()
                  .like(Announcement::getContent, keyword);
        annWrapper.eq(Announcement::getStatus, "published");
        
        List<Announcement> announcements = announcementMapper.selectList(annWrapper);
        for (Announcement ann : announcements) {
            Map<String, Object> map = new HashMap<>();
            map.put("type", "announcement");
            map.put("id", ann.getId());
            map.put("title", ann.getTitle());
            results.add(map);
        }
        
        // 搜索网址
        LambdaQueryWrapper<Link> linkWrapper = new LambdaQueryWrapper<>();
        linkWrapper.like(Link::getName, keyword)
                   .or()
                   .like(Link::getUrl, keyword);
        
        List<Link> links = linkMapper.selectList(linkWrapper);
        for (Link link : links) {
            Map<String, Object> map = new HashMap<>();
            map.put("type", "link");
            map.put("id", link.getId());
            map.put("name", link.getName());
            map.put("url", link.getUrl());
            results.add(map);
        }
        
        return Result.success(results);
    }
    
    /**
     * 搜索员工
     */
    @GetMapping("/employees")
    public Result<List<Employee>> searchEmployees(@RequestParam String keyword) {
        LambdaQueryWrapper<Employee> wrapper = new LambdaQueryWrapper<>();
        wrapper.like(Employee::getName, keyword)
               .or()
               .like(Employee::getEmployeeId, keyword)
               .or()
               .like(Employee::getPosition, keyword);
        
        List<Employee> list = employeeMapper.selectList(wrapper);
        return Result.success(list);
    }
    
    /**
     * 搜索公告
     */
    @GetMapping("/announcements")
    public Result<List<Announcement>> searchAnnouncements(@RequestParam String keyword) {
        LambdaQueryWrapper<Announcement> wrapper = new LambdaQueryWrapper<>();
        wrapper.like(Announcement::getTitle, keyword)
               .or()
               .like(Announcement::getContent, keyword);
        wrapper.eq(Announcement::getStatus, "published");
        
        List<Announcement> list = announcementMapper.selectList(wrapper);
        return Result.success(list);
    }
    
    /**
     * 搜索网址
     */
    @GetMapping("/links")
    public Result<List<Link>> searchLinks(@RequestParam String keyword) {
        LambdaQueryWrapper<Link> wrapper = new LambdaQueryWrapper<>();
        wrapper.like(Link::getName, keyword)
               .or()
               .like(Link::getUrl, keyword);
        
        List<Link> list = linkMapper.selectList(wrapper);
        return Result.success(list);
    }
}

