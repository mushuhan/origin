package com.webias.util;

import com.webias.entity.Employee;
import jakarta.servlet.http.HttpServletResponse;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Excel工具类
 */
@Component
public class ExcelUtil {
    
    /**
     * 导入员工Excel
     */
    public List<Employee> importEmployees(MultipartFile file) throws IOException {
        List<Employee> employees = new ArrayList<>();
        
        try (Workbook workbook = WorkbookFactory.create(file.getInputStream())) {
            Sheet sheet = workbook.getSheetAt(0);
            
            // 跳过标题行
            for (int i = 1; i <= sheet.getLastRowNum(); i++) {
                Row row = sheet.getRow(i);
                if (row == null) continue;
                
                Employee employee = new Employee();
                employee.setEmployeeId(getCellValue(row.getCell(0)));
                employee.setName(getCellValue(row.getCell(1)));
                employee.setSection(Integer.parseInt(getCellValue(row.getCell(2))));
                employee.setPosition(getCellValue(row.getCell(3)));
                employee.setPhone(getCellValue(row.getCell(4)));
                employee.setEmail(getCellValue(row.getCell(5)));
                
                String status = getCellValue(row.getCell(6));
                employee.setStatus(status != null && !status.isEmpty() ? status : "active");
                employee.setIsLeader(false);
                
                employees.add(employee);
            }
        }
        
        return employees;
    }
    
    /**
     * 导出员工Excel
     */
    public void exportEmployees(List<Employee> employees, HttpServletResponse response) throws IOException {
        try (Workbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("员工列表");
            
            // 创建标题行
            Row headerRow = sheet.createRow(0);
            String[] headers = {"工号", "姓名", "工段", "职位", "电话", "邮箱", "状态"};
            for (int i = 0; i < headers.length; i++) {
                Cell cell = headerRow.createCell(i);
                cell.setCellValue(headers[i]);
            }
            
            // 填充数据
            for (int i = 0; i < employees.size(); i++) {
                Row row = sheet.createRow(i + 1);
                Employee emp = employees.get(i);
                
                row.createCell(0).setCellValue(emp.getEmployeeId());
                row.createCell(1).setCellValue(emp.getName());
                row.createCell(2).setCellValue(emp.getSection());
                row.createCell(3).setCellValue(emp.getPosition());
                row.createCell(4).setCellValue(emp.getPhone());
                row.createCell(5).setCellValue(emp.getEmail());
                row.createCell(6).setCellValue(emp.getStatus());
            }
            
            // 设置响应头
            String filename = URLEncoder.encode("员工列表.xlsx", StandardCharsets.UTF_8);
            response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
            response.setHeader("Content-Disposition", "attachment; filename=" + filename);
            
            // 写入输出流
            try (OutputStream out = response.getOutputStream()) {
                workbook.write(out);
                out.flush();
            }
        }
    }
    
    /**
     * 获取单元格值
     */
    private String getCellValue(Cell cell) {
        if (cell == null) return "";
        
        switch (cell.getCellType()) {
            case STRING:
                return cell.getStringCellValue();
            case NUMERIC:
                if (DateUtil.isCellDateFormatted(cell)) {
                    return cell.getLocalDateTimeCellValue().toLocalDate().toString();
                }
                return String.valueOf((int) cell.getNumericCellValue());
            case BOOLEAN:
                return String.valueOf(cell.getBooleanCellValue());
            case FORMULA:
                return cell.getCellFormula();
            default:
                return "";
        }
    }
}

