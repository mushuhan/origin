package com.webias.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.extension.handlers.JacksonTypeHandler;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.webias.common.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;
import java.time.LocalDate;
import java.util.List;

/**
 * 员工实体
 */
@Data
@EqualsAndHashCode(callSuper = true)
@TableName(value = "employees", autoResultMap = true)
public class Employee extends BaseEntity {
    
    @TableId(type = IdType.AUTO)
    private Integer id;
    
    private String employeeId;
    
    private String name;
    
    private Integer section;
    
    private String position;
    
    private String phone;
    
    private String email;
    
    private String avatar;
    
    private Boolean isLeader;
    
    private String status; // active, inactive
    
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate joinDate;
    
    @TableField(typeHandler = JacksonTypeHandler.class)
    private List<String> skills;
    
    private String description;
}

