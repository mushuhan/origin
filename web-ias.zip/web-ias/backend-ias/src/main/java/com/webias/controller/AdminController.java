package com.webias.controller;

import com.webias.common.Result;
import com.webias.mapper.*;
import com.webias.websocket.WebSocketServer;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

/**
 * 管理员Controller
 */
@RestController
@RequestMapping("/admin")
@PreAuthorize("hasRole('ADMIN')")
public class AdminController {
    
    private final UserMapper userMapper;
    private final AnnouncementMapper announcementMapper;
    private final EmployeeMapper employeeMapper;
    private final LinkMapper linkMapper;
    private final WebSocketServer webSocketServer;
    
    public AdminController(UserMapper userMapper,
                          AnnouncementMapper announcementMapper,
                          EmployeeMapper employeeMapper,
                          LinkMapper linkMapper,
                          WebSocketServer webSocketServer) {
        this.userMapper = userMapper;
        this.announcementMapper = announcementMapper;
        this.employeeMapper = employeeMapper;
        this.linkMapper = linkMapper;
        this.webSocketServer = webSocketServer;
    }
    
    /**
     * 获取统计数据
     */
    @GetMapping("/stats")
    public Result<Map<String, Object>> getStats() {
        Map<String, Object> stats = new HashMap<>();
        
        stats.put("totalUsers", userMapper.selectCount(null));
        stats.put("totalAnnouncements", announcementMapper.selectCount(null));
        stats.put("totalEmployees", employeeMapper.selectCount(null));
        stats.put("totalLinks", linkMapper.selectCount(null));
        stats.put("onlineUsers", webSocketServer.getOnlineCount());
        
        return Result.success(stats);
    }
    
    /**
     * 获取系统信息
     */
    @GetMapping("/system")
    public Result<Map<String, Object>> getSystemInfo() {
        Map<String, Object> info = new HashMap<>();
        
        info.put("javaVersion", System.getProperty("java.version"));
        info.put("osName", System.getProperty("os.name"));
        info.put("osVersion", System.getProperty("os.version"));
        info.put("osArch", System.getProperty("os.arch"));
        
        Runtime runtime = Runtime.getRuntime();
        info.put("totalMemory", runtime.totalMemory() / 1024 / 1024 + "MB");
        info.put("freeMemory", runtime.freeMemory() / 1024 / 1024 + "MB");
        info.put("maxMemory", runtime.maxMemory() / 1024 / 1024 + "MB");
        
        return Result.success(info);
    }
}

