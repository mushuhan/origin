package com.webias.service;

import com.webias.dto.LoginRequest;
import com.webias.dto.LoginResponse;

/**
 * 认证Service
 */
public interface AuthService {
    
    /**
     * 登录
     */
    LoginResponse login(LoginRequest request);
    
    /**
     * 登出
     */
    void logout(Integer userId);
    
    /**
     * 检查认证状态
     */
    boolean checkAuth(Integer userId);
}

