package com.webias.controller;

import com.webias.common.Result;
import com.webias.dto.LoginRequest;
import com.webias.dto.LoginResponse;
import com.webias.service.AuthService;
import jakarta.validation.Valid;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

/**
 * 认证Controller
 */
@RestController
@RequestMapping("/auth")
public class AuthController {
    
    private final AuthService authService;
    
    public AuthController(AuthService authService) {
        this.authService = authService;
    }
    
    /**
     * 登录
     */
    @PostMapping("/login")
    public Result<LoginResponse> login(@Valid @RequestBody LoginRequest request) {
        LoginResponse response = authService.login(request);
        return Result.success("登录成功", response);
    }
    
    /**
     * 登出
     */
    @PostMapping("/logout")
    public Result<Void> logout() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication != null && authentication.getPrincipal() instanceof Integer) {
            Integer userId = (Integer) authentication.getPrincipal();
            authService.logout(userId);
        }
        return Result.success("登出成功", null);
    }
    
    /**
     * 检查认证状态
     */
    @GetMapping("/check")
    public Result<Boolean> checkAuth() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication != null && authentication.getPrincipal() instanceof Integer) {
            Integer userId = (Integer) authentication.getPrincipal();
            boolean isAuth = authService.checkAuth(userId);
            return Result.success(isAuth);
        }
        return Result.success(false);
    }
}

