package com.webias.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.webias.entity.User;

/**
 * 用户Service
 */
public interface UserService extends IService<User> {
    
    /**
     * 根据用户名查询用户
     */
    User getUserByUsername(String username);
    
    /**
     * 注册用户
     */
    User register(String username, String password, String role);
    
    /**
     * 更新用户信息
     */
    boolean updateUserInfo(User user);
}

