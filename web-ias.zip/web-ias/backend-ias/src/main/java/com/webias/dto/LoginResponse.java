package com.webias.dto;

import com.webias.entity.User;
import lombok.Data;

/**
 * 登录响应DTO
 */
@Data
public class LoginResponse {
    
    private String token;
    
    private User userInfo;
}

