package com.webias.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.webias.common.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 常用网址实体
 */
@Data
@EqualsAndHashCode(callSuper = true)
@TableName("links")
public class Link extends BaseEntity {
    
    @TableId(type = IdType.AUTO)
    private Integer id;
    
    private String name;
    
    private String url;
    
    private String category; // office, business, learning, tool, other
    
    private String description;
    
    private String icon;
    
    private String color;
    
    private Integer sortOrder;
    
    private Integer clicks;
}

