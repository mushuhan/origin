package com.webias.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.webias.entity.Link;
import org.apache.ibatis.annotations.Mapper;

/**
 * 常用网址Mapper
 */
@Mapper
public interface LinkMapper extends BaseMapper<Link> {
}

