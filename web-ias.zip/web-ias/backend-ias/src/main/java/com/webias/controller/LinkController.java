package com.webias.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.webias.common.Result;
import com.webias.entity.Link;
import com.webias.mapper.LinkMapper;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

/**
 * 常用网址Controller
 */
@RestController
@RequestMapping("/link")
public class LinkController {
    
    private final LinkMapper linkMapper;
    
    public LinkController(LinkMapper linkMapper) {
        this.linkMapper = linkMapper;
    }
    
    /**
     * 获取网址列表
     */
    @GetMapping("/list")
    public Result<List<Link>> getList(@RequestParam(required = false) String category) {
        LambdaQueryWrapper<Link> wrapper = new LambdaQueryWrapper<>();
        
        if (category != null && !category.isEmpty()) {
            wrapper.eq(Link::getCategory, category);
        }
        
        wrapper.orderByAsc(Link::getSortOrder);
        
        List<Link> list = linkMapper.selectList(wrapper);
        return Result.success(list);
    }
    
    /**
     * 创建网址
     */
    @PostMapping("/create")
    @PreAuthorize("hasRole('ADMIN')")
    public Result<Void> create(@RequestBody Link link) {
        if (link.getSortOrder() == null) {
            link.setSortOrder(0);
        }
        if (link.getClicks() == null) {
            link.setClicks(0);
        }
        linkMapper.insert(link);
        return Result.success("创建成功", null);
    }
    
    /**
     * 更新网址
     */
    @PostMapping("/update")
    @PreAuthorize("hasRole('ADMIN')")
    public Result<Void> update(@RequestBody Link link) {
        linkMapper.updateById(link);
        return Result.success("更新成功", null);
    }
    
    /**
     * 删除网址
     */
    @PostMapping("/delete")
    @PreAuthorize("hasRole('ADMIN')")
    public Result<Void> delete(@RequestBody Link link) {
        linkMapper.deleteById(link.getId());
        return Result.success("删除成功", null);
    }
    
    /**
     * 导入网址Excel
     */
    @PostMapping("/import")
    @PreAuthorize("hasRole('ADMIN')")
    public Result<String> importExcel(@RequestParam("file") MultipartFile file) {
        try {
            // TODO: 实现Excel导入
            return Result.success("导入成功", null);
        } catch (Exception e) {
            return Result.error("导入失败：" + e.getMessage());
        }
    }
}

