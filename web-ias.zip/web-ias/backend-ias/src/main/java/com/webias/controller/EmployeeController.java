package com.webias.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.webias.common.Result;
import com.webias.entity.Employee;
import com.webias.mapper.EmployeeMapper;
import com.webias.util.ExcelUtil;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import jakarta.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * 员工Controller
 */
@RestController
@RequestMapping("/employee")
public class EmployeeController {
    
    private final EmployeeMapper employeeMapper;
    private final ExcelUtil excelUtil;
    
    public EmployeeController(EmployeeMapper employeeMapper, ExcelUtil excelUtil) {
        this.employeeMapper = employeeMapper;
        this.excelUtil = excelUtil;
    }
    
    /**
     * 获取员工列表
     */
    @GetMapping("/list")
    public Result<List<Employee>> getList(
            @RequestParam(required = false) Integer section,
            @RequestParam(required = false) String status) {
        
        LambdaQueryWrapper<Employee> wrapper = new LambdaQueryWrapper<>();
        
        if (section != null) {
            wrapper.eq(Employee::getSection, section);
        }
        if (status != null) {
            wrapper.eq(Employee::getStatus, status);
        }
        
        wrapper.orderByDesc(Employee::getIsLeader)
               .orderByAsc(Employee::getSection);
        
        List<Employee> list = employeeMapper.selectList(wrapper);
        return Result.success(list);
    }
    
    /**
     * 获取员工详情
     */
    @GetMapping("/detail")
    public Result<Employee> getDetail(@RequestParam Integer id) {
        Employee employee = employeeMapper.selectById(id);
        return Result.success(employee);
    }
    
    /**
     * 创建员工
     */
    @PostMapping("/create")
    @PreAuthorize("hasRole('ADMIN')")
    public Result<Void> create(@RequestBody Employee employee) {
        employeeMapper.insert(employee);
        return Result.success("创建成功", null);
    }
    
    /**
     * 更新员工
     */
    @PostMapping("/update")
    @PreAuthorize("hasRole('ADMIN')")
    public Result<Void> update(@RequestBody Employee employee) {
        employeeMapper.updateById(employee);
        return Result.success("更新成功", null);
    }
    
    /**
     * 删除员工
     */
    @PostMapping("/delete")
    @PreAuthorize("hasRole('ADMIN')")
    public Result<Void> delete(@RequestBody Employee employee) {
        employeeMapper.deleteById(employee.getId());
        return Result.success("删除成功", null);
    }
    
    /**
     * 导入员工Excel
     */
    @PostMapping("/import")
    @PreAuthorize("hasRole('ADMIN')")
    public Result<String> importExcel(@RequestParam("file") MultipartFile file) {
        try {
            List<Employee> employees = excelUtil.importEmployees(file);
            for (Employee employee : employees) {
                employeeMapper.insert(employee);
            }
            return Result.success("导入成功，共 " + employees.size() + " 条", null);
        } catch (Exception e) {
            return Result.error("导入失败：" + e.getMessage());
        }
    }
    
    /**
     * 导出员工Excel
     */
    @GetMapping("/export")
    @PreAuthorize("hasRole('ADMIN')")
    public void exportExcel(HttpServletResponse response) {
        try {
            List<Employee> employees = employeeMapper.selectList(null);
            excelUtil.exportEmployees(employees, response);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

