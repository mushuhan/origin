package com.webias;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * 部门信息管理系统 - 后端应用入口
 * 
 * @author WebIAS Team
 * @version 1.0.0
 */
@SpringBootApplication
@MapperScan("com.webias.mapper")
public class BackendIasApplication {

    public static void main(String[] args) {
        SpringApplication.run(BackendIasApplication.class, args);
        System.out.println("\n========================================");
        System.out.println("部门信息管理系统后端启动成功！");
        System.out.println("访问地址: http://localhost:8080");
        System.out.println("API文档: http://localhost:8080/doc.html");
        System.out.println("========================================\n");
    }
}

