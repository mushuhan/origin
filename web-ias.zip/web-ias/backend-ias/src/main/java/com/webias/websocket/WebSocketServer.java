package com.webias.websocket;

import com.alibaba.fastjson2.JSON;
import jakarta.websocket.*;
import jakarta.websocket.server.PathParam;
import jakarta.websocket.server.ServerEndpoint;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * WebSocket服务器
 */
@Slf4j
@Component
@ServerEndpoint("/ws/{userId}")
public class WebSocketServer {
    
    /**
     * 存储所有连接的Session
     */
    private static final Map<String, Session> sessions = new ConcurrentHashMap<>();
    
    /**
     * 连接建立时调用
     */
    @OnOpen
    public void onOpen(Session session, @PathParam("userId") String userId) {
        sessions.put(userId, session);
        log.info("WebSocket连接建立: userId={}, 当前在线人数: {}", userId, sessions.size());
        
        // 发送欢迎消息
        sendMessage(userId, "连接成功");
    }
    
    /**
     * 连接关闭时调用
     */
    @OnClose
    public void onClose(@PathParam("userId") String userId) {
        sessions.remove(userId);
        log.info("WebSocket连接关闭: userId={}, 当前在线人数: {}", userId, sessions.size());
    }
    
    /**
     * 收到客户端消息时调用
     */
    @OnMessage
    public void onMessage(String message, @PathParam("userId") String userId) {
        log.info("收到WebSocket消息: userId={}, message={}", userId, message);
        
        // 可以处理客户端发送的消息
        // 这里简单回显
        sendMessage(userId, "收到消息: " + message);
    }
    
    /**
     * 发生错误时调用
     */
    @OnError
    public void onError(Session session, Throwable error) {
        log.error("WebSocket发生错误", error);
    }
    
    /**
     * 发送消息给指定用户
     */
    public void sendMessage(String userId, String message) {
        Session session = sessions.get(userId);
        if (session != null && session.isOpen()) {
            try {
                Map<String, Object> data = Map.of(
                    "type", "message",
                    "content", message,
                    "timestamp", System.currentTimeMillis()
                );
                session.getBasicRemote().sendText(JSON.toJSONString(data));
            } catch (IOException e) {
                log.error("发送WebSocket消息失败: userId={}", userId, e);
            }
        }
    }
    
    /**
     * 广播消息给所有用户
     */
    public void broadcastMessage(String type, String message) {
        Map<String, Object> data = Map.of(
            "type", type,
            "content", message,
            "timestamp", System.currentTimeMillis()
        );
        String jsonMessage = JSON.toJSONString(data);
        
        sessions.forEach((userId, session) -> {
            if (session.isOpen()) {
                try {
                    session.getBasicRemote().sendText(jsonMessage);
                } catch (IOException e) {
                    log.error("广播WebSocket消息失败: userId={}", userId, e);
                }
            }
        });
        
        log.info("WebSocket广播消息: type={}, message={}, 接收人数: {}", 
                type, message, sessions.size());
    }
    
    /**
     * 获取在线用户数
     */
    public int getOnlineCount() {
        return sessions.size();
    }
}

