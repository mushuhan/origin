package com.webias.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.webias.common.Result;
import com.webias.entity.Todo;
import com.webias.mapper.TodoMapper;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

/**
 * 待办事项Controller
 */
@RestController
@RequestMapping("/todo")
public class TodoController {
    
    private final TodoMapper todoMapper;
    
    public TodoController(TodoMapper todoMapper) {
        this.todoMapper = todoMapper;
    }
    
    /**
     * 获取待办列表
     */
    @GetMapping("/list")
    public Result<List<Todo>> getList(@RequestParam(required = false) Boolean completed) {
        Integer userId = getCurrentUserId();
        
        LambdaQueryWrapper<Todo> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Todo::getUserId, userId);
        
        if (completed != null) {
            wrapper.eq(Todo::getCompleted, completed);
        }
        
        wrapper.orderByDesc(Todo::getCreatedAt);
        
        List<Todo> list = todoMapper.selectList(wrapper);
        return Result.success(list);
    }
    
    /**
     * 创建待办
     */
    @PostMapping("/create")
    public Result<Void> create(@RequestBody Todo todo) {
        Integer userId = getCurrentUserId();
        todo.setUserId(userId);
        todo.setCompleted(false);
        todoMapper.insert(todo);
        return Result.success("创建成功", null);
    }
    
    /**
     * 更新待办
     */
    @PostMapping("/update")
    public Result<Void> update(@RequestBody Todo todo) {
        todoMapper.updateById(todo);
        return Result.success("更新成功", null);
    }
    
    /**
     * 删除待办
     */
    @PostMapping("/delete")
    public Result<Void> delete(@RequestBody Todo todo) {
        todoMapper.deleteById(todo.getId());
        return Result.success("删除成功", null);
    }
    
    /**
     * 完成待办
     */
    @PostMapping("/complete")
    public Result<Void> complete(@RequestBody Todo todo) {
        Todo existing = todoMapper.selectById(todo.getId());
        if (existing != null) {
            existing.setCompleted(true);
            existing.setCompletedAt(LocalDateTime.now());
            todoMapper.updateById(existing);
        }
        return Result.success("已完成", null);
    }
    
    /**
     * 获取当前用户ID
     */
    private Integer getCurrentUserId() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication != null && authentication.getPrincipal() instanceof Integer) {
            return (Integer) authentication.getPrincipal();
        }
        throw new RuntimeException("未找到当前用户");
    }
}

