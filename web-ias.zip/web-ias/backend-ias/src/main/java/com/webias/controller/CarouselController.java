package com.webias.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.webias.common.Result;
import com.webias.entity.Carousel;
import com.webias.mapper.CarouselMapper;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 轮播图Controller
 */
@RestController
@RequestMapping("/carousel")
public class CarouselController {
    
    private final CarouselMapper carouselMapper;
    
    public CarouselController(CarouselMapper carouselMapper) {
        this.carouselMapper = carouselMapper;
    }
    
    /**
     * 获取轮播图列表
     */
    @GetMapping("/list")
    public Result<List<Carousel>> getList() {
        LambdaQueryWrapper<Carousel> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Carousel::getStatus, "active")
               .orderByAsc(Carousel::getSortOrder);
        
        List<Carousel> list = carouselMapper.selectList(wrapper);
        return Result.success(list);
    }
    
    /**
     * 创建轮播图
     */
    @PostMapping("/create")
    @PreAuthorize("hasRole('ADMIN')")
    public Result<Void> create(@RequestBody Carousel carousel) {
        if (carousel.getSortOrder() == null) {
            carousel.setSortOrder(0);
        }
        if (carousel.getStatus() == null) {
            carousel.setStatus("active");
        }
        carouselMapper.insert(carousel);
        return Result.success("创建成功", null);
    }
    
    /**
     * 更新轮播图
     */
    @PostMapping("/update")
    @PreAuthorize("hasRole('ADMIN')")
    public Result<Void> update(@RequestBody Carousel carousel) {
        carouselMapper.updateById(carousel);
        return Result.success("更新成功", null);
    }
    
    /**
     * 删除轮播图
     */
    @PostMapping("/delete")
    @PreAuthorize("hasRole('ADMIN')")
    public Result<Void> delete(@RequestBody Carousel carousel) {
        carouselMapper.deleteById(carousel.getId());
        return Result.success("删除成功", null);
    }
}

