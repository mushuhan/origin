package com.webias.service.impl;

import com.webias.dto.LoginRequest;
import com.webias.dto.LoginResponse;
import com.webias.entity.User;
import com.webias.exception.BusinessException;
import com.webias.service.AuthService;
import com.webias.service.UserService;
import com.webias.util.JwtUtil;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

/**
 * 认证Service实现
 */
@Service
public class AuthServiceImpl implements AuthService {
    
    private final UserService userService;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtil jwtUtil;
    
    public AuthServiceImpl(UserService userService, 
                          PasswordEncoder passwordEncoder,
                          JwtUtil jwtUtil) {
        this.userService = userService;
        this.passwordEncoder = passwordEncoder;
        this.jwtUtil = jwtUtil;
    }
    
    @Override
    public LoginResponse login(LoginRequest request) {
        // 查询用户
        User user = userService.getUserByUsername(request.getUsername());
        if (user == null) {
            throw new BusinessException(10001, "用户名或密码错误");
        }
        
        // 验证密码
        if (!passwordEncoder.matches(request.getPassword(), user.getPassword())) {
            throw new BusinessException(10001, "用户名或密码错误");
        }
        
        // 检查状态
        if ("inactive".equals(user.getStatus())) {
            throw new BusinessException("账号已被禁用");
        }
        
        // 生成Token
        String token = jwtUtil.generateToken(user.getId(), user.getUsername(), user.getRole());
        
        // 构建响应
        LoginResponse response = new LoginResponse();
        response.setToken(token);
        response.setUserInfo(user);
        // 清除密码
        user.setPassword(null);
        
        return response;
    }
    
    @Override
    public void logout(Integer userId) {
        // 可以在这里清除Redis中的Token等操作
    }
    
    @Override
    public boolean checkAuth(Integer userId) {
        User user = userService.getById(userId);
        return user != null && "active".equals(user.getStatus());
    }
}

