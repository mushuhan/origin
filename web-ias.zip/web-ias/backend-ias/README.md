# 部门信息管理系统 - 后端

基于Spring Boot 3开发的后端服务，提供RESTful API接口和WebSocket实时通信。

## 技术栈

- **Spring Boot 3.1.5** - 核心框架
- **Spring Security** - 安全认证
- **JWT** - Token认证
- **MyBatis Plus 3.5.4** - ORM框架
- **MySQL 8.0+** - 数据库
- **WebSocket** - 实时通信
- **Apache POI** - Excel处理
- **Lombok** - 简化代码
- **Hutool** - 工具类库

## 快速开始

### 1. 环境要求

- JDK 17+
- Maven 3.6+
- MySQL 8.0+

### 2. 数据库配置

1. 创建数据库:
```sql
CREATE DATABASE web_ias CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

2. 导入SQL文件:
```bash
mysql -u root -p web_ias < ../database.sql
```

3. 修改配置文件 `src/main/resources/application.yml`:
```yaml
spring:
  datasource:
    url: jdbc:mysql://localhost:3306/web_ias
    username: root
    password: your_password
```

### 3. 启动项目

```bash
# 编译项目
mvn clean compile

# 启动项目
mvn spring-boot:run
```

或者使用IDE直接运行 `BackendIasApplication.java`

### 4. 访问地址

- **API基础地址**: http://localhost:8080
- **WebSocket地址**: ws://localhost:8080/ws/{userId}

## 项目结构

```
backend-ias/
├── src/main/java/com/webias/
│   ├── common/            # 公共类
│   │   ├── Result.java   # 统一响应格式
│   │   └── BaseEntity.java
│   ├── config/           # 配置类
│   │   ├── SecurityConfig.java    # Security配置
│   │   ├── WebSocketConfig.java   # WebSocket配置
│   │   ├── MyBatisPlusConfig.java # MyBatis Plus配置
│   │   └── JwtProperties.java     # JWT属性配置
│   ├── controller/       # 控制器
│   │   ├── AuthController.java
│   │   ├── UserController.java
│   │   ├── AnnouncementController.java
│   │   ├── EmployeeController.java
│   │   ├── CarouselController.java
│   │   ├── LinkController.java
│   │   ├── TodoController.java
│   │   ├── SearchController.java
│   │   └── AdminController.java
│   ├── entity/           # 实体类
│   │   ├── User.java
│   │   ├── Announcement.java
│   │   ├── Employee.java
│   │   ├── Carousel.java
│   │   ├── Link.java
│   │   └── Todo.java
│   ├── mapper/           # Mapper接口
│   ├── service/          # 服务层
│   │   ├── UserService.java
│   │   ├── AuthService.java
│   │   └── impl/
│   ├── dto/              # 数据传输对象
│   │   ├── LoginRequest.java
│   │   └── LoginResponse.java
│   ├── security/         # 安全相关
│   │   ├── JwtAuthenticationFilter.java
│   │   └── JwtAuthenticationEntryPoint.java
│   ├── websocket/        # WebSocket
│   │   └── WebSocketServer.java
│   ├── exception/        # 异常处理
│   │   ├── BusinessException.java
│   │   └── GlobalExceptionHandler.java
│   └── util/             # 工具类
│       ├── JwtUtil.java
│       └── ExcelUtil.java
└── src/main/resources/
    ├── application.yml   # 配置文件
    └── mapper/          # Mapper XML文件
```

## 核心功能

### 1. JWT认证

- 基于Token的无状态认证
- 自动刷新机制
- 权限控制（用户/管理员）

### 2. 安全配置

- Spring Security集成
- CORS跨域配置
- 密码加密（BCrypt）

### 3. WebSocket实时通信

- 支持多用户连接
- 实时消息推送
- 广播通知功能

### 4. Excel导入导出

- 员工信息批量导入
- 数据导出功能
- 格式验证

## API接口

详见前端项目中的 `API-DOCUMENTATION.md`

### 认证接口

- `POST /auth/login` - 登录
- `POST /auth/logout` - 登出
- `GET /auth/check` - 检查认证状态

### 用户接口

- `GET /user/info` - 获取用户信息
- `POST /user/update` - 更新用户信息
- `POST /user/avatar` - 上传头像

### 公告接口

- `GET /announcement/list` - 获取公告列表
- `GET /announcement/detail` - 获取公告详情
- `POST /announcement/create` - 创建公告（管理员）
- `POST /announcement/update` - 更新公告（管理员）
- `POST /announcement/delete` - 删除公告（管理员）

### 员工接口

- `GET /employee/list` - 获取员工列表
- `GET /employee/detail` - 获取员工详情
- `POST /employee/create` - 创建员工（管理员）
- `POST /employee/update` - 更新员工（管理员）
- `POST /employee/delete` - 删除员工（管理员）
- `POST /employee/import` - 导入Excel（管理员）
- `GET /employee/export` - 导出Excel（管理员）

### 其他接口

参考API文档

## WebSocket使用

### 连接

```javascript
const ws = new WebSocket('ws://localhost:8080/ws/用户ID');

ws.onopen = () => {
  console.log('WebSocket连接成功');
};

ws.onmessage = (event) => {
  const data = JSON.parse(event.data);
  console.log('收到消息:', data);
};

ws.onclose = () => {
  console.log('WebSocket连接关闭');
};
```

### 消息格式

```json
{
  "type": "announcement",
  "content": "新公告发布",
  "timestamp": 1234567890
}
```

## 配置说明

### JWT配置

```yaml
jwt:
  secret: your-secret-key    # 密钥
  expiration: 86400000       # 过期时间（毫秒）
  header: Authorization      # 请求头名称
  prefix: Bearer            # Token前缀
```

### 文件上传配置

```yaml
spring:
  servlet:
    multipart:
      max-file-size: 10MB    # 单个文件大小限制
      max-request-size: 10MB # 请求大小限制

file:
  upload-path: ./uploads/    # 上传路径
```

## 安全说明

### 1. 密码加密

使用BCrypt算法加密存储，不可逆

### 2. Token验证

每个请求都会验证Token有效性

### 3. CORS配置

```java
configuration.setAllowedOrigins(Arrays.asList("http://localhost:3000"));
```

### 4. 权限控制

- `@PreAuthorize("hasRole('USER')")` - 普通用户
- `@PreAuthorize("hasRole('ADMIN')")` - 管理员

## 开发建议

### 1. 添加新接口

1. 在Controller中添加方法
2. 使用`@PreAuthorize`添加权限控制
3. 统一使用`Result`封装响应

### 2. 异常处理

使用`BusinessException`抛出业务异常:
```java
throw new BusinessException("错误信息");
```

### 3. 日志记录

```java
@Slf4j
public class YourClass {
    log.info("信息日志");
    log.error("错误日志", exception);
}
```

## 测试

### 1. 单元测试

```bash
mvn test
```

### 2. 接口测试

使用Postman或其他工具测试接口

测试账号:
- 管理员: admin / admin123
- 普通用户: user / user123

## 部署

### 1. 打包

```bash
mvn clean package -DskipTests
```

生成的jar文件在 `target/backend-ias-1.0.0.jar`

### 2. 运行

```bash
java -jar backend-ias-1.0.0.jar
```

### 3. 配置外部配置文件

```bash
java -jar backend-ias-1.0.0.jar --spring.config.location=application.yml
```

## 常见问题

### Q: 数据库连接失败？
A: 检查MySQL是否启动，用户名密码是否正确

### Q: Token验证失败？
A: 检查Token是否过期，是否正确携带在请求头中

### Q: WebSocket连接失败？
A: 检查防火墙设置，确认端口8080可访问

### Q: 文件上传失败？
A: 检查文件大小是否超限，上传目录是否有写权限

## 更新日志

### v1.0.0 (2024-01-15)
- ✨ 初始版本发布
- 🔐 JWT认证系统
- 📡 WebSocket实时通信
- 📊 完整的CRUD接口
- 📥 Excel导入导出
- 🛡️ Spring Security安全配置

## 许可证

MIT License

## 联系方式

如有问题请联系开发团队

